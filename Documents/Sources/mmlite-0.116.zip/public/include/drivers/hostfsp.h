/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Microsoft MMLITE June 1995 --jvh
 * Protocol specification for remote IFile using sockets.
 */

struct _LINK_ERRORS {
    UINT LongTimeout;
    UINT BeforeSTX;
    UINT Retransmit;
    UINT FirstByteSum;
    UINT SecondByteSum;
    UINT OutOfSequence;
    UINT BadLength;
    UINT Reset;
};

#define MAX_READ_SIZE (512)
#undef MAX_PATH           /* delete NT definition. Must be same on both ends */
#define MAX_PATH 200      /* XXX, down from 1024 to make it fit */

/* Server handles both UNICODE strings and not.
 * Not UNICODE clients should escape their ASCII strings this way
 */
typedef _PACKED struct _STRING_ESCAPE {
    wchar_t  Escape;
#ifndef UNICODE_NOT_A_CHARACTER
#define UNICODE_NOT_A_CHARACTER ((wchar_t)0xFFFF)
#endif
    char     String[1];         /* varsize */
} STRING_ESCAPE, *PSTRING_ESCAPE;

struct open_req {
    UINT32 flags;               /* native flags, server xlates */
    char path[MAX_PATH];        /* translated (to UNICODE) by server if */
};
struct open_rep {
    UINT32 handle;
};

#define close_req open_rep
/* close_rep -- no private data */

#define delete_req open_req
/* delete_rep -- no private data */

struct read_req {
    UINT32 handle;
    UINT32 count;
    UINT64 position;
};
struct read_rep {
    UINT32 nread;
    char data[MAX_READ_SIZE];
};

struct write_req {
    UINT32 handle;
    UINT32 count;
    UINT64 position;
    char data[MAX_READ_SIZE];
};
struct write_rep {
    UINT32 nwritten;
};

#define getsize_req open_rep
struct getsize_rep {
    UINT64 size;
};

struct setsize_req {
    UINT32 handle;
    UINT32 align_pad;
    UINT64 size;
};
/* setsize_rep -- no private data */

struct findnext_req {
    UINT16 offset_of_previous;
    char prefix[MAX_PATH*2];    /* translated (to UNICODE) by server if */
};
struct findnext_rep {
    char name[MAX_PATH];        /* translated by server */
};

typedef UINT8 PACKETTYPE;

struct packet {
    PACKETTYPE packet_type;
#define PACKET_TYPE_RESET               0
/* avoid 1 (clash with STH); all req even, all rep odd */
#define PACKET_TYPE_OPEN_REQ            2
#define PACKET_TYPE_OPEN_REP            3
#define PACKET_TYPE_CLOSE_REQ           4
#define PACKET_TYPE_CLOSE_REP           5
#define PACKET_TYPE_READ_REQ            6
#define PACKET_TYPE_READ_REP            7
#define PACKET_TYPE_WRITE_REQ           8
#define PACKET_TYPE_WRITE_REP           9
#define PACKET_TYPE_GETSIZE_REQ         10
#define PACKET_TYPE_GETSIZE_REP         11
#define PACKET_TYPE_SETSIZE_REQ         12
#define PACKET_TYPE_SETSIZE_REP         13
#define PACKET_TYPE_FINDNEXT_REQ        14
#define PACKET_TYPE_FINDNEXT_REP        15
#define PACKET_TYPE_DELETE_REQ          16
#define PACKET_TYPE_DELETE_REP          17
    UINT8 seqno;
    UINT16 packet_length;               /* all inclusive */
    INT32 sc;   /* sign extended */     /* in every reply basically */
#define SUCCESS 0
    union {
        struct open_req open_req;
        struct open_rep open_rep;
        struct read_req read_req;
        struct read_rep read_rep;
        struct write_req write_req;
        struct write_rep write_rep;
        struct getsize_rep getsize_rep;
        struct setsize_req setsize_req;
        struct findnext_req findnext_req;
        struct findnext_rep findnext_rep;
    } u;
};

/* Just the header... but beware of bad packing ! */
#define MIN_PACKET_SIZE 8
/* When encoding in-place we need 4 overhead plus some (12) escaped chars */
#define MAX_PACKET_SIZE (sizeof(struct packet) + 4 + 12)

/* Initialize a header */
static INLINE void packet_init(struct packet *p, PACKETTYPE type)
{
    p->packet_type = type;
    p->sc = SUCCESS;
    /* header length including alignment */
    p->packet_length = (UINT16) ((char *)&p->u - (char *)p);
}

/* Finalize packet for send */
static INLINE void packet_prepare(struct packet *p, UINT32 sizedelta)
{
    p->packet_length = (UINT16) (p->packet_length + sizedelta);
}

/* Check a received packet */
/* OK to inline as this is used only once in client and once in server */
static INLINE SCODE packet_check(struct packet *p, PACKETTYPE expect_type)
{
    SCODE sc;
#if 0
    printf("packet_check(%x %x) p->l = %x d=%x\n",
           p, expect_type, p->packet_length,
           (char *)&p->u - (char *)p);
#endif

    /* add more sanity checks here */
    if (p->packet_length < (char *)&p->u - (char *)p)
        return E_RESTART;      /* BUGBUG: bogus error */

    if (p->packet_type != expect_type)
        return E_RESTART;      /* BUGBUG: bogus error */

    sc = (SCODE) p->sc;         /* sign extends */
    return sc;
}


/* The client-side library exports/imports the following
 */
/*
 * Constructor implemented&exported by the library
 */
PINAMESPACE InitHostFileSystem(const _TCHAR *LinkName);
UINT HostFile_Server(void *handle, struct packet *p, UINT MaxSize);
UINT ByteswappedHostFile_Server(void *handle, struct packet *p, UINT MaxSize);

#if defined(__HOSTFS_SERVER)

/* Tell simulator we are entering NT system calls */
UINT HostFsd_NTBegin(void);
void HostFsd_NTEnd(UINT);

#if !defined(__HOSTFS_CLIENT)   /* enable defining both */
/* hostfsd internals */
extern UINT hostfsd_debug_level;
extern BOOL hostfsd_may_write;

#define NOISE(x)  {if (hostfsd_debug_level > 2) printf x;}
#define DPRINT(x) {if (hostfsd_debug_level > 1) printf x;}
#define DPRINTT(x) {if (hostfsd_debug_level > 1) _tprintf x;}
#define EPRINT(x) {if (hostfsd_debug_level) printf x;}
#define EPRINTT(x) {if (hostfsd_debug_level) _tprintf x;}

/* NB: Targets send data in their native byteorder.
 * Windows has a well-defined byteorder.
 * Change this definition to get a server that byteswaps
 */
#if !defined(BYTESWAPEM)
#define BYTESWAPEM 0
#endif

#if BYTESWAPEM
UINT16 ByteSwap16(UINT16 Value);
UINT32 ByteSwap32(UINT32 Value);
UINT64 ByteSwap64(UINT64 Value, UINT64 *pRetValue);
#else
#define ByteSwap16(x) x
#define ByteSwap32(x) x
#define ByteSwap64(v,d) *(d) = v
#endif
#endif
#endif
