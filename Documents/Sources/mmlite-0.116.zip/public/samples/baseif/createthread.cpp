/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

/* BEGIN_SAMPLE */
/* Demonstrates 2 Threads and the main program running simultaneously.*/

/* Thread function, SleepTime, definition. */
void THREAD_LINKAGE SleepTime(THREAD_ARGUMENT Parm)
{
    INT i = (INT)Parm;
    TIME t;
 
    /* Convert Parm to time in seconds. */
    Int32ToInt64(t, TIME_RELATIVE(i));
    t = Int64TimesInt32(t, 10000000); /* TIME is in 10 MHz units (100 ns) */

    if(i == 2) {
        /* Allow 2 seconds to pass. */
        SleepUntil(t);
        _tprintf(_TEXT("This is the first thread, slept longer.\n"));
    } else if(i == 1) {
        /* Allow 1 second to pass. */
        SleepUntil(t);
        _tprintf(_TEXT("This is the second thread, waking sooner.\n"));
    }
}

int _tmain()
{
    IProcess *pPrc;         /* Pointer to process object. */
    IThread *pThread[2];    /* Array of pointers to thread objects. */
    UINT i, t;
    SCODE StatusCode;
    TIME FiveSeconds;

    /* Create 2 threads in the current process. */
    pPrc = CurrentProcess();
    for (i = 0, t = 2; i < 2; i++, t--) {
        /* SleepTime is the starting function of each thread.   */
        /* t is the parameter passed to the SleepTime function. */
        StatusCode = pPrc->CreateThread(0, SleepTime, (THREAD_ARGUMENT)t, 
                                        0, NULL, &pThread[i]);
        _tprintf(_TEXT("Created Thread %d (%08x).\n"),
                 i+1, (ADDRESS) pThread[i]);
        if (FAILED(StatusCode)) {
            _tprintf(_TEXT("Could not create more than %d threads\n"), i);
            exit(0);
        }
        pThread[i]->Release();
    }
    /* Wait for 5 seconds to pass in the main program thread. */
    Int32ToInt64(FiveSeconds, TIME_RELATIVE(5));
    FiveSeconds = Int64TimesInt32(FiveSeconds, 10000000); /* 10 MHz units */
    SleepUntil(FiveSeconds);
    return 0;
}
/* END_SAMPLE */
