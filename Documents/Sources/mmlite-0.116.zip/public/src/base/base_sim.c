/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* null file */
int foo;
