/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*=============================================================================

  This file contains NT-specific stuff needed to implement
  the NT simulator.

=============================================================================*/

/*
 * If anything needs to be done to start the system timer(s),
 * do it when this function is called.
 */
typedef BOOL (*TIMERCALLBACK)(UINT *pEip, UINT *pCs, UINT *pEsp, UINT *pEFlags, UINT InterruptId);

extern void NT_EnableTimers(TIMERCALLBACK cb);

/*
 * If anything needs to be done to stop the system timer(s),
 * do it when this function is called.  
 * Called on system (orderly) shutdown. 
 */
extern void NT_DisableTimers(void);

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is machine-specific.
 */
extern _int64 NT_GetKernelTime (void);

 /* Set the hardware programmable interrupt timer (PIT) to
  * give us an interrupt in DELTA time units from now.
  */
extern void NT_SetNextInterrupt( int Delta);

/*
 * Returns the speed of the current processor.
 */
extern UINT64 NT_CurrentProcessorSpeed(void);

 /* Terminate the system.  Whatever that means (=>machdep)
  */
extern void NT_TheEnd(void);

extern void NT_putchar(unsigned char c);

int NT_getchar(void);

extern void NT_Init();

/* Return the last error of a failed NT system call */
extern int NT_GetLastError(void);

/* Idle, do power savings, or in the case of simulation, cycle savings */
void NT_Idle(void);
