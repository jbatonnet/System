/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Concrete type of continuation -jvh */

#ifndef __CONT_H_
#define __CONT_H_ 1

#include <mmlite.h>
#include <web/typeinfo.h>
#include <base/cobdesc.h>       /* for CUnknown */

typedef struct CONTINFO *PCONTINFO;
typedef const struct CONTINFO *CPCONTINFO;

struct CONTINFO {
    struct CUnknown super;

    ListNodeDeclare(CONTINFO, ListNode);
#define contloff offsetof(struct CONTINFO, ListNode)
    UINT Flags;
#ifdef _CLR
    BOOL isCLR;
    _TCHAR *CLRObjectName;
#endif

    /* Messaging delay tracking */
    TIME BeginTime; /* when this cont was created (serv) or called (client) */
    TIME sendTime;  /* when the message to this  continuation was sent */

    INT32 RetVal;
    void *Method;

    PBYTE Frame;             /* Stack frame, in ArgSpace or on client stack */
    UINT FrameSize;          /* Size of Frame. Tracks reuse on server. */
    PIUNKNOWN pThis;         /* The object, to be released afterwards. */
    CONDITION cd;            /* Wait point for future */
    MUTEX mx;                /* To protect wait point for c_Broadcast */
    enum CONT_STATE {CONT_INIT, CONT_RPC, CONT_READY} State;

    /* Temp heap for allocating arguments */
    PIHEAP TmpHeap;
    PBYTE ArgSpace;         /* IHeap impl */
    PBYTE ArgSpaceLast;     /* IHeap impl */
    INT ArgSpaceAvail;      /* IHeap impl */

    /* Current thread info */
    PITHREAD Thread;
    PBYTE StackBase;
    UINT StackSize;
    PBYTE StackCurrent;

    /* Transaction handle if any */
    PICIMTRANSACTION Transaction;

    /* Post-processing */
    _TCHAR *resname;
};

typedef struct SOAPCONT *PSOAPCONT;
//typedef const struct SOAPCONT *CPSOAPCONT;

struct SOAPCONT {
    struct CONTINFO super;

    /* method info */
    _TCHAR *Uri;
    _TCHAR *WsaTo;              /* Uri w/ possible arguments */
    _TCHAR *SoapAction;         /* by default use method ns QName */
    CPXMLNAMESPACE methodNS;
    CPMETHOD_DESCR metd;

    /* Response generation */
    PISOAPSERIALIZER Serializer; /* Where to write result message */
    PIHTTPCONNECTOR Request;    /* For SendReply() */
    BOOL MsgStarted;            /* did we already call ser->StartMessage() */

    /* Deserializer state saved for response processing */
    CPXMLNAMESPACE encodingNS;
    CPXMLNAMESPACE envelopeNS;
    PXMLNAMESPACE namespaces;

    /* Other necessary things */
    PIHTTPCONNECTOR pConnector;
    PWSCONTEXT pContext; /* wsa context made available to services */
    /* WS-Addressing, WS-Routing, WS-Reservation, and related fields */
    BOOL MayOverrideAddr; /* FALSE: Proxy or already got addr */

    const _TCHAR *To;
};

#define iCONT(_p_) ((PICONTINUATION)(_p_))
#define pCONT(_i_) ((PCONTINFO)(_i_))
#define pSOAPCONT(_i_) ((PSOAPCONT)(_i_))


/*** bar flags ***/
/* Refcount */
#define BAR_FLAGS_REFCOUNT_MASK     0x0000ffff
/* User settable */
#define BAR_FLAGS_PRODUCER          0x00010000
#define BAR_FLAGS_CONSUMER          0x00020000
#define BAR_FLAGS_CASCADE_CANCEL    0x00040000
#define BAR_FLAGS_NEEDS_TRIGGER     0x00080000
#define BAR_FLAGS_AND_TRIGGERED     0x00100000 /* else OR */
#define BAR_FLAGS_MASK              0x00ff0000
/* Internal state */
#define BAR_FLAGS_TRIGGERED         0x01000000
#define BAR_FLAGS_RUNNING           0x02000000
#define BAR_FLAGS_COMPLETED         0x04000000
#define BAR_FLAGS_HAS_ALL_MESSAGES  0x10000000
#define BAR_FLAGS_RECURRING         0x20000000
#define BAR_FLAGS_COPY_MASK (BAR_FLAGS_MASK|0xf0000000)

#endif /* __CONT_H_ */
