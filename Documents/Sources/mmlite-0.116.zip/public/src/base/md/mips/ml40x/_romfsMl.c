/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <diagnostics.h>
#include <mips/ml40x.h>

#define TheGpio ((struct _Pio*)GPIO_DEFAULT_ADDRESS)
#define ROMFS_BIT   1 /* starting at 0, that is DIP switch #2 in the "GPIO Switches" */

extern PINAMESPACE RomFsNew( PTR StartAddress, UINT MaxSize);

/* RomFs initialization specific to board */
PINAMESPACE BoardInitRomFs(void)
{
    PINAMESPACE ns = NULL;
    UINT32 x = TheGpio->PinStatus;

    printf("GPIO=%x\n", x);

    /* Check that we are actually supposed to use the builtin FS
     */
    if (TheGpio->PinStatus & (1 << ROMFS_BIT)) {
        ns = RomFsNew( (PTR) 0xF0080000, 0x0F000000 /*240M max*/);
        if (!ns) DBGME(3,printf("BoardInitRomFs failed\n"));
    }
    return ns;
}

