/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Get a pointer to the current process heap. */
IHeap *pHeap = CurrentHeap();
void *ptr = NULL;    /* Pointer to void and initially equal to NULL. */
UINT AllocSize = 50;
UINT RealSize;
BOOL OK;

ptr = pHeap->Alloc(HEAP_ZERO_MEMORY, AllocSize, 0);
if(ptr == NULL)    {
    _tprintf(_TEXT("Memory allocation failed.\n"));
    return 0;
}
/* Free the allocated memory block. */
OK = SUCCEEDED(pHeap->Free(0, ptr));
/* Determine the size of the memory block after the Free method. */
RealSize = pHeap->Size(0, ptr);
if(!OK)
    _tprintf(_T("Memory block not created by either Alloc or Realloc or ")
             _T("it is corrupted.\n"));
/* If the Free method succeeds, the size of the memory block is zero. */
else if(RealSize != 0)
    _tprintf(_TEXT("Memory block not freed.\nHeap size is %d.\n"),
             RealSize);
else
    _tprintf(_TEXT("The memory block freed successfully.\n"));
/* END_SAMPLE */
return 0;
}
