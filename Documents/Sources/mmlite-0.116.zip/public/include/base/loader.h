/* Copyright (c) Microsoft Corporation. All rights reserved. */
#if defined(SIM)
PIMODULE NT_LookupModule(const _TCHAR *pModName, UINT VersionCheck);
#endif

SCODE LdrLoadImage(PINAMESPACE pNameSpace, const _TCHAR * pImage,
                   const _TCHAR * pArgs, UINT Flags,
                   PIMODULE *ppIModule);
PINAMESPACE GetImageNameSpace(void);
void SetImageNameSpace(PINAMESPACE pINS);

/* xxx fixme */
extern PIMODULE LookupModule(const _TCHAR *pModName, UINT VersionCheck);

