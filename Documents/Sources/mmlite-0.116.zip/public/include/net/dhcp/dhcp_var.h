/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _DHCP_VAR_H_
#define _DHCP_VAR_H_

/*
 * DHCP info kept on a per-interface basis.
 * Note: all internet addresses and address masks are in network byte order.
 * BUGBUG: some of this is duplicated elsewhere in the sytem.
 */
struct DhcpInfo {
    UINT8 State;             /* protocol state */
    UINT8 Flags;             /* see below */
    UINT8 HdwrAddrType;      /* interface hardware address type */
    UINT8 HdwrAddrLen;       /* interface hardware address length */
    UINT8 HdwrAddr[16];      /* interface hardware address */
    UINT32 XIdInUse;         /* outstanding transaction id */
    UINT32 RexmitInterval;   /* retransmission backoff amount */
    UINT32 RexmitTimer;      /* seconds remaining until retransmission */
    UINT32 DhcpSrvrIpAddr;   /* IP address of server we picked */
    UINT32 OfferedIpAddr;    /* IP address we've been offered */
    UINT32 LeasedIpAddr;     /* IP address we have a lease for */
    UINT32 RenewalTimer;     /* (aka T1) seconds until we enter RENEWING */
    UINT32 RebindTimer;      /* (aka T2) seconds until we enter REBINDING */
    UINT32 LeaseTimer;       /* seconds until our lease expires */
    UINT32 AutoIPRecheckTimer; /* seconds until auto ip rechecks DHCP */
    UINT32 SubnetMask;       /* INFO: Our subnet mask */
    UINT32 DefaultRouter;    /* INFO: IP address of default IP router */
    UINT32 BootSrvrIpAddr;   /* INFO: IP address of boot (e.g. TFTP) server */
    char *pBootFilename;     /* INFO: filename to pass to TFTP server */

#define MAXNS 3
    UINT nscount;
    struct sockaddr_in nsaddr_list[MAXNS];      /* address of name server */

    UINT32 TimeServer;
    char *DomainName;
    char *HostName;

    TIME TimeStarted;        /* when we started Xaction (leases relative to)*/
    struct inpcb *pInPcb;    /* pointer to our inet protocol control block */

    UINT32 AutoIpCandidate;  /* candidate auto IP address */
    UINT8 AutoIpRetryCount;
};

#define DHCP_F_FORCE_TFTP_INFO 0x1
#define DHCP_F_FORCE_MITV_INFO 0x2

struct DhcpOption {
        UINT8 Option;     /* option tag */
        UINT8 Len;        /* amount of valid data in Data field */
        UINT8 Data[255];  /* option value(s) */
};

void DhcpInit(void);
void DhcpStart(struct ifnet *, UINT8);
INT DhcpWaitTillBound(struct ifnet *);
void DhcpInput(struct mbuf *);
void DhcpOutput(struct ifnet *);
UINT8 DhcpParseOptions(UINT8 *, INT, struct DhcpInfo *);
void DhcpFreeInfoAreas(struct DhcpInfo *);
void DhcpInitStoredInfo(struct ifnet *pNetInterface);
void DhcpRecordLease(struct ifnet *);
INT  DhcpGetInfo(struct ifnet *, struct DhcpInfo *);
INT  DhcpGetOption(struct ifnet *, UINT8, struct DhcpOption *);
INT  DhcpGetFile(struct ifnet *, char *);
void DhcpTimer(void);

#endif /* _DHCP_VAR_H_ */
