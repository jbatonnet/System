/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Implementation of kernel time constraints. */

#include <mmlite.h>
#include <fred.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <base/kconstraint2.h>
#include <base/urgency2.h>
#include <base/thread2.h>

/* Fills a new kernel constraint with default values.
 */
void KConstraint_Init(
     PKCONSTRAINT pkcNew,
     PTIME_CONSTRAINT pcval)
{
    TIME tNow = CurrentTime(), t;
    PURGENCY puLocal;

    assert(pkcNew != NULL);
    assert(!pcval);             /* code missing, see cb_sched.c XXX */
    
    KConstraint_SetSchedObject(pkcNew, NULL);
    KConstraint_SetLastRefresh(pkcNew, tNow);
    puLocal = KConstraint_GetLocalUrgency(pkcNew);

    if (pcval) {
        Urgency_GetCriticality(puLocal) = pcval->Criticality;;
        if (TimeIsRelative(pcval->Deadline)) {
            /* Convert from relative to absolute kernel time. */
            INT64SUB(pcval->Deadline, tNow, pcval->Deadline);
            /* If we have overflowed, use TIME_FOREVER. */
            if (TimeLess(pcval->Deadline, tNow))
                pcval->Deadline = TIME_FOREVER;
        }
        /* Convert deadline into restartby time (deadline - est runtime). */
        INT64SUB(t, pcval->Deadline, pcval->Estimate);
        if (TimeLess(t,TIME_ORIGIN))
            t = TIME_ORIGIN;

        KConstraint_SetInitialRestartBy(pkcNew, t);
    } else {
        KConstraint_SetInitialRestartBy(pkcNew, tNow); /* shouldnt matter */
        Urgency_Init(puLocal);
        Urgency_SetTimeSharing(puLocal);
    }
    Urgency_Copy(KConstraint_GetCurrentUrgency(pkcNew), puLocal);

    KConstraint_SetPending(pkcNew, NULL);
    KConstraint_SetStackNext(pkcNew, NULL);
    
    Node_Init(KConstraint_GetSchedQueueNode(pkcNew), pkcNew);
    Node_Init(KConstraint_GetWaitQueueNode(pkcNew), pkcNew);
}

/* Pushes a new kernel constraint onto the stack rooted as pkcStackHead
 * and returns the new stack head, which is the newly pushed kconstraint.
 * Used in BeginConstraint.
 */
PKCONSTRAINT KConstraint_Push(
     PKCONSTRAINT pkcStackHead,
     PKCONSTRAINT pkcNew
     )
{
    assert(pkcNew != NULL);
    assert(!KConstraint_HasStackNext(pkcNew));

    KConstraint_SetStackNext(pkcNew, pkcStackHead);
    return pkcNew;
}

/* Pops a new kernel constraint off of stack rooted at pkcStackHead
 * and returns the new stack head, which is the popped kconstraint's next.
 * The old stack head is discarded, so save it if you need it in the caller.
 * Used in EndConstraint.
 */
PKCONSTRAINT KConstraint_Pop(
     PKCONSTRAINT pkcStackHead
     )
{
    PKCONSTRAINT pkcNext;

    assert(pkcStackHead != NULL);

    pkcNext = KConstraint_GetStackNext(pkcStackHead);
    KConstraint_SetStackNext(pkcStackHead, NULL);
    return pkcNext;
}

/* Propagates up urgencies that may be more or equally urgent than
 * owners, but not less than.
*/
void KConstraint_StartInheritance(
     PKCONSTRAINT pkcOwner,
     PURGENCY puNew
     )
{
    PURGENCY puCurrent;

    assert(pkcOwner != NULL);

    puCurrent = KConstraint_GetCurrentUrgency(pkcOwner);

    if (Urgency_IsTimeSharing(puCurrent)) {
      return;
    }

    if (Urgency_GT(puNew, puCurrent)) {
      PTHDINFO pThdOwner = (PTHDINFO)KConstraint_GetSchedObject(pkcOwner);

      Urgency_Copy(puCurrent, puNew);

      if (Thread_IsWaitingForMutex(pThdOwner)) {
	PMUTEX pMutex = Thread_GetWaitObject(pThdOwner);
	PITHREAD pThdWaitee = Mutex_GetSchedObject(pMutex);
	PKCONSTRAINT pkcOwnerOwner = Thread_GetCurrentConstraint(pThdWaitee);
	KConstraint_StartInheritance(pkcOwnerOwner, puNew);
      }
    }
}	    

/* Propagates up urgencies that may be less than or equally urgent than
 * owners, but not greater than.
*/
#if 0
void KConstraint_StopInheritance(
     PKCONSTRAINT pkcOwner,
     PURGENCY puOld
     )
{
    PURGENCY puCurrent;

    assert(pkcOwner != NULL);

    puCurrent = KConstraint_GetCurrentUrgency(pkcOwner);

    if (Urgency_EQ(puOld, puCurrent)) {
      PTHDINFO pThdOwner = (PTHDINFO)KConstraint_GetSchedObject(pkcOwner);
      PKCONSTRAINT pkcMostUrgent = Thread_FindMostUrgentMutexWaiter(pThdOwner);

      Urgency_Copy(puCurrent, KConstraint_GetLocalUrgency(pkcOwner));

      if (pkcMostUrgent != NULL) {
	PURGENCY puMostUrgent = KConstraint_GetCurrentUrgency(pkcMostUrgent);
	if (Urgency_GT(puMostUrgent, puCurrent)) {
	  Urgency_Copy(puCurrent, puMostUrgent);
	}
      }

      /* No other waiting urgency can be greater than the owner's
       * current urgency, due to our inherited urgency invariant.
       */
      assert(!Urgency_GT(puMostUrgent, puOld));

      if (Thread_IsWaitingForMutex(pThdOwner)) {
	PKCONSTRAINT pkcOwnerOwner =
	  Thread_GetCurrentConstraint(Mutex_GetSchedObject(
					  Thread_GetWaitObject(pThdOwner)));
	KConstraint_StopInheritance(pkcOwnerOwner, puOld);
      }
    }
}
#endif

void KConstraint_RecalculateInheritance(
     PKCONSTRAINT pkcRecalc
     )
{
  PKCONSTRAINT pkcMostUrgent =
    Thread_FindMostUrgentMutexWaiter(KConstraint_GetSchedObject(pkcRecalc));
  PURGENCY puRecalc = KConstraint_GetCurrentUrgency(pkcRecalc);
    
  Urgency_Copy(puRecalc, KConstraint_GetLocalUrgency(pkcRecalc));
    
  if (pkcMostUrgent != NULL) {
    PURGENCY puMostUrgent = KConstraint_GetCurrentUrgency(pkcMostUrgent);
    if (!Urgency_IsTimeSharing(puMostUrgent) &&
	Urgency_GT(puMostUrgent, puRecalc)) {
	Urgency_Copy(puRecalc, puMostUrgent);
      }
    }
}

BOOL KConstraint_UrgencyGT(
     PTR pkc1,
     PTR pkc2
     )
{
  return Urgency_GT(KConstraint_GetCurrentUrgency(pkc1),
		      KConstraint_GetCurrentUrgency(pkc2));
}

BOOL KConstraint_UrgencyGTEQ(
    PTR pkc1,
    PTR pkc2
    )
{
  return Urgency_GTEQ(KConstraint_GetCurrentUrgency(pkc1),
		      KConstraint_GetCurrentUrgency(pkc2));
}

