/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Loose ends for minimal version */
#include <mmlite.h>
#include <fred.h>

/* Should be called only from interrupt handlers (ie kernel mode, interrupts
 * disabled).  This is not enforced, but if called from any other mode the
 * duration of the call can vary greatly.  The only real guarantee is that
 * we will spend AT LEAST uSec microseconds inside this routine.
 */
UINT DelayMultiplier = 10; /* machdep should refine at boot time */

void Delay(UINT uSec)
{
    volatile UINT LoopCount = uSec * DelayMultiplier;

    while (LoopCount-- > 0)
        ;
}

/* Get current absolute time
 */
#if defined(CurrentTime)
#undef CurrentTime
#endif
TIME CurrentTime(void)
{
    return GetKernelTime();
}

/* XXX use SetBaseExports() in process.c instead of static */
struct IBaseRtlVtbl BaseRtlVtbl = {0,}; /* XXX */

#ifdef _DEBUG
/* XXX slight configuration problem dragged this in. */
PIHEAP CreateDebugHeap(const _TCHAR *Name, /* caller allocated */
                       UINT Flags,
                       UINT MaxSize,
                       UINT TrailerSize)
{
    return CurrentHeap();
}
#endif
