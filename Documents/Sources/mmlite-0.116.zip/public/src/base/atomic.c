/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define OPTIMIZE        /* enable Base.h optimizations, since we're the "base" */

#include <mmlite.h>
#include <fred.h>
#include <assert.h>

/* Get machdep implementation of AtomicCompareAndSwap
 */
#include "_atomic.c"

/* *** AtomicAdd
 *
 * Atomically adds Cnt to *pCount and returns the new value.
 */
UINT AtomicAdd(PUINT pCount, UINT Cnt)
{ 
    UINT OldCount, NewCount;

    for (;;) {
        OldCount = *pCount;
        NewCount = OldCount + Cnt;
        if (AtomicCmpAndSwap(pCount, OldCount, NewCount))
            return NewCount;
    }
}

/* *** AtomicSub
 *
 * Atomically subtracts Cnt from *pCount and returns the new value.
 */
UINT AtomicSub(PUINT pCount, UINT Cnt)
{
    UINT OldCount, NewCount;

    for (;;) {
        OldCount = *pCount;
        NewCount = OldCount - Cnt;
        if (AtomicCmpAndSwap(pCount, OldCount, NewCount))
            return NewCount;
    }
}

/* *** AtomicDec
 *
 * Atomically decrements *pCount and returns the new value.
 */
#undef AtomicDec
UINT AtomicDec(PUINT pCount)
{
    UINT OldCount, NewCount;

    for (;;) {
        OldCount = *pCount;
        NewCount = OldCount - 1;
        if (AtomicCmpAndSwap(pCount, OldCount, NewCount)) {
            return NewCount;
        }
    }
}

/* *** AtomicInc
 *
 * Atomically increments *pCount and returns the new value.
 */
#undef AtomicInc
UINT AtomicInc(PUINT pCount)
{
    UINT OldCount, NewCount;

    for (;;) {
        OldCount = *pCount;
        NewCount = OldCount + 1;
        if (AtomicCmpAndSwap(pCount, OldCount, NewCount)) {
            return NewCount;
        }
    }
}

void AtomicLIFOInsert(PTR * RESTRICT pHead, PTR RESTRICT Item)
{
    PTR OldHead;

    assert(Item);

    for(;;) {
        OldHead = *pHead;
        *(PTR*)Item = OldHead;
        if (AtomicCmpAndSwap((PUINT) pHead, (UINT) OldHead, (UINT) Item))
          break;
    }
}

PTR AtomicLIFORemove(PTR *pHead)
{
    PTR Item = 0, NewHead;

    for (;;) {
        Item = *pHead;
        if (!Item) {
            return NULL;
        }
        NewHead = *(PTR *)Item;
        if (AtomicCmpAndSwap((PUINT) pHead, (UINT) Item, (UINT) NewHead))
          break;
    }
    return Item;
}
