/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _irq_h_
#define _irq_h_

#define IRQ_ID_COUNT            32

#define IRQ_ID_GPIO0            0
#define IRQ_ID_GPIO1            1
#define IRQ_ID_GPIO2            2
#define IRQ_ID_GPIO3            3
#define IRQ_ID_GPIO4            4
#define IRQ_ID_GPIO5            5
#define IRQ_ID_GPIO6            6
#define IRQ_ID_GPIO7            7
#define IRQ_ID_GPIO8            8
#define IRQ_ID_GPIO9            9
#define IRQ_ID_GPIO10           10
#define IRQ_ID_GPIO11_27        11
#define IRQ_ID_LCD              12
#define IRQ_ID_UDC              13
#define IRQ_ID_SDLC             14
#define IRQ_ID_UART0            15
#define IRQ_ID_UART1            16
#define IRQ_ID_UART2            17
#define IRQ_ID_MCP              18
#define IRQ_ID_SSP              19
#define IRQ_ID_DMA0             20
#define IRQ_ID_DMA1             21
#define IRQ_ID_DMA2             22
#define IRQ_ID_DMA3             23
#define IRQ_ID_DMA4             24
#define IRQ_ID_DMA5             25
#define IRQ_ID_TIMER0           26
#define IRQ_ID_TIMER1           27
#define IRQ_ID_TIMER2           28
#define IRQ_ID_TIMER3           29
#define IRQ_ID_RTC              30
#define IRQ_ID_RTCALARM         31

#define IRQ_MASK_GPIO0          (1 << IRQ_ID_GPIO0)
#define IRQ_MASK_GPIO1          (1 << IRQ_ID_GPIO1)
#define IRQ_MASK_GPIO2          (1 << IRQ_ID_GPIO2)
#define IRQ_MASK_GPIO3          (1 << IRQ_ID_GPIO3)
#define IRQ_MASK_GPIO4          (1 << IRQ_ID_GPIO4)
#define IRQ_MASK_GPIO5          (1 << IRQ_ID_GPIO5)
#define IRQ_MASK_GPIO6          (1 << IRQ_ID_GPIO6)
#define IRQ_MASK_GPIO7          (1 << IRQ_ID_GPIO7)
#define IRQ_MASK_GPIO8          (1 << IRQ_ID_GPIO8)
#define IRQ_MASK_GPIO9          (1 << IRQ_ID_GPIO9)
#define IRQ_MASK_GPIO10         (1 << IRQ_ID_GPIO10)
#define IRQ_MASK_GPIO11_27      (1 << IRQ_ID_GPIO11_27)
#define IRQ_MASK_LCD            (1 << IRQ_ID_LCD)
#define IRQ_MASK_UDC            (1 << IRQ_ID_UDC)
#define IRQ_MASK_SDLC           (1 << IRQ_ID_SDLC)
#define IRQ_MASK_UART0          (1 << IRQ_ID_UART0)
#define IRQ_MASK_UART1          (1 << IRQ_ID_UART1)
#define IRQ_MASK_UART2          (1 << IRQ_ID_UART2)
#define IRQ_MASK_MCP            (1 << IRQ_ID_MCP)
#define IRQ_MASK_SSP            (1 << IRQ_ID_SSP)
#define IRQ_MASK_DMA0           (1 << IRQ_ID_DMA0)
#define IRQ_MASK_DMA1           (1 << IRQ_ID_DMA1)
#define IRQ_MASK_DMA2           (1 << IRQ_ID_DMA2)
#define IRQ_MASK_DMA3           (1 << IRQ_ID_DMA3)
#define IRQ_MASK_DMA4           (1 << IRQ_ID_DMA4)
#define IRQ_MASK_DMA5           (1 << IRQ_ID_DMA5)
#define IRQ_MASK_TIMER0         (1 << IRQ_ID_TIMER0)
#define IRQ_MASK_TIMER1         (1 << IRQ_ID_TIMER1)
#define IRQ_MASK_TIMER2         (1 << IRQ_ID_TIMER2)
#define IRQ_MASK_TIMER3         (1 << IRQ_ID_TIMER3)
#define IRQ_MASK_RTC            (1 << IRQ_ID_RTC)
#define IRQ_MASK_RTCALARM       (1 << IRQ_ID_RTCALARM)

#endif // _irq_h_
