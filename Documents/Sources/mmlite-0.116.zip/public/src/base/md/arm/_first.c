/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains FirstThread */

#include <mmlite.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <fred.h>

#if defined(ANGEL_SEMIHOST)

extern SCODE SizeofArmImage( PTR pAif, INT *pSize );

extern const _TCHAR * ArmCmdLine(BYTE *buffer, UINT nBytes);

const char *FIRST_IMAGE_NAME = "tzk.cob";

void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    SCODE sc;
    BYTE buffer[96];
    _TCHAR * Args = (_TCHAR *) buffer;
    PIMODULE pMod;

    if (ArmCmdLine(buffer, 96)) {
        printf("Failed to get command line\n");
        Args[0] = (_TCHAR) 0;
    }

    sc = FirstApp(Args);

    if (FAILED(sc))
        printf("FirstApp failed sc=x%x)\n", sc);

    /* Try and hope there is an image there...
     */
    {
#define LINK_BASE 0x10000
        THREAD_FUNCTION Geronimo = (THREAD_FUNCTION)(LINK_BASE+8);
        INT Siz;

        sc = SizeofArmImage( (PTR) LINK_BASE, &Siz );
        if (FAILED(sc)) {
            printf("Did not find a valid image at x%x\n", LINK_BASE);
        } else {
            PIHEAP pHeap = CurrentHeap();

            /* Mark the memory as in use
             */
            if (pHeap->v->Extract(pHeap, 0, (PTR) LINK_BASE, Siz) == NULL) {
                printf("Extract:image corrupted\n");
            } else {

                /* Create a module descriptor
                 */
                sc = ModuleCreate( /*FIRST_IMAGE_NAME*/NULL, Args,
                                   (PBYTE)LINK_BASE, Siz,
                                   (MODULEENTRY) Geronimo,
                                   NULL,    /* Export Data  */
                                   0,       /* Export Size  */
                                   NULL, 0, /* Imported modules */
                                   0, 0,    /* Com+ stuff */
                                   0,       /* Flags */
                                   &pMod    /* ppIModule    */
                       );

                /* Off we go.
                 */
                printf("Found pre-loaded image (%d bytes at x%x)\n",
                       Siz, LINK_BASE);
                Geronimo(pTheBaseRtl);
            }
        }
    }

    BaseDelete();
}

#else

PINAMESPACE InitMemoryFileSystem(void);
SCODE InitDebugConsole(void);
/* These symbols are linker-generated in the GCC case, cant change */
extern char _binary_fs_flp_start[], _binary_fs_flp_end[];
extern void MemDeviceSet( UINT32 FSSize, ADDRESS FSPointer );

const _TCHAR *FIRST_IMAGE_NAME = _TEXT("tzk.cob");

void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    SCODE sc;
    const _TCHAR * Args = _TEXT("");
    PIMODULE pMod;
    PINAMESPACE pRoot;
    MODULEENTRY EntryPoint;
    UINT FsSize;

    UnusedParameter(arg);

    printf("arm/_first.c FirstThread\n");

    FsSize = _binary_fs_flp_end - _binary_fs_flp_start;
    MemDeviceSet( FsSize, (ADDRESS)_binary_fs_flp_start);

    pRoot = InitMemoryFileSystem();

    if (pRoot == NULL) {
        printf("FirstThread: InitMemoryFileSystem failed\n");
    } else {
        SetImageNameSpace(pRoot);
    }

    sc = InitDebugConsole();
    if (FAILED(sc)) {
        printf("Failed to create debug console (sc = x%x)\n", sc);
        goto Out;
    }

    FirstApp(_T(""));

  Out:
    BaseDelete();
}

#endif
