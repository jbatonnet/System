/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>
#include <drivers/serp.h>
#include <mips\ml40x.h>

const DRIVER_CONFIG DriverConfigs[] = {
  {_T("null"), _T("COB/null.cob"), DEVICE_FLAGS_MANUAL_START, },

  /* Flash notyet */

  {_T("com1"), _T("COB/neilsart.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_LEVEL_TRIGGER|DEVICE_FLAGS_POSITIVE_LEVEL, 0xfff90000, AIC_USART/*9*/, NULL, NULL, 38400, },

  /* Console, hostfs and sernet share one serial port. Run serplexd.exe on NT side. */
  {_T("serplex6a"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, FSSerplexAddr, },
  {_T("srfs"), _T("COB/hostfs.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("serplex6a"), },

  /* public channel */
  {_T("serplex6d"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, NICSerplexAddr, },
  {_T("sr0"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6d"), NULL,},

  {_T("serplex6c"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, CONSerplexAddr, },

  /* System ACE */
  {_T("sysace"), _T("COB/sysace.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_LEVEL_TRIGGER|DEVICE_FLAGS_POSITIVE_LEVEL, 0xfff50000, AIC_SYSTEM_ACE/*4*/, NULL, },

  {NULL,}
};
