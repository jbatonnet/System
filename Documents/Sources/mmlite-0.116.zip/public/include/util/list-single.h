/* Header file for src\base\list-single.c
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __LIST_SINGLE_H__
#define __LIST_SINGLE_H__

#include <util/util.h>

/******************************************************************************
 * TYPE DEFINITIONS AND MACROS 
 */

/* Singly-linked list node, pointer, and pointer-to-pointer type defines */
typedef struct _NODE NODE, *PNODE, **PPNODE;

/* Single-linked list and pointer type defines */
typedef struct _LIST LIST, *PLIST;

/* Macros for casting */
#define pN(_pn_) ((PNODE)(_pn_))
#define pL(_pl_) ((PLIST)(_pl_))

/* Data structure for singly-linked list nodes. */
struct _NODE {
  PNODE pnNext;  /* Next node in a singly-linked list */
  PTR pData;      /* Data payload of this list node */
};

/* Data structure for singly-linked NULL-terminated lists
 * If the list is empty, pnHead == pnTail == NULL.
 * If the list is not empty, pnHead != NULL, pnTail != NULL,
 *     pnTail->pnNext == NULL, pnTail->pnNext == pnHead.
 * If the list has one element, pnHead == pnTail.
 */

struct _LIST {
  PNODE pnHead;
  PNODE pnTail;
};

/******************************************************************************
 * NODE MACROS AND METHODS
 */

/*** Node read macros ***/

#define /* PTR */                                                             \
Node_GetData(/* PNODE */ _pn_)                                                \
     (pN(_pn_)->pData)

#define /* PNODE */                                                           \
Node_GetNext(/* PNODE */ _pn_)                                                \
     (pN(_pn_)->pnNext)

#define /* BOOL */                                                            \
Node_IsAlone(/* PNODE */ _pn_)                                                \
     (Node_GetNext(_pn_) == NULL)


/*** Node write macros ***/

#define /* void */                                                            \
Node_Init(/* PNODE */ _pn_,                                                   \
           /* PTR    */ _ptr_)                                                \
     Node_SetNext((_pn_), NULL);                                              \
     Node_SetData((_pn_), (_ptr_))

#define /* void */                                                            \
Node_SetData(/* PNODE */ _pn_,                                                \
            /* PTR    */ _pData_)                                             \
     (Node_GetData(_pn_) = (_pData_))

#define /* void */                                                            \
Node_SetNext(/* PNODE */ _pn_,                                                \
            /* PNODE */ _pnNext_)                                             \
     (Node_GetNext(_pn_) = pN(_pnNext_))


/*** Node methods ***/

PNODE Node_Push(
    PNODE pnStackHead,
    PNODE pnNew
    );

PNODE Node_Pop(
    PNODE  pnStackHead,
    PPNODE ppnPopped
    );

void Node_InsertAfter(
    PNODE pnInsertAfter,
    PNODE pnNew
    );

void Node_RemoveAfter(
    PNODE pnPrevious
    );

PNODE Node_StackRemove(
    PNODE pnStackHead,
    PNODE pnRemove
    );

PNODE Node_StackClear(
    PNODE pnStackHead
    );


/******************************************************************************
 * LIST MACROS AND METHODS
 */

/*** List read macros ***/

#define /* PLIST */                                                           \
List_GetHead(/* PLIST */ _pl_)                                                \
     (pL(_pl_)->pnHead)

#define /* PLIST */                                                           \
List_GetTail(/* PLIST */ _pl_)                                                \
     (pL(_pl_)->pnTail)

#define /* BOOL */                                                            \
List_IsEmpty(/* PLIST */ _pl_)                                                \
     (List_GetHead(_pl_) == NULL)


/*** List write macros ***/

#define /* void */                                                            \
List_SetHead(/* PLIST */ _pl_,                                                \
              /* PNODE */ _pnNewHead_)                                        \
     (List_GetHead(_pl_) = pN(_pnNewHead_))

#define /* void */                                                            \
List_SetTail(/* PLIST */ _pl_,                                                \
              /* PNODE */ _pnNewTail_)                                        \
     (List_GetTail(_pl_) = pN(_pnNewTail_))

#define /* void */                                                            \
List_Init(/* PLIST */ _pl_)                                                   \
     List_SetHead((_pl_), NULL);                                              \
     List_SetTail((_pl_), NULL)


/*** List methods ***/

void List_Clear(
    PLIST plClear
    );

void List_HeadAdd(
    PLIST plAddTo,
    PNODE pnNew
    );

void List_TailAdd(
    PLIST plAddTo,
    PNODE pnNew
    );

PNODE List_HeadRemove(
    PLIST plRemoveFrom
    );

PNODE List_TailRemove(
    PLIST plRemoveFrom
    );

void List_Remove(
    PLIST plRemoveFrom,
    PNODE pnRemove
    );

PNODE List_FindData(
    PLIST plThis,
    PTR pFindData
    );

PNODE List_FindDataAndRemove(
    PLIST plRemoveFrom,
    PTR pFindData
    );

PTR List_FindDataMax(
    PLIST plThis,
    CompareFunc CompareGT
    );

PTR List_RemoveDataMax(
    PLIST plThis,
    CompareFunc CompareGT
    );

void List_TransformData(
    PLIST plThis,
    TransformFunc Transform
    );

void List_TransformDataWithArg(
    PLIST plThis,
    TransformArgFunc Transform,
    PTR pArg
);

void List_InsertSortedDescending(
    PLIST plThis,
    CompareFunc CompareGT,
    PNODE pnNew
    );

#endif /* __LIST_SINGLE_H__ */
