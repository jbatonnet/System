/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Cdr-consed list                                   --jvh 2006
   This is an out-of-line list, where the pointers are in blocks of
   ptr,size pairs.
   - The pointer block is variable size
   - The data is of variable size
   - Pointer,Size pairs point to the data.
   - The first Pointer,Size pair points to the next pointer block.
   - The fist size contains the size of the pointer block.
   - The list is "single-linked", i.e. there are no back pointers.
   - Unused pointers can be NULL.

   p -> {next,size} {data,len}*size
         +
         +->{next2,size2} {data,len}*size2
             +
             +->NULL
*/

typedef struct _CCLIST_NODE {
    PTR pItem;
    UINT Size;
} *PCCLIST_NODE;

typedef struct _CCLIST_HEAD *PCCLIST_NODE;
struct _CCLIST_HEAD {
    PCCLIST_HEAD pItem;
    UINT Size;
} *PCCLIST_NODE;

#define CcBlockDeclare(Count) \
struct _CcBlock_ # Count { \
    struct _CCLIST_HEAD Head; \
    struct _CCLIST_NODE Items[Count]; \
}

PCCLIST_NODE CcListAlloc(UINT Count);
PCCLIST_NODE CcListInit(UINT Count);

/* returns item matched (SEARCH,REMOVE), NULL otherwise */
PTR CcListWalk(PTR pHead, LIST_WALK Function,
               INT (*Transform)(PTR pItem, UINT Size, PTR pArg), PTR pArg);

