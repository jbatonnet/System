/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <tchar.h>      /* for StrFormat */
#include <wchar.h>      /* for wprintf, wcstol, etc */
#include <stdlib.h>

#include <x86_cpu.h>
#include <base/cons.h>
#include <base/loader.h>
#include "_dosx.h"      /* for DosxPointer */


extern _TCHAR * RTLCALLTYPE ProcessImageFromPC( ADDRESS Pc );
extern _TCHAR * RTLCALLTYPE ProcessArgsFromPC( ADDRESS Pc );
extern void MpSendInterrupt(void);

/* Compiler intrinsics are __stdcall but don't follow the naming scheme */
extern INT64 __cdecl _allmul(INT64, INT64);
extern INT64 __cdecl _alldiv(INT64, INT64);
extern INT64 __cdecl _allrem(INT64, INT64);
extern INT64 __cdecl _aulldiv(INT64, INT64);
extern INT64 __cdecl _aullrem(INT64, INT64);
extern INT64 __cdecl _allshl(INT64, INT8);
extern INT64 __cdecl _allshr(INT64, INT8);
extern INT64 __cdecl _aullshr(INT64, INT8);

#define _allmul (PTR) _allmul
#define _alldiv (PTR) _alldiv
#define _allrem (PTR) _allrem
#define _aulldiv (PTR) _aulldiv
#define _aullrem (PTR) _aullrem

const _TCHAR * RTLCALLTYPE ProcessImage(void)
{
    ADDRESS ThePc;
    __asm {
        mov     eax,DWORD PTR [ebp+4];
        mov     ThePc,eax;
    }
    return ProcessImageFromPC(ThePc);
}

const _TCHAR * RTLCALLTYPE ProcessArgs(void)
{
    ADDRESS ThePc;
    __asm {
        mov     eax,DWORD PTR [ebp+4];
        mov     ThePc,eax;
    }
    return ProcessArgsFromPC(ThePc);
}

/* BUGBUG refine */
/* Should be called only from interrupt handlers (ie kernel mode, interrupts
 * disabled).  This is not enforced, but if called from any other mode the
 * duration of the call can vary greatly.  The only real guarantee is that
 * we will spend AT LEAST uSec microseconds inside this routine.
 */
UINT DelayMultiplier = 10; /* machdep should refine at boot time */

void Delay(UINT uSec)
{
    volatile UINT LoopCount = uSec * DelayMultiplier;

    while (LoopCount-- > 0)
        ;
}

struct BASERTL {
    const struct IBaseRtlVtbl *v;
    UINT RefCnt;
};

SCODE BaseRtlQueryInterface(_Inout_ PIBASERTL This, REFIID Iid, void **ppObject)
{
    UnusedParameter(This);
    UnusedParameter(Iid);
    UnusedParameter(ppObject);
    return E_NOT_IMPLEMENTED;
}

UINT BaseRtlAddRef(_Inout_ PIBASERTL This)
{
    UnusedParameter(This);
    return 1;
}

UINT BaseRtlRelease(_Inout_ PIBASERTL This)
{
    UnusedParameter(This);
    return 1;
}

#ifdef _MSC_VER
#pragma warning(disable:4054 4153)/* cast from function ptr to data ptr (/Za)*/
#pragma warning(disable:4152)/* function/data pointer conversion in expression*/
#endif

#include "s_BaseRtl_v.c"
static const struct BASERTL _TheRtlObject = { &BaseRtlVtbl, 1 };
ADDRESS *RtlTable = (ADDRESS*) &_TheRtlObject;

PIBASERTL pTheBaseRtl = (PIBASERTL) &_TheRtlObject;
