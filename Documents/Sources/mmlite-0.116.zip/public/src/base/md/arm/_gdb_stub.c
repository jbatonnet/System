/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * GDB stub
 */
#include <mmlite.h>
#include <machdep.h>
#include <base/debugger.h>

/************************************************************************
 *
 * entry points into this code are as per debugger.h
 */

PUBLIC BOOL DebuggerAttached = FALSE;
PUBLIC ADDRESS StartOfIoSpace = 0;
PUBLIC ADDRESS EndOfIoSpace = 0;

/************************************************************************
 *
 * other global variables exported by this particular module
 */

/* GDB doesnt like error replies to its read memory commands,
 * at least not during the "target remote ..." connection.
 * So... change this (once connected) if you want to see them.
 * Otherwise invalid locations will just read as zeroes.
 */
BOOL gdb_makes_sense = FALSE;

/************************************************************************
 *
 * definitions related to GDB's remote protocol
 */

/* packets are of this size max [see remote.c]
 */
#define BUFMAX 400
PRIVATE unsigned char remcomBuffer[BUFMAX] = {0,};

/* packets encode bytes as hexnum pairs
 */
PRIVATE const unsigned char hexchars[]="0123456789abcdef";

/* GDB gets/sets the whole register set in one single shot, 
 * it assumes the following layout in a register data packet.
 */
#define GP0_REGNUM      0       /* 4 bytes each */
#define GPLAST_REGNUM   15
#define FP0_REGNUM      16      /* 12 bytes each */
#define FPLAST_REGNUM   23
#define FPS_REGNUM      24      /* 4 bytes each */
#define PS_REGNUM       25
#define LAST_REGNUM     25

/* GDB thinks an ARM has an FPU. We dont have one so we fake it.
 */
PRIVATE const unsigned char FakeFpuRegister[12] = {0,};

PRIVATE unsigned char *
AddressOfGdbRegister(PCXTINFO pContext, int RegNum)
{
    if (RegNum <= GPLAST_REGNUM)
        /* Our CXTINFO starts with the PS
         */
        return (unsigned char*)(&((UINT32*)pContext)[RegNum+1]);
    if (RegNum == PS_REGNUM)
        return (unsigned char *)&pContext->CPSR;
    return (unsigned char *) FakeFpuRegister;
}

PRIVATE int
SizeOfGdbRegister(int RegNum)
{
    /* All regs are one word except floats that are supposedly 3 */
    if ((RegNum >= FP0_REGNUM) &&
        (RegNum <= FPLAST_REGNUM))
        return 12;
    return 4;
}

/* Convert the ARM hardware trap code to GDB's code.
 */
PRIVATE int
GdbTrapNumber(int ArmTrap)
{
    switch (ArmTrap) {
        case 1: return 5;       /* undefined instruction (SIGTRAP U*x) */
        case 3:                 /* prefetch abort */
        case 4: return 11;      /* data abort (SIGSEGV U*x) */
    }

    return 1;                   /* anything else we donno (SIGHUP U*x) */
}

/* This is the instruction that 'breaks' into the debugger
 */
#define BREAKPOINT_INSTR    0xe7ffdefe // the undefined instruction

/* atoh only smaller ;-)
 */
PRIVATE int 
hex(unsigned char ch)
{
    if ((ch >= 'a') && (ch <= 'f')) return (ch-'a'+10);
    if ((ch >= '0') && (ch <= '9')) return (ch-'0');
    if ((ch >= 'A') && (ch <= 'F')) return (ch-'A'+10);
    return (-1);
}

/* scan for the sequence $<data>#<checksum>    
 */
PRIVATE unsigned char *
getpacket (unsigned char *buffer)
{
    unsigned char checksum;
    unsigned char xmitcsum;
    int count;
    unsigned char ch;

    while (1) {
        /* wait around for the start character, ignore all other characters
         */
        while ((ch = getDebugChar ()) != '$')
            ;

    retry:
        checksum = 0;
        xmitcsum = -1;
        count = 0;

        /* now, read until a # or end of buffer is found */
        while (count < BUFMAX) {
            ch = getDebugChar ();
            if (ch == '$')
                goto retry;
            if (ch == '#')
                break;
            checksum = checksum + ch;
            buffer[count] = ch;
            count = count + 1;
        }
        buffer[count] = 0;

        if (ch == '#') {
            ch = getDebugChar ();
            xmitcsum = hex (ch) << 4;
            ch = getDebugChar ();
            xmitcsum += hex (ch);

            if (checksum != xmitcsum) {
                /* Negative acknowledge
                 */
                putDebugChar ('-');
            } else {
                putDebugChar ('+'); /* successful transfer */

                /* if a sequence char is present, reply the sequence ID */
                if (buffer[2] == ':')
                {
                    putDebugChar (buffer[0]);
                    putDebugChar (buffer[1]);

                    return &buffer[3];
                }

                return &buffer[0];
            }
        }
    }
}

/* send the packet in the comm buffer.  
 */
PRIVATE void 
putpacket(const unsigned char *buffer)
{
    unsigned char checksum;
    int  count;
    unsigned char ch;

    /*  $<packet info>#<checksum>. */
    do {
        putDebugChar('$');
        checksum = 0;
        count    = 0;

        while ((ch=buffer[count]) != 0) {
            putDebugChar(ch);
            checksum += ch;
            count += 1;
        }

        putDebugChar('#');
        putDebugChar(hexchars[checksum >> 4]);
        putDebugChar(hexchars[checksum % 16]);

    } while (getDebugChar() != '+');

}

/* send a string to gdb [for use with printf() say]
 */
void DebuggerOutputString( const unsigned char *string, int len )
{
    const unsigned char *s = string;
    unsigned char checksum;
    int count;
    unsigned char ch, hc;
    UINT32 u;

    /* Sanity
     */
    if (len == 0)
        return;

    /* If no debugger just print
     */
    if (!DebuggerAttached) {
        if (len < 0) len = ((UINT)~0 >> 1);
        while (s && ((ch = *s++) != 0)) {
            if (ch == '\n')
                putDebugChar('\r');
            putDebugChar(ch);
            if (--len == 0) return;
        }
        return;
    }

    /*  $O<packet info>#<checksum>. */
    TURN_INTERRUPTS_OFF(u);
    do {
        putDebugChar('$');
        putDebugChar('O');
        checksum = 'O';
        s = string;
    
        count = 0;

        while (TRUE) {
            if (len == -1) {
                if (!(ch = *s++))
                    break;
            } else if (count++ < len)
                ch = *s++;
            else
                break;

            hc = hexchars[ch >> 4];
            putDebugChar(hc);
            checksum += hc;
            hc = hexchars[ch % 16];
            putDebugChar(hc);
            checksum += hc;
        }

        putDebugChar('#');
        putDebugChar(hexchars[checksum >> 4]);
        putDebugChar(hexchars[checksum % 16]);

    } while (getDebugChar() != '+');
    RESTORE_INTERRUPTS(u);
}

/* This function references memory trusting a pointer value given
 * by the host GDB.  It might be a bogus one, esp. if we are in
 * some sort of trouble.  Therefore the stub protects itself
 * against faults.  If the main finds that a bad memory access happened
 * inside this function it will set the MEM_ERR variable and continue.
 * (af) We did this in Mach ten years ago ..
 * Keep it simple or else.
 */
PRIVATE volatile BOOL get_set_char_faulted = FALSE;

PRIVATE unsigned char
get_set_char (unsigned char *addr, unsigned char val, BOOL set_it)
{
    get_set_char_faulted = FALSE;
    if (set_it)
        *addr = val;
    else
        val = *addr;
    return val;
}

/* Dangerous game here: we swear the compiler will keep these
 * two functions close to each other.
 */
PRIVATE unsigned char
get_set_char_end(void)
{
    /* linkem */
    return get_set_char(NULL,0,FALSE);
}

/* convert the memory pointed to by mem into hex, placing result in buf
 * return a pointer to the last char put in buf (zero, unless faulted).
 */
PRIVATE unsigned char* 
mem2hex(const unsigned char* mem,
        unsigned char* buf,
        int count)
{
    int i;
    unsigned char ch;

    for (i=0;i<count;i++) {
        ch = get_set_char ((unsigned char *)mem++,0,FALSE);
        if (get_set_char_faulted) {
            if (gdb_makes_sense)
                return buf;
            ch = 0;
        }
        *buf++ = hexchars[ch >> 4];
        *buf++ = hexchars[ch % 16];
    }
    *buf = 0;
    return(buf);
}

/* convert the hex array pointed to by buf into binary to be placed in mem
 * return a pointer to the character AFTER the last byte written
 */
PRIVATE unsigned char*
hex2mem(unsigned char* buf,
        unsigned char* mem,
        int count)
{
    int i;
    unsigned char ch;

    for (i=0;i<count;i++) {
        ch = hex(*buf++) << 4;
        ch = ch + hex(*buf++);
        (void) get_set_char (mem++, ch, TRUE);
        if (get_set_char_faulted) {
            if (gdb_makes_sense)
                return mem;
        }
    }
    return(mem);
}

/* while we find nice hex chars, build an int
 * return number of chars processed          
 */
PRIVATE int 
hexToInt(unsigned char **ptr, int *intValue)
{
    int numChars = 0;
    int hexValue;

    *intValue = 0;

    while (**ptr) {
        hexValue = hex(**ptr);
        if (hexValue >=0) {
            *intValue = (*intValue <<4) | hexValue;
            numChars ++;
        }
        else
            break;

        (*ptr)++;
    }

    return (numChars);
}

/* Similarly, for I/O space
 */
PRIVATE unsigned char* 
io2hex(ADDRESS addr,
       unsigned char* buf,
       int count)
{
    int i;
    UINT16 s;
    UINT32 w;

    /* byte-aligned -> do it by bytes */
    if ((addr & 1) || (count < 2))
        return mem2hex( (const unsigned char*)addr, buf, count);

    /* short-aligned -> by shorts */
    if ((addr & 2) || (count < 4)) {
        for (i=0;i<count;i += 2) {
            s = *(UINT16*)addr;
            addr += 2;
            buf = mem2hex( (const unsigned char*)&s, buf, 2);
        }
    } 
    /* word-aligned -> by words unless.. */
    else {
        for (i=0;i<count;i += 4) {
            w = *(UINT32*)addr;
            addr += 4;
            buf = mem2hex( (const unsigned char*)&w, buf, 4);
        }
    }
    *buf = 0;
    return(buf);
}

PRIVATE unsigned char*
hex2io(unsigned char* buf,
       ADDRESS addr,
       int count)
{
    int i;
    UINT16 s;
    UINT32 w;

    /* byte-aligned -> do it by bytes */
    if ((addr & 1) || (count < 2))
        return hex2mem( buf, (unsigned char*)addr, count);

    /* short-aligned -> by shorts */
    if ((addr & 2) || (count < 4)) {
        for (i=0;i<count;i += 2) {
            hex2mem(buf,(unsigned char*)&s,2);
            buf += 2*2;
            *(UINT16*)addr = s;
            addr += 2;
        }
    } 
    /* word-aligned -> by words unless.. */
    else {
        for (i=0;i<count;i += 4) {
            hex2mem(buf,(unsigned char*)&w,4);
            buf += 2*4;
            *(UINT32*)addr = w;
            addr += 4;
        }
    }
    return (unsigned char*)(addr);
}



/* Following codes relates to single-stepping.
 * ARM doesnt have hardware support for it, 
 * so we must use a brakpoint instruction and
 * do things in software.  The hard part is
 * to figure out where to put the breakpoint..
 */

/* Instruction condition field values. 
 */
#define INSTR_EQ        0x0
#define INSTR_NE        0x1
#define INSTR_CS        0x2
#define INSTR_CC        0x3
#define INSTR_MI        0x4
#define INSTR_PL        0x5
#define INSTR_VS        0x6
#define INSTR_VC        0x7
#define INSTR_HI        0x8
#define INSTR_LS        0x9
#define INSTR_GE        0xa
#define INSTR_LT        0xb
#define INSTR_GT        0xc
#define INSTR_LE        0xd
#define INSTR_AL        0xe
#define INSTR_NV        0xf

#define PSFLAG_N        0x80000000
#define PSFLAG_Z        0x40000000
#define PSFLAG_C        0x20000000
#define PSFLAG_V        0x10000000

/* Condition table. Specifies flags state for a given condition.
 */
const struct {
    int mask;
    int val1;
    int val2;
} CondTable[16] = {
    {PSFLAG_Z, PSFLAG_Z, PSFLAG_Z},                     /* EQ, Z set */
    {PSFLAG_Z, 0, 0},                                   /* NE, Z clear */
    {PSFLAG_C, PSFLAG_C, PSFLAG_C},                     /* CS, C set */
    {PSFLAG_C, 0, 0},                                   /* CC */
    {PSFLAG_N, PSFLAG_N, PSFLAG_N},                     /* MI */
    {PSFLAG_N, 0, 0},                                   /* PL */
    {PSFLAG_V, PSFLAG_V, PSFLAG_V},                     /* VS */
    {PSFLAG_V, 0, 0},                                   /* VC */
    {PSFLAG_C|PSFLAG_Z, PSFLAG_C, PSFLAG_C},            /* HI, C set and Z clear  */
    {PSFLAG_C|PSFLAG_Z, 0, PSFLAG_Z},                   /* LS, C clear or Z set (NB. additional condition tested seperately) */
    {PSFLAG_N|PSFLAG_V, PSFLAG_N|PSFLAG_V, 0},          /* GE */
    {PSFLAG_N|PSFLAG_V, PSFLAG_N, PSFLAG_V},            /* LT */
    {PSFLAG_Z|PSFLAG_N|PSFLAG_V, PSFLAG_N|PSFLAG_V, 0}, /* GT */
    {PSFLAG_N|PSFLAG_V, PSFLAG_N, PSFLAG_V},            /* LE (NB. additional condition tested seperately) */
    {0, 0, 0},                                          /* always */
    {0, 1, 1}                                           /* never */
};

#define ROR(a,b)    (((a) >> (b)) | ((a) << (32-(b))))
#define LSL(a,b)    ((a) << (b))
#define LSR(a,b)    (((a) >> (b)) & ~(0xffffffff << (32 - (b))))
#define ASR(a,b)    (((a) >> (b)) | (0xffffffff << (32 - (b))))

#define FIELD(inst,o,s) (((inst) >> (o)) & ~(0xffffffff << (s)))
#define RM(inst)    ((inst) & 0xf)
#define RS(inst)    (((inst) >> 8) & 0xf)
#define RN(inst)    (((inst) >> 16) & 0xf)
#define SH(inst)    (((inst) >> 7) & 0x1f)
#define U(inst)     ((inst) & 0x00800000)

#define IREG(_ctxt_,_n_) ((UINT32*)(_ctxt_))[(_n_)+1]

/* Compute the value of the operand for the specified instruction
 * There are 4 addressing modes we are interested in.
 */
PRIVATE unsigned int
ComputeAddrMode1(PCXTINFO pCxt, unsigned int inst)
{
    unsigned int r, Rm, Rs, sh, Im;

    /* #<immediate> */
    if ((inst & 0x0e000000) == 0x02000000) {
        Im = FIELD(inst,0,8);
        sh = FIELD(inst,8,4) * 2;
        r = ROR(Im, sh);
        return r;
    }

    /* Rm, LSL #<shift_imm> */
    if ((inst & 0x0e000070) == 0) {
        Rm = IREG(pCxt,RM(inst));
        sh = SH(inst);
        r = LSL(Rm, sh);
        return r;
    }

    /* Rm, LSL Rs */
    if ((inst & 0x0e0000f0) == 0x00000010) {
        Rm = IREG(pCxt,RM(inst));
        Rs = IREG(pCxt,RS(inst)) & 0x1f;
        r = LSL(Rm, Rs);
        return r;
    }

    /* Rm, LSR #<shift_imm> */
    if ((inst & 0x0e000070) == 0x00000020) {
        Rm = IREG(pCxt,RM(inst));
        sh = SH(inst);
        if (sh == 0)
            r = 0;
        else
            r = LSR(Rm, sh);
        return r;
    }

    /* Rm, LSR Rs */
    if ((inst & 0x0e0000f0) == 0x00000030) {
        Rm = IREG(pCxt,RM(inst));
        Rs = IREG(pCxt,RS(inst)) & 0x1f;
        r = LSR(Rm, Rs);
        return r;
    }

    /* Rm, ASR #<shift_imm> */
    if ((inst & 0x0e000070) == 0x00000040) {
        Rm = IREG(pCxt,RM(inst));
        sh = SH(inst);
        if (sh == 0)
            if (Rm & 0x80000000)
                r = 0xffffffff;
            else
                r = 0;
        else
            r = ASR(Rm, sh);
        return r;
    }

    /* Rm, ASR Rs */
    if ((inst & 0x0e0000f0) == 0x00000060) {
        Rm = IREG(pCxt,RM(inst));
        Rs = IREG(pCxt,RS(inst)) & 0x1f;
        r = ASR(Rm, Rs);
        return r;
    }

    /* Rm, ROR #<shift_imm> */
    if ((inst & 0x0e000070) == 0x00000060) {
        Rm = IREG(pCxt,RM(inst));
        sh = SH(inst);
        if (sh == 0)
            r = LSR(Rm, 1) | (pCxt->CPSR & PSFLAG_C) ? 0x80000000 : 0;
        else
            r = ROR(Rm, sh);
        return r;
    }

    /* Rm, ROR Rs */
    if ((inst & 0x0e0000f0) == 0x00000070) {
        Rm = IREG(pCxt,RM(inst));
        Rs = IREG(pCxt,RS(inst));
        r = ROR(Rm, Rs);
        return r;
    }
    /*amusme*/
    return 0;
}

PRIVATE unsigned int *
ComputeAddrMode2(PCXTINFO pCxt, unsigned int inst)
{
    unsigned int r, Rm, Rn, sh, Im, i;

    Rn = IREG(pCxt,RN(inst));

    /* [Rn, #+/- <12_bit_offset>]  */
    /* [Rn, #+/- <12_bit_offset>]! */
    if ((inst & 0x0f100000) == 0x05100000) {
        Im = FIELD(inst, 0, 12);
        if (U(inst))
            r = Rn + Im;
        else
            r = Rn - Im;
        return (unsigned int *) r;
    }

    Rm = IREG(pCxt,RM(inst));
    i = 0; /* keep compiler quiet */

    /* [Rn, +/-Rm, LSL|LSR|ASR|ROR|RRX #<shift_imm>]  */
    /* [Rn, +/-Rm, LSL|LSR|ASR|ROR|RRX #<shift_imm>]! */
    if ((inst & 0x0f100010) == 0x07100000) {
        sh = FIELD(inst,7,5);

        switch ((inst & 0x60) >> 5) {
        case 0: /* LSL */
            i = LSL(Rm, sh);
            break;
        case 1: /* LSR */
            i = LSR(Rm, sh);
            break;
        case 2: /* ASR */
            i = ASR(Rm, sh);
            break;
        case 3: /* ROR or RRX */
            if (sh == 0)
                i = LSR(Rm, 1) | (pCxt->CPSR & PSFLAG_C) ? 0x80000000 : 0;
            else
                i = ROR(Rm, sh);
            break;
        default:
            break;
        }

        if (U(inst))
            r = Rn + i;
        else
            r = Rn - i;
        return (unsigned int *) r;
    }

    /* [Rn], #+/- <12_bit_offset> */
    /* [Rn], +/- Rm, LSL|LSR|ASR|ROR|RRX #<shift_imm> */
    if (((inst & 0x0f300000) == 0x04100000) ||
        ((inst & 0x0f300010) == 0x06100000)) {
        r = IREG(pCxt,RN(inst));
        return (unsigned int *) r;
    }
    /*amusme*/
    return 0;
}


PRIVATE unsigned int *
ComputeAddrMode4(PCXTINFO pCxt, unsigned int inst, int regi)
{
    unsigned int r, Rn, b, slot, nRegs, regBit;

    Rn = IREG(pCxt,RN(inst));

    nRegs = 0;
    regBit = 1 << (regi % 16);

    /*
     * Count the total number of regs involved (nRegs), and compute the
     * position of the register (slot) we're interested in.
     */
    slot = 0;
    for (b = 1; b < 0x10000; b <<= 1)
        if (inst & b) {
            if (regBit & b)
                slot = nRegs*4;
            ++nRegs;
        }

    /* LDMIA, LDMIB */
    if ((inst & 0x0e900000) == 0x08900000) {
        if (inst & 0x01000000)
            r = Rn + slot + 4;           /* LDMIB */
        else
            r = Rn + slot;               /* LDMIA */
        return (unsigned int *) r;
    }

    /* LDMDA, LDMDB */
    if ((inst & 0x0e900000) == 0x08100000) {
        if (inst & 0x01000000)
            r = Rn - nRegs*4 + slot;     /* LDMDB */
        else
            r = Rn - nRegs*4 + slot + 4; /* LDMDA */
        return (unsigned int *) r;
    }
    /*amusme*/
    return 0;
}


/*
 * We need to single step, which means we have to decode the next instruction to
 * execute in order to determine the address at which we'll insert a breakpoint.
 */
PRIVATE unsigned int *NextInstrAddress = NULL;
PRIVATE unsigned int  NextInstruction = 0;

PRIVATE void 
SingleStep(PCXTINFO pCxt)
{
    unsigned int *pc = (unsigned int *) pCxt->PC;
    unsigned int inst = *pc;
    unsigned int nexti = 0;
    unsigned int step = FALSE;
    unsigned int mask, instCond = inst >> 28;

    /*
     * Check the condition field against the PSR to see if this instruction will
     * be executed.
     */
    mask = pCxt->CPSR & CondTable[instCond].mask;

    if (mask == CondTable[instCond].val1 || mask == CondTable[instCond].val2) {
        step = TRUE;
    } else {
        if (instCond == INSTR_LS) {
            if (mask == (PSFLAG_C|PSFLAG_Z))
                step = TRUE;
        } else if (instCond == INSTR_LE) {
            if (inst & PSFLAG_Z)
                step = TRUE;
        }
    }

    if (step) {
        /*
         * The instruction will be executed.  See if it branches.
         * We look at only the most likely branch instructions.
         *  MOV     pc, --
         *  LDR     pc, --
         *  LDMxx   --, {--,pc}
         *  B       --
         *  BL      --
         *
         * TODO:
         *  ADD     pc, --
         *  SUB     pc, --
         *  RSB     pc, --
         *  SWP     pc, --
         *  etc
         */
        if ((inst & 0x0e000000) == 0x0a000000) {
            /*
             * B or BL
             */
             nexti = (inst & 0x00ffffff) << 2;
             /* sign extend */
             if (inst & 0x00800000)
                 nexti |= 0xff000000 << 2;
             nexti += (int) pc + 8;

        } else if ((inst & 0x0deff000) == 0x01a0f000) {
            /*
             * MOV  pc, --
             */
            nexti = ComputeAddrMode1(pCxt,inst);

        } else if ((inst & 0x0c50f000) == 0x0410f000) {
            /*
             * LDR  pc, --
             */
            nexti = *ComputeAddrMode2(pCxt,inst);

        } else if ((inst & 0x0e108000) == 0x08108000) {
            /*
             * LDM  --, {--,pc}
             */
            nexti = *ComputeAddrMode4(pCxt, inst, 15);

        } else {
            nexti = pCxt->PC + 4;
        }
    } else {
        nexti = pCxt->PC + 4;
    }

    /* Insert a breakpoint at nexti. */
    NextInstrAddress = (unsigned int *) nexti;
    NextInstruction = *NextInstrAddress;
    *NextInstrAddress = BREAKPOINT_INSTR;
    FlushCache();
}

PRIVATE const unsigned char OkMsg[3] = {'O', 'K', 0};
PRIVATE unsigned char ErMsg[4] = {'E', '0', '0', 0};
#define ErrorReply(_c_) {ErMsg[2] = _c_;goto Bummer;}

/*
 * This function does all command processing for interfacing to gdb.
 */
void Debugger(PCXTINFO pContext, UINT32 TrapNumber)
{
    int    GdbTrap, stepping, i;
    ADDRESS addr;
    int    length;
    unsigned int regno;
    unsigned char * ptr, *ptrSave;

    /* If it wasnt attached before its attached now
     */
    DebuggerAttached = TRUE;

    /* Guard against faults inside this stub.
     */
    if (/*(TrapNumber == ?) &&*/
        (pContext->PC >= (ADDRESS)get_set_char) &&
        (pContext->PC < (ADDRESS)get_set_char_end)) {

        /* Say it and continue. PC has been advanced already.
         */
        get_set_char_faulted = TRUE;
        return;
    }

    /*
     * Adjust PC to point to the instruction causing the trap, unless it was
     * breakpoint.  For data aborts, invoker has already backed by 4.
     * BUGBUG Is this BP thing really necessary and/or general enough
     */
    if (pContext->PC == (unsigned int) DebugBreak + 4)
        pContext->PC = pContext->R14;
    else
        pContext->PC -= 4;      /* all others are PC-4 */

    /*
     * If we single stepped, restore the next instruction.  Note that we may
     * not have actually executed the previous instruction, so PC may not be
     * the same as NextInstrAddress.
     */
    if (NextInstruction) {
        *NextInstrAddress = NextInstruction;
        NextInstruction = 0;
        FlushCache();
    }

    /* Inform the remote debugger of what happened
     */
    GdbTrap = GdbTrapNumber( TrapNumber );
    remcomBuffer[0] = 'S';
    remcomBuffer[1] =  hexchars[GdbTrap >> 4];
    remcomBuffer[2] =  hexchars[GdbTrap % 16];
    remcomBuffer[3] = 0;

    putpacket(remcomBuffer);

    /* We are not single-stepping, unless GDB says so.
     */
    stepping = 0;

    /* Enter command loop, accept packet from debugger and act on it.
     * Until instructed to continue execution.
     */
    for (;;) {
        /* Get next command
         */
        ptr = getpacket(&remcomBuffer[0]);
        i = *ptr++;

        /* Default reply -- none
         */
        remcomBuffer[0] = 0;

        /* See whatnot
         */
        switch (i) {

        case '?' :
            /* re-synchronize, or get the list of loaded modules.
             */
            if (*ptr == 'L') {
                DebuggerNotifyModuleList();
                /* Return OK, no matter what */
                remcomBuffer[0] = 0;
            } else {
                remcomBuffer[0] = 'S';
                remcomBuffer[1] =  hexchars[GdbTrap >> 4];
                remcomBuffer[2] =  hexchars[GdbTrap % 16];
                remcomBuffer[3] = 0;
            }
            break;

        case 'g' :
            /* return the value of the CPU registers
             */
            ptr = remcomBuffer;
            for (i = 0; i <= LAST_REGNUM; i++) {
                int register_size = SizeOfGdbRegister(i);
                mem2hex(AddressOfGdbRegister(pContext,i),
                        ptr,
                        register_size);
                ptr += register_size*2; /* 2 hex(es) per byte */
            }
            break;

        case 'G' :
            /* set the value of the CPU registers - return OK 
             */
            for (i = 0; i <= LAST_REGNUM; i++) {
                int register_size = SizeOfGdbRegister(i);
                hex2mem(ptr,
                        AddressOfGdbRegister(pContext,i),
                        register_size);
                ptr += register_size*2; /* 2 hex(es) per byte */
            }
            goto Itsok;

        case 'P' :
            /* set the value of a single CPU register - return OK
             */
            if (hexToInt (&ptr, (int *)&regno) && *ptr++ == '=') 
                if (regno < LAST_REGNUM) {
                    hex2mem (ptr,
                             AddressOfGdbRegister(pContext,regno), 
                             SizeOfGdbRegister(regno));
                    goto Itsok;
                }

            ErrorReply('1');
            break;

        case 'm' :
            /* mAA..AA,LLLL  Read LLLL bytes at address AA..AA
             */
            ptrSave = ptr;
            /* TRY TO READ %x,%x.  IF SUCCEED, SET PTR = 0
             * NB: eval is left to right in C, case you forgot.
             */
            if (hexToInt(&ptr,(int*)&addr) &&
                (*(ptr++) == ',') &&
                hexToInt(&ptr,&length) &&
                (length < BUFMAX/2)) {
                ptr = 0;
                if (StartOfIoSpace &&
                    (addr >= StartOfIoSpace) &&
                    (addr < EndOfIoSpace)) {
                    io2hex( addr, remcomBuffer, length);
                } else {
                    mem2hex((unsigned char*) addr, remcomBuffer, length);
                }
                if (get_set_char_faulted && gdb_makes_sense) {
                    ErrorReply('3');
                }
            }

            if (ptr) {
                ErrorReply('1');
            }

            break;

        case 'M' :
            /* MAA..AA,LLLL: Write LLLL bytes at address AA.AA return OK
             */
            if (hexToInt(&ptr,(int*)&addr) &&
                (*(ptr++) == ',') &&
                hexToInt(&ptr,&length) &&
                (*(ptr++) == ':')) {
                if (StartOfIoSpace &&
                    (addr >= StartOfIoSpace) &&
                    (addr < EndOfIoSpace)) {
                    hex2io( ptr, addr, length);
                } else {
                    hex2mem(ptr, (unsigned char*) addr, length);
                }
                FlushCache();

                if (get_set_char_faulted) {
                    ErrorReply('3');
                }

                goto Itsok;

            }

            ErrorReply('2');
            break;

        case 's' :
            /* sAA..AA   Step one instruction from AA..AA(optional)
             */
            stepping = 1;
            /* fall through
             */

        case 'c' :
            /* cAA..AA    Continue at address AA..AA(optional)
             */

            /* try to read optional parameter, pc unchanged if no parm
             */
            if (hexToInt(&ptr,(int*)&addr))
                pContext->PC = addr;

            /* if we're stepping, set a breakpoint at next instruction
             */
            if (stepping)
                SingleStep(pContext);

            /* Return to invoker, who reloads context and continues
             */
            return;
            break;

        case 'D' :
            /* Debugger is detaching, wont speak again
             */
            putpacket(remcomBuffer);
            DebuggerAttached = FALSE;
            return;
            break;

        case 'k' :
            /* Kill program
             */
            DebuggerAttached = FALSE;
            BaseDelete(); /* wont come back */
            break;

        case 'H' :
            /* Select thread.  NYI.
             */
            break;

        default:
            break;              /* silently ignore */
        }

        /* Send reply back.  Its either an error, a standard reply,
         * or a reply with some information.
         */
        putpacket(remcomBuffer);
        continue;

    Itsok:
        /* Reply OK to request
         */
        putpacket(OkMsg);
        continue;

    Bummer:
        /* Something wrong
         */
        putpacket(ErMsg);
        continue;
    }
}

/* Worker for next two
 */
PRIVATE UINT DebuggerNotify(const char *ModuleName, ADDRESS LoadAddress, char Event)
{
    int count;
    UINT32 s;
    unsigned char *p = remcomBuffer;

    if (!DebuggerAttached)
        return 0;

    /*  $L<Ffilename>:<Address>#<checksum>. */
    count = strlen(ModuleName);

    TURN_INTERRUPTS_OFF(s);
    *p++ = Event;
    mem2hex((const unsigned char *)ModuleName,p,count);
    p += count*2;
    *p++ = ':';
    for (count = 0; count < 8; count++) {
        *p++ = hexchars[(LoadAddress>>28) & 0xf];
        LoadAddress <<= 4;
    }
    *p++ = 0;

    putpacket(remcomBuffer);
    RESTORE_INTERRUPTS(s);

    return 1;
}

/* Notify GDB of a local image loading event
 */
PUBLIC UINT DebuggerNotifyLoad(const char *ModuleName,
                               ADDRESS LoadAddress,
                               ADDRESS LoadEnd,
                               PTR Unused)
{
    return DebuggerNotify(ModuleName,LoadAddress,'L');
}

/* Notify GDB of a local image unloading event
 */
PUBLIC void DebuggerNotifyUnload(const char *ModuleName, ADDRESS LoadAddress,
                                 UINT Token)
{
    /* Only notify if *we* told the debugger about it
     */
    if (Token)
        DebuggerNotify(ModuleName,LoadAddress,'U');
}

