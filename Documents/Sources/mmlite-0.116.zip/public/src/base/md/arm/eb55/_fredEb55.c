/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define DBGLVL 0
#include <mmlite.h>
#include <mmmacros.h>
#include <fred.h>

#include "at91m55800.h"
#include "eb55.h"

extern void _start(void); /* truly our image's start */

extern void ClockDetect(void);

/* Take the memory configuration from the EBI setup
 */
#define SRAM_Base ((ADDRESS)EBICS_BA(TheEbi->ChipSelect[SRAM_CHIP_SELECT]))

void BoardInit(void)
{
#if 0 /* no need to waste code if.. */
    /* The EBI setup is fine with us.
     */
#else
    /* Setup the EBI the way we want it.
     * NB: ROM boot sets up the EBI as:
     * cs0: 0x01002529
     *      flash 16MB @x01000000, 16bit, 3ws+2f enabled, byteselect, valid
     * cs1: 0x02002121
     *      sram  16MB @x02000000, 16bit, 1ws+0f enabled, bytewrite, valid
     * cs2: 0x20000000  -- disabled
     * cs3: 0x30000000  -- disabled
     * cs4: 0x40000000  -- disabled
     * cs5: 0x50000000  -- disabled
     * cs6: 0x60000000  -- disabled
     * cs7: 0x70000000  -- disabled
     * rc:  ??????????
     * mc:  0x00000006  -- cs4..6 (2MB), RDP standard
     *
     * Notice we also turn off FLASH/SRAM boot-time remapping, ifnot.
     */
    static const struct _Ebi EbiSetup = {
     { 
         /* FLASH
          */
         0x01000000 | EBICS_DBW_16 | EBICS_NWS(2) | EBICS_WSE | EBICS_PS_16M |
             EBICS_TDF(2) | EBICS_BAT_W | EBICS_CSEN,

         /* RAM
          */
         0x02000000 | EBICS_DBW_16 | EBICS_NWS(0) | EBICS_WSE | EBICS_PS_16M |
             EBICS_TDF(0) | EBICS_BAT_W | EBICS_CSEN,

#if 0
         /* Ray's LCD
          */
         0x20000000 | EBICS_DBW8 | EBICS_NWS(5) | EBICS_WSE | EBICS_PS_1M|  
             EBICS_TDF(1) | EBICS_BAT_W | EBICS_CSEN,
#else
         0x20000000,            /* invalid */
#endif

         /* Rest is invalid
          */
         0x30000000, 0x40000000, 0x50000000, 0x60000000, 0x70000000 },
       EBIRC_NO_REMAP,
#ifdef _EB63
     0x00000006
#else
     0x00000000
#endif
    };
    *TheEbi = EbiSetup;
#endif

    /* Turn the clock on to all the peripherals we (know we'll) use
     */
    ThePmc->PerClockEnable = PMCPC_USART0 | PMCPC_USART1 |
                             PMCPC_TC0 | PMCPC_TC1 |
                             PMCPC_PIOB | PMCPC_PIOA;
    /* Initialize the PIO-B
     */
    PioB->OutEnable = PIOB_PB8  | PIOB_PB9  | PIOB_PB10 | PIOB_PB11 |
                    PIOB_PB12 | PIOB_PB13 | PIOB_PB14 | PIOB_PB15;

    PioB->FilterDisable = PIOB_PB8  | PIOB_PB9  | PIOB_PB10 | PIOB_PB11 |
                    PIOB_PB12 | PIOB_PB13 | PIOB_PB14 | PIOB_PB15;

    PioB->IntrDisable = PIOB_PB8  | PIOB_PB9  | PIOB_PB10 | PIOB_PB11 |
                    PIOB_PB12 | PIOB_PB13 | PIOB_PB14 | PIOB_PB15;

    PioB->Enable = PIOB_PB8  | PIOB_PB9  | PIOB_PB10 | PIOB_PB11 |
                    PIOB_PB12 | PIOB_PB13 | PIOB_PB14 | PIOB_PB15;

    /* Turn off all the LEDs, they suck power.
     */
    PioB->SetData = PIOB_PB8  | PIOB_PB9  | PIOB_PB10 | PIOB_PB11 |
                    PIOB_PB12 | PIOB_PB13 | PIOB_PB14 | PIOB_PB15;

    /* Check what clock we are using
     */
    ClockDetect();

    /* ..Any other peripherals that need initialization
     */
}

/* See how much SRAM we have
 * Memory banks are aliased.
 */
UINT MemorySize(void)
{
    ADDRESS MemBase, MemTop, MemLimit;
    UINT32 *pa, *pb, a, b;
    UINT MaxSize, Size;

    /* Start by finding how far we can go before trapping
     */
    Size = TheEbi->ChipSelect[SRAM_CHIP_SELECT];
    MemBase = EBICS_BA(Size);
    /* use PageSize info */
    MaxSize = 1*1024*1024 * (1 << (EBICS_PS_G(Size)*2));
    DBGME(1,printf("CS=%x MaxSize=%x\n",Size,MaxSize));
    MemLimit = MemBase + MaxSize;

    for (;;) {
        /* This will be aliased, unless we got it */
        MemTop = MemBase+ MaxSize;
        pa = (UINT32*)(MemTop - 4);
        a  = *pa;

        /* Cut our size estimate in half */
        Size = MaxSize >> 1;

        /* Watch out just below the new potential top
         */
        pb = (UINT32*)(MemBase + Size - 4);

        /* Write at the old top, check, put it back
         */
        *pa = a+1;
        b = *pb;
        *pa = a;

        /* Look for an alias */
        if ((b != (a + 1)) || (*pb != a))
            /* Not aliased, stop here */
            break;

        /* Its an alias, keep going */
        MaxSize = Size;
        DBGME(0,printf("Size -> %x\n",MaxSize));
    }

#if 1 /* save some code */
    return MaxSize;
#else /*anal-retentive*/

    /* If fully populated we are done
     */
    if (MemTop == MemLimit)
        return MaxSize;

    /* Now suppose we got 768K... the code above gets 512K.
     * Next loop makes sure there no fragments of a smaller "Size"
     * That would happen iff we had two memory chips of different size.
     * Which is very unlikely, so this code is normally disabled.
     */
    /* First pass checks for no extra memory, which is common case.
     * Following passes estimate the size of the extra chunk
     */
    pa = (UINT32*)(MemBase);
    Size = 0;
    for (;;) {
        /* Once we get the right Size we'll see an alias
         */
        pb = (UINT32*)(MemTop + Size);
        DBGME(0,printf("check @%x @%x\n",pa,pb));
        a = *pa;
        b = *pb;

        /* Found an alias ?
         */
        if (b == a) {
            /* Uhmm, could be a coincidence
             * Write a different value and check again
             */
            *pa = a + 1;
            b = *pb;
            *pa = a; /* dont forgetta.. */
            if (b == (a + 1))
                /* Really an alias, thats it then.
                 */
                goto Done;
        }                

        /* No alias, so there is (more) memory.
         */
        if (Size)
            /* Not the second pass, try a bigger chunk
             */
            Size = Size << 1;
        else {
            /* Smallest chunk we'll detect is 2K.
             * Anything less will be marked as 2k. Sorry.
             */
            Size = 2*1024;

            /* We are no longer looking at the first memory chip.
             */
            pa = (UINT32*)(MemTop);
        }
        
    }

  Done:
    DBGME(1,printf("MemorySize: %d+%d bytes\n",MaxSize,Size));
    return MaxSize+Size;
#endif
}

/* Create the system heap.  Left to machdep code because messy otherwise.
 * The heap should account for all available memory, carved out of memory
 * that is already used or unavailable (like the 640K-1meg hole on PCs).
 * It does not have to account for all the memory in the system.
 * Returns a PIHEAP pointer.
 */

PIHEAP MachineHeapCreate( void )
{
    PIHEAP pIHeap;
    ADDRESS MemBase = (ADDRESS) _end;
    ADDRESS ImageBase = (ADDRESS) _start;
    UINT MemSize = MemorySize();

#define MemTop  (SRAM_Base+MemSize)

    DBGME(1,printf("MachineHeapCreate: SRAM=%x..%x start=%x end=%x delta=",
                   SRAM_Base, MemTop, ImageBase, MemBase));

    if (ImageBase < SRAM_Base || ImageBase > SRAM_Base + MemSize) {
        DBGME(1,printf("%x ROM/Flash\n", MemBase-SRAM_Base));
        /* If we are running from ROM/Flash, assume .data is at the
         * beginning of RAM so start the heap after it.
         * Does not account for image in heap size (the heap is .data + .bss
         * smaller than SRAM size).
         */
        MemSize -= MemBase - SRAM_Base;
        pIHeap = CreateHeapFrom(MemBase, 0, MemSize, MemSize);
    } else {
        DBGME(1,printf("%x RAM\n", MemBase-ImageBase));
        /* If instead .text is in RAM then the image might be in the middle
         * of it so make a heap out of the entire RAM and then carve out the
         * image. This assumes there is space for the heap metadata at
         * start of RAM.
         * Accounts for image in heap size (the heap size is that of SRAM size)
         */
        pIHeap = CreateHeapFrom(SRAM_Base, 0, MemSize, MemSize);

        if (MemTop > MemBase) {
            MemSize = MemBase - ImageBase;
            pIHeap->v->Extract(pIHeap, 0, (PTR) ImageBase, MemSize);
        }
    }

    return pIHeap;
}

void TheEnd(void)
{
    void (*Reset)(void) = (void (*)(void))0x0;

    /* BUGBUG Somewhere there's got to be a reset register or somehting.
     */
    printf("Jumping to 0 cuz I'm stoop (seeya!)\n");
    for(;;)
        Reset();
}


#define verify 0
#if verify
extern void PrintIrqCounts(void);
#endif
/* .. */
void ArmMachineIdle(ADDRESS Arg)
{
    UnusedParameter(Arg);
#if verify
    UINT16 t0, t1;
    static INT32 maxsleep = -1;

    t0 = Tc0->Channel0.Counter;
    ThePmc->SysClockDisable = PMCSC_CPU;
    t1 = Tc0->Channel0.Counter;
    if ((t1 - t0) > maxsleep) {
        maxsleep = t1 - t0;
        printf("{%d}",maxsleep);
        PrintIrqCounts();
    }
#else
    ThePmc->SysClockDisable = PMCSC_CPU;
#endif
}
