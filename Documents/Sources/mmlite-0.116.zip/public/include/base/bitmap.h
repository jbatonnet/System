/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Add bitmap support to C -jvh 2009 */

#ifndef _BASE_BITMAP_H
#define _BASE_BITMAP_H 1

#define BITMAP_SET(map, bit) (map)[(bit)/32] |= (1<< (bit) % 32)
#define BITMAP_CLEAR(map, bit) (map)[(bit)/32] &= ~(1<< (bit) % 32)
#define BITMAP_VALUE(map, bit) ((map)[(bit)/32] & (1 << (bit)%32))
#define BITMAP_SIZE(bitcount) (__ROUND((bitcount), 32) / 8)
#define BITMAP_DECLARE(name, bitcount) UINT32 name[BITMAP_SIZE(bitcount)/4]
#define BITMAP_POINTER_DECLARE(name) UINT32 *name

#endif
