/* Copyright (c) Microsoft Corporation. All rights reserved. */

#include <mmlite.h>
#include <fred.h>
#include <base/debugger.h>

extern void SetLED(UINT leds);

/* Constants for the National Semiconductor 8250,16450,16550 chips
 */
#define COM_IEN     0x04        /* interrupt enable register */
#define COM_IIR     0x08        /* interrupt identification register */
#define COM_FCR                 /* fifo control register */
#define COM_MCR     0x10        /* modem control reg */
#define COM_MSR     0x18        /* modem status register */
#define COM_DLL     0x00        /* divisor latch least sig */
#define COM_DLM     0x04        /* divisor latch most sig */

#define COM_BI

#define COM_DLAB    0x80        /* divisor latch access bit */
#define COM_DTRRTS  0x03        /* Control bits to assert DTR and RTS */

#define COM_DAT     0x00        /* data buffer */
#define COM_LCR     0x0C        /* line control registers */
#define COM_LSR     0x14        /* line status register */

#define COM_DATRDY  0x01
#define COM_OE      0x02        /* Overrun error */
#define COM_PE      0x04        /* Parity error */
#define COM_FE      0x08        /* Frame error */
#define COM_OUTRDY  0x20

#define COM_RESET   0x03        /* 8-bit data, 1-stop bit, no parity */


#define COM_WRITE_BYTE(x, y)    (*(volatile BYTE *)(x) = (BYTE)(y))
#define COM_READ_BYTE(x)        (*(volatile BYTE *)(x))

/* fifo control register (only in 16550) */
#define iFIFOENA    0x01    /* Enable fifos */
#define iCLRRCVRFIFO 0x02   /* Clear receive fifo */
#define iCLRXMITFIFO 0x04   /* Clear transmit fifo */
#define iDMAMODE    0x08    /* DMA transfer enable */
#define iFIFO1CH    0x00    /* Receive fifo trigger level 1 char */
#define iFIFO4CH    0x40    /* Receive fifo trigger level 4 chars*/
#define iFIFO8CH    0x80    /* Receive fifo trigger level 8 chars*/
#define iFIFO14CH   0xc0    /* Receive fifo trigger level 14 chars*/

/* IR control ports */
#define SIRCTRL ((volatile char *) 0xFFFF0C00)      /* Serial Infrared control */
#define PCSR    ((volatile int *)  0xFFFFAC04)      /* Peripheral clock select */

#define IOPORT  ADDRESS

void ComPortPut(IOPORT Port, UINT8 Byte);
BOOL ComPortGet(IOPORT Port, UINT8 *pByte);


/* *** ComPortInit
 *
 * Initializes a COM port for low-level (polling) debugging use.
 */
void ComPortInit(IOPORT Port, UINT Baud, BOOL UseFifo)
{
    UINT8 reg;

    /* Don't set the baud rate if zero was specified.
     * For the some reason the Penguins have a COM3 with a non-standard
     * clock rate so this code won't work. Baud=0 will leave
     * the baud rate alone so the boot ROM's setting will be used.
     */
    if (Baud != 0) {
        INT divisor;

        divisor = (24000000 / 16) / Baud;     /* UART clock rate = 24MHz */

        /* Set the divisor latch access bit (DLAB) in the line control reg.
         */
        reg = COM_READ_BYTE(Port + COM_LCR);
        COM_WRITE_BYTE(Port + COM_LCR, reg | COM_DLAB);

        /* Set the divisor latch value.
         */
        COM_WRITE_BYTE(Port + COM_DLM, (divisor >> 8) & 0xff);
        COM_WRITE_BYTE(Port + COM_DLL, divisor & 0xff);

        COM_WRITE_BYTE(Port + COM_LCR, reg);
    }

    /* Set LCR to 8-bit data, 1-stop bit, no parity.
     */
    COM_WRITE_BYTE(Port + COM_LCR, COM_RESET);

    /* Assert DTR, RTS.
     */
    COM_WRITE_BYTE(Port + COM_MCR, COM_DTRRTS);

    /* Disable interrupt
     */
    COM_WRITE_BYTE(Port + COM_IEN, 0);

#ifdef USE_FIFO
    if (UseFifo) {
        /* Enable FIFO. This code is conditionalized because
         * the FIFO doesn't work properly on some chips.
         * If you try to use it on such chips, a hard-reset
         * is needed to get the chip back to a usable state.
         */
        COM_WRITE_BYTE(Port + COM_FCR, iFIFOENA | iFIFO14CH);
        reg = COM_READ_BYTE(Port + COM_FCR);
        if ((reg & iFIFO14CH) != iFIFO14CH) {

            /* The enable didn't work right, so don't use the FIFO.
             */
            COM_WRITE_BYTE(Port + COM_FCR, 0);
        }
    }
#endif

    /* Clear up the serial line buffer and the line status register.
     */
    (void) ComPortGet(Port, &reg);
}

/* *** ComPortPut
 *
 * Write a byte to the specified port.
 */
void ComPortPut(IOPORT Port, UINT8 Byte)
{
    /* Wait for transmit ready.
     */
    while ((COM_READ_BYTE(Port + COM_LSR) & COM_OUTRDY) == 0)
        ;

    /* Send the byte.
     */
    COM_WRITE_BYTE(Port + COM_DAT, Byte);
}

UINT ComPortErrors = 0;

/* *** ComPortGet
 *
 * Read a byte from the specified port.
 * Returns FALSE if there was no byte ready
 * to be read, or in case of error.
 */
BOOL ComPortGet(IOPORT Port, UINT8 *pByte)
{
    UINT8 lsr;

    lsr = COM_READ_BYTE(Port + COM_LSR);
    if ((lsr & COM_DATRDY) == 0)
        return FALSE;

    *pByte = COM_READ_BYTE(Port + COM_DAT);

    if (lsr & (COM_FE|COM_PE|COM_OE)) {

        ComPortErrors++;

        /* Reset error status.
         */
        COM_WRITE_BYTE(Port + COM_LCR, COM_RESET);
        return FALSE;
    }

    return TRUE;
}


#define DbgPort ((ADDRESS)0xFFFF0400)
#define IrPort  ((ADDRESS)0xFFFF0800)

ADDRESS DxPort=DbgPort;

#ifdef __GNUC__
#define USE_DEBUGGER_OUTPUT
#else
#define USE_SERIAL_LINE
#endif
#define dputc DCPutChar
//#define dgetc getc
unsigned char dgetc(int echo);

void DbgPortInit(void)
{
    /* Init IR */
    *PCSR = *PCSR | (1 << 8);
    *SIRCTRL = 0x2;       // UART2 mode

    ComPortInit(DxPort, 38400, FALSE);

#if !defined(__GNUC__)
    printf("MMLite...press mm\n");

    SetLED(0x4);

    /* Wait for someone to give us the go-ahead.
     */
    {
        int i;
        for (i = 2; i > 0; --i)
            if ('m' != dgetc(FALSE))
                i = 3;
    }
#endif

    SetLED(0x8);
}

static BOOL dxInit = TRUE;

void dputc(unsigned char c)
{
#if defined(USE_SERIAL_LINE)
    if (dxInit) {
        dxInit = FALSE;
        DbgPortInit();
    }

    if (c == '\n')
        ComPortPut(DxPort, '\r');
    ComPortPut(DxPort, c);
#elif defined(USE_DEBUGGER_OUTPUT)
    DebuggerOutputString(&c, 1);
#endif
}

unsigned char dgetc(int echo)
{
#if defined(USE_SERIAL_LINE) || 1
    UINT led = 1;
    UINT ledCnt = 0;
    unsigned char c;

    while (!ComPortGet(DxPort, &c)) {
        if ((ledCnt++ % 0x100) == 0)
            SetLED(led);
        if (led == 0x8)
            led = 1;
        else
            led += led;
    }
    if (echo == TRUE)       
        dputc(c);
#if 1
    if (c == 3) /* ^C , likely from GDB */
        DebugBreak();
#endif
    return c;
#else
    return 0;
#endif
}

void putDebugChar(unsigned char c)
{
    if (dxInit) {
        dxInit = FALSE;
        DbgPortInit();
    }
    ComPortPut(DxPort, c);
}

int getDebugChar(void)
{
    unsigned char c;

    while (!ComPortGet(DxPort, &c))
        continue;

    return c;
}


#if 0

void IrdaPortInit()
{
    *PCSR = *PCSR | (1 << 8);
    *SIRCTRL = 0x2;       // UART2 mode
#if 0
#if 1
    ComPortInit(IrPort, 9600, FALSE);

puts("IrDA initialized, press enter to continue...");
while ('\r' != dgetc(FALSE))
    continue;
dputc('\n');

    for (;;) {
        char c;
        int i;
        char *p;


        for (i=16;i>0;--i) {
            for (p = "Hello "; *p != 0; ++p)
                ComPortPut(IrPort, *p);
        }

        DxPort = IrPort;
        puts("Press Enter to continue");
        Delay(5000);
        while ('\r' != (c = dgetc(FALSE))) {
            Delay(5000);
            dputc(c);
            Delay(5000);
        }
        dputc('\n');
        DxPort = DbgPort;

    }

#else
    ComPortInit(IrPort, 9600, FALSE);

    for (;;) {
        UINT8 c;
        int i = 0;

        while (!ComPortGet(IrPort, &c)) {
            if (++i == 1 << 24)
                printf("errors: %d  ", ComPortErrors);
        }
        dputc(c);
    }

#endif
#endif
}
#endif
