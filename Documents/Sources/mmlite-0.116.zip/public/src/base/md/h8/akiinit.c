/* Copyright (c) Microsoft Corporation. All rights reserved. */

#include <mmlite.h>

#ifdef H8_3069F
#include "3069s.h"
#else
#include "3048F.h"
#endif
#include "lcd.h"
#include "sci.h"

//
// Init1
//
void AkiInit()
{
#ifdef H8_3069F
	P5DDR = 0xF0;		// SW:  PORT5 0-3:

	P4DDR = 0xFF;		// LCD: PORT4 0-5 LED: PORT4 6-7
	P6DDR = 0;
#else
	//
	// AKI-H8-LAN
	//
	SYSCR.BYTE = 3;
	
	BSC.BRCR.BYTE = 0xFE;
	
	P1.DDR = 0xFF;		// ADDRESS BUS 0-7 OUTPUT
	P2.DDR = 0xFF;		// ADDRESS BUS 8-15 OUTPUT
	P5.DDR = 0xFF;		// ADDRESS BUS 16-19 OUTPUT
	
	P8.DDR = 0xFE;		// CS1,2,3 ENABLE SET
	P8.DR.BYTE = 0xFE;	// CS1,2,3 OUTPUT

	PA.DDR = 0xF0;		// SW:  PORTA 0-3:
	PB.DDR = 0xFF;		// LED: PORTB

	P4.DDR = 0xFF;		// Debug LED
	P6.DDR |= 0x0F;		// Debug LED

	P4.DR.BYTE = 0xDB; // DebugLED 
#endif
}

//
// Init2
//
void AkiInit2()
{
	Lcd_Init();
	Sci_Init();

	Lcd_WriteStr("Hello MMLiteH8");
	Sci_WriteStr("Hello MMLiteH8\r\n");

	Sci_WriteStr("INTC.IER=0x");
	Sci_WriteHexByte(INTC.IER.BYTE);
	Sci_WriteStr("\r\n");

	//	Sci_WriteStr("FirstThread=0x");
//	Sci_WriteHexLong((UINT32)FirstThread);
//	Sci_WriteStr("\r\n");
	
//	Sci_WriteStr("sizeof CXTINFO = 0x");
//	Sci_WriteHexLong(sizeof(struct _CXTINFO));
//	Sci_WriteStr("\r\n");
	
//#ifdef __MEMFUNC_ARE_INLINED
//	Sci_WriteStr("__MEMFUNC_ARE_INLINED IS DEFINED\r\n");
//#else
//	Sci_WriteStr("__MEMFUNC_ARE_INLINED IS *NOT* DEFINED\r\n"); // <--- THIS
//#endif

#ifdef H8_3069F
	P4DR.BIT.B6 = 1; // LED1 OFF
	P4DR.BIT.B7 = 1; // LED2 OFF
#else
	PB.DR.BIT.B0 = 1; // LED0 OFF
	PB.DR.BIT.B1 = 1; // LED1 OFF
	PB.DR.BIT.B2 = 1; // LED2 OFF
	PB.DR.BIT.B3 = 1; // LED3 OFF

	P4.DR.BYTE = 0x0; // DebugLED OFF

	P6.DR.BIT.B0 = 0;
	P6.DR.BIT.B1 = 0;
	P6.DR.BIT.B2 = 0;
	P6.DR.BIT.B3 = 0;
#endif
}

