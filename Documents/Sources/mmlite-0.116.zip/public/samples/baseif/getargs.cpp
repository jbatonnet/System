/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
IModule *pModule;
SCODE StatusCode;
_TCHAR Args[100];

StatusCode = GetCurrentModule(&pModule);
if (FAILED(StatusCode)) {
    _tprintf(_TEXT("Error getting current module: %x\n"), StatusCode);
    exit(0);
}

/* Retrieve the arguments of the current module. */
if((StatusCode = pModule->GetArgs(Args, 100)) != 0) {
    _tprintf(_TEXT("Error getting module arguments: %x\n"), StatusCode);
    exit(0);
}
_tprintf(_TEXT("The module arguments are: %s.\n"), Args);

pModule->Release();
/* END_SAMPLE */
return 0;
}
