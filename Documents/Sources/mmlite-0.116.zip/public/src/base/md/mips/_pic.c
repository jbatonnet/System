/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include "linkage.h"
#include <mmlite.h>
#include <fred.h>
#include <mmhal.h>
#include <schedulif.h>

/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
}


IPic *PicCreate(void)
{
    return NULL;
}
