/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>

/* If the component was linked into a joined image, this file is omitted
 * and instead the CobMgr calls CobSampCobMain() directly through
 * ThePreCobTable. If this compnent instead was linked as a stand-alone binary,
 * this stub function calls the function. This way the rest of the component
 * does not need to be aware of linkage. This stub will in the future be
 * automatically generated.
 */
PIUNKNOWN CobMain(void)
{
    return CobSampCobMain();
}
