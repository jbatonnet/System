/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <base/cons.h>
#include <stdio.h>

SCODE FirstApp(const _TCHAR *Args)
{
    //    return RunSoapServer("http", TRUE);
    printf("eb63soap.c: CODE DELETED\n");
    return E_NOT_IMPLEMENTED;
}
