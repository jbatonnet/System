/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>

int _tmain()
{
IProcess *pPrc = CurrentProcess();
/* BEGIN_SAMPLE */
/* Pointer and reference to the current process. */
/* We want to force this process to stay around even after its last
 * thread is gone, presumably because some persistent object has
 * been registered in the namespace.
 */
pPrc->AddRef();
ThreadExit();
/* END_SAMPLE */
return 0; 
}
