/* Copyright (c) Microsoft Corporation. All rights reserved. */


/* May be disabled by mmmacros.h */
#ifndef __DIAGNOSTICS__
#define __DIAGNOSTICS__ 1


#include <stdio.h>

#ifdef _DEBUG
#ifndef DBGLVL
#define DBGLVL 1  /* 0 noise, 1 - comment, 2 - major function (def DbgLvl == 3)*/
#endif
#define DBGME(_l_,_s_) do { if ((_l_) >= DBGLVL) (_s_); } while(0);
#else
#define DBGME(_l_,_s_)
#endif

#ifdef _DEBUG
#define DBG(_x_) printf _x_
#define TRACE(_x_) DBGME(0,printf("%s (%s, %u)\n", _x_, __FILE__, __LINE__))
#else
#define DBG(_x_)
#define TRACE(_x_)
#endif

#endif /* __DIAGNOSTICS__ */
