/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains FirstThread
 */

#define DEVICE_ORDER BIG_ENDIAN
#include <mmlite.h>
#include <mmhal.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <fred.h>
#define _DEBUG 1
#include <diagnostics.h>
#include <drivers/serp.h>

extern PIBASERTL pTheBaseRtl;

extern PINAMESPACE BoardInitFileSystem(void);

/* Leftover linking issues */
INT MODENTRY CrtInit(INT Op)
{
    return 1;/* TRUE */
}

typedef _TCHAR *TSTR;
const TSTR FIRST_IMAGE_NAME = _TEXT("tzk.cob");

/* To help diagnose product boot problems.
 * Should be an LED or something else externally accessible.
 */
int BootStep = 0;

void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    SCODE sc;
    const _TCHAR * Args = _TEXT("");
    PINAMESPACE pRoot;
    PIUNKNOWN pUnk;

    UnusedParameter(arg);

    /* Start the linked-in drivers
     */
    pRoot = CurrentNameSpace();

    BootStep++; 

    sc = pRoot->v->Bind(pRoot,"COB/drivers.cob", 0, &pUnk);
    if (FAILED(sc)) {
        DBGME(3,printf("drivers.cob failed\n"));
        goto Out;
    }
    BootStep++; 
    /* leak the Unk */

    /* Start all drivers that need to be started, thank you very much
     */
    sc = pRoot->v->Bind(pRoot,"COB/drivercfg.cob", 0, &pUnk);
    if (FAILED(sc)) {
        DBGME(3,printf("drivercfg.cob failed\n"));
        goto Out;
    }
    BootStep++; 
    /* leak the Unk */

    /* Start the console, using the serial line driver
     */
#if USE_SERPLEX
    sc = InitConsole("serplex6c");
#else
    sc = InitConsole("com1");
#endif
    if (FAILED(sc)) {
        DBGME(3,printf("Failed to create debug console (sc = x%x)\n", sc));
        goto Out;
    }
    BootStep++; 

    pRoot = BoardInitFileSystem();
    if (!pRoot) goto Out;

    BootStep++; 

    SetImageNameSpace(pRoot);
    BootStep++; 

    FirstApp(Args);
    BootStep++; 

  Out:
    BaseDelete();
}
