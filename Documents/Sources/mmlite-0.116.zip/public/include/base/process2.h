/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef _OLDSCHED

#ifndef __BASE_PROCESS_H__
#define __BASE_PROCESS_H__

#include <util/list-single.h>

#ifdef _DEBUG
#define PRINT_IDLE_TIME 1
#else
#define PRINT_IDLE_TIME 0
#endif

/* ++++++++++++++++++++++++++++++++++++++++++
 * Common Process/Module descriptor
 */
typedef struct _MODULE {
    CONST_VTBL struct IModuleVtbl *v; /* Our primary methods table   */
    CONST_VTBL struct IProcessVtbl *pv;/* Our secondary methods table */

    UINT  RefCnt;         /* Reference count for this object         */

    NODE snListNode;     /* list of all modules                     */

                          /* IModule data                            */
    ADDRESS Start;        /* module starts here in memory            */
    ADDRESS End;          /* module ends here (exclusive) in memory  */
    MODULEENTRY Entry;/* module's entry point is at this address */

                          /* IProcess data                           */
    UINT DefaultStackSize;/* If not explicitly indicated.            */
#ifndef DEFAULT_STACK_SIZE
#define DEFAULT_STACK_SIZE (4*2048)-8
#endif

#if PRINT_IDLE_TIME
    TIME IdleWas;
    TIME TimeWas;
#endif

    /* process/module exit code & wait point*/
    INT ExitCode;
    CONDITION Termination;

    /* Fields for multi-process support */
    PIVMVIEW pVmView;
    PIHEAP pHeap;
    PINAMESPACE pNameSpace;

    /* Pointer to the exports list of this module. */
    ADDRESS *Exports;
    UINT ExportsCount;

    /* List of dependent modules */
    PIMODULE *ImportedModules;
    UINT nImportedModules;

    UINT DebugToken;
    UINT32 CreationFlags;

    const _TCHAR * pName;
    const _TCHAR * pArgs;       /* .. passed to the newly created module   */

} MODULE, *PMODULE, PROCESS, *PPROCESS;

#define pMD(_x_) ((PMODULE)_x_)
#define GetModuleFrom(_ptr_,_field_) \
        ((PMODULE)((UINT)(_ptr_) - offsetof(MODULE,_field_)))

#define /* PNODE */                                                          \
ModuleGetNode(/* PMODULE */ _pmd_)                                            \
     (&(pMD(_pmd_)->snListNode))

#define /* ADDRESS */                                                         \
ModuleGetStartAddress(/* PMODULE */ _pmd_)                                    \
     (pMD(_pmd_)->Start)

#define /* ADDRESS */                                                         \
ModuleGetEndAddress(/* PMODULE */ _pmd_)                                      \
     (pMD(_pmd_)->End)

#define /* _tchar* */                                                         \
ModuleNameGet(/* PMODULE */ _pmd_)                                            \
     (pMD(_pmd_)->pName)

#define /* void */                                                            \
ModuleNodeRemove(/* PMODULE */ _pmd_)                                         \
     NodeRemove(ModuleGetNode(_pmd_))

#define /* void */                                                            \
ModuleNodeInitialize(/* PMODULE */ _pmd_)                                     \
     Node_Init(ModuleGetNode(_pmd_), (_pmd_))

/* IProcess::<this> points to the secondary method table */
#define pPR(_x_) \
        ((PPROCESS)((UINT)(_x_) - offsetof(PROCESS,pv)))

#define /* PNODE */                                                          \
ProcessGetNode(/* PMODULE */ _ppr_)                                           \
     (&(pPR(_ppr_)->snListNode))

#endif /* __BASE_PROCESS_H__ */

#endif /* _OLDSCHED */
