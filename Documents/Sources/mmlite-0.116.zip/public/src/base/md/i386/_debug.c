/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <x86_cpu.h>
#include <_dosx.h>
//#include <mmhal.h>
#include <base/debugger.h>

#define __HAS_MACHINE_GETS 1  /* No gets is needed on this platform */
#define BROKEN_CONSOLE 0xff

#define __HAS_MACHINE_PUTS 1

void DCPutChar( UINT8 c);
int DCGetChar( BOOL DoEcho );

#define DBG(_x_)

static struct IFileVtbl DebugConsoleVtbl;

typedef struct _DCONS {
    const struct IFileVtbl *v;
    UINT    RefCnt;
} *PDCONS;

#define pDC(_t_) ((PDCONS)(_t_))

struct _DCONS TheDebugConsole = {&DebugConsoleVtbl, 1};

PDCONS DCInit(void)
{
    return &TheDebugConsole;
}

void DCDestroy(PDCONS File)
{
    DBG(("DCDestroy\n"));
    //CurrentHeap()->v->Free(CurrentHeap(), 0, File);
}

SCODE MCT DCQueryInterface(PIFILE pThis, REFIID pIid, void* *ppNew)
{
    DBG(("DCQueryInterface\n"));
    return GenericQueryInterface((PIUNKNOWN) pThis, pIid, ppNew, &IID_IFile);
}

UINT MCT DCAddRef(PIFILE pThis)
{
    PDCONS File = pDC(pThis);

    return AtomicInc(&File->RefCnt);
}

UINT MCT DCRelease(PIFILE pThis)
{
    PDCONS File = pDC(pThis);
    UINT Refs;

    Refs = AtomicDec(&File->RefCnt);
    if (Refs == 0)
      DCDestroy(File);

    return Refs;
}

/*
 * Read from a file (i.e. the console STDIN).
 */

#define ASCII_BELL      0x07
#define ASCII_BS        0x08
#define ASCII_TAB       0x09
#define ASCII_LF        0x0A
#define ASCII_CR        0x0D

SCODE MCT
DCReadAt(PIFILE pThis, UINT64 Position, BYTE *Buffer, UINT ByteCount,
         PUINT pSizeRead)
{
    UINT8       c = 0;
    UINT32      BytesRead = 0;
    BOOL        Done = FALSE;

    UnusedParameter(pThis);
    UnusedParameter(Position);

    /*
     *  Read up ByteCount number of characters or until a NEWLINE
     *  character occurs.
     */

    while (!Done && BytesRead < ByteCount) {
        c = (UINT8) DCGetChar(FALSE);
        if (c == '\r') {
            c = '\n';
        }
        if (c == '\n') {
            Done = TRUE;
        }

        *(_TCHAR*)(&Buffer[BytesRead]) = c;
        BytesRead += sizeof(_TCHAR);
    }

    if (pSizeRead)
        *pSizeRead = BytesRead;

    return (c == '\n') ? S_FALSE : S_OK;
}

/*
 * Write to a file
 */
SCODE MCT
DCWriteAt(PIFILE pThis, UINT64 Position, const BYTE *Buffer, UINT ByteCount,
          PUINT pSizeWritten)
{
    UnusedParameter(pThis);
    UnusedParameter(Position);

    if (pSizeWritten)
      *pSizeWritten = ByteCount;

    for ( ; ByteCount >= sizeof(_TCHAR); Buffer+=sizeof(_TCHAR), ByteCount-=sizeof(_TCHAR))
        _puttchar(*(_TCHAR*)Buffer);

    return S_OK;
}

/* Get/Set a file's size
 */
SCODE MCT DCGetSize(PIFILE pThis, PUINT64 pSize)
{
    UnusedParameter(pThis);
    UnusedParameter(pSize);

    return E_NOT_IMPLEMENTED;
}

SCODE MCT DCSetSize(PIFILE pThis, UINT64 Size)
{
    UnusedParameter(pThis);
    UnusedParameter(Size);

    return E_NOT_IMPLEMENTED;
}

static struct IFileVtbl DebugConsoleVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    DCQueryInterface,
    DCAddRef,
    DCRelease,
    DCReadAt,
    DCWriteAt,
    DCSetSize,
    DCGetSize
};

SCODE InitDebugConsole(void)
{
    PIFILE File = (PIFILE) DCInit();
    PINAMESPACE ns = CurrentNameSpace();
    SCODE sc;

    if (!File)
        return E_NOT_ENOUGH_MEMORY;

    sc = ns->v->Register(ns, _TEXT("stdin"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = ns->v->Register(ns, _TEXT("stdout"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = ns->v->Register(ns, _TEXT("stderr"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    return S_OK;

  Error:
    DBG(("InitDebugConsole failed sc=%x", sc));
    return sc;
}
