/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define DEVICE_ORDER LITTLE_ENDIAN
#include <mmlite.h>
#include <mmhal.h>
#include <arm/at91m63200.h>
#include "eb63.h"
#define EBCLOCK Eb63Clock

/*** the rest is the same on eb55/eb63 ***/

#include <machdep.h>
#include <fred.h>
#include <base/debugger.h>

/* USE_SERPLEX is defined in ... */
#include <drivers/serp.h>
 
extern void gdbOutputString( const unsigned char *string, int len );

#define _DEBUG_LINE_IS_CONSTANT 1

#if USE_SERPLEX

#if _DEBUG_LINE_IS_CONSTANT
#define DxPort Usart0
#define DxPortNo 0
#else
USART *DxPort = Usart0;
UINT8 DxPortNo = 0;
#endif

#else

#if _DEBUG_LINE_IS_CONSTANT
#define DxPort Usart1
#define DxPortNo 1
#else
USART *DxPort = Usart1;
UINT8 DxPortNo = 1;
#endif

#endif

/* *** ComPortReset
 *
 * Re-Initialize a COM port for low-level (polling) debugging use.
 *
 */
PRIVATE void 
ComPortReset(USART *Port, UINT Baud, UINT8 PortNo, BOOL Polling)
{
    UINT32 Divisor;

    /* Enable clock to the part */
    ThePmc->PerClockEnable = _bs32(PMCPC_USART0 << PortNo);

    /* Better be slower than faster, roundup 
     * NB: ASYNC, else no x16;
     */
    Divisor = (EBCLOCK/8)/Baud;
    Divisor = (Divisor/2) + (Divisor&1);
    Port->Baud = _bs32(Divisor);

    /* 8 bit, no parity, 1 stop */
    Port->Mode = _bs32(USM_CLK_MCKI | USM_BPC_8 | USM_NONE | USM_1STOP);

    if (Polling) {
        /* disable all interrupts */
        Port->IntrDisable = ~0;

        /* disable DMA stuff */
        Port->RxPointer = 0;
        Port->TxPointer = 0;
        Port->RxTimeout = 0;
        Port->TxTimeout = 0;
        Port->RxCounter = 0;
        Port->TxCounter = 0;
    }

    /* Enable rx/tx and clear any leftover status bits */
    Port->Control = _bs32(USC_RXEN | USC_TXEN | USC_RSTSTA | USC_STPBRK);

    /* Turn on external pins */
    PioA->Disable = _bs32(((PIOA_TXD0|PIOA_RXD0) << (PortNo*3)));
}

PRIVATE char DbgioInited = 0;
#define LIGHTLY 1
#define HEAVILY 2

PRIVATE void
ComPortInit(char How)
{
    if ((DbgioInited & How) == 0) {
        DbgioInited |= How;
        ComPortReset(DxPort, 38400, DxPortNo, (How == HEAVILY));
    }
}

/* *** ComPortPut
 *
 * Write a byte to the specified port.
 */
void ComPortPut(USART *Port, UINT8 Byte)
{
    /* wait until we can transmit */
    while ((Port->ChannelStatus & _bs32(USI_TXEMPTY)) == 0)
        continue;

    Port->TxData = _bs32(Byte);
}


UINT ComPortErrors = 0;

/* *** ComPortGet
 *
 * Read a byte from the specified port.
 * Returns FALSE if there was no byte ready
 * to be read, or in case of error.
 */
BOOL ComPortGet(USART *Port, UINT8 *pByte)
{
    UINT32 Status = Port->ChannelStatus;

    /* See if anything available */
    Status = _bs32(Status);
    if (Status & USI_RXRDY) {
        UINT32 x = Port->RxData;
        *pByte = (UINT8) _bs32(x);

        /* Check for errors */
        if (Status & (USI_RXBRK|USI_OVRE|USI_FRAME|USI_PARE)) {
            ComPortErrors++;
            if ((Status & USI_OVRE) == 0)   /* Overrun? */
                return FALSE;           /*  no, parity or framing error */
        }

        return TRUE;
    }

    return FALSE;
}

#define USE_SERIAL_LINE 1
#define dputc DCPutChar

/* Called possibly more than once at startup
 */
void DbgPortInit(void)
{
#if defined(USE_SERIAL_LINE)

#if 0
    /* DONT do this. The RESET state of this register is 0x18 */

    /* wait for any characters to drain */
    while ((DxPort->ChannelStatus & _bs32(USI_TXEMPTY)) == 0)
        continue;
#endif

    ComPortReset(DxPort, 38400, DxPortNo, TRUE);

#endif
}

void dputc(unsigned char c)
{
#if defined(USE_SERIAL_LINE)
    ComPortInit(LIGHTLY);

#if USE_SERPLEX
    /* Wrap the bytes into serplex frames */
    ComPortPut(DxPort, STH_CHAR);
    ComPortPut(DxPort, CONSerplexAddr);
    if ((c == STH_CHAR) || (c == EOT_CHAR) 
        || (c == ESC_CHAR) || (c == COMP_CHAR)) 
    {
        ComPortPut(DxPort,ESC_CHAR);
    }
#endif

    if (c == '\n')
        ComPortPut(DxPort, '\r');
    ComPortPut(DxPort, c);

#if USE_SERPLEX
    ComPortPut(DxPort, EOT_CHAR);
    /* Fix checksum on account of STX chars */
    if (c == STH_CHAR)
        c++;
    if (c == '\n')
        c += '\r';
    ComPortPut(DxPort, c);
    ComPortPut(DxPort, 0);
#endif
#endif
}

unsigned char dgetc(int echo)
{
#if defined(USE_SERIAL_LINE)
    unsigned char c;

    while (!ComPortGet(DxPort, &c)) {
        //SleepUntil(TIME_ORIGIN);
        continue;
    }

    if (echo == TRUE)       
        dputc(c);

    if (/*DebuggerAttached &&*/ (c == 3)) /* ^C , likely from GDB */
        DebugBreak();

    return c;
#else
    return 0;
#endif
}

void putDebugChar(unsigned char c)
{
    ComPortInit(LIGHTLY);

    ComPortPut(DxPort, c);
}

int getDebugChar(void)
{
    unsigned char c;

    ComPortInit(HEAVILY);
    while (!ComPortGet(DxPort, &c))
        continue;

    return c;
}
