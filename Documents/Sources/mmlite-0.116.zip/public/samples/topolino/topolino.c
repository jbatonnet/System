/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* Program for testing various dependency scenarios for temporal analyzer
 * project.                                            --jvh & sibin 2007
 *
 * Also includes simple example to demonstrate the timing methodologies:
 *  - static function call
 *  - dynamic/function pointer call
 *  - Type matching
 *  - elimination based on type.
 */


#ifdef _MSC_VER
#pragma warning(disable:4431)
#endif

#include <stdio.h>
#include <stdlib.h>
#include <mmlite.h>
/****** Dependency graph samples *****/

CONDITION k, x, y, z;

work()
{
}

done()
{
}

/*
1: simple client/server, producer/consumer
2: cycle
3: transitive client/server, producer/consumer
4: three threads reduce to two ordered or not
5: weird cycle, combo #1 + #2
 */

/* #1.01: simple client/server, producer/consumer */

a101()
{
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Signal(&y);
    done();
}

b101()
{
    Condition_Signal(&x);
    work();
    Condition_Wait(&y, NULL, NULL);
    done();
}

/* #1.02: variation w/ three threads */

a102()
{
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Signal(&x);
    done();
}

b102()
{
    Condition_Wait(&y, NULL, NULL);
    work();
    Condition_Signal(&y);
    done();
}

c102()
{
    Condition_Signal(&x);
    work();
    Condition_Signal(&y);
    work();
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Wait(&y, NULL, NULL);
    done();
}

/* #1.03: variation, binary semaphore limitation */

a103()
{
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Wait(&x, NULL, NULL);
    done();
}

b103()
{
    Condition_Signal(&x);
    work();
    Condition_Signal(&x);
    done();
}

/* #2.01: cycle */

a201()
{
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Signal(&y);
    done();
}

b201()
{
    Condition_Wait(&y, NULL, NULL);
    work();
    Condition_Signal(&z);
    done();
}

c201()
{
    Condition_Signal(&x);
    work();
    Condition_Wait(&z, NULL, NULL);
    done();
}

/* #3.01: transitive c/s, p/c */

a301()
{
    Condition_Wait(&k, NULL, NULL);
        work();
    Condition_Signal(&x);
    work();
    Condition_Wait(&z, NULL, NULL);
    work();
    Condition_Signal(&y);
    done();
}

b301()
{
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Signal(&z);
    done();
}

c301()
{
    Condition_Signal(&k);
    work();
    Condition_Wait(&y, NULL, NULL);
    done();
}

/* #4.01: three to two threads, unordered */

a401()
{
    Condition_Signal(&x);
    work();
    Condition_Signal(&y);
    work();
    Condition_Wait(&z, NULL, NULL);
    work();
    Condition_Wait(&k, NULL, NULL);
    done();
}

b401()
{
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Signal(&z);
    done();
}

c401()
{
    Condition_Wait(&y, NULL, NULL);
    work();
    Condition_Signal(&k);
    done();
}

/* #4.02: three to two threads, specific order (c before b) */

a402()
{
    Condition_Wait(&k, NULL, NULL);
    work();
    Condition_Signal(&x);
    work();
    Condition_Signal(&y);
    work();
    Condition_Wait(&z, NULL, NULL);
    done();
}

b402()
{
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Signal(&z);
    done();
}

c402()
{
    Condition_Signal(&k);
    work();
    Condition_Wait(&y, NULL, NULL);
    done();
}

/* #5.01: weird cycle: p/c and cycle (101 + 201) */

a501()
{
    Condition_Wait(&x, NULL, NULL);
    work();
    Condition_Wait(&z, NULL, NULL);
    work();
    Condition_Signal(&y);
    done();
}

b501()
{
    Condition_Signal(&x);
    work();
    Condition_Signal(&k);
    work();
    Condition_Wait(&y, NULL, NULL);
    done();
}

c501()
{
    Condition_Wait(&k, NULL, NULL);
    work();
    Condition_Signal(&z);
    done();
}


/*************** test driver *****************************/

void THREAD_LINKAGE TestThread1(THREAD_ARGUMENT arg)
{
    UINT test = (UINT) arg;
    switch(test) {
        case 101: a101(); break;
        case 102: a102(); break;
        case 103: a103(); break;
        case 201: a201(); break;
        case 301: a301(); break;
        case 401: a401(); break;
        case 402: a401(); break;
        case 501: a501(); break;
        default: printf("bad test number\n");
    }
}

void THREAD_LINKAGE TestThread2(THREAD_ARGUMENT arg)
{
    UINT test = (UINT) arg;
    switch(test) {
        case 101: b101(); break;
        case 102: b102(); break;
        case 103: b103(); break;
        case 201: b201(); break;
        case 301: b301(); break;
        case 401: b401(); break;
        case 402: b401(); break;
        case 501: b501(); break;
        default: printf("bad test number\n");
    }
}


/* #0.01: Timing methodologies test */
void static_callee()
{
}

void dynamic_callee_one( int i, int j )
{
}

void dynamic_callee_two( int i, int j )
{
}

void uncalled_function( int i, double d, char c ) 
{
}


PRIVATE SCODE TopolinoMain(_Inout_ PIPROGRAM iThis, const _TCHAR *CommandLine)
{
    void (*pdynamic_func)( int, int ) = dynamic_callee_one ;
    UINT test = _ttoi(CommandLine);

    if (test > 100) {
        /* Test for sychronization constructs & loops
         */
        SCODE sc;
        PIPROCESS prc = CurrentProcess();

        /*
        if (test == 0)
            test = 101;
        */
        Condition_Init(&x);
        Condition_Init(&y);
        Condition_Init(&z);
        Condition_Init(&k);

        sc = prc->v->CreateThread(prc, 0, TestThread1,
                (PTR) test, 0, NULL, NULL);
        if (sc != S_OK)
            printf("topolino 1 FAILED sc=%x\n", sc);

        sc = prc->v->CreateThread(prc, 0, TestThread2,
                (PTR) test, 0, NULL, NULL);
        if (sc != S_OK)
            printf("topolino 4 FAILED sc=%x\n", sc);

        switch (test) {
            case 102: c102(); break;
            case 201: c201(); break;
            case 301: c301(); break;
            case 401: c401(); break;
            case 402: c401(); break;
            case 501: c501(); break;
            default:;
                /* nothing, only two needed */
        }

        printf("topolino main thread done\n");
    }
    else
    {
        /* Function call methodologies test.
         */

        /* static call */
        static_callee() ;

        /* function pointer/dynamic call */
        pdynamic_func( 0, 0 ) ;

        done() ;
    }

    return 0;
}

#include <base/cobdesc.h>
typedef struct _DefCob Topolino;
#define TopolinoDestroy NULL
#include <s_Topolino_v.c>
