/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _ASSERT_H_
#define _ASSERT_H_

#ifdef _DEBUG
#include <stdio.h> /* printf prototype */
#define __Assert_print(_m_, _f_, _l_) printf("Assertion `%s' failed at %s:%u\n", _m_, _f_, _l_)
#define assert(_x_) { if (!(_x_)) {__Assert_print(#_x_, __FILE__, __LINE__);DebugBreak(); }}
#ifdef _MSC_VER
#pragma warning(disable:4127)  /* conditional expression is constant */
#endif

#else
#define assert(_x_)
#endif

#endif /* !_ASSERT_H_ */
