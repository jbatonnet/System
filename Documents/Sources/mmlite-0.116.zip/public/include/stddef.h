/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __STDDEF_H_
#define __STDDEF_H_

#define __NEEDS_SIZE_T 1
#define __NEEDS_WCHAR_T 1
#define __NEEDS_NULL 1
#define __NEEDS_OFFSETOF 1
#define __NEEDS_PTRDIFF_T 1
#include <__defs.h>

#endif /* __STDDEF_H_ */
