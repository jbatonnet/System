/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <base/cons.h>

SCODE FirstApp(const _TCHAR *Args)
{
    return RunSoapServer("http", TRUE);
}
