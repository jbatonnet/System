/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>

DRIVER_CONFIG DriverConfigs[] = {
  {_T("null"), _T("COB/null.cob"), 0, },

  {_T("ee0"), _T("COB/ee16.cob"), DEVICE_FLAGS_NET_DRIVER|DEVICE_FLAGS_INTERRUPTS, 0x300, 5, NULL,NULL,3,},
  {_T("vga"), _T("COB/vga.cob"), 0, 0xb8000, },
  {_T("com1"), _T("COB/8250.cob"), DEVICE_FLAGS_INTERRUPTS, 0x3f8, 4, NULL, NULL, 1200,},
  {_T("com2"), _T("COB/8250.cob"), DEVICE_FLAGS_INTERRUPTS, 0x2f8, 3, NULL, NULL,19200,},
  {_T("mouse"), _T("COB/mouse.cob"), DEVICE_FLAGS_STACKED_DRIVER, 0, 0, _T("com1"), NULL, 0x10002, },

  {NULL,}    
};
