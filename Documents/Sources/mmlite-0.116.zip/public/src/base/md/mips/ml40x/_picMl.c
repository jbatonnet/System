/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * ARM RPS Interrupt Controller support for eMIPS.
 */
#include <mmlite.h>
#include <diagnostics.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <drivers/drivers.h>
#include <fred.h>
#include <mmhal.h>
#include <mips/ml40x.h>

#define TheAic ((struct _Aic *)INTERRUPT_CONTROLLER_DEFAULT_ADDRESS)

#define _STATISTICS 0

#define IRQ_ID_COUNT (32)

extern PCXTINFO _Reschedule(PCXTINFO pContext);

typedef struct _ITABLE {
    INTERRUPT_SERVICE_ROUTINE Isr;  /* isr for IRQn*/
    void *pDevice;                  /* Argument to pass to ISR */
#if _STATISTICS
    UINT32 Count;
    UINT32 pad;
#endif
} ITABLE;

/* The interrupt dispatcher uses a simple table of handlers. */
typedef struct _PIC {
    const struct IPicVtbl *v;
    UINT32 Enabled;
    ITABLE InterruptTable[IRQ_ID_COUNT];
} PIC;

/* Enable an interrupt source
 */
void MCT EnableInterrupt( IPic *pThis, DEVICE_FLAGS Flags, UINT Irq,
                          INTERRUPT_SERVICE_ROUTINE Isr, void *pDevice)
{
    PIC *pic = (PIC *) pThis;
    UINT32 Mask;

    /* Make that a bitmask
     */
    Mask = 1 << Irq;

#if 0
    /* We might want to protect the innocents and prevent them from
     * getting screwed trying to use the wrong IRQ.
     */
    if (Mask & AICI_unused) {
        DBGME(3,printf("Useless IRQ %d, will never trigger.\n",Irq));
        return;
    }
#endif

    /* First disable that interrupt source, in case it was enabled.
     * This prevents us from getting very confused with ISRs and arguments.
     */
    TheAic->IrqEnableClear = Mask;
    
    /* Second, the argument & isr.
     */
    pic->InterruptTable[ Irq ].pDevice = pDevice;
    pic->InterruptTable[ Irq ].Isr = Isr;

    /* Third, enable and done.
     */
    pic->Enabled |= Mask;
    TheAic->IrqEnable = Mask;
}

/*
 * Undo the above EnableInterrupt
 */
void MCT DisableInterrupt( IPic *pThis, UINT Irq, void **pOldDevice)
{
    PIC *pic = (PIC *) pThis;
    UINT32 Mask;

    /* Make that a bitmask
     */
    Mask = 1 << Irq;

    /* Disable the interrupt source.
     * No checks required, disabling unused ones is ok.
     */
    TheAic->IrqEnableClear = Mask;
    pic->Enabled &= ~Mask;

    /* Remove the ISR and its argument from our tables,
     * but return the previous argument.
     */
    pic->InterruptTable[ Irq ].Isr = NULL;
    *pOldDevice = pic->InterruptTable[ Irq ].pDevice;
    pic->InterruptTable[ Irq ].pDevice = NULL;
}

/*
 * Mask *all* interrupts.
 */
void MCT MaskAll( IPic *pThis )
{
    UnusedParameter(pThis);
    TheAic->IrqEnableClear = ~0;
}

/*
 * Unmask all interrupts that should be unmasked.
 */
void MCT UnmaskAll( IPic *pThis )
{
    PIC *pic = (PIC *) pThis;
    TheAic->IrqEnable = pic->Enabled;
}

static const struct IPicVtbl picVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    EnableInterrupt,
    DisableInterrupt,
    MaskAll,
    UnmaskAll
};

PIC ThePIC = {
    &picVtbl,
    0,
};

/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
    /* Disable all channels*/
    MaskAll(pThis);
}


IPic *PicCreate(void)
{
    IPic *pThis;

    /* Make sure the PIC is there
     */
    if (TheAic->Tag != PMTTAG_INTERRUPT_CONTROLLER)
        return NULL;

    ThePIC.Enabled = 0;
    pThis = (IPic *)&ThePIC;

    /* Reset chip, disable all ints
     * Donno what to do for pending ones, sorry.
     */
    TheAic->IrqEnableClear = ~0;

    return pThis;
}

/* Rightmost 1. BUGBUG optimize in assembly
 */
int INLINE Rightmost1(UINT32 Val)
{
    UINT32 Mask;

    Mask = Val & -Val;
    return ((Mask & 0xFFFF0000)!=0) << 4
         | ((Mask & 0xFF00FF00)!=0) << 3
         | ((Mask & 0xF0F0F0F0)!=0) << 2
         | ((Mask & 0xCCCCCCCC)!=0) << 1
         | ((Mask & 0xAAAAAAAA)!=0);
}

/* Dispatch an interrupt
 *
 * The argument "InterruptPendingMask" shows the status of the interrupt lines
 * in the MIPS processor's CAUSE register.  We only have one AIC so.
 */
CXTINFO *ExternalInterrupt(CXTINFO *pContext, UINT InterruptPendingMask)
{
    UINT32 Pending;
    BOOL DoReschedule;
    BOOL NotMyInterrupt;
    int Index;
    ITABLE *IntSource;

    UnusedParameter(InterruptPendingMask);

    /* For starters..
     */
    DoReschedule = 0;

    /* See whats pending, check for spurious
     */
    Pending = TheAic->IrqStatus;
#if _STATISTICS
    if (!Pending)
        ThePIC.InterruptTable[0].Count++;
#endif
    while (Pending) {

        /* Take one
         */
        Index = Rightmost1(Pending);
        Pending = Pending & ~(1 << Index);

        IntSource=&ThePIC.InterruptTable[Index];

#if _STATISTICS
        IntSource->Count++;
#endif
        DoReschedule |= (IntSource->Isr)(IntSource->pDevice, &NotMyInterrupt);

    };

    /* If any handler requested a reschedule, it will get done
     */
    if (DoReschedule)
        pContext = _Reschedule(pContext);

    return pContext;
}

#if _STATISTICS
void PrintIrqCounts(void)
{
    int i;
    for (i = 0; i < IRQ_ID_COUNT; i++)
        if (ThePIC.InterruptTable[i].Count != 0)
            printf("int[%d] = %d\n", i, ThePIC.InterruptTable[i].Count);
}
#endif
