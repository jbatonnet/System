// Copyright (c) Microsoft Corporation. All rights reserved.
//

// Process interface definitions and other XML metadata and produce documentation
// headers etc. This is the driver program. --jvh 2000

var cpuname = null; // used by apply_script.
var verbose = 0;
var debug = false;
var inputpath = "";
var oLog = null;
var objsuffix = "obj";
var docindexfile = null;
var ofs = null;
var domdocument_name = "Msxml2.DOMDocument.5.0";
var schema_cache;

try {
    schema_cache = new ActiveXObject("Msxml2.XMLSchemaCache.5.0");
} catch (exception) {
try {
    schema_cache = new ActiveXObject("Msxml2.XMLSchemaCache.4.0");
    domdocument_name = "Msxml2.DOMDocument.4.0";
} catch (exception) {
    alert("*** Runtime Error: " + exception.description + "\n*** Looks like msxml4 is missing.\n*** Try downloading from http://msdn.microsoft.com/XML/XMLDownloads/default.aspx");
    exit;
}}

function loadError(oSRC, str) {
  var oErr = oSRC.parseError;

  var s = "";
  for (var i=1; i < oErr.linepos; i++) {
    s += " ";
  }
  alert("XML parse error " + oErr.url + "(" + oErr.line + "): pos " + oErr.linepos + "\n" + oErr.reason + "\n"
        + oErr.srcText + "\n" + s + "^");
}

var namespaces= "xmlns:mic='x-schema:spec-schema.xml'";
//var namespaces= "xmlns:mic='spec.xsd'";
function setprops(tree) {
  tree.setProperty("SelectionLanguage", "XPath");
  if (namespaces != null)
    tree.setProperty("SelectionNamespaces", namespaces);
}

function setprops2(tree) {
  tree.setProperty("SelectionLanguage", "XPath");
  tree.setProperty("SelectionNamespaces", "xmlns:exp='x-schema:expanded-schema.xml'" );
}

function load_xml(file, validate, resolve, quiet) {
  if (ofs.FileExists(file)) {
  } else if (ofs.FileExists(src_dir2 + "\\" + file)) {
      file = src_dir2 + "\\" + file;
  } else if (ofs.FileExists(src_dir3 + "\\" + file)) {
      file = src_dir3 + "\\" + file;
  } else {
    if (!quiet)
      echo ("File " + file + " does not exist");
    return null;
  }

  if (verbose > 1)
    echo("Loading " + file);

  var oXML = new ActiveXObject(domdocument_name);
  oXML.validateOnParse = validate;
  oXML.resolveExternals = resolve;
  oXML.async = false;
  oXML.schemas = schema_cache;
  if (!oXML.load(inputpath + file))
    loadError(oXML, "Load of " + file + " failed");

  setprops(oXML);
  return oXML;
}

function validate_xml(tree) {
  tree.validateOnParse = true;
  tree.resolveExternals = true;
  tree.async = false;
  var text = tree.xml;
  tree.schemas = schema_cache;
  if (!tree.loadXML(text))
    loadError(tree, "Validate failed");

  setprops(tree);

  return tree;
}

function apply_script(oSRC, result_name, result_suffix, script_path, script_name, dowrite) {
  var sXML2 = null;
  var oXSL = new ActiveXObject(domdocument_name);
  oXSL.validateOnParse = true;
  oXSL.schemas = schema_cache;
  oXSL.async = false;

  var actual = script_path + "\\" + nonsuffix(script_name) + "-" + cpuname + suffix(script_name);

  if (cpuname == null || !oXSL.load(actual)) {
    if (oXSL.parseError.errorCode != 0 && oXSL.parseError.line != 0)
      loadError(oXSL, "");
    actual = script_path + "\\" + script_name;
    if (!oXSL.load(actual)) {
      loadError(oXSL, "Load of " + actual + " failed");
      return null;
    }
  }

  if (verbose > 1)
    echo("Transforming with " + actual);

  try {
    sXML2 = oSRC.transformNode(oXSL);
  } catch (exception) {
    alert("XSL Runtime Error: " + exception.description);
    return null;
  }

  if (verbose > 1 && debug)
    echo("Done with " + script_name);

  /* Fix output for C compiler */
  var re = /&gt;/g;
  sXML2 = sXML2.replace(re, ">");

  if (dowrite) {
    // Make sure the name isn't empty
    if (result_name.match(/[\/\\]$/) != null)
      result_name += "tmp";
    if (verbose > 1)
      echo("Creating " + result_name + result_suffix);
    var oFile = ofs.CreateTextFile(result_name + result_suffix);
    oFile.Write(sXML2);
    oFile.Close();
  }

  return sXML2;
}

function apply_transform(tree, result_name, script_path, script_name) {

  // Turn it into text and back
  var sXML2 = apply_script(tree, result_name,
                           "-" + nonsuffix(script_name) + ".xml",
                           script_path, script_name, debug);

  var oXML2 = new ActiveXObject(domdocument_name);
  oXML2.validateOnParse = false;
  oXML2.async = false;
  oXML2.schemas = schema_cache;
  if (!oXML2.loadXML(sXML2))
    loadError(oXML2, "loadXML failed " + nonsuffix(script_name) + ".xml");

  setprops(oXML2);
  return oXML2;
}

function basename(path) {
  var basenameregexp = new RegExp("[^/\\\\]*$", "");

  var result = path.match(basenameregexp);
  //echo("basename(" + path + ") -> " + result);
  return "" + result;
}

/*
function pathname(path) {
  var basenameregexp = new RegExp("[/\\\\][^/\\\\]*$", "");

  if (path == "")
    return path;

  var result = path.replace(basenameregexp, "");
  echo("pathname(" + path + ") -> " + result);
  return "" + result;
}
*/

function nonsuffix(path) {
  var suffixregexp = /[.][^.]*$/;
  var result = path.replace(suffixregexp, "");
  //echo("nonsuffix(" + path + ") -> " + result);
  return "" + result;
}

function suffix(path) {
  var suffixregexp = /([.][^.]*)$/;
  path.match(suffixregexp);
  var result = "" + RegExp.$1;
  //echo("suffix(" + path + ") -> " + result);
  return result;
}


function makedir(path) {
  if (path == "")
    return;

  var basename = new RegExp("[/\\\\][^/\\\\]*$", "");
  if (path.match(basename) != null) {
    makedir(path.replace(basename, ""));
  }

  if (!ofs.FolderExists(path)) {
    if (verbose > 0)
      echo("mkdir " + path);
    ofs.CreateFolder(path);
  }
}

function split_files(s, path, prefix, suffix, delim, category, prelude) {
  var re = new RegExp("@FILE:([^ ]+) [*]/([^@]+)", "");
  var zap = new RegExp("/[*] $", "");
  var ampersands = new RegExp("&amp;", "g");
  var ampersands2 = new RegExp("&lt;", "g");
  var basename = new RegExp("[/\\\\][^/\\\\]*$", "");
  var m = s.match(re);
  var objlist = "";
  var file = "";
    
  while (m != null) {
    if (file != m[1]) {
      file = m[1];
      var contents = m[2];

      // Zap possible "/* " from end of contents
      contents = contents.replace(zap, "");

      makedir(path);
      if (file.match(basename) != null) {
        makedir(path + file.replace(basename, ""));
      }

      if (category == "h") {
        var name = path + file;
      } else if (category == "package") {
        var name = path + file;
      } else if (category == "i") {
        // Create import files in subdir to avoid unnecessary recompilation
        makedir(path + "tmp");
        var name = path + "tmp\\" + file + suffix;
      } else if (category == "c") {
        // Create classes in another subdir so as to run tr in them
        makedir(path + "tmp2");
        var name = path + "tmp2\\" + file + delim + category + suffix;
        // Another special hack: replace &amp; with &
        contents = contents.replace(ampersands, "&");
        contents = contents.replace(ampersands2, "<");
      } else if (category == "m") {
        // Create import files in subdir to avoid unnecessary recompilation
        makedir(path + "tmp3");
        var name = path + "tmp3\\" + prefix + delim + file + delim + category + suffix;
      } else {
        var name = path + prefix + delim + file + delim + category + suffix;
      }
      if (verbose > 1)
        echo("Creating " + name);
      var oFile = ofs.CreateTextFile(name);
      oFile.Write(prelude);
      oFile.Write(contents);
      oFile.Write("\n");
      oFile.Close();

      if (category == "h")
        objlist += " $(GEN_INC_DIR)\\" + file;
      else if (category == "package")
        objlist += " package\\" + file;
      else if (category == "v" || category == "t")
        objlist += " $(GEN_INC_DIR)\\" + prefix + delim + file + delim + category + suffix;
      else
        objlist += " " + prefix + delim + file + delim + category + "." + objsuffix;
    }

    s = s.slice(m[0].length);
    m = s.match(re);        
  }

  return objlist;
}

function apply_and_split(tree, path, prefix, suffix, scriptpath, script_name, mkvar, category, prelude) {
  var delim = "_";
  if (category == "")
      delim = "";
  var suff = delim + category + suffix;
  if (category == "h" || category == "package")
    suff = suffix;

  var contents = apply_script(tree, path + prefix, suff, scriptpath, script_name, debug);
  var filelist = split_files(contents, path, prefix, suffix, delim, category, prelude);

  var mkfile;
  if (category == "h" || category == "v" || category == "t" || category == "m" || category == "package")
    mkfile = path + mkvar + ".mk";
  else if (mkvar == "HTML_FILES") {
    mkfile = path + "map.inc";
    filelist = filelist.replace(/obj/g, "htm");
    filelist = filelist.replace(/([a-zA-Z0-9_.,:]+)/g, "  <L url='$1' pth='toc-2' />\n");
  } else if (category == "")
    return;
  else
    mkfile = path + prefix + delim + category + ".mk";

  if (verbose > 1)
    echo("Generating " + mkfile);
  var oFile = ofs.CreateTextFile(mkfile);
  if (category != "")
      oFile.Write(mkvar + "=");
  oFile.Write(filelist + "\n");
  oFile.Close();
}

// This function handles <include> tags
function handle_includes(tree) {
  while (true) {
    //var nodelist = tree.selectNodes("//*[name() = 'include']");
    var nodelist = tree.selectNodes("//mic:include");
    if (verbose > 0)
      echo("Found " + nodelist.length + " includes");

    if (nodelist.length == 0)
        break;

    for (var i = 0; i < nodelist.length; i++) {
      //echo("NODE: " + nodelist.item(i).namespaceURI + ":" +  nodelist.item(i).nodeName);
      var select = nodelist.item(i).getAttribute("select");
      var file = nodelist.item(i).getAttribute("file");
      var optional = nodelist.item(i).getAttribute("optional");
      var silent = nodelist.item(i).getAttribute("silent");
      var tgt = load_xml(file, false, false, optional == "true");

      if (tgt == null) {
        if (optional == "true") {
          echo("Skipped optional " + file + " (not found)");
          // Done with include, let it go.
          nodelist.item(i).parentNode.removeChild(nodelist.item(i));
          continue;
        }
        alert(file + " not found");
      }
      var nl2 = tgt.selectNodes(select);

      var nlgroup = tgt.selectNodes("//mic:interface-group");
      if (nlgroup.length > 0) {
        var mygroup = nlgroup.item(0).getAttribute("name");
        if (verbose > 2)
          echo("MyGroup is " + mygroup);

        // Add mygroup attributes to interfaces
        var nl3 = tgt.selectNodes("//mic:interface");
        for (var j = 0; j < nl3.length; j++)
          nl3.item(j).setAttribute("mygroup", mygroup);
      }

      var mygroup="UNKNOWN";
      nlgroup = tgt.selectNodes("//mic:component-group|//mic:component");
      for (var j = 0; j < nlgroup.length; j++) {
        var node = nlgroup.item(j);
        //echo("NODE <" + node.baseName + ">");
        if (node.baseName == "component-group") {
          mygroup = node.getAttribute("name");
          if (verbose > 2)
            echo("MyGroup is " + mygroup);
        } else if (node.getAttribute("mygroup")) {
          if (verbose > 2)
            echo("Predefined group " + node.getAttribute("mygroup")
                 + " for component " + node.getAttribute("name"));
        } else {
          if (mygroup == 'UNKNOWN')
            alert("UNKNOWN component group for " + node.getAttribute("name"));
          node.setAttribute("mygroup", mygroup);
        }
      }

      if (verbose > 1 || nl2.length == 0)
          echo("" + (nl2.length==0 ? "Empty inclusion " : "") + "file=" + file
               + " select=" + select + " got " + nl2.length);
      if (silent != "true" && nl2.length > 0) {
        // Record what file this node came from.
        // Only the first one so as to show change.
        nl2.item(0).setAttribute("original-file", nonsuffix(basename(file)));
      }

      // flatten entries and insert into global tree
      for (var j = 0; j < nl2.length; j++) {
        //echo(nl2.item(j).xml);
        nodelist.item(i).parentNode.insertBefore(nl2.item(j), nodelist.item(i));
      }

      // Done with include, let it go.
      nodelist.item(i).parentNode.removeChild(nodelist.item(i));
    }
  }

  return tree;
}

// This function handles @documentation-file tags and imports documentation
// tags from the file to all the right places (top, methods, args).
function handle_docincludes(tree) {
  // XXX Broken after I had to remove parentheses for XSLT upgrade
  var categories = "//interface|concrete-class|component|profile|hardware-platform|product";

  var nodelist = tree.selectNodes(categories + "[@documentation-file]");
  if (nodelist.length > 0 && verbose > 0)
    echo("Found " + nodelist.length + " @documentation-file refs");
  for (var i = 0; i < nodelist.length; i++) {
    var item = nodelist.item(i);
    var file = item.getAttribute("documentation-file");
    var name = item.getAttribute("name");
    var tgt = handle_includes(load_xml(file, false, true, false));

    // Handle /interface level includes
    var tgtlist = tgt.selectNodes(categories + "[@name = '"
                                  + name + "']/(P|description|discussion|see-also|example)");
    if (verbose > 1)
      echo("file= " + file + " name=" + name +" got " +tgtlist.length);
    for (var t = 0; t < tgtlist.length; t++) {
      //echo(tgtlist.item(t).xml);
      item.insertBefore(tgtlist.item(t), null);
    }
    var methods = item.selectNodes("mic:method");
    if (verbose > 1)
      echo("Got " + methods.length + " methods from " + name);
    for (var j = 0; j < methods.length; j++) {
      var method = methods.item(j);
      var methodname = method.getAttribute("name");
      tgtlist = tgt.selectNodes(categories + "[@name = '"
                                + name + "']/method[@name = '"
                                + methodname + "']/(P|description|discussion|see-also|example|return-value)");
      if (verbose > 1)
        echo("name=" + name + " methodname=" + methodname + " got " + tgtlist.length);
      for (t = 0; t < tgtlist.length; t++) {
        //echo(tgtlist.item(t).xml);
        method.insertBefore(tgtlist.item(t), null);
      }
      var args = method.selectNodes("mic:arg");
      if (verbose > 1)
        echo("Got " + args.length + " args from " + methodname);
      for (var k = 0; k < args.length; k++) {
        var arg = args.item(k);
        var argname = arg.getAttribute("name");
        tgtlist = tgt.selectNodes(categories + "[@name = '"
                                  + name + "']/method[@name = '"
                                  + methodname + "']/arg[@name = '"
                                  + argname + "']/(P|description|discussion|see-also|example)");
        if (verbose > 1)
          echo("argname=" + argname + " got " + tgtlist.length);
        for (t = 0; t < tgtlist.length; t++) {
          //echo(tgtlist.item(t).xml);
          arg.insertBefore(tgtlist.item(t), null);
        }
      }
    }
  }

  return tree;
}

// This function handles @sample-file tags and imports the C code
function handle_sample_files(tree) {
  var nodelist = tree.selectNodes("//node()[@sample-file]");
  if (nodelist.length > 0 && verbose > 0)
    echo("Found " + nodelist.length + " @sample-file refs");
  for (var i = 0; i < nodelist.length; i++) {
    var item = nodelist.item(i);
    var file = item.getAttribute("sample-file");
    var name = item.getAttribute("name");
    // Get file and read contents
    if (verbose > 2)
      echo("name=\"" + name + "\" gets file " + file);
    var f = ofs.GetFile(file);
    if (f == null)
      alert("Could not open " + file);
    //echo("is " + f.Type + " Size=" + f.Size);
    var ff = f.OpenAsTextStream(1, 0);
    var content = ff.ReadAll();
    ff.Close();
    ff = f = null;
    // Extract code fragment if marked with BEGIN_SAMPLE ... END_SAMPLE
    if (Number(ScriptEngineMajorVersion() + "." + ScriptEngineMinorVersion()) >= 5.5) {
      var begin = new RegExp("(^.*BEGIN_SAMPLE *[*]/.*$)", "m");
      var end = new RegExp("(^.*END_SAMPLE *[*]/.*$)", "m");
      if (begin.exec(content) != null) {
        content = RegExp.rightContext.slice(1);
      }
      if (end.exec(content) != null) {
        content = RegExp.leftContext.slice(0, -1);
      }
    } else {
      echo("Warning: Need IE 5.5 or newer to get samples formatted properly");
    }

    //echo(content);
    var newnode = tree.createTextNode (content);
    item.insertBefore(newnode, null);
  }

  return tree;
}

function make_iid_files(tt, targetdir, prefix) {
  if (verbose > 0)
    echo("Generating IID files");
  // Create individual files for iids.
  var nodelist = tt.selectNodes("/exp:mmlite-spec/exp:interface");
  var iidfiles="IIDOBJS = ";
  if (nodelist.length > 0) {
    // Convert iid representation from dashed list to C struct.
    // Two regexps are needed because $10 and $11 dont work
    var re1 = /^([0-9a-f]{8})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{2})([0-9a-f]{2})-/i;
    var rere1 = "{0x$1, 0x$2, 0x$3, {0x$4, 0x$5, -";

    var re2 = /-([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i;
    var rere2 = "0x$1, 0x$2, 0x$3, 0x$4, 0x$5, 0x$6}}";

    // Create iid files in subdir to avoid unnecessary recompilation
    var tmptargetdir = targetdir + "tmp\\";
    makedir(tmptargetdir);

    for (var i = 0; i < nodelist.length; i++) {
      var ifacename = nodelist.item(i).getAttribute("name");
      var suffix = "_" + ifacename + "_iid.c";
      var iid = nodelist.item(i).getAttribute("iid");
      var ciid = iid.replace(re1, rere1).replace(re2, rere2);
      var contents = "#include <mmlite.h>\n\nconst struct IID IID_" + ifacename + " = " + ciid + ";\n";
      if (verbose > 1)
        echo("Generating " + tmptargetdir + prefix + suffix);

      var oFile = ofs.CreateTextFile(tmptargetdir + prefix + suffix);
      oFile.Write(contents);
      oFile.Close();

      iidfiles += " " + prefix + "_" + ifacename + "_iid." + objsuffix;
    }
  }
  var oFile = ofs.CreateTextFile(targetdir + prefix + "_iids.mk");
  oFile.Write(iidfiles + "\n");
  oFile.Close();
}

// Add relative size-is-pos and length-is-pos numeric attributes
// to args that have size-is and length-is attributes.
// The reason is that I couldn't figure out how to easily do this in XSL
// - unfortunately the position() function does not take an argument.
function add_sizeis_pos_tags(tt)
{
    // Go through all methods that have some size-is or length-is arguments
    var ml = tt.selectNodes("//exp:method[exp:arg/@size-is|exp:arg/@length-is|exp:arg/@type-is|exp:arg/@selector-is]|//exp:method-response[exp:arg/@size-is|exp:arg/@length-is|exp:arg/@type-is|exp:arg/@selector-is]|//exp:extended-method[exp:arg/@size-is|exp:arg/@length-is|exp:arg/@type-is]|//exp:struct[exp:field/@size-is|exp:field/@length-is|exp:field/@type-is|exp:field/@selector-is]");
    if (verbose > 1)
        echo("add_sizeis: " + ml.length + " methods");
    for (var i = 0; i < ml.length; i++) {
        var al = ml.item(i).selectNodes("exp:arg|exp:field");
        if (verbose > 1)
            echo("Method " + ml.item(i).getAttribute("name") + " has " + al.length + " args");
        for (var j = 0; j < al.length; j++) {
            // If this arg has a size-is find the corresponding arg.
            var si = al.item(j).getAttribute("size-is");
            var found = false;
            if (si) {
                for (var k = 0; k < al.length; k++) {
                    if (k == j)
                        continue;
                    if (al.item(k).getAttribute("name") == si) {
                        if (verbose > 1)
                            echo("Method " + ml.item(i).getAttribute("name") +
                                 " arg " + al.item(j).getAttribute("name") +
                                 " ix " + j + " size-is ix " + k);
                        // Stuff a size-is-pos arg into it
                        al.item(j).setAttribute("size-is-pos", ""+ k-j);
                        found = true;
                    }
                }
                if (!found)
                    alert("Unmatched size-is attribute: Method " +
                          ml.item(i).getAttribute("name") +
                          " arg " + al.item(j).getAttribute("name") +
                          " interface=" + ml.item(i).selectSingleNode("..").getAttribute("name"));
                
            }
        }
        // Same for length-is
        for (var j = 0; j < al.length; j++) {
            // If this arg has a length-is find the corresponding arg.
            var si = al.item(j).getAttribute("length-is");
            var found = false;
            if (si) {
                for (var k = 0; k < al.length; k++) {
                    if (k == j)
                        continue;
                    if (al.item(k).getAttribute("name") == si) {
                        if (verbose > 1)
                            echo("Method " + ml.item(i).getAttribute("name") +
                                 " arg " + al.item(j).getAttribute("name") +
                                 " ix " + j + " length-is ix " + k);
                        // Stuff a length-is-pos arg into it
                        al.item(j).setAttribute("length-is-pos", ""+ k-j);
                        found = true;
                    }
                }
                if (!found)
                    alert("Unmatched length-is attribute: method=" +
                          ml.item(i).getAttribute("name") +
                          " arg=" + al.item(j).getAttribute("name") +
                          " interface=" + ml.item(i).selectSingleNode("..").getAttribute("name"));
                
            }
        }
        // Same for type-is
        for (var j = 0; j < al.length; j++) {
            // If this arg has a type-is find the corresponding arg.
            var si = al.item(j).getAttribute("type-is");
            var found = false;
            if (si) {
                for (var k = 0; k < al.length; k++) {
                    if (k == j)
                        continue;
                    if (al.item(k).getAttribute("name") == si) {
                        if (verbose > 1)
                            echo("Method " + ml.item(i).getAttribute("name") +
                                 " arg " + al.item(j).getAttribute("name") +
                                 " ix " + j + " type-is ix " + k);
                        // Stuff a length-is-pos arg into it
                        al.item(j).setAttribute("type-is-pos", ""+ k-j);
                        found = true;
                    }
                }
                if (!found)
                    alert("Unmatched type-is attribute: method=" +
                          ml.item(i).getAttribute("name") +
                          " arg=" + al.item(j).getAttribute("name") +
                          " interface=" + ml.item(i).selectSingleNode("..").getAttribute("name"));
                
            }
        }
        // Same for selector-is
        for (var j = 0; j < al.length; j++) {
            // If this arg has a type-is find the corresponding arg.
            var si = al.item(j).getAttribute("selector-is");
            var found = false;
            if (si) {
                for (var k = 0; k < al.length; k++) {
                    if (k == j)
                        continue;
                    if (al.item(k).getAttribute("name") == si) {
                        if (verbose > 1 || 1)
                            echo("Method " + ml.item(i).getAttribute("name") +
                                 " arg " + al.item(j).getAttribute("name") +
                                 " ix " + j + " selector-is ix " + k);
                        // Stuff a length-is-pos arg into it
                        al.item(j).setAttribute("selector-is-pos", ""+ k-j);
                        found = true;
                    }
                }
                if (!found)
                    alert("Unmatched selector-is attribute: method=" +
                          ml.item(i).getAttribute("name") +
                          " arg=" + al.item(j).getAttribute("name") +
                          " interface=" + ml.item(i).selectSingleNode("..").getAttribute("name"));
                
            }
        }
    }
}

// Add saveindex attribute. This is the count of args that
// need to be saved (before this one) plus an extra slot for arrays (lengths)
// This is used for allocating storage area for callee saved values that
// are needed for reply marshaling in the SOAP server. One-based.
//
// The reason for doing this here instead of XSL is that I couldn't 
// figure out how to easily do this in XSL.
// The reason for doing this offline rather than at run-time is that
// the data should be ROMable.

function add_saveindex(tt)
{
    // Go through all methods
    var ml = tt.selectNodes("//exp:method|//exp:method-response|//exp:extended-method");
    if (verbose > 1)
        echo("add_saveindex: " + ml.length + " methods");
    for (var i = 0; i < ml.length; i++) {
        var saveindex = 1;
        var al = ml.item(i).selectNodes("exp:arg");
        if (verbose > 1)
            echo("Method " + ml.item(i).getAttribute("name") + " has " + al.length + " args");
        for (var j = 0; j < al.length; j++) {
            // If this arg is "in" only or it is size-of or length-of skip it.
            var a = al.item(j).getAttribute("direction");
            if (a == "in")
                continue;
            a = al.item(j).getAttribute("size-of");
            if (a)
                continue;
            a = al.item(j).getAttribute("length-of");
            if (a)
                continue;

            al.item(j).setAttribute("saveindex", ""+ saveindex);
            if (verbose > 1)
                echo("Saveindex method " + ml.item(i).getAttribute("name") + " = " + saveindex);
            saveindex++;
            /* For arrays one slot for size */
            if (al.item(j).getAttribute("is-array")
                || al.item(j).getAttribute("length-is"))
                saveindex++;
        }
        ml.item(i).setAttribute("savecount", ""+ saveindex);
    }
}


function make_code_files(tt, targetdir, prefix, scriptpath, product) {
  if (verbose > 0)
    echo("Generating IDL files");
prefix="s";

  var target = targetdir + prefix;
  apply_script(tt, target, ".idl", scriptpath, "genidl.xsl", true);

  if (cpuname == "i386")
      var prelude = "#include <mmlite.h>\n";
  else
      var prelude = "#include <mmlite.h>\n";

  if (verbose > 0)
    echo("Generating import functions");
  apply_and_split(tt, targetdir, prefix, ".c", scriptpath, "genimp.xsl", "IMPORT_OBJS", "i", prelude);

  if (verbose > 0)
    echo("Generating C headers");
  apply_and_split(tt, targetdir, prefix, ".h", scriptpath, "gencheader.xsl", "INCLUDE_FILES", "h", "");

  if (verbose > 0)
    echo("Generating C++ header");
  apply_script(tt, target, ".hpp", scriptpath, "gencplusheader.xsl", true);

  if (verbose > 0)
    echo("Generating v-tables and component descriptors");
  var prelude = "#include <mmlite.h>\n";
  apply_and_split(tt, targetdir, prefix, ".c", scriptpath, "genvtab.xsl", "VTAB_FILES", "v", prelude);

  if (verbose > 0)
    echo("Generating stub classes");
  contents = apply_and_split(tt, targetdir, prefix, ".c", scriptpath, "gencclass.xsl", "STUB_CLASS_FILES", "c", "");

  if (verbose > 0)
    echo("Generating DLL exports");
  apply_script(tt, target, ".def", scriptpath, "gendlldef.xsl", true);

  if (verbose > 0)
    echo("Generating package makefiles");
  apply_script(tt, target + "-pack", ".mk", scriptpath, "genpackmk.xsl", true);
  apply_script(tt, target + "-pack2", ".mk", scriptpath, "genpackmk2.xsl", true);
  apply_script(tt, target + "-imp", ".mk", scriptpath, "genimpmk.xsl", true);

  if (verbose > 0)
    echo("Generating package C files");
  apply_and_split(tt, targetdir, "", ".c", scriptpath, "genpackc.xsl",
                  "PACKAGE_C_FILES", "package", prelude);

  if (verbose > 0)
    echo("Generating typeinfo");
  tt = apply_transform(tt, target, scriptpath, "gentypeinfo0.xsl");
  tt = apply_transform(tt, target, scriptpath, "gentypeinfo.xsl");

  // Write a file and expand to tree (could be combined...)
  apply_script(tt, target, "-typeinfo.xml", scriptpath, "gentypeinfo2.xsl", true);

  tt = apply_transform(tt, target, scriptpath, "gentypeinfo2.xsl");
  setprops2(tt);
  apply_and_split(tt, targetdir, prefix, ".c", scriptpath, "gentypeinfo-c.xsl", "TYPEINFO_OBJS", "m", prelude);
  if (verbose > 0)
    echo("Generating tokens");
  apply_and_split(tt, targetdir, prefix, ".h", scriptpath, "gentoken.xsl", "TOKEN_FILES", "t", prelude);
}

function expand_spec(tree, target, scriptpath) {
  tree = apply_transform(tree, target, scriptpath, "expand0.xsl");
  tree = apply_transform(tree, target, scriptpath, "expand1.xsl");
  tree = apply_transform(tree, target, scriptpath, "expand2.xsl");
  tree = apply_transform(tree, target, scriptpath, "expand3.xsl");
  tree = apply_transform(tree, target, scriptpath, "expand4.xsl");
  tree = apply_transform(tree, target, scriptpath, "expand5.xsl");
  tree = apply_transform(tree, target, scriptpath, "exptypes.xsl");
  setprops2(tree);
  add_sizeis_pos_tags(tree);
  add_saveindex(tree);

  if (verbose > 1) {
    // Make sure the name isn't empty
    if (target.match(/[\/\\]$/) != null)
      target += "tmp";
    if (verbose > 1)
      echo("Creating " + target + "-added.xml");
    var oFile = ofs.CreateTextFile(target + "-added.xml");
    oFile.Write(tree.xml);
    oFile.Close();
  }

  return tree;
}

function include_codedata(tree, codedatafile) {
  var content = "";
  var treetext;

  if (verbose > 0)
    echo ("Inserting data from " + codedatafile);

  var f = ofs.GetFile(codedatafile);
  if (f.Size != 0) {
    var ff = f.OpenAsTextStream(1, 0);
    content = ff.ReadAll();
    ff.Close();
    ff = f = null;
  }

  treetext = "" + tree.xml;
  treetext = treetext.replace(/\<\/mmlite-spec\>/, content + "</mmlite-spec>");

  tree.validateOnParse = false;
  tree.schemas = schema_cache;
  if (!tree.loadXML(treetext))
    loadError(tree, "LoadXML failed");

  setprops(tree);

  return tree;
}

function filter_for_product(tt, product) {
  // Delete nodes not matching our product
  var nodelist = tt.selectNodes("/mmlite-spec/(concrete-class|component|image|group|profile|device|hardware-platform)[not(product-name) or $all$ product-name != '" + product + "' ]");
  var specnode = tt.selectSingleNode("/mmlite-spec");
  if (nodelist.length > 0)
    echo("Deleting " + nodelist.length + " nodes");
  for (var i = 0; i < nodelist.length; i++) {
    specnode.removeChild(nodelist.item(i));
  }
}

function swap_schema(tree, filename) {
  var re = new RegExp("<mmlite-spec[^>]+>", "");

  if (verbose > 1)
    echo("Creating " + filename);
  var file = ofs.CreateTextFile(filename);
  file.Write(tree.xml.replace(re, "<mmlite-spec xmlns=\"x-schema:expanded-schema.xml\">"));
  file.Close();

  namespaces = null;
  var tree = load_xml(filename, true, true, false);
  setprops2(tree);
  return tree;
}

function make_doc_files(tt, webpath, scriptpath) {
  if (verbose > 0)
    echo("Generating html pages in " + webpath);
  apply_and_split(tt, webpath, "", ".htm", scriptpath, "genhtml.xsl", "HTML_FILES", "", "");
  apply_and_split(tt, webpath, "", ".htm", scriptpath, "gendocindex.xsl", "HTML_DOC_INDEX_FILES", "", "");
  if (verbose > 1)
    echo("Generating " + webpath + "manual.htm");
  apply_script(tt, webpath + "manual", ".htm", scriptpath, "genmanual.xsl", true);
  apply_script(tt, webpath + "filelist", ".htm", scriptpath, "genfilelist.xsl", true);
  apply_script(tt, webpath + "definitions", ".htm", scriptpath, "gendefs.xsl", true);
  //apply_script(tt, webpath + "toc", ".xml", scriptpath, "gentoc.xsl", true);
  apply_script(tt, webpath + "toc-2", ".xml", scriptpath, "gentoc2.xsl", true);
  apply_script(tt, webpath + "map2.inc", ".xml", scriptpath, "gentocmap2.xsl", true);
  apply_and_split(tt, webpath, "", ".xml", scriptpath, "gencomponentlist.xsl", "COMPONENT_DESCRIPTOR_FILES", "", "");
}

function genspec(inputxml, doctarget, codetarget, codeprefix, product, scriptpath, codedatafile)
{
  schema_cache.add("x-schema:spec-schema.xml", "spec-schema.xml");
  schema_cache.add("x-schema:expanded-schema.xml", "expanded-schema.xml");
  var tree = load_xml(inputxml, false, true, false);

  if (verbose > 0)
    echo("Expanding and inheriting " + inputxml);

  // Print XML into string and reparse with checking
  tree = handle_includes(tree);
  if (doctarget != null) {
    tree = handle_docincludes(tree);
    tree = handle_sample_files(tree);
  }

  if (codetarget) {
    // Output a merged file before validation so that we get line numbers
    var mergedname = codetarget + codeprefix + "-merged.xml";
    if (verbose > 1)
      echo("Creating " + mergedname);
    var file = ofs.CreateTextFile(mergedname);
    file.Write(tree.xml);
    file.Close();
    tree = load_xml(mergedname, true, true, false);
  } else {
    tree = validate_xml(tree);
  }
  // Zap old schema and put in new one.
  tree = swap_schema(tree, codetarget
                     ? (codetarget + codeprefix + "-swapped.xml")
                     : doctarget + "/tmp.xml");

  if (codetarget)
    tree = expand_spec(tree, codetarget + codeprefix, scriptpath);
  else if (doctarget)
    tree = expand_spec(tree, doctarget + "/", scriptpath);
  else
    return;

  if (codedatafile != null)
      tree = include_codedata(tree, codedatafile);

  if (doctarget != null)
      make_doc_files(tree, doctarget + "/", scriptpath);

  if (docindexfile != null) {
    echo ("Generating index file " + docindexfile);
    apply_script(tree, docindexfile, "", scriptpath, "gendocindex2.xsl", true);
  }

  if (codetarget != null) {
    setprops2(tree);

    if (verbose > 0)
        echo("cpu=" + cpuname);

    if (debug) {
      var filteredname = codetarget + codeprefix + "-filtered.xml";
      if (verbose > 1)
        echo("Creating " + filteredname);
      var file = ofs.CreateTextFile(filteredname);
      file.Write(tree.xml);
      file.Close();
    }

    make_code_files(tree, codetarget, codeprefix, scriptpath, product);
    make_iid_files(tree, codetarget, "s");
  }
}

function alert(str) {
  if (WScript != null) {
    WScript.Echo(str);
    WScript.Quit(1);
  } else {
    echo("ALERT: " + s);
  }
}

function echo(s) {
  if (WScript != null) {
    WScript.Echo(s);
  } else {
    oLog.WriteLine(s);
  }
}

// --> From web page ASP
function gendocfromweb(inputxml, doctarget, _ofs, path) {
  ofs = _ofs;
  oLog = ofs.CreateTextFile(path + "/genspec.log", true);
  inputpath = path + "/";
  verbose = 2;
  genspec(inputxml, doctarget, null, null, null, path, null);
}

function usage() {
  alert("USAGE: genspec [-v] [-v] [-d] [-n code-prefix] [-o code-dir] [-w web-path] [-p cpu-name] [-i index-file] [-p object-suffix] source-file\nExample1: genspec -o /foo/obj -n spec -w /foo/web -p aeb-std spec.xml\nExample2: genspec -w /foo/web spec.xml\nExample3: genspec -o /foo/obj/spec -p pc-http -s o spec.xml\nNote that -o requires -p");
}

// main()  --> From command line CScript
if (WScript != null) {
  var codetarget = null;
  var codeprefix = null;
  var doctarget = null;
  var src_dir2 = null;
  var src_dir3 = null;
  var codedata = null;
  var product = null;
  var verbose = 0;
  var debug = false;

  var args = WScript.arguments;
  var consumedargs = 0;
  for (var i = 0; i < args.length; i++) {
    switch(args.item(i)) {
    case "-o":
      if (args.length - i < 2)
        usage();
      codetarget = args.item(++i);
      consumedargs += 2;
      break;
    case "-c":
      if (args.length - i < 2)
        usage();
      codedata = args.item(++i);
      consumedargs += 2;
      break;
    case "-i":
      if (args.length - i < 2)
        usage();
      docindexfile = args.item(++i);
      consumedargs += 2;
      break;
    case "-n":
      if (args.length - i < 2)
        usage();
      codeprefix = args.item(++i);
      consumedargs += 2;
      break;
    case "-w":
      if (args.length - i < 2)
        usage();
      doctarget = args.item(++i);
      consumedargs += 2;
      break;
    case "-d2":
      if (args.length - i < 2)
        usage();
      src_dir2 = args.item(++i);
      consumedargs += 2;
      break;
    case "-d3":
      if (args.length - i < 2)
        usage();
      src_dir3 = args.item(++i);
      consumedargs += 2;
      break;
    case "-p":
      if (args.length - i < 2)
        usage();
      cpuname = args.item(++i);
      consumedargs += 2;
      break;
    case "-s":
      if (args.length - i < 2)
        usage();
      objsuffix = args.item(++i);
      consumedargs += 2;
      break;
    case "-v":
      verbose++;
      consumedargs++;
      break;
    case "-d":
      debug = true;
      consumedargs++;
      break;
    }
  }

  if (args.length - consumedargs != 1)
    usage();
  if (codetarget != null && cpuname == null)
    usage();

  var inputxml = args.item(consumedargs);

  ofs = WScript.CreateObject("Scripting.FileSystemObject");
  var scriptpath = ofs.getParentFolderName(WScript.scriptFullName);

  genspec(inputxml, doctarget, codetarget, codeprefix, product, scriptpath, codedata);
}
