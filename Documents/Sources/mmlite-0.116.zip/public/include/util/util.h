/* Header file for miscellaneous utility functions and definitions..
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __UTIL_H__
#define __UTIL_H__

#include <mmlite.h>

PRIVATE INLINE void
DelayMilli(
    int mSecs
    )
{
  TIME t0;
  TIME t;
  t0 = CurrentTime();
  Int32ToInt64(t, TIME_MILLIS(40));
  t = TimeAdd(t0, t);
  while (!TimeLess(CurrentTime(), t));
}

PRIVATE INLINE void
MilliSleep(
    int mSecs
    )
{
  TIME t;
  Int32ToInt64(t, TIME_RELATIVE(TIME_MILLIS(mSecs)));
  SleepUntil(t);
}

/* Used for linked list transforms */
typedef void (* TransformArgFunc)(PTR, PTR);
typedef void (* TransformFunc   )(PTR);

/* Used for linked list sorted operations */
typedef BOOL (* CompareFunc     )(PTR, PTR);

#endif /* __UTIL_H__ */
