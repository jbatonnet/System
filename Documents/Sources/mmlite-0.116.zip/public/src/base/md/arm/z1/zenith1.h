/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Reference:
 * "Zenith Platform-2, USER MANUAL"
 * PubNo ?? Rev ??
 * Editor: Microsoft Corporation, 2001
 *
 * Definitions for the Zenith Platform-2 board(s)
 * See the at91x40 doc for the processor defines.
 */

/* The board uses a ????MHz crystal as reference clock.
 */
#define Z1Crystal (22118400) /* 22+MHz */

/* The timer code uses TC0 and TC1 for timing purposes
 */
#define ThePIT (&Tc0->Channel0)
#define TheRTC (&Tc0->Channel1)
#define TheCNT (&Tc0->Channel2)

/* The timer code auto-detects the clock frequency
 */
typedef struct _TIMER_CONFIG {
    UINT32 ClockFrequency;  /* in Hz */
    UINT8 PitClockScaler;
    UINT8 PitShiftValue;
    UINT16 RtcTicks;
    TIME RtcClockTick;
    TIME PitMaxInterval;
} TIMER_CONFIG;

extern TIMER_CONFIG Z1TimerConfig[];

#define Z1Clock Z1TimerConfig[0].ClockFrequency

/* Chip selects
 */
#define FLASH_CHIP_SELECT 0
#define SRAM_CHIP_SELECT  1  /* external! */
#define LCD_CHIP_SELECT 2

/* GPIO usage:
 * P0  ? T0_CLK
 * P1  ? T0_A
 * P2  ? T0_B
 * P3  - Boot select (jumper NN, 0 if jumper NOT installed)
 * P4  - Boot select (jumper NN, 0 if jumper NOT installed)
 * P5  - Debug connector
 * P6  - 32768Hz clock
 * P7  - Button 1
 * P8  - Button 2
 * P9  ? IRQ0
 * P10 ? IRQ1
 * P11 ? IRQ2
 * P12 ? FIQ
 * P13 ? SCLK0
 * P14 - TXD0 (debug board)
 * P15 - RXD0 (debug board)
 * P16 - Button 3
 * P17 - Button 4
 * P18 - Button 5
 * P19 - Button 6
 * P20 ? SCLK1
 * P21 - TXD1 (debug board)
 * P22 - RXD1 (debug board)
 * P23 - Battery DS2760 DQ
 * P24 - Piezo-speaker
 * P25 - Debug connector
 * P26 - chip-select for LCD panel
 * P27 ? CS3
 * P28 ? CS7
 * P29 ? CS6
 * P30 ? CS5
 * P31 ? CS4
 */

