/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <loaders/cobtab.h>

extern PIUNKNOWN DriverCfgCobMain(void);
extern PIUNKNOWN SerialCobMain(void);
extern PIUNKNOWN NullCobMain(void);
extern PIUNKNOWN SerplexCobMain(void);

const struct PRECOB ThePreCobTable[] = {
  {"drivercfg.cob", DriverCfgCobMain },
  {"drivers.cob", DriversCobMain },
  {"eb63usart.cob", SerialCobMain },
  {_T("serplex.cob"), SerplexCobMain },
#if 0
  {"null.cob", NullCobMain },
#endif
  {0,0}
};
