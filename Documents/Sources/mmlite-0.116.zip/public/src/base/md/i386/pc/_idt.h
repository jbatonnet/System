/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Specification for IDT-related functions.
 */

 /* Install/Remove an interrupt handler entry
  */
extern void InstallIsr( UINT InterruptNumber, ADDRESS Isr,
                       BOOL RawTrapNumber, BOOL UserAccessible);
