/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __MMLITE_MD_H__
#define __MMLITE_MD_H__

typedef signed char INT8;       /* size is 1 */
typedef unsigned char UINT8;    /* size is 1 */
typedef short INT16;            /* size is 2 */
typedef unsigned short UINT16;  /* size is 2 */
typedef long INT32;             /* size is 4 */
typedef unsigned long UINT32;   /* size is 4 */
/* in case we do not want the compiler supported ones (almost never) */
#if defined(__NO_BUILTIN_INT64)
typedef struct _INT64 INT64;
typedef struct _UINT64 UINT64;
#else
typedef signed __int64 INT64;   /* size is 8 */
typedef unsigned __int64 UINT64; /* size is 8 */
#endif

/* in case Windows.h was included first (benign redefinition) */
#pragma warning(disable:4142)
typedef INT32 INT;
typedef UINT32 UINT;
#pragma warning(default:4142)

#ifdef _MSC_VER
/* VC7 complains about volatile r-values */
#pragma warning(disable:4197)
#endif

#define _UINTSIZE ( 32 )
#ifdef _OLDSCHED
#define _MUTEX_STATE_SIZE       ( 1 )
#define _CONDITION_STATE_SIZE   ( 2 )
#else
#define _MUTEX_STATE_SIZE       ( 5 )
#define _CONDITION_STATE_SIZE   ( 3 )
#endif

struct  _FPAINFO                /* size is 108 */
{
    UINT32 ControlWord;
    UINT32 StatusWord;
    UINT32 TagWord;
    UINT32 ErrorOffset;
    UINT32 ErrorSelector;
    UINT32 DataOffset;
    UINT32 DataSelector;
    UINT16 Registers[ 5 ][ 8 ];
};

struct  _CXTINFO                /* size is 72 */
{
    struct _FPAINFO *pFpa;
    UINT32 EDI;
    UINT32 ESI;
    UINT32 EBP;
    UINT32 PAD;
    UINT32 EBX;
    UINT32 EDX;
    UINT32 ECX;
    UINT32 EAX;
    UINT32 FS;
    UINT32 GS;
    UINT32 ES;
    UINT32 DS;
    UINT32 EIP;
    UINT32 CS;
    UINT32 EFL;
    /* NOTE: ESP and SS are valid only if CS indicates user mode
     * Otherwise the actual saved stack starts at the ESP location
     * and the stack pointer is implicit.
     */
    UINT32 ESP;
    UINT32 SS;
};

#define __DebugBreak() __asm { __asm int 3 __asm }

/* Frequently needed processor dependent constants. */
#define _DCACHELINESIZE 16      /* Size in bytes of data-cache line   */
#define _PAGE_SIZE (4096)
#define _PAGE_SHIFT (12)

#endif /* __MMLITE_MD_H__ */
