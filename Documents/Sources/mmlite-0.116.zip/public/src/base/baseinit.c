/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define OPTIMIZE        /* enable Base.h optimizations, since we're the "base" */

#include <mmlite.h>
#include <fred.h>
#ifdef _OLDSCHED
#include "../base/process.h"
#else
#include <base/process2.h>
#endif
#include <base/cons.h>
#include <base/schedul.h>       /* XXX constructor */

#if defined(_DEBUG)
#define DBG(_x_) printf _x_
#define _USE_DEBUG_HEAP
#else
#define DBG(_x_)
#endif

#include <heaps/dbg_heap.h>

extern PUBLIC SCODE MCT BaseInitializeClassRegistry(void);
#if __SUPPORTS_COB_NAMESPACE
extern BOOL CobInit(void);
#endif

/* xxx globals xxx */
PIPIC pThePic = NULL;
PIHEAP pTheHeap = NULL;
PINAMESPACE pTheNameSpace = NULL;
PISCHEDULER pTheScheduler = NULL;
#ifdef _USE_DEBUG_HEAP
PIHEAP pDebugHeap = NULL;
#endif

/*
 * Base initialization.  This is the first MI function ever invoked.
 */
void BaseInit(void)
{
    PITHREAD TheThread;
    PIPROCESS TheProcess;
    static int BootCount = 0;

    BootCount++;
    DBG(("BaseInit: %sEntered, stack= ~0x%x\n",(BootCount>1) ? "Re" : "", (UINT) &TheThread));

    /* Initialize the memory allocator.
     */
    DBG(("BaseInit: Initializing heap\n"));
#if 0
    sc = CobPreLookup(_T("ff_heap.cob"), (PIUNKNOWN *) &HeapFactory);
    if (FAILED(sc)) {
        DBG(("CobPreLookup failed"));
        BaseDelete();
    }
#endif

    pTheHeap = MachineHeapCreate();

#ifdef _USE_DEBUG_HEAP
    pTheHeap = pDebugHeap = CreateDebugHeap(_T("system"), 0, 0, 8);
#if 0
    {
        PIHEAPFACTORY HeapFactory;
        SCODE sc;
        sc = CobPreLookup(_T("dbg_heap.cob"), (PIUNKNOWN *) &HeapFactory);
        if (SUCCEEDED(sc)) {
            sc = HeapFactory->v->CreateNested(HeapFactory, pTheHeap,
                                              0, 0, 8, &pDebugHeap);
            if (SUCCEEDED(sc))            
                pTheHeap = pDebugHeap;
        }
    }
#endif
#endif

    /* Deal with interrupts next.
     */
    DBG(("BaseInit: Calling PicCreate()\n"));
    pThePic = PicCreate();

#if 0 && defined(AEB)
    AddDevice((PTR) NULL, (void *) ButtonHit, 0, IRQ_ID_EXTRN0, 0);
#endif

    /* Initialize the scheduler
     */
    pTheScheduler = SchedulerCreate();

    /* Initialize the system timer
     */
    DBG(("BaseInit: Calling EnableTimers()\n"));
    EnableTimers();

    /* Initialize the name space.
     */
    DBG(("BaseInit: Initializing Namespace\n"));
    pTheNameSpace = NameSpaceNew(NULL);

#if __SUPPORTS_COB_NAMESPACE
    /* Initialize class registry
     */
    BaseInitializeClassRegistry();

    /* Initialize the COB demand-loading namespace
     */
    CobInit();
#endif

    /* Initialize the loader.
     * Also makes CurrentHeap() work for the thread.
     */
    DBG(("BaseInit: Initializing Loader\n"));
    TheProcess = InitializeIModule(pTheHeap, pTheNameSpace);

    /* Create the first thread. Must succeed.
     */
    DBG(("BaseInit: Creating First Thread\n"));
    (void) TheProcess->v->CreateThread(TheProcess,
                         0,
                         FirstThread,
                         NULL,
                         0,/*default stacksize*/
                         NULL,
                         &TheThread);

    /* This is now the current thread
     */
    ThreadSetCurrent(TheThread);
    (void) TheThread->v->Release(TheThread);

/* #ifndef _OLDSCHED */
/*     if (pTheNameSpace->v->Register(pTheNameSpace, SCHEDULER_NAME, */
/* 				   (PIUNKNOWN)pTheScheduler, 0, */
/* 				   NULL) != S_OK) { */
/*       printf("failed to register scheduler\n"); */
/*       goto Exit; */
/*     } */
/* #endif */

    /* Let scheduler go by giving it the first timer interrupt.
     */
    DBG(("BaseInit: Starting scheduler\n"));
    {
        TIME Delta;
        BOOL bIgnore;
        Int32ToInt64(Delta,10);
        SetNextInterrupt(Delta,&bIgnore);
    }

    /* Interrupts had been assumed disabled until now.
     */
    ENABLE_INTERRUPTS();

    /* Spin a while so the timer interrupt does go off
     */
    Delay(50000);

    /* Should never get here
     */
/* #ifndef _OLDSCHED */
/*  Exit: */
/* #endif */
    DBG(("Failed to start first thread ??..\n"));
    BaseDelete();
}

void BaseDeleteClassRegistry (void);
void CobMgrExit(void);

/*
 * Base finalization
 */
void BaseDelete(void)
{
    DBG(("BaseDelete: I have nothing left to do.  Thanks for the ride.\n"));

#if __SUPPORTS_COB_NAMESPACE
    BaseDeleteClassRegistry();
    CobMgrExit();
#endif

    RELEASE_NULL(pTheNameSpace);
    PicDelete(pThePic);

#if 0
    /* no can do, thread is still running on stack */
    CurrentThread()->v->Release(CurrentThread());
    pDebugHeap->v->Validate(pDebugHeap, 0, 0);
#endif

#ifdef _USE_DEBUG_HEAP
    /* Catch some leaks if any */
    {
        PIHEAP heap = pDebugHeap;
        /* Set to NULL in case heap does DebugBreak and we end up here again */
        pDebugHeap = NULL; 
        RELEASE_NULL(heap);
    }
#endif
    
    TheEnd();
}
