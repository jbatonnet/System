/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Copyright (c)
 *    1982, 1986, 1988, 1993  Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the University of
 *    California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *    @(#)mbuf.h    8.1 (Berkeley) 6/4/93
 */

#ifndef __MBUF__
#define __MBUF__ 1

#ifndef MSIZE                   /* sock.h not included */
#define MSIZE 128L
#define MCLBYTES 2048L
struct ifnet;
#endif

/*
 * Mbufs are of a single size, MSIZE (machine/machparam.h), which
 * includes overhead.  An mbuf may add a single "mbuf cluster" of size
 * MCLBYTES (also in machine/machparam.h), which has no additional overhead
 * and is used instead of the internal data area; this is done when
 * at least MINCLSIZE of data must be stored.
 */

#define MLEN (MSIZE - sizeof(struct m_hdr))   /* normal data len */
#define MHLEN (MLEN - sizeof(struct pkthdr))  /* data len w/pkthdr */

#define MINCLSIZE (MHLEN + MLEN)   /* smallest amount to put in cluster */
#define M_MAXCOMPRESS (MHLEN / 2)  /* max amount to copy for compression */

/* Cast the data an mbuf 'm' points-to to a pointer of type 't'
 */
#define mtod(m,t) ((t)((m)->m_data))

/* header at beginning of each mbuf: */
struct m_hdr {
    const struct IBufferVtbl *v;
    UINT mh_RefCnt;
    struct mbuf *mh_next;     /* next buffer in chain */
    struct mbuf *mh_nextpkt;  /* next chain in queue/record */
    PBYTE mh_data;            /* location of data */
    INT mh_len;               /* amount of data in this mbuf (in bytes) */
    UINT16 mh_type;           /* type of data in this mbuf */
    UINT16 mh_flags;          /* flags; see below */
};

/* record/packet header in first mbuf of chain; valid if M_PKTHDR set */
struct pkthdr {
    union {
        struct ifnet *c_rcvif;  /* rcv interface */
        int c_pktype;           /* packet type */
    } pkctl;
    INT len;              /* total packet length */
};

#define rcvif   pkctl.c_rcvif
#define pktype  pkctl.c_pktype

/* description of external storage mapped into mbuf, valid if M_EXT set */
struct m_ext {
    struct mbuf *ext_buf;               /* start of large buffer */
    void (*ext_free)(struct mbuf *);    /* free routine if not the usual */
    UINT        ext_count;              /* reference count */
};
 
typedef struct mbuf {
    struct m_hdr m_hdr;
    union {
        struct {
            struct pkthdr MH_pkthdr;     /* M_PKTHDR set */
            union {
                struct m_ext MH_ext;     /* M_EXT set */
                char MH_databuf[MHLEN];
            } MH_dat;
        } MH;
        char M_databuf[MLEN];            /* !M_PKTHDR, !M_EXT */
    } M_dat;
} MBUF, * PMBUF;

#define m_next m_hdr.mh_next
#define m_len m_hdr.mh_len
#define m_data m_hdr.mh_data
#define m_type m_hdr.mh_type
#define m_flags m_hdr.mh_flags
#define m_nextpkt m_hdr.mh_nextpkt
#define m_pkthdr M_dat.MH.MH_pkthdr
#define m_ext M_dat.MH.MH_dat.MH_ext
#define m_pktdat M_dat.MH.MH_dat.MH_databuf
#define m_dat M_dat.M_databuf

/* mbuf flags */
#define M_EXT    0x0001  /* has associated external storage */
#define M_PKTHDR 0x0002  /* start of record */
#define M_EOR    0x0004  /* end of record */

/* mbuf pkthdr flags, also in m_flags */
#define M_BCAST  0x0100  /* send/received as link-level broadcast */
#define M_MCAST  0x0200  /* send/received as link-level multicast */
#define M_ACKED  0x0800  /* already sent an ACK for this packet */
#define M_MUSTACK 0x1000 /* MUST send an ACK for this packet */

/* flags copied when copying m_pkthdr */
#define M_COPYFLAGS (M_PKTHDR|M_EOR|M_BCAST|M_MCAST)

/* mbuf types */
#define MT_FREE    0   /* should be on free list */
#define MT_DATA    1   /* dynamic (data) allocation */
#define MT_HEADER  2   /* packet header */
#define MT_SOCKET  3   /* socket structure */
#define MT_PCB     4   /* protocol control block */
#define MT_RTABLE  5   /* routing tables */
#define MT_HTABLE  6   /* IMP host tables */
#define MT_ATABLE  7   /* address resolution tables */
#define MT_SONAME  8   /* socket name */
#define MT_SOOPTS  10  /* socket options */
#define MT_FTABLE  11  /* fragment reassembly header */
#define MT_RIGHTS  12  /* access rights */
#define MT_IFADDR  13  /* interface address */
#define MT_CONTROL 14  /* extra-data protocol message */
#define MT_OOBDATA 15  /* expedited data  */
#define MT_MAXTYPE 16

/* flags to m_get/MGET */
#define M_DONTWAIT    1
#define M_WAIT        0

/*
 * Set the m_data pointer of a newly-allocated mbuf (m_get/MGET) to place
 * an object of the specified size at the end of the mbuf, longword aligned.
 */
#define M_ALIGN(m, len) \
    { (m)->m_data += (MLEN - (len)) &~ (sizeof(long) - 1); }
/*
 * As above, for mbufs allocated with m_gethdr/MGETHDR
 * or initialized by M_COPY_PKTHDR.
 */
#define MH_ALIGN(m, len) \
    { (m)->m_data += (MHLEN - (len)) &~ (sizeof(long) - 1); }

/* length to m_copy to copy all */
#define M_COPYALL  0x40000000
#define M_COPYDEEP 0x20000000

/* compatiblity with 4.3 */
#define m_copy(m, o, l) m_copym((m), (o), (l), M_DONTWAIT)

#ifdef __WANTS_STATS
/*
 * Mbuf statistics.
 */
struct mbstat {
    UINT m_mbufs;          /* mbufs obtained from page pool */
    UINT m_clusters;       /* clusters obtained from page pool */
    UINT m_spare;          /* spare field */
    UINT m_clfree;         /* free clusters */
    UINT m_drops;          /* times failed to find space */
    UINT m_wait;           /* times waited for space */
    UINT m_drain;          /* times drained protocols for space */
    UINT16 m_mtypes[256];  /* type specific mbuf allocations */
};
#endif

extern INT max_linkhdr;            /* largest link-level header */
extern INT max_protohdr;           /* largest protocol header */
extern INT max_hdr;                /* largest link+protocol header */
extern INT max_datalen;            /* MHLEN - max_hdr */

struct mbuf * m_copym(struct mbuf *, INT, INT, INT);
struct mbuf * m_free(struct mbuf *);
struct mbuf * RTLCALLTYPE m_get(INT, INT);
struct mbuf * m_getclr(INT, INT);
struct mbuf * RTLCALLTYPE m_gethdr(INT, INT);
struct mbuf * RTLCALLTYPE m_clget(struct mbuf *, INT);
struct mbuf * m_prepend(struct mbuf *, UINT, INT, BOOL);
struct mbuf * m_pullup(struct mbuf *, INT);
struct mbuf * m_split(struct mbuf *,INT,INT);
void m_reclaim(void);
void m_copyback(struct mbuf *, INT, INT, PTR);
void m_adj(struct mbuf *mp, INT req_len);
void m_cat(struct mbuf *m, struct mbuf *n);
void m_copydata(struct mbuf *m, INT off, INT len, PBYTE cp);

void RTLCALLTYPE m_freem(struct mbuf *);

#define MGET(m, how, type) {m = m_get(how,type);}
#define MCLGET(m, how) {m = m_clget(m,how);}
#define MGETHDR(m, how, type) {m = m_gethdr(how,type);}
#define MFREE(m, n) { n = m_free(m); }
#define M_PREPEND(m, plen, how) {m = m_prepend(m,plen,how, TRUE);}

/*
 * Copy mbuf pkthdr from from to to.
 * from must have M_PKTHDR set, and to must be empty.
 */
#define M_COPY_PKTHDR(to, from) { \
    (to)->M_dat.MH.MH_pkthdr = (from)->M_dat.MH.MH_pkthdr; \
    (to)->m_hdr.mh_flags = (UINT16)((from)->m_hdr.mh_flags & M_COPYFLAGS); \
    (to)->m_hdr.mh_data = (PTR) (to)->M_dat.MH.MH_dat.MH_databuf; \
}

/*
 * Compute the amount of space available
 * before the current start of data in an mbuf.
 */
#define M_LEADINGSPACE(m) \
    (((m)->m_flags & M_EXT) ? /* (m)->m_data - (char*)(m)->m_ext.ext_buf */ 0 : \
       ((m)->m_flags & M_PKTHDR) ? ((char*)(m)->m_data - (m)->m_pktdat) : \
        ((char*)(m)->m_data - (m)->m_dat))

/*
 * Compute the amount of space available
 * after the end of data in an mbuf.
 */
/* Used MCLBYTES directly instead of m->m_ext.ext_size */

#define M_TRAILINGSPACE(m) \
    (((m)->m_flags & M_EXT) ? ((char*)(m)->m_ext.ext_buf + MCLBYTES - \
        ((char*)(m)->m_data + (m)->m_len)) : \
        (&(m)->m_dat[MLEN] - ((char*)(m)->m_data + (m)->m_len)))

#endif /* __MBUF__ */
