/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains FirstThread
 */
#define _DEBUG 1
#define BGLVL 0
#include <mmlite.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <fred.h>
#include <diagnostics.h>

/* USE_SERPLEX is defined in ... */
#include <drivers/serp.h>
 
#define BREAK_BUTTON 1
#if BREAK_BUTTON
#include "at91m55800.h"

/* Push SW2 (PA9/IRQ0) to drop in the debugger 
 */
BOOL MCT BreakIsr(void *This, PBOOL pNotMyInterrupt)
{
    DebugBreak();
    return FALSE;
}
#define BREAK_INTNO 29
#endif

extern PIBASERTL pTheBaseRtl;

extern PINAMESPACE BoardInitFileSystem(void);

/* Leftover linking issues */
INT MODENTRY CrtInit(INT Op)
{
    return 1;/* TRUE */
}

typedef _TCHAR *TSTR;
const TSTR FIRST_IMAGE_NAME = _TEXT("tzk.cob");

/* To help diagnose product boot problems.
 * Should be an LED or something else externally accessible.
 */
int BootStep = 0;

void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    SCODE sc;
    const _TCHAR * Args = _TEXT("");
    PINAMESPACE pRoot;
    PIUNKNOWN pUnk;

    DBGME(3,printf("_firstEb55 FirstThread\n"));

#if BREAK_BUTTON
    PioA->Disable = PIOA_IRQ0;
    PioA->FilterEnable = PIOA_IRQ0;
    sc = AddDevice (NULL, (PTR) BreakIsr, (ADDRESS)0, BREAK_INTNO, 0);
#endif

    UnusedParameter(arg);

    /* Start the linked-in drivers
     */
    pRoot = CurrentNameSpace();

    BootStep++; 

    sc = pRoot->v->Bind(pRoot,"COB/drivers.cob", 0, &pUnk);
    if (FAILED(sc)) {
        DBGME(3,printf("drivers.cob failed\n"));
        goto Out;
    }
    BootStep++; 
    /* leak the Unk */

    /* Start the console, using the serial line driver
     */
    StartDriver("com1");
    BootStep++;
    
    StartDriver("com2");
    BootStep++;
    
    /* Hostfs must use serplex */
    StartDriver("serplex6a");
    BootStep++;

#if USE_SERPLEX
    StartDriver("serplex6c");
    BootStep++;
 
    sc = InitConsole("serplex6c");
#else
    sc = InitConsole("com2");
#endif
    if (FAILED(sc)) {
        DBGME(3,printf("Failed to create debug console (sc = x%x)\n", sc));
        goto Out;
    }
    BootStep++; 

    pRoot = BoardInitFileSystem();
    if (!pRoot) goto Out;

    BootStep++; 

    SetImageNameSpace(pRoot);
    BootStep++; 

    FirstApp(Args);
    BootStep++; 

  Out:
    BaseDelete();
}

