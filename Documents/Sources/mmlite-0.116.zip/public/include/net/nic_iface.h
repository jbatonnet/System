/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Interface between driver and NIC
 */

/* compat:: used as upcall in simulator */
typedef BOOL (*HOST_ISR)(UINT32 InterruptReason, UINT nWordArgs, UINT32 *Args);

#define MAX_ARGS 4 /*?*/

/* RPCs from Host to NIC
 */

/* All request must be odd numbers.  The reply is reqno + 1 */

/* Pseudo number for acks */
#define NIF_NONE 0

#define NIF_IMHERE  1
# define cNIF_IMHERE  1
#define NIF_IMHERE_REPLY  2
# define rNIF_IMHERE 1

#define NIF_CREATE_VI  3
# define cNIF_CREATE_VI  4
#define NIF_CREATE_VI_REPLY  4
# define rNIF_CREATE_VI  2
# define NIF_RAW_PACKETS  0
# define NIF_SIMPLE_SAN_PROTOCOL 1
# define NIF_TCP_PROTOCOL 2

#define NIF_DESTROY_VI  5
# define cNIF_DESTROY_VI  1
#define NIF_DESTROY_VI_REPLY 6
# define rNIF_DESTROY_VI  0

#if 0
#define NIF_CREATE_ASID  
#endif

#define NIF_DESTROY_ASID  7
# define cNIF_DESTROY_ASID  1
#define NIF_DESTROY_ASID_REPLY  8
# define rNIF_DESTROY_ASID  0

#define NIF_TLB_ENTER  9
# define cNIF_TLB_ENTER  4
#define NIF_TLB_ENTER_REPLY 10
# define rNIF_TLB_ENTER  0
#define I_TLB_VALID    0x1
#define I_TLB_WRITE    0x2
#define I_TLB_RDMAW    0x4
#define I_TLB_RDMAR    0x8
# define I_TLB_MASK     0xf
#define I_MISS_SENDQ   0x10
#define I_MISS_CTLQ    0x20
#define I_MISS_HEAD    0x40
#define I_MISS_DESC    0x80

#define NIF_TLB_REMOVE  11
# define cNIF_TLB_REMOVE  2
#define NIF_TLB_REMOVE_REPLY 12
# define rNIF_TLB_REMOVE  0

/* same as TLB_ENTER except takes a VI */
#define NIF_TLB_RESOLVE  13
# define cNIF_TLB_RESOLVE  cNIF_TLB_ENTER
#define NIF_TLB_RESOLVE_REPLY 14
# define rNIF_TLB_RESOLVE  rNIF_TLB_ENTER

#define NIF_MAKE_CONNECTED  15
# define cNIF_MAKE_CONNECTED  4
#define NIF_MAKE_CONNECTED_REPLY 16
# define rNIF_MAKE_CONNECTED  0

#define NIF_DISCONNECT  17
# define cNIF_DISCONNECT  1
#define NIF_DISCONNECT_REPLY  18
# define rNIF_DISCONNECT  0

#define NIF_GET_HW_INFO  19
# define cNIF_GET_HW_INFO  0
#define NIF_GET_HW_INFO_REPLY 20
# define rNIF_GET_HW_INFO  3

#define NIF_SEND_PACKET  21
# define cNIF_SEND_PACKET  2
#define NIF_SEND_PACKET_REPLY  22
# define rNIF_SEND_PACKET  1

#define NIF_CHANGE_IMASK  23
# define cNIF_CHANGE_IMASK  3
#define NIF_CHANGE_IMASK_REPLY  24
# define rNIF_CHANGE_IMASK  1
#define NIFCI_OR   1
#define NIFCI_NAND 2
#define NIFCI_ONCE 3
#define NIFCI_IRECV 0x2 /* valid bits in mask */
#define NIFCI_ISEND 0x4

/* Same as connected but no SEND */
#define NIF_MAKE_ACCEPTED  25
# define cNIF_MAKE_ACCEPTED  4
#define NIF_MAKE_ACCEPTED_REPLY 26
# define rNIF_MAKE_ACCEPTED  0

/* Interrupt codes
 */
#define NIT_TLB_MISS  2
# define cNIT_TLB_MISS  4
// see I_TLB_xx above

#define NIT_SEND_DONE  3
# define cNIT_SEND_DONE  4

#define NIT_RECV_DONE  4
# define cNIT_RECV_DONE (cNIT_SEND_DONE)

/* Pkt interface
 */
typedef struct {
  UINT8 Pad[2];
  UINT8 DestinationAddress[6];
  UINT8 Data[1]; /* varsize */
} SR_PACKET, *PSR_PACKET;

/* Errors
 */
#define NIF_ERROR_BASE         0x10000
#define NIF_E_BAD_COMMAND      (NIF_ERROR_BASE+1)
#define NIF_E_OUTTAMEM         (NIF_ERROR_BASE+2)
#define NIF_E_INVALID_ARGUMENT (NIF_ERROR_BASE+3)
