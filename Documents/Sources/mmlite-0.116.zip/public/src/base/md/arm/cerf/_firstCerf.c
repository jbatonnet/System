/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains FirstThread
 */

#include <mmlite.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <fred.h>
#define _DEBUG 1
#include <diagnostics.h>

extern PIBASERTL pTheBaseRtl;

#define _SECURE_FS 0

#if _SECURE_FS
static PINAMESPACE ImageNameSpace = NULL;
#endif

PINAMESPACE GetImageNameSpace(void)
{
#if _SECURE_FS
    /* This forbids changing the filesystem where code comes from */
    return ImageNameSpace;
#else
    SCODE r;
    PIUNKNOWN pUnk;
    PINAMESPACE pNs = CurrentNameSpace();

    r = pNs->v->Bind(pNs,
                     _T("fs"),
                     0,
                     &pUnk);
    if (FAILED(r))
        return NULL;

    /* Ok, but is it a namespace
     */
    r = pUnk->v->QueryInterface(pUnk,
                                &IID_INameSpace,
                                (void **) &pNs);

    (void) pUnk->v->Release(pUnk);

    if (FAILED(r))
        return NULL;

    /* This one is not supposed to take a ref so lets do this horrible one */
    (void) pNs->v->Release(pNs);
    
    return pNs;

#endif
}
void SetImageNameSpace(PINAMESPACE pINS)
{
    CurrentNameSpace()->v->Register(CurrentNameSpace(), _T("fs"),
                                    (PIUNKNOWN) pINS, 0, NULL);
#if _SECURE_FS
    ImageNameSpace = pINS;
#endif
}


PINAMESPACE InitHostFileSystem(_TCHAR *LinkName);

/* Leftover linking issues */
INT MODENTRY CrtInit(INT Op)
{
    return 1;/* TRUE */
}

PINAMESPACE BoardInitHostFs(void)
{
    /* hostfs must use serplex */
    PINAMESPACE ns = InitHostFileSystem("serplex6a");
    if (!ns) DBGME(3,printf("BoardInitHostFs failed\n"));
    return ns;
}

const _TCHAR *FIRST_IMAGE_NAME = _TEXT("init.exe");

/* To help diagnose product boot problems.
 * Should be an LED or something else externally accessible.
 */
int BootStep = 0;

void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    SCODE sc;
    const _TCHAR * Args = _TEXT("");
    PIMODULE pMod;
    PIPROGRAM prog;
    PINAMESPACE Root;
    MODULEENTRY EntryPoint;
    PIUNKNOWN pUnk;

    UnusedParameter(arg);

    /* Start the linked-in drivers
     */
    Root = CurrentNameSpace();

    sc = Root->v->Bind(Root,"COB/drivers.cob", 0, &pUnk);
    if (FAILED(sc)) {
        DBGME(3,printf("drivers.cob failed\n"));
        goto Out;
    }
printf("Cant hurt?\n");
    BootStep++; 
    /* leak the Unk */

    sc = Root->v->Bind(Root,"COB/drivercfg.cob", 0, &pUnk);
    if (FAILED(sc)) {
        DBGME(3,printf("drivercfg.cob failed\n"));
        goto Out;
    }
printf("Cant hurt?\n");
    BootStep++; 
    /* leak the Unk */

#define USE_SERPLEX 1

#if USE_SERPLEX
    StartDriver("serplex6c");
    BootStep++;
 
    /* Start the console, using the serplex
     */
    sc = InitConsole("serplex6c");
    if (FAILED(sc)) {
        DBGME(3,printf("Failed to create debug console (sc = x%x)\n", sc));
        goto Out;
    }
#else
    /* Start the console, using the serial line driver
     */
    sc = InitConsole("com3");
    if (FAILED(sc)) {
        DBGME(3,printf("Failed to create debug console (sc = x%x)\n", sc));
        goto Out;
    }
#endif
    BootStep++; 

#if USE_SERPLEX
    /* Hostfs must use serplex */
    StartDriver("serplex6a");
    BootStep++;

    Root = BoardInitHostFs();
    if (!Root) goto Out;
#else
    /* Start HostFs using the serial line driver
     */
    Root = InitHostFileSystem("com1"); /* "udc" for USB */

    if (Root == NULL) {
        DBGME(3,printf("FirstThread: InitRootFileSystem failed\n"));
        goto Out;
    }
#endif
    BootStep++; 

    SetImageNameSpace(Root);
    BootStep++; 

#if 1
    /* Get the Cob's Main method */
    sc = BindToObject(CurrentNameSpace(), _T("COB/tzk.cob"),
                      NAME_SPACE_READ, &IID_IProgram,
                      (void **) &prog);
    if (FAILED(sc)) {
        DBGME(3,printf("FirstThread: Could not load tzk.cob\n"));
        goto Out;
    }

    BootStep++; 
    sc = prog->v->Main(prog, Args ? Args : _T(""));
    prog->v->Release(prog);
#else
    sc = LdrLoadImage(GetImageNameSpace(), FIRST_IMAGE_NAME, Args, 0, &pMod);
    if (FAILED(sc)) {
        DBGME(3,printf("Failed to load %s (sc = x%x)\n", FIRST_IMAGE_NAME,sc));
        goto Out;
    }
    BootStep++; 

    pMod->v->GetEntryPoint(pMod, (ADDRESS *) &EntryPoint);
    EntryPoint(pTheBaseRtl);
    pMod->v->Release(pMod);
#endif

  Out:
    BaseDelete();
}

/* Should be somewhere else but fornow 
*/
SCODE InitConsole(const char *DriverName)
{
    PIUNKNOWN pUnk;
    PINAMESPACE Ns = CurrentNameSpace();
    SCODE sc;

    sc = Ns->v->Bind(Ns,DriverName, 0, &pUnk);
    if (FAILED(sc))
        return sc;

    sc = Ns->v->Register(Ns, _TEXT("stdin"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = Ns->v->Register(Ns, _TEXT("stdout"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = Ns->v->Register(Ns, _TEXT("stderr"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

 Error:
    /* Let our own reference go
     */
    (void) pUnk->v->Release(pUnk);

    return sc;
}

