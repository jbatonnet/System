/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <loaders/cobtab.h>

extern PIUNKNOWN HostfsCobMain(void);
extern PIUNKNOWN SerplexCobMain(void);
extern PIUNKNOWN GsoundCobMain(void);

const struct PRECOB ThePreCobTable[] = {
    {_T("drivercfg.cob"), DriverCfgCobMain },
    {_T("drivers.cob"), DriversCobMain },
    {_T("eb63usart.cob"), SerialCobMain },
    {_T("sernet.cob"), SerNetCobMain },
    {_T("serplex.cob"), SerplexCobMain },
    {_T("hostfs.cob"), HostfsCobMain },
    {_T("gsound.cob"), GsoundCobMain },
    {0,0}
};

/* Select root "fs" file system */
PINAMESPACE BoardInitRomFs(void);
PINAMESPACE BoardInitHostFs(void);

PINAMESPACE BoardInitFileSystem(void)
{
    /* Use RomFs with eb63big: it's a flashed standalone image */
    PINAMESPACE ns = BoardInitRomFs();
    if (!ns)                    /* not there */
        ns = BoardInitHostFs(); /* use hostfs instead */
    return ns;
}
