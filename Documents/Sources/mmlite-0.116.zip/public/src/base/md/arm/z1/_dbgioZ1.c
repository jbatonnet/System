/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <machdep.h>
#include <fred.h>
#include <base/debugger.h>
#include "at91x40.h"
#include "zenith1.h"

extern void gdbOutputString( const unsigned char *string, int len );

#define _DEBUG_LINE_IS_CONSTANT 1
#if _DEBUG_LINE_IS_CONSTANT
#define DxPort Usart0
#define DxPortNo 0
#else
USART *DxPort = Usart0;
UINT8 DxPortNo = 0;
#endif

/* *** ComPortInit
 *
 * Initializes a COM port for low-level (polling) debugging use.
 *
 */
void ComPortInit(USART *Port, UINT Baud, UINT8 PortNo)
{
    UINT32 Divisor;

    /* Enable clock to the part */
    ThePs->PerClockEnable = PSPC_USART0 << PortNo;

    /* disable unused stuff */
    Port->RxTimeout = 0;
    Port->TxTimeout = 0;
    Port->RxPointer = 0;
    Port->TxPointer = 0;
    Port->RxCounter = 0;
    Port->TxCounter = 0;

    /* Better be slower than faster, roundup 
     * NB: ASYNC, else no x16;
     */
    Divisor = (Z1Clock/8)/Baud;
    Divisor = (Divisor/2) + (Divisor&1);
    Port->Baud = Divisor;

    /* 8 bit, no parity, 1 stop */
    Port->Mode = USM_CLK_MCKI | USM_BPC_8 | USM_NONE | USM_1STOP;

    /* disable all interrupts */
    Port->IntrDisable = ~0;

    /* Enable rx/tx and clear any leftover status bits */
    Port->Control = USC_RXEN | USC_TXEN | USC_RSTSTA | USC_STPBRK;

    /* Turn on external pins */
    ThePio->Disable = ((PIO_TXD0|PIO_RXD0) << (PortNo*7));
}


/* *** ComPortPut
 *
 * Write a byte to the specified port.
 */
void ComPortPut(USART *Port, UINT8 Byte)
{
    /* wait until we can transmit */
    while ((Port->ChannelStatus & USI_TXEMPTY) == 0)
        continue;

    Port->TxData = Byte;
}


UINT ComPortErrors = 0;

/* *** ComPortGet
 *
 * Read a byte from the specified port.
 * Returns FALSE if there was no byte ready
 * to be read, or in case of error.
 */
BOOL ComPortGet(USART *Port, UINT8 *pByte)
{
    UINT32 Status = Port->ChannelStatus;

    /* See if anything available */
    if (Status & USI_RXRDY) {
        *pByte = (UINT8) Port->RxData;

        /* Check for errors */
        if (Status & (USI_RXBRK|USI_OVRE|USI_FRAME|USI_PARE)) {
            ComPortErrors++;
            if ((Status & USI_OVRE) == 0)   /* Overrun? */
                return FALSE;           /*  no, parity or framing error */
        }

        return TRUE;
    }

    return FALSE;
}

#define USE_SERIAL_LINE 1
#define USE_DEBUGGER_OUTPUT 1
#define dputc DCPutChar
//#define dgetc getc
unsigned char dgetc(int);


void DbgPortInit(void)
{
#if defined(USE_SERIAL_LINE)

#if 0
    /* DONT do this. The RESET state of this register is 0x18 */

    /* wait for any characters to drain */
    while ((DxPort->ChannelStatus & USI_TXEMPTY) == 0)
        continue;
#endif

    ComPortInit(DxPort, 38400, DxPortNo);

#endif
}

static BOOL dxNeedsInit = TRUE;

void dputc(unsigned char c)
{
#if defined(USE_SERIAL_LINE)
#if defined(USE_DEBUGGER_OUTPUT)
    DebuggerOutputString(&c, 1);
#else
    if (dxNeedsInit) {
        dxNeedsInit = FALSE;
        DbgPortInit();
    }

    if (c == '\n')
        ComPortPut(DxPort, '\r');
    ComPortPut(DxPort, c);
#endif
#endif
}

unsigned char dgetc(int echo)
{
#if defined(USE_SERIAL_LINE)
    unsigned char c;

    while (!ComPortGet(DxPort, &c)) {
        //SleepUntil(TIME_ORIGIN);
        continue;
    }

    if (echo == TRUE)       
        dputc(c);

    if (/*DebuggerAttached &&*/ (c == 3)) /* ^C , likely from GDB */
        DebugBreak();

    return c;
#else
    return 0;
#endif
}

#define USE_LCD 0
#if USE_LCD
#else

void putDebugChar(unsigned char c)
{
    if (dxNeedsInit) {
        dxNeedsInit = FALSE;
        DbgPortInit();
    }
    ComPortPut(DxPort, c);
}
#endif

int getDebugChar(void)
{
    unsigned char c;

    while (!ComPortGet(DxPort, &c))
        continue;

    return c;
}

