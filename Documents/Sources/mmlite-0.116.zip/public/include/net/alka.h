/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* IoControl codes and their arguments
 * Reserved range is x20-x3f
 */
#define FILE_DEVICE_ALKA 0x8001
#define ALKA_CODE(_function_,_method_)  CTL_CODE(FILE_DEVICE_ALKA, 0x800 | (_function_), (_method_), FILE_ANY_ACCESS)

#define ALKA_GET_NIC_ATTR               ALKA_CODE(0x20,METHOD_BUFFERED)

#define ALKA_CREATE_VI                  ALKA_CODE(0x21,METHOD_BUFFERED)
typedef struct {
    HANDLE ViHandle;/*xxx*/
    PVOID DbellAddress;
    UINT32 ViId;
} CREATE_VI_ARGS;

#define ALKA_IS_BOUND                   ALKA_CODE(0x22,METHOD_BUFFERED)

#define ALKA_REGISTER_MEMORY            ALKA_CODE(0x23,METHOD_BUFFERED)
typedef struct {
    PVOID StartAddress;
    UINT32 Length;
    UINT32 Flags;
#define ARMF_RDMAW 0x4
#define ARMF_RDMAR 0x8
} REGISTER_MEMORY_ARGS;

#define ALKA_DEREGISTER_MEMORY          ALKA_CODE(0x24,METHOD_IN_DIRECT)
typedef struct {
    PVOID StartAddress;
    UINT32 Length;
    UINT32 RegionId;
} DEREGISTER_MEMORY_ARGS;

#define ALKA_WAIT                       ALKA_CODE(0x25,METHOD_BUFFERED)
typedef struct {
    UINT32 Event;
#define AW_RECV     1
#define AW_SEND     2
#define AW_RECV_CTL 3
#define AW_SEND_CTL 4
    UINT32 TimeOut;
    VIP_CONTROL_SEGMENT *Descriptor;
} WAIT_ARGS;

#define ALKA_COW                        ALKA_CODE(0x26,METHOD_BUFFERED)
typedef struct {
    UINT32 TimeOut;
    UINT8 Addr[8];
} COW_iARGS;
typedef struct {
    VIP_RETURN RetCode;
    VIP_VI_ATTRIBUTES Attrs;
    UINT8 Addr[8];
    UINT32 ConnId;
} COW_oARGS;

#define ALKA_CONREQ                     ALKA_CODE(0x27,METHOD_BUFFERED)
typedef struct {
    UINT32 TimeOut;
    UINT8 RemoteAddr[8];
} CONREQ_iARGS;
typedef struct {
    VIP_RETURN RetCode;
    VIP_VI_ATTRIBUTES Attrs;
} CONREQ_oARGS;

#define ALKA_CONACP                     ALKA_CODE(0x28,METHOD_BUFFERED)
typedef struct {
    VIP_RETURN RetCode;
} CONREP_ARGS;

#define ALKA_CONREJ                     ALKA_CODE(0x29,METHOD_BUFFERED)

#define ALKA_BIND                       ALKA_CODE(0x2a,METHOD_BUFFERED)
typedef struct {
    UINT8 Addr[8];
} BIND_ARGS;

#define ALKA_DISCON                     ALKA_CODE(0x2b,METHOD_IN_DIRECT)

#define ALKA_ACOW                       ALKA_CODE(0x2c,METHOD_BUFFERED)
typedef struct {
    HANDLE Event;
    UINT8 Addr[8];
} ACOW_iARGS;
typedef struct {
    VIP_RETURN RetCode;
} ACOW_oARGS;

#define ALKA_ACONREQ                    ALKA_CODE(0x2d,METHOD_BUFFERED)
/* same args as above */

/* Reserved for kernel mode code */
#define IOCTL_GET_VIA_DRIVER            ALKA_CODE(0x2e,METHOD_BUFFERED)
