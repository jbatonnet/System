/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*  Low level I/O routines (on a simulator) */

#ifndef _INC_IO
#define _INC_IO

typedef int FILE_HANDLE;

FILE_HANDLE open(const char *path, int oflag, ...);
#define _open open
/* open flags (totally arbitrary, compat with Philips) */
#define O_RDONLY       0x0000
#define O_WRONLY       0x0001
#define O_RDWR         0x0002
#define O_APPEND       0x0008

#define O_CREAT        0x0200
#define O_TRUNC        0x0400
#define O_EXCL         0x0800

#define O_BINARY       0  /* meaning, always binary--no text */

/* Seek method constants
 */
#ifndef SEEK_CUR
#define SEEK_CUR    1
#define SEEK_END    2
#define SEEK_SET    0
#endif

extern int read(FILE_HANDLE fildes, void *buf, size_t nbyte);

extern int write(FILE_HANDLE fildes, const void *buf, size_t nbyte);

extern long int lseek(FILE_HANDLE fildes, long offset, int whence);

extern int close(FILE_HANDLE fildes);

extern int access(const char *filename, int mode);
/* access 'mode' */
#define F_OK 0
#define X_OK 1
#define W_OK 2
#define R_OK 4

extern int filelength( FILE_HANDLE fildes);

#endif  /* _INC_IO */
