/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _irq_h_
#define _irq_h_

#define IRQ_ID_COUNT            12

#define IRQ_ID_EXTRN0           0
#define IRQ_ID_EXTRN1           1
#define IRQ_ID_EXTRN2           2
#define IRQ_ID_EXTRN3           3
#define IRQ_ID_EXTRN4           4
#define IRQ_ID_EXTRN5           5
#define IRQ_ID_TIMER0           6
#define IRQ_ID_TIMER1           7
#define IRQ_ID_TIMER2           8
#define IRQ_ID_UART0            9
#define IRQ_ID_UART1            10
#define IRQ_ID_UART2            11

#define IRQ_MASK_EXTRN0         (1 << IRQ_ID_EXTRN0)
#define IRQ_MASK_EXTRN1         (1 << IRQ_ID_EXTRN1)
#define IRQ_MASK_EXTRN2         (1 << IRQ_ID_EXTRN2)
#define IRQ_MASK_EXTRN3         (1 << IRQ_ID_EXTRN3)
#define IRQ_MASK_EXTRN4         (1 << IRQ_ID_EXTRN4)
#define IRQ_MASK_EXTRN5         (1 << IRQ_ID_EXTRN5)
#define IRQ_MASK_TIMER0         (1 << IRQ_ID_TIMER0)
#define IRQ_MASK_TIMER1         (1 << IRQ_ID_TIMER1)
#define IRQ_MASK_TIMER2         (1 << IRQ_ID_TIMER2)
#define IRQ_MASK_UART0          (1 << IRQ_ID_UART0)
#define IRQ_MASK_UART1          (1 << IRQ_ID_UART1)
#define IRQ_MASK_UART2          (1 << IRQ_ID_UART2)

#endif // _irq_h_
