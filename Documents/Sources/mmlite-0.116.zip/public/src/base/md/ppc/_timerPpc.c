/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Time might be kept using both an RTC and the PIT (timer 0).
 * The former gives an RTCDelta interrupt granularity, and
 * is the sole responsible for the drift [temperature & co.].
 * The latter gives fine grain resolution, and is used for
 * scheduling purposes.
 *
 * The basic idea is that the current time is given by
 *
 *      Now = TOY + ReloadDelta + (Ticks - PIT)
 *
 * where TOY is the accumulated count of the RTC interrupts,
 * ReloadDelta is the accumulated count of PIT reloads (one
 * reload per rescheduling), Ticks is the value the PIT was
 * last reloaded with, and PIT is the current reading of
 * the PIT.
 *
 * An important but subtle point is how the subexpression
 * in parens is evaluated.  PIT is a 16 bit counter, which
 * counts down from the (Ticks) value it is loaded with.
 * When it reaches zero it keeps decrementing from xFFFF.
 * (We use the Intel 8254 in Mode0).
 * By using signed 16 bits arithmetic we are guaranteed that
 * the (unsigned!) result of the subtraction is precisely
 * the number of ticks elapsed.  Assuming only that we did
 * not ignore the PIT interrupt for e.g. 54 milliseconds,
 * which is a safe assumption (else this whole OS is garbage..).
 *
 *
 * Formal analysis was based on the following pseudo code.
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (Ticks - PIT)
 *
 * PIT.Set(t) ::
 *      ReloadDelta += (Ticks - PIT)
 *      PIT = t
 *      Ticks = t
 *
 * PIT.Interrupt() :: <nothing needed>
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, 16msec
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * All functions are assumed atomic interrupt-wise.
 *
 * Notice that the above proof still holds if we remove
 * the RTC chip: just cancel RTC.Interrupt() and wire TOY==0.
 * Drift analysis (in PIT.Set()) becomes important, e.g. the
 * time between the first and second statement.
 *
 * UPDATE UPDATE UPDATE --for Atmel board-- UPDATE UPDATE UPDATE
 *
 * Here the PIT counts up, not down. One way to work around this
 * is to set COUNTER at MAX-desired_delta and take the interrupt
 * at overflow. At interrupt time COUNTER measures our latency,
 * so we can account for it.
 * One useful idea here is to use ARM's "swap" instruction, which
 * atomically does a read+write operation, e.g. on the COUNTER.
 * Darn, the counter is infact read-only. So much for that one.
 * There is no way to load anything but zero in that COUNTER, sorry.
 *
 * Another way is to load register C with COUNTER+desired_delta,
 * and use the match as interrupt trigger. At interrupt time the
 * difference COUNTER-C is the latency. COUNTER would be free-running
 * in this solution. There is an issue here as to how many cycles
 * does it take to (a) read COUNTER (b) add DELTA (c) write C.
 * Unless this is (a) deterministic and (b) known with high accuracy
 * we'll get strong clock drift.
 *
 * Yet another way is to load C with desired-delta, and reset+start
 * the counter. Interrupt again is at match with C.  One advantage is
 * that C holds Ticks directly on-chip, reducing memory load/stores.
 * The same drift problem as above applies here, the sequence is
 * (a) read COUNTER (b) reset-restart it.
 *
 * In both these last two cases the counter could be match-reset.
 * The problem with that is that we sometimes load very small delta
 * values, and it might be a while after the interrupt triggers
 * before we reload the timer. [This is scheduler-dependent]
 * So the counter might reset multiple times...
 *
 * The first (non-)solution would be the one that works best without
 * the RTC, assuming the swap trick.  The third one is the one that
 * minimizes drift uncertainty, and therefore the chosen one.
 * The equations for this solution are
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (PIT - Ticks)
 *
 * PIT.Set(t) ::
 *      PIT.C = t
 *      PIT_WAS = PIT
 *      PIT.Restart()
 *      ReloadDelta += (PIT_WAS - Ticks) + <drift>
 *      Ticks = 0
 *
 * PIT.Interrupt() :: <nothing needed [except calling PIT.Set()]>
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, ~2 seconds
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 */

#define DEVICE_ORDER LITTLE_ENDIAN
#include <mmlite.h>
#include <mmhal.h>
#include <diagnostics.h>
#include <fred.h>

TIME TimeSinceBoot = Int64Initializer(0,0);

extern void WriteDecrementer(UINT32 Value);
extern UINT32 ReadDecrementer(void);
extern void WriteTimeBase(UINT64 Value);
extern UINT64 ReadTimeBase(void);

typedef UINT32 (* TO_TICKS32)(TIME TimeValue);
typedef TIME (* TO_TIME)(UINT64 TicksValue);

PRIVATE UINT32 ProcessorSpeed = 0;
PRIVATE UINT32 TimebaseFrequency = 0;

/* NB: Only valid if ProcessorSpeed > 10MHz */
UINT32 GeneralTimeToTicks32(TIME TimeValue)
{
    UINT64 t;
    assert(TimebaseFrequency >= 10*1000*1000);
    t = *(UINT64*)&TimeValue;
    t = Uint64TimesUint32(t,TimebaseFrequency);
    t = Uint64DividedByUint32(t,10*1000*1000);
    return Uint64ToUint32(t);
}

TIME GeneralTicksToTime(UINT64 TicksValue)
{
    TIME t;
    t = *(TIME*)&TicksValue;
    t = Int64TimesInt32(t,10*1000*1000);
    t = Int64DividedByInt32(t,TimebaseFrequency);
    return t;
}

/* Lasts much longer before overflow..
 */
UINT32 G5TimeToTicks32(TIME TimeValue)
{
    UINT64 t;
    assert(TimebaseFrequency == 33333333);
    t = *(UINT64*)&TimeValue;
    t = Uint64TimesUint32(t,10);
    t = Uint64DividedByUint32(t,3);
    return Uint64ToUint32(t);
}

TIME G5TicksToTime(UINT64 TicksValue)
{
    TIME t;
    t = *(TIME*)&TicksValue;
    t = Int64TimesInt32(t,3);
    t = Int64DividedByInt32(t,10);
    return t;
}


/* Lasts much longer on simulator before overflow..
 * [otherwise just 10 hours]
 */
UINT32 SimTimeToTicks32(TIME TimeValue)
{
    UINT64 t;
    assert(TimebaseFrequency == 50*1000*1000);
    t = *(UINT64*)&TimeValue;
    t = Uint64TimesUint32(t,5);
    return Uint64ToUint32(t);
}

TIME SimTicksToTime(UINT64 TicksValue)
{
    TIME t;
    TicksValue = Uint64DividedByUint32(TicksValue,5);
    t = *(TIME*)&TicksValue;
    return t;
}


TO_TICKS32 TimeToTicks32 = GeneralTimeToTicks32;
TO_TIME      TicksToTime = GeneralTicksToTime;

BOOL SetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    UINT IntrState;
    BOOL StateWas;
    UINT32 DecrementerValue = TimeToTicks32(Delta);

    TURN_INTERRUPTS_OFF(IntrState);

    WriteDecrementer(DecrementerValue);

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);

    return StateWas;
}

/*
 * Return count of time since boot in 100 ns units.
 */
TIME GetKernelTime ()
{
    TIME TOY;
    UINT IntrState;
    UINT64 TimeBaseValue;

    TURN_INTERRUPTS_OFF(IntrState);

    TimeBaseValue = ReadTimeBase();
    TOY = TimeSinceBoot;

    RESTORE_INTERRUPTS(IntrState);

    TOY = TimeAdd(TOY,TicksToTime(TimeBaseValue));

    return TOY;
}

/* Initialization
 */
extern UINT DelayMultiplier;
extern UINT DelayShifter;
extern UINT DelayOverhead;
extern TIME SleepOverhead;

extern BOOL IsSimulator(void);

void EnableTimers( void )
{
    /* Clear up any pending decrementer interrupts
     */
    WriteDecrementer(0x7fffffff);

    /* Initialize boot time
     */
    WriteTimeBase(0);

    /* BUGBUG should auto-find processor speed later on */

#if 0
    if (IsSimulator()) {
        /* These are for simulator */
        ProcessorSpeed = 25*1000*1000;     /* in Hz, release ROMSIM */
        TimebaseFrequency = 50*1000*1000;  /* in Hz, release ROMSIM */
        TimeToTicks32 = SimTimeToTicks32;
        TicksToTime = SimTicksToTime;
        DelayMultiplier = 2560;
        DelayOverhead = 10240;
        DelayShifter = 10;
        Int32ToInt64(SleepOverhead,1670);  /* 167 uSec              */
    } else {
        ProcessorSpeed = 2*1000*1000*1000; /* in Hz, G5             */
        TimebaseFrequency = 33333333;      /* in Hz, G5             */
        TimeToTicks32 = G5TimeToTicks32;
        TicksToTime = G5TicksToTime;
        DelayMultiplier = 314551;
        DelayOverhead = 5802;
        DelayShifter = 10;
        Int32ToInt64(SleepOverhead,30);    /* ~3 uSec               */
    }
#else
    if (IsSimulator()) {
        /* This really should be "IsEb63()" because the USART there expects it */
        ProcessorSpeed = 25*1000*1000;
    } else {
        ProcessorSpeed = 2*1000*1000*1000;
    }

    TimebaseFrequency = 33333333;
    TimeToTicks32 = G5TimeToTicks32;
    TicksToTime = G5TicksToTime;
    DelayMultiplier = 314551;
    DelayOverhead = 5802;
    DelayShifter = 10;
    Int32ToInt64(SleepOverhead,30);    /* ~3 uSec               */
#endif

}

/* Estimate the current processor speed
 */
UINT64 CurrentProcessorSpeed(void)
{
    return (UINT64)ProcessorSpeed;
}
