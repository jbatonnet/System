/* Copyright (c) Microsoft Corporation. All rights reserved. */


#ifndef __HTTP_PROCESS_INTERFACE__
#define __HTTP_PROCESS_INTERFACE__ 1


#include <mmlite.h>
#include <util/list-double2.h>
#include <wsif.h>
#include <soapif.h>
#include <httpif.h>
#include <tokenizerif.h>


/* HTTP process interface */


/* There is no HEAD method; on a HEAD request GET will be called, 
 * and HTTPResponseSendMessage and HTTPResponseReportError are 
 * then smart enough to figure out not to send content if the 
 * actual verb is HEAD rather than GET. */


/* Protocol constants */


typedef enum {
    /* Request methods */
#ifndef _MINIMIZE
    TOKEN_OPTIONS                   = 1,
    TOKEN_GET                       ,
    TOKEN_HEAD                      ,
#endif
    TOKEN_POST                      ,
#ifndef _MINIMIZE
    TOKEN_PUT                       ,
    TOKEN_DELETE                    ,
    TOKEN_TRACE                     ,
    TOKEN_EXTMETH                   ,
    /* Responses */
    TOKEN_OPTIONS_RESPONSE          ,
    TOKEN_GET_RESPONSE              ,
    TOKEN_HEAD_RESPONSE             ,
#endif
    TOKEN_POST_RESPONSE             ,
#ifndef _MINIMIZE
    TOKEN_PUT_RESPONSE              ,
    TOKEN_DELETE_RESPONSE           ,
    TOKEN_TRACE_RESPONSE            ,
    TOKEN_EXTMETH_RESPONSE          ,
#endif

    /* Version tokens */            
    TOKEN_HTTP_1_0                  ,
    TOKEN_HTTP_1_1                  ,
    /* Request field tokens */
#ifndef _MINIMIZE
    TOKEN_ACCEPT                    ,
    TOKEN_ACCEPT_CHARSET            ,
    TOKEN_ACCEPT_ENCODING           ,
    TOKEN_ACCEPT_LANGUAGE           ,
    TOKEN_AUTHORIZATION             ,
    TOKEN_FROM                      ,
    TOKEN_HOST                      ,
    TOKEN_IF_MODIFIED_SINCE         ,
    TOKEN_IF_MATCH                  ,
    TOKEN_IF_NONE_MATCH             ,
    TOKEN_IF_RANGE                  ,
    TOKEN_IF_UNMODIFIED_SINCE       ,
    TOKEN_MAX_FORWARDS              ,
    TOKEN_PROXY_AUTHORIZATION       ,
    TOKEN_RANGE                     ,
    TOKEN_REFERER                   ,
    TOKEN_USER_AGENT                ,
    /* Response field tokens */     
    TOKEN_AGE                       ,
    TOKEN_LOCATION                  ,
    TOKEN_PROXY_AUTH                ,
    TOKEN_PUBLIC                    ,
    TOKEN_RETRY_AFTER               ,
    TOKEN_SERVER                    ,
    TOKEN_VARY                      ,
    TOKEN_WARNING                   ,
    TOKEN_WWW_AUTH                  ,
    /* extension responses */       
    /* Entity field tokens */       
    TOKEN_ALLOW                     ,
    TOKEN_CONTENT_BASE              ,
    TOKEN_CONTENT_ENCODING          ,
    TOKEN_CONTENT_LANGUAGE          ,
#endif
    TOKEN_CONTENT_LENGTH            ,
#ifndef _MINIMIZE
    TOKEN_CONTENT_LOCATION          ,
    TOKEN_CONTENT_MD5               ,
    TOKEN_CONTENT_RANGE             ,
#endif
    TOKEN_CONTENT_TYPE              ,
#ifndef _MINIMIZE
    TOKEN_ETAG                      ,
    TOKEN_EXPIRES                   ,
    TOKEN_LAST_MODIFIED             ,
#endif
    TOKEN_CONNECTION                , /* XXX I suppose the actual number is irrelevant */
    TOKEN_CONNECTION_CLOSE          ,
    TOKEN_TRANSFER_ENCODING         ,

#ifndef _MINIMIZE
    /* extension headers */

    /* The values are defined in RFC 2068 */
    TOKEN_NOT_SET                   = 0,
#endif
    TOKEN_CONTINUE                  = 100,
#ifndef _MINIMIZE
    TOKEN_SWITCHING_PROTOCOLS       = 101,
#endif
    TOKEN_OK                        = 200,
#ifndef _MINIMIZE
    TOKEN_CREATED                   = 201,
    TOKEN_ACCEPTED                  = 202,
    TOKEN_NON_AUTH_INFO             = 203,
#endif
    TOKEN_NO_CONTENT                = 204,
#ifndef _MINIMIZE
    TOKEN_RESET_CONTENT             = 205,
    TOKEN_PARTIAL_CONTENT           = 206,
    TOKEN_MULTIPLE_CHOICES          = 300,
    TOKEN_MOVED_PERMANENTLY         = 301,
    TOKEN_MOVED_TEMPORARILY         = 302,
    TOKEN_SEE_OTHER                 = 303,
    TOKEN_NOT_MODIFIED              = 304,
    TOKEN_USE_PROXY                 = 305,
    TOKEN_BAD_REQUEST               = 400,
    TOKEN_UNAUTHORIZED              = 401,
    TOKEN_PAYMENT_REQUIRED          = 402,
    TOKEN_FORBIDDEN                 = 403,
#endif
    TOKEN_NOT_FOUND                 = 404,
    TOKEN_METHOD_NOT_ALLOWED        = 405,
#ifndef _MINIMIZE
    TOKEN_NOT_ACCEPTABLE            = 406,
    TOKEN_PROXY_AUTH_REQUIRED       = 407,
#endif
    TOKEN_REQUEST_TIME_OUT          = 408,
#ifndef _MINIMIZE
    TOKEN_CONFLICT                  = 409,
    TOKEN_GONE                      = 410,
    TOKEN_LENGTH_REQUIRED           = 411,
    TOKEN_PRECOND_FAILED            = 412,
    TOKEN_REQ_ENTITY_TOO_LARGE      = 413,
    TOKEN_REQ_URI_TOO_LARGE         = 414,
    TOKEN_UNSUPP_MEDIA_TYPE         = 415,
#endif
    TOKEN_INTERNAL_SERVER_ERROR     = 500,
#ifndef _MINIMIZE
    TOKEN_NOT_IMPLEMENTED           = 501,
    TOKEN_BAD_GATEWAY               = 502,
    TOKEN_SERVICE_UNAVAILABLE       = 503,
    TOKEN_GATEWAY_TIME_OUT          = 504,
#endif
    TOKEN_HTTP_VERSION_UNSUPP       = 505,

    TOKEN_SOAP_FAULT = 1111
#define TOKEN_SOAP_PARSING_ERROR TOKEN_SOAP_FAULT
} HTTPTOKEN;

#if _MINIMIZE
#define NUM_REQUEST_METHOD_TOKENS   1
#define NUM_ENTITY_FIELD_TOKENS     5
#else
#define NUM_REQUEST_METHOD_TOKENS   7
#define NUM_REQUEST_FIELD_TOKENS    17
#define NUM_RESPONSE_FIELD_TOKENS   9
#define NUM_ENTITY_FIELD_TOKENS     16
#endif

/* HTTP request interface */




/* HTTP header field, concrete structure with public members. Made 
 * public to allow IHTTPPROCESS implementation access to request 
 * header fields. */


struct HTTPHEADERFIELD {
/*  
    BUGBUG - the union would be better but gcc bitched about it so I'm 
    overloading the HTTPTOKEN to hold a string pointer whenever the 
    StringLength value is greater than zero.

    union {
        HTTPTOKEN           Name;
        char*               String;
    };                             
*/                                 
    INT                     Name;               /* Token *OR* string ptr */
    UINT                    StringLength;       /* 0 *OR* length of string */
    _TCHAR *                Value;              /* Delimited with '\0' */
    UINT                    ValueLength;        /* Length without '\0' delimiter */
};

#endif /* __HTTP_PROCESS_INTERFACE__ */

