/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

/* BEGIN_SAMPLE */
/* Prints maximum memory usage. */
int _tmain()
{
    PIHEAP pHeap = CurrentHeap();    /* use this heap */
    ADDR_SIZE MaxUsed = 0;
    SCODE sc;

    sc = pHeap->Status(NULL, NULL, NULL, &MaxUsed);
    if (FAILED(sc)) {
        _tprintf(_TEXT("Heap::Status returned sc = x%x\n"), sc);
        return 0;
    }
    _tprintf(_TEXT("Maximum heap memory usage was %d bytes\n"),
             MaxUsed);
    return 0;
}
/* END_SAMPLE */
