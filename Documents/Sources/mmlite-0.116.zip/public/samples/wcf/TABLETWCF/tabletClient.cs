/* Copyright (c) Microsoft Corporation. All rights reserved. */
using System;
using System.ServiceModel;
using System.Threading;
using System.Xml;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Microsoft.Ink;
using System.Runtime.Serialization;


namespace TabletService
{
    [ServiceContract(Namespace = "http://tempuri.org/2006/06/itablet")]
    public interface ITabletService
    {
        [OperationContract]
        int sendData(string sData);

        [OperationContract]
        void sendMessage(TabletMessage message);
    }

    [DataContract(Namespace = "http://tempuri.org/2006/06/itablet")]
    public class tabletInkInfo
    {
        [DataMember]
        public tabletStroke[] strokeList;
        [DataMember]
        public float width;
        [DataMember]
        public float height;
    }
    
    [DataContract(Namespace = "http://tempuri.org/2006/06/itablet")]
    public class tabletStroke
    {
        
        [DataMember]
        public string penTip;
        [DataMember]
        public point[] pointList;
    }
    
    [DataContract(Namespace = "http://tempuri.org/2006/06/itablet")]
    public class point
    {
        [DataMember]
        public int x;
        [DataMember]
        public int y;
        [DataMember]
        public int z;
    }
    
    [MessageContract]
    public class TabletMessage
    {
        [MessageBody(Namespace = "http://tempuri.org/2006/06/itablet")]
        public tabletInkInfo tabletInfo;
    }

    class tabletClientImpl
    {
        public void clientFunc(string sPar)
        {
            using (TabletServiceProxy tabletProxy = new TabletServiceProxy())
            {
                tabletProxy.sendData(sPar);
                tabletProxy.Close();
            }
        }

        public void clientSendMessage(tabletInkInfo inkInClasses)
        {
            using (TabletServiceProxy tabletProxy = new TabletServiceProxy())
            {
                TabletMessage mess = new TabletMessage();
                mess.tabletInfo = inkInClasses;
                tabletProxy.sendMessage(mess);
                tabletProxy.Close();
            }
        }
    }
    
    public class convertISFToStr
    {
        tabletInkInfo inkC;
        int iCount = 0;
        int iLimit = 200;
        bool bQuit = false;
        int iPackets = 0;

        public convertISFToStr()
        {
            inkC = new tabletInkInfo();
        }
        public tabletInkInfo convertISFCl(Ink ink, int iX, int iY)
        {
            inkC.strokeList = new tabletStroke[ink.Strokes.Count];
            //Collection<tabletStroke> tabletStrokesCollection = new Collection<tabletStroke>();
            int iIndex = 0;
            foreach (Stroke stroke in ink.Strokes)
            {
                
                inkC.strokeList[iIndex] = new tabletStroke();
                //inkC.strokeList[iIndex].width = stroke.DrawingAttributes.Width;
                //inkC.strokeList[iIndex].height = stroke.DrawingAttributes.Height;
                inkC.strokeList[iIndex].penTip = stroke.DrawingAttributes.PenTip.ToString();

                iPackets = stroke.PacketCount;
                if(iPackets > iLimit)
                    iPackets = iLimit;

                inkC.strokeList[iIndex].pointList = new point[iPackets];
                
                for (int i = 0; i < stroke.PacketCount; i++)
                {

                    //this checking is required because there is a limit on the received buffer size
                    if (iCount >= iLimit)
                    {
                        bQuit = true;
                        break;
                    }
                    iCount++;

                    inkC.strokeList[iIndex].pointList[i] = new point();
                    
                    int[] packet = stroke.GetPacketData(i, 1);
                    Guid[] packetGuids = stroke.PacketDescription;

                    for (int j = 0; j < packetGuids.Length; j++)
                    {
              
                        if (packetGuids[j].Equals(PacketProperty.X))
                            inkC.strokeList[iIndex].pointList[i].x = packet[j] - iX;
                        if (packetGuids[j].Equals(PacketProperty.Y))
                            inkC.strokeList[iIndex].pointList[i].y = packet[j] - iY;
                        if (packetGuids[j].Equals(PacketProperty.NormalPressure))
                            inkC.strokeList[iIndex].pointList[i].z = packet[j];                        
                    }
                    

                    
                    
                }
                if (bQuit)
                    break;

                iIndex++; 
            }
            
            return inkC;
        }
    }
}
