/* Copyright (c) Microsoft Corporation. All rights reserved. */

#include <mmlite.h>

#include "3048F.h"

void KernelDebug(CXTINFO *pCxtInfo);
UINT32 g_rgUnknownIntCounts[61];
int g_InvalidIntNum = -1;

void H8UnknownAdInt(int int_num)
{
	PB.DR.BIT.B1 = 0;

//	P4.DR.BIT.B0 = 1;  // LED0

	if (int_num >= 1 && int_num <= 60) {
		g_rgUnknownIntCounts[int_num]++;
	} else {
		g_rgUnknownIntCounts[0]++;
		g_InvalidIntNum = int_num;
	}
}

void H8UnknownDmacInt(int int_num)
{
	PB.DR.BIT.B1 = 0;

//	P4.DR.BIT.B1 = 1;  // LED1

	if (int_num >= 1 && int_num <= 60) {
		g_rgUnknownIntCounts[int_num]++;
	} else {
		g_rgUnknownIntCounts[0]++;
		g_InvalidIntNum = int_num;
	}
}

/*
void H8UnknownTrapaInt(int int_num)
{
	PB.DR.BIT.B1 = 0;

	P4.DR.BIT.B2 = 1;  // LED2

	if (int_num >= 1 && int_num <= 60) {
		g_rgUnknownIntCounts[int_num]++;
	} else {
		g_rgUnknownIntCounts[0]++;
		g_InvalidIntNum = int_num;
	}
}
*/

// IRQs
void H8UnknownHwInt(int int_num)
{
	PB.DR.BIT.B1 = 0;

//	P4.DR.BIT.B3 = 1;  // LED3

	if (int_num >= 1 && int_num <= 60) {
		g_rgUnknownIntCounts[int_num]++;
	} else {
		g_rgUnknownIntCounts[0]++;
		g_InvalidIntNum = int_num;
	}
}

// Other Timers
void H8UnknownTimerInt(int int_num)
{
	PB.DR.BIT.B1 = 0;

//	P4.DR.BIT.B4 = 1;  // LED4

	if (int_num >= 1 && int_num <= 60) {
		g_rgUnknownIntCounts[int_num]++;
	} else {
		g_rgUnknownIntCounts[0]++;
		g_InvalidIntNum = int_num;
	}
}

// Sci
void H8UnknownSciInt(int int_num)
{
	PB.DR.BIT.B1 = 0;

//	P4.DR.BIT.B5 = 1;  // LED5

	if (int_num >= 1 && int_num <= 60) {
		g_rgUnknownIntCounts[int_num]++;
	} else {
		g_rgUnknownIntCounts[0]++;
		g_InvalidIntNum = int_num;
	}
}

// Others
void H8UnknownInt(int int_num)
{
	PB.DR.BIT.B1 = 0;

//	P4.DR.BIT.B6 = 1;  // LED6

	if (int_num >= 1 && int_num <= 60) {
		g_rgUnknownIntCounts[int_num]++;
	} else {
		g_rgUnknownIntCounts[0]++;
		g_InvalidIntNum = int_num;
	}
}

// NMI
void H8NMIProc(CXTINFO *pCxtInfo)
{
	PB.DR.BIT.B2 = 0;

/////// test
	g_rgUnknownIntCounts[7]++;
////////////
	
	KernelDebug(pCxtInfo);
}

// NMI
void H8TrapaProc(CXTINFO *pCxtInfo)
{
	PB.DR.BIT.B1 = 0;

//	P4.DR.BIT.B2 = 1;  // LED2

	KernelDebug(pCxtInfo);
}

#pragma	interrupt
void H8Irq5( void )
{
	INTC.IER.BIT.IRQ5E = 0;
	INTC.IER.BIT.IRQ5E = 1;
}
