/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Time might be kept using both an RTC and the PIT (timer 0).
 * The former gives an RTCDelta interrupt granularity, and
 * is the sole responsible for the drift [temperature & co.].
 * The latter gives fine grain resolution, and is used for
 * scheduling purposes.
 *
 * The basic idea is that the current time is given by
 *
 *      Now = TOY + ReloadDelta + (Ticks - PIT)
 *
 * where TOY is the accumulated count of the RTC interrupts,
 * ReloadDelta is the accumulated count of PIT reloads (one
 * reload per rescheduling), Ticks is the value the PIT was
 * last reloaded with, and PIT is the current reading of
 * the PIT.
 *
 * An important but subtle point is how the subexpression
 * in parens is evaluated.  PIT is a 16 bit counter, which
 * counts down from the (Ticks) value it is loaded with.
 * When it reaches zero it keeps decrementing from xFFFF.
 * (We use the Intel 8254 in Mode0).
 * By using signed 16 bits arithmetic we are guaranteed that
 * the (unsigned!) result of the subtraction is precisely
 * the number of ticks elapsed.  Assuming only that we did
 * not ignore the PIT interrupt for e.g. 54 milliseconds,
 * which is a safe assumption (else this whole OS is garbage..).
 *
 *
 * Formal analysis was based on the following pseudo code.
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (Ticks - PIT)
 *
 * PIT.Set(t) ::
 *      ReloadDelta += (Ticks - PIT)
 *      PIT = t
 *      Ticks = t
 *
 * PIT.Interrupt() :: <nothing needed>
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, 16msec
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * All functions are assumed atomic interrupt-wise.
 *
 * Notice that the above proof still holds if we remove
 * the RTC chip: just cancel RTC.Interrupt() and wire TOY==0.
 * Drift analysis (in PIT.Set()) becomes important, e.g. the
 * time between the first and second statement.
 *
 * This is the way it is used in this file for the MSP processor.
 *
 */

#include <mmlite.h>
#include <diagnostics.h>
#include <fred.h>
#include <mmhal.h>
#include <_irqSA.h>
#include "_picSA.h"
#include "_timerSA.h"

/*
 * 32x32->64 bit multiplies rely on the compiler recognizing the cast of the
 * multiplicand to int64 to generate the optimal code inline.
 */

#ifdef __GNUC__
#define __int64 long long
#endif

#define Int32x32To64( a, b ) (__int64)((__int64)(INT32)(a) * (INT32)(b))
#define UInt32x32To64( a, b ) (unsigned __int64)((unsigned __int64)(UINT32)(a) * (UINT32)(b))

volatile struct {
    TIME Toy;                   /* Time-of-year */
    UINT32 TickCount;           /* Counter value at the last Toy update */
} SystemTimers = {
    Int64Initializer(0, 0),
    0};


/*
 * Read the timer's free-running counter register.
 */
#define OSTReadCount() (TheTimer->Count)

/*
 * Write one of the timer's match registers
 */
#define OSTWriteMatch(_regno_,_value_) {TheTimer->Match[_regno_] = _value_;}

/*
 * Write the timer's Status&control register
 */
#define OSTWriteStatus(_value_) {TheTimer->Status = _value_;}

/*
 * Export a general purpose debugging up counter. Resolution is 271.27 nS.
 */
UINT32 ReadCounter(void)
{
    return OSTReadCount();
}

/*
 * Handler for os timer match register hit.
 */
BOOL TimerIsr(void *pThis, BOOL *pNotMine)
{
    UnusedParameter(pThis);
    UnusedParameter(pNotMine);

    /* Acknowledge the interrupt */
    OSTWriteStatus(1);

    /* *pNotMine=FALSE; default, unneeded */
    return TRUE;
}


/*
 * We get one clock tic per second from the RTC.
 */
BOOL ClockIsr(void *pThis, BOOL *pNotMine)
{
    static const TIME ClockTick = Int64Initializer(0,10000000);

    UnusedParameter(pThis);
    UnusedParameter(pNotMine);

    /* Acknowledge the interrupt */
    TheRTC->Status = TheRTC->Status | 2;

    SystemTimers.TickCount = OSTReadCount();
    SystemTimers.Toy = TimeAdd(SystemTimers.Toy, ClockTick);

    /* *pNotMine=FALSE; default, unneeded */
    return FALSE;
}

/*
 * Timers use a 32 bit count register fed by a 3.6864 Mhz
 * clock signal.  Limit max timer interval to 1 sec.
 */
#define OST_MAX_INTERVAL 10000000       /* 1 sec */

/* Arm the timer for a TIME (100ns) DELTA
 */

BOOL SetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    static TIME OstMaxInterval = Int64Initializer(0,OST_MAX_INTERVAL);
    UINT32 Ost, Ticks, Match, d;
UINT32 Ost0;
    UINT IntrState;
    BOOL StateWas;

    if (TimeLess(OstMaxInterval, Delta)) {
        Ticks = (UINT32) (OST_MAX_INTERVAL * 0.36864);
    } else {
        UINT64 r;

        /*
         * To get from TIME-Delta to Ticks:
         *
         *  Ticks   =  Delta * 0.36864
         *          = (Delta * 0.36864 * 2**29) / 2**29
         *
         * Note: The strongarm has a fast (3 clocks) multiplier.
         */
        *(unsigned __int64 *)(&r) = UInt32x32To64(0xbcbe61d, Int64ToInt32(Delta));
        r = Uint64RShift(r, 29);
        Ticks = Int64ToInt32(r);

        if (Ticks < 2)
            Ticks = 2;              /* sanity minimum */
    }

    assert(Ticks <= 0x384000 && Ticks > 1);

    /*
     * Got the tick count, program the timer now
     * Notice that we really mean NO INTERRUPTS, of any sort.
     */
    TURN_INTERRUPTS_OFF(IntrState);

    /*
     * Read the os timer count register now.
     */
 Again:
    Ost = OSTReadCount();
Ost0 = Ost;

    /* Set the new match register value.  Make certain we're setting
     * it to a value <= Ticks "greater" than the count register
     * (accounting for wrap).
     */
    Match = Ost + Ticks;
    OSTWriteMatch(0, Match);

    /* The only way I can think of this would happen is if
     * that nacro doesnt truly turn interrupts off.
     * [And no, this code wouldnt be pageable on a VM system]
     */
    Ost = OSTReadCount();
    d = Match - Ost; /* unsigned math !! */
    /* If the counter has already passed the match then D is huge */
    if (d > Ticks) {
        DBGME(3,printf("_timerSa: banana %x (%x %x %x %lx)\n",
               d,Ticks,Ost,Ost0,Delta));
        goto Again;
    }

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);

    return StateWas;
}

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is max_toy_resolution
 */
TIME GetKernelTime ()
{
    UINT32 Delta;
    UINT64 Delta64;
    TIME r;
    UINT32 b,c;
    UINT IntrState;

    /* Cache a few values with interrupt protection
     *
     * NB: The value we return is bound to be 'obsolete',
     * not just by the time needed to compute it and return
     * to the point of call but also by unpredictable
     * delays due to device and timer interrupts.
     * Therefore it is not worth over-extending the protection
     * against interrupts inside this function, as it would
     * serve no benefit whatever.  The opposite need,
     * minimizing interrupt latency, is the one that dominates.
     */
    TURN_INTERRUPTS_OFF(IntrState);

    c = OSTReadCount();
    b = SystemTimers.TickCount;
    r = SystemTimers.Toy;

    RESTORE_INTERRUPTS(IntrState);

    /* Compute time since last Toy update.
     */
    Delta = c - b;

    /* Convert from Ticks to TIME.
     *
     * Time = Ticks / .36864
     *      = (Ticks * (2**29 / .36864)) / 2**29
     *
     * Note: the strongarm has a fast (3 clocks) multiplier.
     */
    *(unsigned __int64 *)(&Delta64) = UInt32x32To64(0x56ce38e4, Delta);
    Delta64 = Uint64RShift(Delta64, 29);

    /* Now put them all together.
     */
    r = Int64Add(*(INT64 *)&Delta64, r);

    return r;
}

/* Initialization
 */
extern UINT DelayMultiplier;
extern UINT DelayShifter;
extern UINT DelayOverhead;

void EnableTimers( void )
{
    /* Configure Delay()
     * BUGBUG Check CCF for actual clock freq (see below)
     */
    DelayMultiplier =  32746;
    DelayShifter    =     10;
    DelayOverhead   =  13576;

    /* Start of time is now
     */
    SystemTimers.TickCount = OSTReadCount();

    /* No spurious timer interrupts
     */
    OSTWriteMatch(0, OSTReadCount());
    OSTWriteStatus(1);
    TheTimer->IEnable = TheTimer->IEnable | 1;

    /* Add the timer irq handler to system
     */
    AddDevice((PTR) NULL, (void *) TimerIsr, 0, IRQ_ID_TIMER0, 0);

    /* Add the real time clock irq handler
     */
    TheRTC->Trim = 0x7ffc;
    TheRTC->Status = TheRTC->Status |0xA;
    AddDevice((PTR) NULL, (void *) ClockIsr, 0, IRQ_ID_RTC, 0);
}


/* Estimate the current processor speed
 */
UINT64 CurrentProcessorSpeed(void)
{
    /* The Cerf board uses the SA-1110 processor,
     * which internally clocks itself at different speeds
     * depending on the value written on the PPCR register,
     * field CCF[4:0], see pag 8-2 of the processor manual.
     * The board uses the 3.6864 crystal.
     */
    UINT64 Speed;
    UINT32 CCF;
#define nSM_VALUES 12
    static UINT32 SpeedMap[nSM_VALUES] = {
        59000*1000, 73700*1000, 88500*1000, 103200*1000,
        118000*1000, 132700*1000, 147500*1000, 162200*1000,
        176900*1000, 191700*1000, 206400*1000, 221200*1000
    };

#define ThePpcr ((volatile UINT32 *)0x90020014)

    CCF = *ThePpcr & 0x1f;
    if (CCF <= nSM_VALUES)
        CCF = SpeedMap[CCF];
    else
        CCF = 0; /* urgh, undefined */

    Int64FromHighAndLow(Speed,0,CCF);
    return Speed;
}

