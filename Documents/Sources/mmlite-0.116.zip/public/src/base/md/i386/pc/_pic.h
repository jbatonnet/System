/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Extra, machine-dependent definitions for the PIC.
 * (not the right way to do this)
 */
extern UINT PicToBios(void);
extern void PicFromBios(UINT);

void StartCpu(UINT CpuNo);
