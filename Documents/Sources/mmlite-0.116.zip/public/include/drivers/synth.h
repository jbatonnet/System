/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*++ BUILD Version: 0001    // Increment this if a change has global effects

Module Name:

    synth.h

Abstract:

    This include file defines constants and types for
    the Microsoft midi synthesizer driver

    This header file is shared between the low level driver and the
    kernel mode driver.

Author:

    Robin Speed (RobinSp) 20-Oct-92

Revision History:

    Alessandro Forin (sandrof) 25-Mar-95
       Adapted for use in Rialto.

--*/

#ifndef __SYNTH_H__
#define __SYNTH_H__ 1

/*
 *  Structure for passing synth data
 */

 typedef struct {
     UINT16 IoPort;
     UINT16 PortData;
 } SYNTH_DATA, *PSYNTH_DATA;

/* positions within AdLib's FM
 */
#define AD_LSI                          (0x000)
#define AD_LSI2                         (0x101)
#define AD_TIMER1                       (0x001)
#define AD_TIMER2                       (0x002)
#define AD_MASK                         (0x004)
#define AD_CONNECTION                   (0x104)
#define AD_NEW                          (0x105)
#define AD_NTS                          (0x008)
#define AD_MULT                         (0x020)
#define AD_MULT2                        (0x120)
#define AD_LEVEL                        (0x040)
#define AD_LEVEL2                       (0x140)
#define AD_AD                           (0x060)
#define AD_AD2                          (0x160)
#define AD_SR                           (0x080)
#define AD_SR2                          (0x180)
#define AD_FNUMBER                      (0x0a0)
#define AD_FNUMBER2                     (0x1a0)
#define AD_BLOCK                        (0x0b0)
#define AD_BLOCK2                       (0x1b0)
#define AD_DRUM                         (0x0bd)
#define AD_FEEDBACK                     (0x0c0)
#define AD_FEEDBACK2                    (0x1c0)
#define AD_WAVE                         (0x0e0)
#define AD_WAVE2                        (0x1e0)

#endif /* __SYNTH_H__ */
