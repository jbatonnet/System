/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __MMLITE_MD_H__
#define __MMLITE_MD_H__

typedef signed char INT8;       /* size is 1 */
typedef unsigned char UINT8;    /* size is 1 */
typedef short INT16;            /* size is 2 */
typedef unsigned short UINT16;  /* size is 2 */
typedef int INT32;              /* size is 4 */
typedef unsigned int UINT32;    /* size is 4 */
/* in case we do not want the compiler supported ones (almost never) */
#if defined(__NO_BUILTIN_INT64)
typedef struct _INT64 INT64;
typedef struct _UINT64 UINT64;
#else
typedef long long INT64;
typedef unsigned long long UINT64;
#endif

typedef INT32 INT;
typedef UINT32 UINT;

#ifdef __MIPSEB__
#define __BYTE_ORDER_IS_BIG_ENDIAN 1 /* Default is little-endian */
#elif !defined(__MIPSEB__)
---- Byte order unknown ----
#endif

#define _UINTSIZE        ( 32 )
#ifdef _OLDSCHED
#define _MUTEX_STATE_SIZE       ( 1 )
#define _CONDITION_STATE_SIZE   ( 2 )
#else
#define _MUTEX_STATE_SIZE       ( 5 )
#define _CONDITION_STATE_SIZE   ( 3 )
#endif

struct  _FPAINFO {
    UINT32 fpr[32];
    UINT32 FPSCR;
};

struct  _CXTINFO {
    /* Structure must match with mips_asm.h etc. */
    UINT32 gpr[32];
    UINT32 pc;
#ifdef TIGON
    UINT32 IntsDisabled; /* Boolean: IntsDisabledState at state load */
#else
    UINT32 sr;           /* c0_status */
    UINT32 hi;
    UINT32 lo;
    UINT32 ec;           /* eMIPS: extension control */
#endif
};

#define __DebugBreak() __asm__ volatile ("break 0")

#define _DCACHELINESIZE 16      /* Size in bytes of data-cache line. */
#define _PAGE_SIZE (4096)
#define _PAGE_SHIFT (12)


#ifdef __cplusplus
extern "C"{
#endif 

unsigned int __udivsi3(unsigned int dividend, unsigned int divisor);
unsigned int __umodsi3(unsigned int dividend, unsigned int divisor);
int _rt_idiv(int dividend, int divisor);
int _rt_imod(int dividend, int divisor);
unsigned int __mulsi3(unsigned int a, unsigned int b);

#ifdef __cplusplus
}
#endif

#endif /* MMLITE_MD_H */
