/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __MMLITE_MD_H_
#define __MMLITE_MD_H_

typedef signed char INT8;       /* size is 1 */
typedef unsigned char UINT8;    /* size is 1 */
typedef short INT16;            /* size is 2 */
typedef unsigned short UINT16;  /* size is 2 */
typedef int INT32;              /* size is 4 */
typedef unsigned int UINT32;    /* size is 4 */
/* in case we do not want the compiler supported ones (almost never) */
#if defined(__NO_BUILTIN_INT64)
typedef struct _INT64 INT64;
typedef struct _UINT64 UINT64;
#else
typedef long long INT64;
typedef unsigned long long UINT64;
#endif

typedef INT32 INT;
typedef UINT32 UINT;

#define __BYTE_ORDER_IS_BIG_ENDIAN 1 /* Default is little-endian */

#define _UINTSIZE              ( 32 )
#ifdef _OLDSCHED
#define _MUTEX_STATE_SIZE       ( 1 )
#define _CONDITION_STATE_SIZE   ( 2 )
#else
#define _MUTEX_STATE_SIZE       ( 5 )
#define _CONDITION_STATE_SIZE   ( 3 )
#endif

struct  _FPAINFO {
    UINT32 fpr[32];
    UINT32 FPSCR;
};

struct  _CXTINFO {
/* xxxx */
    UINT32 gpr[32];
    UINT32 pc;
};

#define __DebugBreak() __asm__ volatile ("trap #0") /*?*/
#define _DCACHELINESIZE 16
#define _PAGE_SIZE (4096)
#define _PAGE_SHIFT (12)

#endif  /*__MMLITE_MD_H_*/
