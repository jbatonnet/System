/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <winsock.h>

struct mbuf;
struct sockaddr;
struct socket;
typedef void *caddr_t;
void m_freem(struct mbuf *);

struct hostent *
WINAPI gethostbyname(
        const char *name)
{
    return NULL;
}

/* copy of htons.c XXX */
/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <stdio.h>
#include <mmlite.h>
#include <winsock.h>

/*
 * Byteswap routines for export.
 *
 * Convert from host to network byte order (and vice-versa) on those
 * architectures for which they are different.
 * NOTE: We run MIPS boards in little-endian mode.
 */
u_long WINAPI htonl(u_long hostlong)
{
#if BYTE_ORDER == LITTLE_ENDIAN
    return ((hostlong << 24) | ((hostlong & 0xff00) << 8) |
            ((hostlong & 0xff0000) >> 8) | (hostlong >> 24));
#else
    return(hostlong);
#endif
}

u_long WINAPI ntohl(u_long netlong)
{
#if BYTE_ORDER == LITTLE_ENDIAN
    return ((netlong << 24) | ((netlong & 0xff00) << 8) |
            ((netlong & 0xff0000) >> 8) | (netlong >> 24));
#else
    return(netlong);
#endif
}

u_short WINAPI htons(u_short hostshort)
{
#if BYTE_ORDER == LITTLE_ENDIAN
    return (u_short)(((hostshort & 0xff) << 8) | ((hostshort & 0xff00) >> 8));
#else
    return hostshort;
#endif
}

u_short WINAPI ntohs(u_short netshort)
{
#if BYTE_ORDER == LITTLE_ENDIAN
    return (u_short)(((netshort & 0xff) << 8) | ((netshort & 0xff00) >> 8));
#else
    return netshort;
#endif
}
