/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* Initialize the machine-dependent part of a thread object.
 * The (new) thread should be set to execute the function START
 * with argument ARG.  No scheduling side-effects.
 */
void MachineThreadCreate(PITHREAD pThis, THREAD_FUNCTION pStart, 
                         THREAD_ARGUMENT Arg, PTR StackTop, UINT ArgCount,
                         UINT32 Flags)
{
    UINT32 *pStk = (UINT32 *)StackTop;
    CXTINFO *pCxt;
    UINT32 a0 = 0 ,a1 = 0, a2 = 0, a3 = 0;
    ADDRESS Return;

    if (ArgCount == -1) {
        a0 = (UINT32) Arg;
        Return = (UINT32) ThreadExit;
    } else {
        /* Args are on stack. Pop up to four of them into regs.
         */
        if (ArgCount > 0)
            a0 = *pStk++;
        if (ArgCount > 1)
            a1 = *pStk++;
        if (ArgCount > 2)
            a2 = *pStk++;
        if (ArgCount > 3)
            a3 = *pStk++;

        Return = (UINT32) Arg;
    }
    /* Make room for context on stack
     * Thread's initial state will point there.
     */
    pCxt = (CXTINFO *)pStk;
    pCxt--;
    pTH(pThis)->CxtInfo = pCxt;

    /* Setup non-zero registers
     */
    pCxt->CPSR = 0x13;
    pCxt->PC = (UINT32) pStart;
    pCxt->SP = (UINT32) pStk;
    pCxt->R0 = a0;
    pCxt->R1 = a1;
    pCxt->R2 = a2;
    pCxt->R3 = a3;
    pCxt->R14 = Return;
}
