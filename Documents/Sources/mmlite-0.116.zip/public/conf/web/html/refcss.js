// Copyright (c) Microsoft Corporation. All rights reserved.
//
writeCSS(scriptPath());

function scriptPath()
{
	var col = document.scripts;
	return col[col.length - 1].src;
}

function writeCSS(spath)
{
	// Get a base CSS name based on the browser.
	var css = "backsdkn.css";
	if (navigator.appName == "Microsoft Internet Explorer") {
		var sVer = navigator.appVersion;
		sVer = sVer.substring(0, sVer.indexOf("."));
		if (sVer >= 4)
			css = "ref4.css";
		else
			css = "backsdk3.css";
	}

	// The CSS is in the same directory as the script.
	css = spath.replace(/refcss.js/, css);
	document.writeln('<LINK REL="stylesheet" HREF="' + css + '">');
}

function loadError(oSRC, str) {
    var oErr = oSRC.parseError;

    var s = "";
    for (var i=1; i < oErr.linepos; i++) {
        s += " ";
    }
    alert("XML parse error " + oErr.url + "(" + oErr.line + "): pos " + oErr.linepos + "\n" + oErr.reason + "\n"
          + oErr.srcText + "\n" + s + "^");
}

function load_xml(file, validate) {
  var oXML = new ActiveXObject("MSXML.DOMDocument");
  oXML.validateOnParse = validate;
  oXML.async = false;
  if (!oXML.load(file)) {
      loadError(oXML, "Load of " + file + " failed");
      return null;
  }

  return oXML;
}

function findLink(directory, indexfile, key)
{
    var file = "";

    if (directory == "")
        file = indexfile;
    else
        file = directory + "/" + indexfile;

    var oXML = load_xml(file);
    if (oXML == null) {
        return;
    }

    var node = oXML.selectSingleNode("//A[@NAME = '" + key + "']");
    if (node == null) {
        alert("\"" + key + "\" not found in " + indexfile);
        return;
    }
    var link = node.getAttribute("HREF");
    if (link == null) {
        alert("\"" + key + "\" in " + file + " has no HREF");
        return;
    }

    if (directory != "")
        link = directory + "/" + link;

    // alert(link);

    window.navigate(link);
}

function PrintHeader(text) {
	document.write("<TABLE CLASS='buttonbarshade' CELLSPACING='0'><TR><TD>\n</TD></TR></TABLE>\n");
	document.write("<TABLE CLASS='buttonbartable' CELLSPACING='0'><TR ID='hdr'><TD CLASS='runninghead'>");
	document.write("Microsoft Invisible Computing");
	document.write("</TD>");
        if (text != null) {
          document.write("<TD>" + text + "</TD>\n");
        }       
        document.write("</TR></TABLE>\n<br/>\n");
}

function PrintFooter(myroot) {
	document.write("<TABLE CLASS='footerbar' CELLSPACING='0'><TR><TD>\n</TD></TR></TABLE>\n");
	document.write("<TABLE CLASS='footerbartable' CELLSPACING='0'><TR ID='hdr'>");
	document.write("<TD CLASS='runninghead'>�2004 Microsoft Corporation. All rights reserved.</TD>");
	document.write("<TD CLASS='runninghead'><A HREF='http://www.microsoft.com/isapi/gomscom.asp?target=/info/cpyright.htm' TARGET='_top'>Terms of Use</A></TD>");
	document.write("<TD CLASS='runninghead'><A HREF='http://www.microsoft.com/isapi/gomscom.asp?target=/info/privacy.htm' TARGET='_top'>Privacy Statement</A></TD>");
	document.write("<TD CLASS='runninghead'><A HREF='http://www.microsoft.com/isapi/gomscom.asp?target=/enable/' TARGET='_top'>Accessibility</A></TD>");
	document.write("<TD CLASS='runninghead'><A HREF='" + myroot + "/EULA.htm'>End User License Agreement</A></TD>");
	document.write("</TD></TR></TABLE>");
}
