/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file selectively defines things commonly needed by other include files
 * such as stdio.h.
 *
 * NOTE: This file needs to be multiple included, do not add guards.
 */

#include <mmlite_md.h>             /* For UINT, UINT32 */

#if !defined(_SIZE_T_DEFINED) && defined(__NEEDS_SIZE_T)
#ifdef _MSC_VER                 /* builtin prototypes */
typedef unsigned int size_t;
#elif defined(__GNUC__) && defined(arm)
typedef unsigned long size_t;
#else
typedef UINT size_t;
#endif
#define _SIZE_T_DEFINED
#endif

#if !defined(EXTERN_C) && defined(__NEEDS_EXTERN_C)
#if defined(__cplusplus)
#define EXTERN_C    extern "C"
#else
#define EXTERN_C    extern
#endif
#endif

#if !defined(_MSC_VER) && !defined(__cdecl)
#define __cdecl
#endif

#if !defined(NULL) && defined(__NEEDS_NULL)
#ifdef __cplusplus
#define NULL    0
#else
#define NULL    ((void *)0)
#endif
#endif

#if !defined(_WCHAR_T_DEFINED) && defined(__NEEDS_WCHAR_T) && !((defined(ADS) || defined(__ADSPBLACKFIN__)) && defined(__cplusplus))
typedef unsigned short wchar_t;
#define _WCHAR_T_DEFINED
#endif

#if !defined(_WCTYPE_T_DEFINED) && defined(__NEEDS_WCTYPE_T)
typedef wchar_t wint_t;
typedef wchar_t wctype_t;
#define _WCTYPE_T_DEFINED
#ifndef WEOF
#define WEOF (wint_t)(0xFFFF)
#endif
#endif


#if !defined(offsetof) && defined(__NEEDS_OFFSETOF)
#define offsetof(s,m)   (size_t)&(((s *)0)->m)
#endif

#if !defined(__ROUND) && defined(__NEEDS_ROUND)
/* Generic rounding macros. _size_ must be power of 2 (or result is garbage) */
#define __TRUNC(_addr_, _size_) ((_addr_) & ~((_size_) - 1))
#define __ROUND(_addr_, _size_) __TRUNC((_addr_) + (_size_) - 1, (_size_))
#endif
