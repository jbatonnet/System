/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _timer_h_
#define _timer_h_

struct _TheHWTimer
{
    volatile BYTE    Timer0;
    BYTE    pad0[3];
    volatile BYTE    Timer1;
    BYTE    pad1[3];
    volatile BYTE    Timer2;
    BYTE    pad2[3];
    volatile BYTE    Control;    /* Control Word*/
};

#define TheHWTimer ((struct _TheHWTimer *)0xFFFF1800)

#define SC_0        0x00
#define SC_1        0x40
#define SC_2        0x80
#define SC_READBACK 0xC0

#define RW_LATCH    0x00
#define RW_LSB      0x10
#define RW_MSB      0x20
#define RW_LSB_MSB  0x30

#define MODE0       0x00
#define MODE1       0x02
#define MODE2       0x04
#define MODE3       0x06
#define MODE4       0x08
#define MODE5       0x0A

#define BCD         0x01
#define BINARY      0x00

#define RB_0        0x02
#define RB_1        0x04
#define RB_2        0x08
#define RB_STATUS_NOT 0x10
#define RB_COUNT_NOT  0x20

#define STATUS_NULL 0x40
#define STATUS_OUT  0X80

#endif /* _timer_h_*/
