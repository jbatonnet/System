/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>

DRIVER_CONFIG DriverConfigs[] = {
  {_T("null"), _T("COB/null.cob"), 0, },

  {NULL,}    
};
