/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* The public interface of a Sample Factory.
 * This file would normally go into inc, but as this is just a sample,
 * I didn't put it there.
 */
#ifndef _SAMPFAC_H_
#define _SAMPFAC_H_

/* ------------------- Sample constructor interface ----------------------- */
typedef struct ISampleFactory *PISAMPLEFACTORY;
extern const struct IID IID_ISampleFactory;

#if defined(__cplusplus) && !defined(CINTERFACE)
interface ISampleFactory : public IUnknow {
  public:
    virtual SCODE CreateNullFile(PIUNKNOWN *ppNullFile);
    virtual SCODE CreateFilterFile(PIFILE pParent, UINT64 Offset, UINT64 Size,
                                   PIUNKNOWN *ppRestrictedFile);
};
#else
struct ISampleFactoryVtbl {
    __VTABLE_COMPATIBILITY_FILLER_DECLARATION

    SCODE (*QueryInterface)(PISAMPLEFACTORY This, REFIID Iid, void **ppObject);
    UINT (*AddRef)(PISAMPLEFACTORY This);
    UINT (*Release)(PISAMPLEFACTORY This);

    SCODE (*CreateNullFile)(PISAMPLEFACTORY This, PIUNKNOWN *ppNullFile);
    SCODE (*CreateFilterFile)(PISAMPLEFACTORY This,
                              PIFILE pParent,
                              UINT64 Offset,
                              UINT64 Size,
                              PIUNKNOWN *ppRestrictedFile);
};

struct ISampleFactory {
    CONST_VTBL struct ISampleFactoryVtbl *v;
};
#endif /* __cplusplus */
#endif /* _SAMPFAC_H_ */
