/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* If a namespace object named "MyNamespace/" already exists, get
 * a pointer to it.  Otherwise, create a new namespace object.
 */
INameSpace *pSysNS;
IUnknown *pUnknown;
SCODE StatusCode;
_TCHAR ObjName[] = _TEXT("MyNamespace/");

/* Get a pointer to the object registered as "MyNamespace/". */
pSysNS = CurrentNameSpace();
StatusCode = pSysNS->Bind(ObjName, 0, &pUnknown);
if (FAILED(StatusCode)) {
    /* Need to create namespace object named "MyNamespace/" */
    _tprintf(_TEXT("Namespace \"%s\" does not exist--create it.\n"),
                  ObjName);
    StatusCode = pSysNS->Bind(ObjName, NAME_SPACE_CREATE, &pUnknown);
    if (FAILED(StatusCode)) {
        _tprintf(_TEXT("Failed to create namespace %s.\n"), ObjName);
        exit(0);
    }
}
_tprintf(_TEXT("The namespace object named \"%s\""), ObjName);
_tprintf(_TEXT(" is located at address %08x\n"), (ADDRESS) pUnknown);
pUnknown->Release();
/* END_SAMPLE */
return 0;
}
