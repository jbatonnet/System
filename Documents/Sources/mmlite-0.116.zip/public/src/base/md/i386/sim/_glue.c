/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <import_windows.h>
#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <winsock.h>
#include "_ntmmglu.h"
#include <fred.h>

/* Internal NT Stuff */
typedef struct _KSYSTEM_TIME {
    UINT32 LowPart;
    INT32 High1Time;
    INT32 High2Time;
} KSYSTEM_TIME, *PKSYSTEM_TIME;

typedef struct _KUSER_SHARED_DATA {

    /* Current low 32-bit of tick count and tick count multiplier.
     * N.B. The tick count is updated each time the clock ticks.
     */
    volatile ULONG TickCountLow;
    UINT32 TickCountMultiplier;

    /* Current 64-bit interrupt time in 100ns units. */
    volatile KSYSTEM_TIME InterruptTime;

    /* Current 64-bit system time in 100ns units. */
    volatile KSYSTEM_TIME SystemTime;

    /* Current 64-bit time zone bias. */
    volatile KSYSTEM_TIME TimeZoneBias;
} KUSER_SHARED_DATA, *PKUSER_SHARED_DATA;

#define MM_SHARED_USER_DATA_VA      0x7FFE0000
#define USER_SHARED_DATA ((KUSER_SHARED_DATA * const)MM_SHARED_USER_DATA_VA)



EXTERN_C INT __cdecl NT_printf(const char *format, ...);

/* for old compiler */
#ifndef CreateWaitableTimer
WINBASEAPI
HANDLE
WINAPI
CreateWaitableTimerA(
    LPSECURITY_ATTRIBUTES lpTimerAttributes,
    BOOL bManualReset,
    LPCSTR lpTimerName
    );
WINBASEAPI
HANDLE
WINAPI
CreateWaitableTimerW(
    LPSECURITY_ATTRIBUTES lpTimerAttributes,
    BOOL bManualReset,
    LPCWSTR lpTimerName
    );
#ifdef UNICODE
#define CreateWaitableTimer  CreateWaitableTimerW
#else
#define CreateWaitableTimer  CreateWaitableTimerA
#endif // !UNICODE
typedef
VOID
(APIENTRY *PTIMERAPCROUTINE)(
    LPVOID lpArgToCompletionRoutine,
    DWORD dwTimerLowValue,
    DWORD dwTimerHighValue
    );

WINBASEAPI
BOOL
WINAPI
SetWaitableTimer(
    HANDLE hTimer,
    const LARGE_INTEGER *lpDueTime,
    LONG lPeriod,
    PTIMERAPCROUTINE pfnCompletionRoutine,
    LPVOID lpArgToCompletionRoutine,
    BOOL fResume
    );

#endif

#define fflush(x)

PRIVATE TIMERCALLBACK TimerCallBack = NULL;
PRIVATE HANDLE TheTimer;
PRIVATE HANDLE TheThread;
PRIVATE HANDLE TimerThread;
PRIVATE __int64 NextTime = 0;


PRIVATE ADDRESS MemStart, MemEnd;
//#define MEMSIZE 0xa0000       /* 640 KB */
#define MEMSIZE 0x1000000     /* 16 MB */
//#define MEMSIZE 0x40000         /* 256 KB */

 /* Create the system heap.  Left to machdep code because messy otherwise.
  * The heap should account for all available memory, carved out of memory
  * that is already used or unavailable (like the 640K-1meg hole on PCs).
  * It does not have to account for all the memory in the system.
  * Returns a PIHEAP pointer.
  */
PIHEAP MachineHeapCreate( void )
{
    ADDR_SIZE MemSize;

    MemSize = MEMSIZE;
    MemStart = (unsigned int) VirtualAlloc(0, MemSize, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    if (!MemStart) {
        _asm int 3;
//      printf("VirtualAlloc failed\n"); fflush(stdout);
    }

    MemEnd = MemStart + MemSize;

    return CreateHeapFrom(MemStart, 0, 0, MemSize);
}

HANDLE IdleEvent = INVALID_HANDLE_VALUE;

void NT_Idle(void)
{
#if 1
    WaitForSingleObject(IdleEvent, INFINITE);
#else
    SleepEx(0, TRUE);
#endif
}

PRIVATE void APIENTRY NullApc (DWORD Arg)
{
    UnusedParameter(Arg);
}

PRIVATE void TimerTriggerInterrupt(UINT InterruptId)
{
    int Result;
    CONTEXT cxt;
    static BOOL FirstTime = TRUE;

    cxt.ContextFlags = CONTEXT_CONTROL;

//  printf("[WOKE UP]\n"); fflush(stdout);
    Result = SuspendThread(TheThread);
    if (Result < 0) {
//          printf("SuspendThread failed\n"); fflush(stdout);
      _asm int 3;
    }
    SetEvent(IdleEvent);
//      printf("[Worker suspended]\n"); fflush(stdout);
    Result = GetThreadContext(TheThread, &cxt);
    if (!Result) {
//          printf("GetThreadContext failed\n"); fflush(stdout);
      _asm int 3;
    }

    if (FirstTime)
        FirstTime = FALSE;
    else
        assert(cxt.Esp >= MemStart && cxt.Esp < MemEnd);

    Result = (*TimerCallBack)(&cxt.Eip, &cxt.SegCs, &cxt.Esp, &cxt.EFlags,
                              InterruptId);

    if (Result) {
        Result = SetThreadContext(TheThread, &cxt);
        if (!Result) {
            //      printf("SetThreadContext failed\n"); fflush(stdout);
            _asm int 3;
        }
    }

#if 0 /* too flaky, there is a race of some kind, oh well... */
    /* More bogosity. This is to get the thread out of idle sleep */
    Result = QueueUserAPC(NullApc, TheThread, 0);
    if (!Result) {
        printf("QueueUserAPC failed %x\n", Result); fflush(stdout);
        _asm int 3;
    }
#endif
    
    Result = ResumeThread(TheThread);
    if (Result < 1) {
//          printf("ResumeThread failed\n"); fflush(stdout);
      _asm int 3;
    }
}

extern HANDLE TheCompletionEvent;
PRIVATE HANDLE Handles[10] = {0,};

PRIVATE void TimerThreadRoutine(void *p)
{
    int Result;
    static int FirstTime = TRUE;
    UnusedParameter(p);

//    printf("TestThreadRoutine\n"); fflush(stdout);

    if (FirstTime)
        FirstTime = FALSE;
    else
        _asm int 3;

    Result = SetThreadPriority(GetCurrentThread(),
                               /*THREAD_PRIORITY_ABOVE_NORMAL dont */
                               /*THREAD_PRIORITY_HIGHEST*/
                               THREAD_PRIORITY_TIME_CRITICAL
                               );
    if (!Result) {
//      printf("Unable to boost priority\n"); fflush(stdout);
        _asm int 3;
    }
    for (;;) {
        Handles[0] = TheTimer;
        Handles[1] = TheCompletionEvent;
        Result = WaitForMultipleObjectsEx(2, Handles, FALSE, INFINITE, TRUE);
        if (Result != WAIT_OBJECT_0 && Result != WAIT_OBJECT_0 + 1) {
            _asm int 3;
        }
        TimerTriggerInterrupt(Result);
//      printf("[WAIT]\n"); fflush(stdout);
    }
}

#if 0
//NTSTATUS
//NTAPI
LONG
__stdcall
NtSetTimerResolution (
    IN ULONG DesiredTime,
    IN BOOLEAN SetResolution,
    OUT PULONG ActualTime
    );
// NTSTATUS
// NTAPI
LONG
__stdcall
NtQuerySystemTime (
    OUT unsigned _int64 *pSystemTime
    );
#endif

LONG NT_NtQuerySystemTime(
    OUT unsigned _int64 *pSystemTime)
{
    HANDLE h;
    static LONG (_stdcall *pFunc)(OUT unsigned _int64 *pSystemTime) = NULL;

    if (pFunc == NULL) {
        h = GetModuleHandle(_T("ntdll.dll"));
        assert(h != INVALID_HANDLE_VALUE);
        if (h == INVALID_HANDLE_VALUE || h == NULL)
            return 0;

        pFunc = (LONG (_stdcall *)(
            OUT unsigned _int64 *pSystemTime
            )) GetProcAddress(h, "NtQuerySystemTime");
        assert(pFunc != NULL);
    }
    if (pFunc == NULL)
        return 0;

    return (*pFunc)(pSystemTime);
}

LONG NT_NtSetTimerResolution(
    IN ULONG DesiredTime,
    IN BOOLEAN SetResolution,
    OUT PULONG ActualTime)
{
    HANDLE h;
    static LONG (_stdcall *pFunc)(
        IN ULONG DesiredTime,
        IN BOOLEAN SetResolution,
        OUT PULONG ActualTime) = NULL;

    if (pFunc == NULL) {
        h = GetModuleHandle(_T("ntdll.dll"));
        assert(h != INVALID_HANDLE_VALUE);
        if (h == INVALID_HANDLE_VALUE || h == NULL)
            return 0;

        pFunc = (LONG (_stdcall *)(
            IN ULONG DesiredTime,
            IN BOOLEAN SetResolution,
            OUT PULONG ActualTime)) GetProcAddress(h, "NtSetTimerResolution");
        assert(pFunc != NULL);
    }
    if (pFunc == NULL)
        return 0;

    return (*pFunc)(DesiredTime, SetResolution, ActualTime);
}

__int64 SysToIntTimeOffset = UINT64_ZERO;

/* Initializes the offset between SystemTime and InterruptTime */
void InitTime(void)
{
    union {
        KSYSTEM_TIME SysTime;
        __int64 CurrTime;
    } it, st;

    /* Wait for the system time to change. This ensures that I read
     * SystemTime and InterruptTime when they're most in sync, just after 
     * they've both been updated.
     * (Based on knowledge that SystemTime is updated _after_ InterruptTime)
     */
    st.SysTime.LowPart   = USER_SHARED_DATA->SystemTime.LowPart;
    while (st.SysTime.LowPart == USER_SHARED_DATA->SystemTime.LowPart);

    /* Read system time */
    do {
        st.SysTime.High1Time = USER_SHARED_DATA->SystemTime.High1Time;
        st.SysTime.LowPart   = USER_SHARED_DATA->SystemTime.LowPart;
    } while (st.SysTime.High1Time != USER_SHARED_DATA->SystemTime.High2Time);

    /* Read interrupt time */
    do {
        it.SysTime.High1Time = USER_SHARED_DATA->InterruptTime.High1Time;
        it.SysTime.LowPart   = USER_SHARED_DATA->InterruptTime.LowPart;
    } while (it.SysTime.High1Time != USER_SHARED_DATA->InterruptTime.High2Time);

    /* Save offset between the two */
    SysToIntTimeOffset = st.CurrTime - it.CurrTime;
#ifdef _DEBUG
    printf("SysToIntTimeOffset=0x%016llx\n",SysToIntTimeOffset);
#endif
}

/*
 * If anything needs to be done to start the system timer(s),
 * do it when this function is called.
 */
PRIVATE ULONG TimeDeltaIs;

void NT_EnableTimers(TIMERCALLBACK CallBack)
{
    HANDLE pseudo;
    int RetVal;
    SCODE st;
    static int FirstTime = TRUE;
    double hz;

    /* ask for maximum clock granularity */
    st = NT_NtSetTimerResolution( 1, TRUE, &TimeDeltaIs);

    hz = (double) TimeDeltaIs;
    hz = 10000000.0 / hz;
    
#ifdef _DEBUG
    printf("Timer resolution is %d00 ns (%d Hz)\n",
           TimeDeltaIs, -1/*(UINT) hz*/);
#endif
    if (FirstTime)
        FirstTime = FALSE;
    else
        _asm int 3;

    InitTime();

    pseudo = GetCurrentThread();
    RetVal = DuplicateHandle(GetCurrentProcess(), pseudo,
                             GetCurrentProcess(), &TheThread,
                             0, FALSE, DUPLICATE_SAME_ACCESS);
    if (!RetVal) {
//      printf("DuplicateHandle for this thread failed\n"); fflush(stdout);
        _asm int 3;
    }
    TheTimer = CreateWaitableTimer(NULL, FALSE, NULL);
    if (!TheTimer) {
        _asm int 3;
//      printf("CreateWaitableTimer failed\n");
    }
    TimerCallBack = CallBack;

    TimerThread = CreateThread( NULL,
                                0,
                                (LPTHREAD_START_ROUTINE)TimerThreadRoutine,
                                0,
                                0,
                                0);
//    printf("Created Timer thread %x This=%x Timer=%x\n", TimerThread, TheThread, TheTimer); fflush(stdout);
}

/*
 * If anything needs to be done to stop the system timer(s),
 * do it when this function is called.  
 * Called on kernel (orderly) shutdown. 
 */
extern void NT_DisableTimers(void)
{
    /* reset timer to what it was */
    (void) NT_NtSetTimerResolution( 0, FALSE, &TimeDeltaIs);
//    printf("NT_DisableTimers\n"); fflush(stdout);
}

/* Return the current time in 100ns units since Jan 1, 1601
 * This code reads the interrupt time and then converts to absolute time
 * so it's accurate to within one timer interrupt
 */
__int64 NT_GetKernelTime(void)
{
    union {
        KSYSTEM_TIME SysTime;
        __int64 CurrTime;
    } ts;

    do {
        ts.SysTime.High1Time = USER_SHARED_DATA->InterruptTime.High1Time;
        ts.SysTime.LowPart   = USER_SHARED_DATA->InterruptTime.LowPart;
    } while (ts.SysTime.High1Time != USER_SHARED_DATA->InterruptTime.High2Time);

    return ts.CurrTime + SysToIntTimeOffset;
}

#if 0
/*
 * Return count of time since boot in 100 ns units.
 * Resolution is machine-specific.
 *
 * This version uses a trap and has low resolution.
 * The official published interface GetSystemTime is no good either.
 */
extern _int64 NT_GetKernelTime (void)
{
    static unsigned _int64 LastTime = 0;
    unsigned _int64 SysTime;

    /* ASSUME! not reentered */

    (void) NT_NtQuerySystemTime(&SysTime);
    if (SysTime <= LastTime)
        SysTime = LastTime + 1;
    LastTime = SysTime;
    return SysTime;
}
#endif

#if 0
VOID APIENTRY TimerApcRoutine(LPVOID lpArgToCompletionRoutine,
                              DWORD dwTimerLowValue,
                              DWORD dwTimerHighValue)
{
//    printf("TimerApcRoutine\n"); fflush(stdout);
    _asm int 3;
}
#endif

 /* Set the hardware programmable interrupt timer (PIT) to
  * give us an interrupt in DELTA time units from now.
  */
extern void NT_SetNextInterrupt( int Delta)
{
    _int64 t;
    static int count = 0;

#if 1 /* XXX, too short or too long timeouts??? */
    /* XXX Also should account for overhead somehow */
    if (Delta < (int) TimeDeltaIs)
        Delta = TimeDeltaIs;/* we really shouldnt do this... */
#endif
    t = -Delta;         /* Make it 'relative' time */

//    t *= 40;
//    printf("NT_SetNextInterupt %I64d 00 ns\n", Delta); fflush(stdout);
    count++;
#if 0
    if (count > 1) {
        _asm int 3;
//      printf("XXX Not setting timer\n"); fflush(stdout);
        return;
    }
#endif
    SetWaitableTimer(TheTimer, (LARGE_INTEGER *) &t, 0,
                     NULL /*TimerApcRoutine*/, NULL, FALSE);
}

/* Returns the speed of the current processor.
 * BUGBUG Fix Brad' MHz code to keep more bits of the freq.
 */
extern int MHz(int Iterations);

extern UINT64 NT_CurrentProcessorSpeed(void)
{
    static UINT64 Speed = 0;

    if (Speed == 0) {
        int m = MHz(3);
        if (m > 0)
            Speed = 1000000 * m;
    }
    return Speed;
}

 /* Terminate the system.  Whatever that means (=>machdep)
  */
extern void NT_TheEnd(void)
{
    int RetVal;
//    printf("NT_TheEnd"); fflush(stdout);
#ifdef _MSC_VER
#pragma warning(disable:6258)   /* TerminateThread is bad */
#endif
    RetVal = TerminateThread(TimerThread, 0);
    if (!RetVal) {
        _asm int 3;
        printf("NT_TheEnd, unable to terminate TimerThread\n");
    }
#if 0
    DebugBreak();
#elif 0
    exit(0);
#else
    TerminateProcess(GetCurrentProcess(), 0);
#endif
}

PRIVATE HANDLE StdOutHandle;

int main(int argc, char *argv[]);

void mainCRTStartup()
{
    int i;
    StdOutHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    i = main(0, NULL);
    TerminateProcess(GetCurrentProcess(), i);
}

//#include <io.h>

void NT_putchar(unsigned char c)
{
    DWORD written;

    WriteFile(StdOutHandle, &c, 1, &written, NULL);
    if (written != 1)
        DebugBreak();
}

int NT_getchar(void)
{
    DWORD count, rv = 0;
    int c;
    BOOL ok;
    HANDLE StdInHandle = GetStdHandle(STD_INPUT_HANDLE);
    INPUT_RECORD Input;
    DWORD OldMode = 0, NewMode;

#if 1
    /* Modify console mode */
    if ( GetConsoleMode(StdInHandle, &OldMode) == FALSE ) {
        assert(FALSE);
        return -1;              /* EOF */
    }

    NewMode = OldMode & ~(ENABLE_LINE_INPUT
                          | ENABLE_ECHO_INPUT
                          | ENABLE_WINDOW_INPUT
                          | ENABLE_MOUSE_INPUT);
    NewMode = 0;

    if ( SetConsoleMode(StdInHandle, NewMode) == FALSE ) {
        assert(FALSE);
        return -1;
    }


    for (;;) {
        rv = WaitForSingleObject(StdInHandle, 0);
        if (rv == WAIT_TIMEOUT) {
            c = -2; /* Would block */
            break;
        }
        assert(rv == WAIT_OBJECT_0);

        ok = ReadConsoleInput(StdInHandle, &Input, 1, &count);
        if (!ok || count != 1) {
            assert(FALSE);
            c = -1;
            break;
        }

        if (Input.EventType == KEY_EVENT
            && Input.Event.KeyEvent.bKeyDown == TRUE)
        {
            c = Input.Event.KeyEvent.uChar.AsciiChar;
            break;
        }
    }

    /* Restore mode. Makes control c work again. */
    SetConsoleMode(StdInHandle, OldMode);
#else
    ok = ReadFile(StdInHandle, &c, 1, &count, NULL);
    if (!ok || count == 0)
        return -1; /* EOF */

    if (count != 1)
        DebugBreak();
#endif

    return (int) c;
}

void NT_puts(char *s)
{
    DWORD count;
    UINT Len = strlen(s);

    WriteFile(StdOutHandle, s, Len, &count, NULL);
    if (count != Len)
        DebugBreak();
}

void InitNtFileStuff(void);
BOOL InitPacketStuff(void);

DWORD SimThreadId = 0;

void NT_Init(void)
{
    //int ret;
    //WSADATA wsa;

#ifdef _DEBUG
    NT_puts("NT_Init\n");
#endif
    SimThreadId = GetCurrentThreadId();

    InitNtFileStuff();
#if 0
    ret = InitPacketStuff();
    if (ret == TRUE)
        printf("Raw packet driver present\n");
    else
        printf("Raw packet driver not enabled\n");

    ret = WSAStartup(MAKEWORD(2,2), &wsa);
    assert(ret == 0);
#endif
}

int __stdcall DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
    UnusedParameter(hInstance);
    UnusedParameter(lpReserved);

//    printf("ntmmglue DLLMain(x%x)\n", dwReason);
    if (dwReason == DLL_PROCESS_ATTACH)
    {
//        printf("PROJNAME.DLL Initializing!\n");
    }
    else if (dwReason == DLL_PROCESS_DETACH)
    {
//        printf("PROJNAME.DLL Terminating!\n");
    }
    return 1;   // ok
}

int NT_GetLastError(void)
{
    HANDLE h;
    static int (WINAPI *pGetLastError)() = NULL;

    if (pGetLastError == NULL) {
        h = GetModuleHandle(_T("kernel32.dll"));
        assert(h != INVALID_HANDLE_VALUE);
        if (h == INVALID_HANDLE_VALUE || h == NULL)
            return 0;

        pGetLastError = GetProcAddress(h, "GetLastError");
        assert(pGetLastError != NULL);
    }

    if (pGetLastError == INVALID_HANDLE_VALUE || pGetLastError == NULL)
        return -1;
    return (*pGetLastError)();
}

/**** Leftovers from old _hostfsd.c ****/
#define DPRINT(x)

typedef struct {
    OVERLAPPED ol;
    CONDITION cnd;
} MYOVERLAPPED;

static HANDLE TheCompletionPort = INVALID_HANDLE_VALUE;
HANDLE TheCompletionEvent = INVALID_HANDLE_VALUE;
void InitNtFileStuff()
{
    TheCompletionPort = CreateIoCompletionPort(INVALID_HANDLE_VALUE,NULL,0,0);
    assert(TheCompletionPort != INVALID_HANDLE_VALUE);

    TheCompletionEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
    assert(TheCompletionEvent != INVALID_HANDLE_VALUE);

    IdleEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
    assert(IdleEvent != INVALID_HANDLE_VALUE);
}

/* All we do here is signal the condition that is waiting for
 * a particular i/o to complete.  The OVERLAPPED is followed by the condition.
 */
void ActualIoCompletionInterrupt()
{
    BOOL ok;
    DWORD Transferred, Key;
    OVERLAPPED *pol;
    MYOVERLAPPED *mo;

    ok = GetQueuedCompletionStatus(TheCompletionPort, &Transferred,
                                   &Key, &pol, 0);
    DPRINT(("ActualIoCompletionInterrupt ok=%x transferred=%x\n",
           ok, Transferred));
    if (!ok)
        return;

    mo = (MYOVERLAPPED *) pol;
    Condition_InterruptSignal(&mo->cnd);
}
