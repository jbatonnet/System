/* Copyright (c) Microsoft Corporation. All rights reserved. */

/*
 * Test for the EB63 board buttons SW1..SW4 (and LEDs)
 */

#include <mmlite.h>
#include <stdio.h>
#include <tchar.h>

#include <arm/at91m63200.h>
#include <drivers/drivers.h>

#ifdef _MSC_VER
#pragma warning(disable:4054)   /* cast from function ptr to data ptr (/Za) */
#endif

void setled(int ledno, BOOL on)
{
    if (on)
        PioB->ClearData = PIOB_PB8 << (ledno - 1);
    else
        PioB->SetData = PIOB_PB8 << (ledno - 1);
}


#define nBUTTONS 3

struct _BUTTON {
    UINT EventIndex;
    UINT LastConsumed;
    TIME LastAt;
};

struct _PioDriver {
    CONDITION cd;
    struct _Pio *hw;
    BOOL TimeToDie;
    struct _BUTTON b[nBUTTONS];
};

/* ISR for Buttons that are multiplexed
 */
BOOL MCT PioIsr(void *iThis, PBOOL pNotMyInterrupt)
{
    struct _PioDriver *This = (struct _PioDriver *) iThis;
    UINT Pins, Ints, ButtonNo, bit;
    TIME Now, Last;
    static const TIME DEBOUNCE_TIME = Int64Initializer(0,TIME_MILLIS(10));

    Pins = This->hw->PinDataStatus;
    /* See what ISR-enabled button was pressed
     * NB: This clears the interrupt also.
     */
    Ints = This->hw->IntrStatus & This->hw->IntrMask;

    /* sanity check
     */
    if (Ints == 0) {
        *pNotMyInterrupt = TRUE;
        return FALSE;
    }

    Now = CurrentTime();

    /* There might be more than one pending, dispatch all we got
     */
    for (ButtonNo = 0; ButtonNo < 3; ButtonNo++) {
        struct _BUTTON *b = &This->b[ButtonNo];
        /* If the bit isn't set, skip it */
        bit = PIOB_PB3 << ButtonNo;
        if ((Ints & bit) == 0)
            continue;
        
        /* Debounce the hw */
        Last = b->LastAt;
        Last = TimeSubtract(Now, Last);
        if (TimeLess(Last, DEBOUNCE_TIME))
            continue;

        /* Mark the interrupt received */
        b->EventIndex++;

        /* Make sure we don't get out of sync. If we debounced too much,
         * add another event (0=out,1=in;  even=out,odd=in
         */
        if (!(Pins & bit) && !(b->EventIndex & 1))
            b->EventIndex++;

        /* Record the event time */
        b->LastAt = Now;
    }

    /* Wake up the thread, if necessary */
    return Condition_InterruptSignal(&This->cd);
}

/* This thread does all the non-ISR work */
void THREAD_LINKAGE ButtonThread(THREAD_ARGUMENT arg)
{
    struct _PioDriver *This = (struct _PioDriver *)arg;
    UINT ButtonNo;

    _tprintf(_TEXT("ButtonThread started (%x)\r\n"),(ADDRESS)This);
    
    while (!This->TimeToDie) {
        (void) Condition_Wait(&This->cd, NULL, NULL);
        
        printf("Pio: %x\r\n", PioB->PinDataStatus);
        for (ButtonNo = 0; ButtonNo < nBUTTONS; ) {
            struct _BUTTON *b = &This->b[ButtonNo];
            if (b->EventIndex > b->LastConsumed) {
                if (b->LastConsumed & 1) {
                    _tprintf(_TEXT("Button%d release at %lld00"),
                             1+ButtonNo, b->LastAt);
                    setled(1+ButtonNo,FALSE);
#define DIE_BUTTON (3-1)
                    if (ButtonNo == DIE_BUTTON)
                        This->TimeToDie = TRUE;
                } else {
                    _tprintf(_TEXT("Button%d press at %lld00"),
                             1+ButtonNo,b->LastAt);
                    setled(1+ButtonNo,TRUE);
                }
                b->LastConsumed++;
            } else {
                ButtonNo++;
            }
        }
    }

    /* Disable button interrupts */
    PioB->IntrDisable = PIOB_PB3 | PIOB_PB4 | PIOB_PB5;
    RemoveDevice((PTR)PioB,14);

    _tprintf(_TEXT("ButtonThread terminated (%x)\r\n"),(ADDRESS)This);
}

/* Main driver program
 */
int _tmain(INT argc, _TCHAR **argv)
{
    SCODE sc;
    PIPROCESS pPrc = CurrentProcess();
    static struct _PioDriver pa = {CONDITION_INITIALIZER, PioB,};

    UnusedParameter(argc);
    UnusedParameter(argv);

    _tprintf(_TEXT("Initializing Button 4\r\n"));
    sc = pPrc->v->CreateThread(pPrc,
                               0,
                               ButtonThread,
                               (THREAD_ARGUMENT)&pa,
                               0,
                               NULL,
                               NULL);

    _tprintf(_TEXT("Initializing Buttons 1,2,3\r\n"));
    PioB->Disable = PIOB_PB3 | PIOB_PB4 | PIOB_PB5;
    PioB->FilterEnable = PIOB_PB3 | PIOB_PB4 | PIOB_PB5;
    sc = PioB->IntrStatus; /* clear pending */
    sc = AddDevice ((PTR)&pa, (PTR) PioIsr, DEVICE_FLAGS_LEVEL_TRIGGER, 14, NULL);
    PioB->IntrEnable = PIOB_PB3 | PIOB_PB4 | PIOB_PB5;

    /* Let this thread die, the other one has the refcount
     */

    return 0;
}

