/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
//#include <loaders/cobtab.h>

#define EB63BIG2 1
#include "eb63_cfg.c"

extern PIUNKNOWN Db161CobMain(void);

extern PIUNKNOWN HostfsCobMain(void);
extern PIUNKNOWN SerplexCobMain(void);

const struct PRECOB ThePreCobTable[] = {
#if 1
    EB63BIG_COBS
#else
    {_T("sernet.cob"), SerNetCobMain }, \
    {_T("serplex.cob"), SerplexCobMain }, \
    {_T("hostfs.cob"), HostfsCobMain }, \
    BASIC_NET_COBS
    BASIC_SOAP_COBS
#endif
    {_T("eb63usart.cob"), SerialCobMain },
    {_T("db161.cob"), Db161CobMain },
    PRIVATE_SOAP_COBS
    {0,0}
};

/* Select root "fs" file system */
PINAMESPACE BoardInitRomFs(void);
PINAMESPACE BoardInitHostFs(void);

PINAMESPACE BoardInitFileSystem(void)
{
    /* Use RomFs with eb63big: it's a flashed standalone image */
    PINAMESPACE ns = BoardInitRomFs();
    if (!ns)                    /* not there */
        ns = BoardInitHostFs(); /* use hostfs instead */
    return ns;
}
