/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <stdio.h>
#include <mmhal.h>
#include <machdep.h>
#include "_pic.h"

#include <fred.h>               /* for InstallIsr */

/*
 * Documentation: PC's irq usage
 */
#define PIC0_I_PIT  0x01
#define PIC0_I_KBD  0x02
#define PIC0_I_PIC1 0x04
#define PIC0_I_NET  0x08
#define PIC0_I_SER  0x10
#define PIC0_I_PAR1 0x20
#define PIC0_I_FLPY 0x40
#define PIC0_I_PAR0 0x80

#define PIC1_I_RTC  0x01
#define PIC1_I_x87  0x20
#define PIC1_I_DSK  0x40
/*
 * enddoc 
*/

#define PIC_NS_EOI 0x20

/* On a PC-AT we have two cascaded PICs
 */
#define N_PIC 2
#define N_INTERRUPTS (8*N_PIC)

#define PIC0_PORT 0x20
#define PIC1_PORT 0xa0

#define KPIC0MASK 0xfa          /* only ticker clock, and slave PIC */
/*#define KPIC1MASK 0xfe        /* only RTC intr */
#define KPIC1MASK 0xff          /* nothing */


/* The interrupt dispatcher uses a table of handlers,
 * and a few masks. Things would be much simpler without
 * the BIOS/DOS in the way.. 
 */
typedef struct i8259 {
    const struct IPicVtbl *v;

    struct {
        INTERRUPT_SERVICE_ROUTINE Isr;  /* isr for IRQn */
        struct IDevice *pDevice;        /* Argument to pass to it */
    } InterruptTable[N_INTERRUPTS];

    struct i8259_MASK {
        IO_PORT PicPort;
        UINT8 BiosInitialMask;
        UINT8 BiosMask;
        UINT8 KernMask;
        UINT8 KernExclude;
    } MaskTable[N_PIC];
} i8259;

/* Forward decl */
extern struct i8259 Thei8259;


/* Interrupt dispatching
 * Interrupts all come to this one function, skewed by their IRQ number.
 */
#define DISPATCH_FOR_IRQ(_n_) ((ADDRESS) PICInterrupt + (_n_ * SIZEOF_INTR))

/*static */ __declspec(naked) void __cdecl PICInterrupt()
{
#define INTR(_n_) __asm { __asm nop __asm nop __asm nop __asm call Dispatch }
#define SIZEOF_INTR 8
#define SHIFTOF_INTR 6  /* log2(8*SIZEOF_INTR) */

        INTR( 0); INTR( 1); INTR( 2); INTR( 3); 
        INTR( 4); INTR( 5); INTR( 6); INTR( 7); 
        INTR( 8); INTR( 9); INTR(10); INTR(11); 
        INTR(12); INTR(13); INTR(14); INTR(15); 

    Dispatch:
    __asm {
        /* On top of the stack we now have PICInterrupt+(IRQ*8)+8
         * Save registers
         */
        /* ds slot is occupied by intrNo */
        push es;
        push gs;
        push fs;
        pushad;         /* eax, ecx, edx, ebx, bogus esp, ebp, esi, edi */
        push 0;         /* pFpa */

        /* Finally put ds where it belongs and get the caller address out */
        mov ax, ds;
        xchg [esp+48], eax;

        /* Get the proper offset into InterruptTable
         */
        sub     eax, OFFSET PICInterrupt+SIZEOF_INTR;
        mov     ecx, eax;

        /* Quiet slave PIC iff necessary
         */
        shr     eax, SHIFTOF_INTR;
        mov     al, PIC_NS_EOI;
        jz      eoi_master;
        out     PIC1_PORT,al;   /* one for slave  */

        /* Quiet master PIC
         */
    eoi_master:
        out     PIC0_PORT,al;   /* one for master */

        /* Dispatch the interrupt
         * Pass a NULL pNotMyInterrupt to say we do not handle
         * shared interrupts at this level.
         */
        push    0;
        push    DWORD PTR Thei8259.InterruptTable+4[ecx];
        call    DWORD PTR Thei8259.InterruptTable[ecx];
        add     esp, 8;         /* MCT is __cdecl */

        /* See if rescheduling might be necessary
         */
        test    eax,1;
        jz      getout;

        /* Yes, enter the scheduler. No return.
         */
        jmp     _Reschedule;

    getout:
        /* linkage */
        pop ecx;                /* get rid of pFpa */
        popad;
#if 0
        pop     fs;
        pop     gs;
        pop     es;
        pop     ds;
#else
        add     esp,16;
#endif
        iretd
    }
}


/* Change masks so that we handle an interrupt, and not the BIOS.
 * Install the Isr in the dispatch table, with its argument.
 * Tell the IDT to turn the interrupt to us.
 */
void MCT i8259EnableInterrupt( IPic *pThis, DEVICE_FLAGS Flags, UINT Irq, INTERRUPT_SERVICE_ROUTINE Isr, void *pDevice)
{
    struct i8259_MASK *pMask;
    i8259 *pic = (i8259*)pThis;
    UINT8 Bit;

    /* On PCs, IRQ 2 really is IRQ 9
     */
    if (Irq == 2)
        Irq = 9;

    /* The order of the following operations is NOT irrelevant
     *
     * First, the argument. Failure case is iff interrupt was
     * active and we are called with interrupts on and we get
     * an interrupt right after this statement. Wont happen.
     */
    pic->InterruptTable[ Irq ].pDevice = pDevice;

    /* Second, the ISR. If the interrupt was active we are done already.
     * If not, must activate it.
     */
    pic->InterruptTable[ Irq ].Isr = Isr;

    /* Put the dispatcher into the IDT.
     */
    InstallIsr( Irq, DISPATCH_FOR_IRQ(Irq), FALSE, FALSE);

    /* Deal with interrupt masking
     */
    if (Irq < 8) {
        Bit = (UINT8)(1 << Irq);
        pMask = &pic->MaskTable[0];
    } else {
        Bit = (UINT8)(1 << (Irq&7));
        pMask = &pic->MaskTable[1];
    }

    /* This interrupt no longer masked
     */
    pMask->KernMask &= (UINT8)(~Bit);
    pMask->KernExclude |= Bit;

    /* All done, let it through.
     */
    IOSpaceWriteInt8((IO_PORT)(pMask->PicPort+1),pMask->KernMask);
}

/* Undo the above EnableInterrupt
 */
void MCT i8259DisableInterrupt( IPic *pThis, UINT Irq, void **pOldDevice)
{
    i8259 *pic = (i8259*)pThis;
    struct i8259_MASK *pMask;
    UINT8 Bit;

    /* On PCs, IRQ 2 really is IRQ 9
     */
    if (Irq == 2)
        Irq = 9;

    /* The order of the following operations is NOT irrelevant
     */
    if (Irq < 8) {
        Bit = (UINT8)(1 << Irq);
        pMask = &pic->MaskTable[0];
    } else {
        Bit = (UINT8)(1 << (Irq&7));
        pMask = &pic->MaskTable[1];
    }

    /* This interrupt now masked.
     */
    pMask->KernMask |= Bit;
    pMask->KernExclude &= ~Bit;

    /* Disable it
     */
    IOSpaceWriteInt8((IO_PORT)(pMask->PicPort+1),pMask->KernMask);

    /* Remove the dispatcher from the IDT
     */
    InstallIsr( Irq, (ADDRESS)0, FALSE, FALSE );

    /* Remove the ISR and its argument from our tables
     */
    *pOldDevice = pic->InterruptTable[ Irq ].pDevice; /* Return the old one */
    pic->InterruptTable[ Irq ].pDevice = NULL;
    pic->InterruptTable[ Irq ].Isr = NULL;

}

/*
 * Mask *all* interrupts.  Except NMI, but thats another story.
 */
void MCT i8259MaskAll( IPic *pThis )
{
    /* quick&dirty */
    UnusedParameter(pThis);
    IOSpaceWriteInt8((IO_PORT)(PIC1_PORT+1),(UINT8)0xff);
    IOSpaceWriteInt8((IO_PORT)(PIC0_PORT+1),(UINT8)0xff);
}

/*
 * Unmask all interrupts that should be unmasked.
 */
void MCT i8259UnmaskAll( IPic *pThis )
{
    i8259 *pic = (i8259*)pThis;

    IOSpaceWriteInt8((IO_PORT)(PIC1_PORT+1),pic->MaskTable[1].KernMask);
    IOSpaceWriteInt8((IO_PORT)(PIC0_PORT+1),pic->MaskTable[0].KernMask);
}

#ifdef _DEBUG
void PICState(void)
{
    printf("PICs: %x %x  %x %x\n", 
           IOSpaceReadInt8(PIC0_PORT),
           IOSpaceReadInt8((IO_PORT)(PIC0_PORT+1)),
           IOSpaceReadInt8(PIC1_PORT),
           IOSpaceReadInt8((IO_PORT)(PIC1_PORT+1)));
}
#endif

#if 1 /* despised */
UINT PicToBios(void)
{
    UINT Eflags;

    /* Mask them all, turning interrupts off.
     * This way *we* get all pending ones.
     */
    IOSpaceWriteInt8((IO_PORT)(PIC1_PORT+1),(UINT8)0xff);
    IOSpaceWriteInt8((IO_PORT)(PIC0_PORT+1),(UINT8)0xff);

    TURN_INTERRUPTS_OFF(Eflags);

    /* Now enable those that BIOS should see
     */
    {
        UINT8 p, q;
#if usedtobebutIthinkitswrong
        p = (UINT8)(BiosPic0Mask | (KernPic0Exclude & (~PIC0_I_PIT)));
        q = (UINT8)(BiosPic1Mask | (KernPic1Exclude & (~PIC1_I_RTC)));
#endif

        p = (UINT8)(Thei8259.MaskTable[0].BiosMask | 
                    Thei8259.MaskTable[0].KernExclude);
        q = (UINT8)(Thei8259.MaskTable[1].BiosMask | 
                    Thei8259.MaskTable[1].KernExclude);

        IOSpaceWriteInt8((IO_PORT)(PIC0_PORT+1), p);
        IOSpaceWriteInt8((IO_PORT)(PIC1_PORT+1), q);
    }

    return Eflags;
}

static void DeBios( i8259 *pic )
{
    UINT8 v;

    /* Get current (BIOS/DOS) PIC mask state
     * NOTE compilerbug
     */
    v = IOSpaceReadInt8((IO_PORT)(PIC0_PORT+1));
    pic->MaskTable[0].BiosMask = v;
    v = IOSpaceReadInt8((IO_PORT)(PIC1_PORT+1));
    pic->MaskTable[1].BiosMask = v;

    /* Install *our* PIC mask state
     */
    IOSpaceWriteInt8((IO_PORT)(PIC0_PORT+1),pic->MaskTable[0].KernMask);
    IOSpaceWriteInt8((IO_PORT)(PIC1_PORT+1),pic->MaskTable[1].KernMask);
}

void PicFromBios(UINT Eflags)
{
    /* BIOS might have enabled/disabled some more.
     * Thats ok as long as they dont conflict with ours
     */
    DeBios(&Thei8259);

    RESTORE_INTERRUPTS(Eflags);

}
#endif

static const struct IPicVtbl i8259Vtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    i8259EnableInterrupt,
    i8259DisableInterrupt,
    i8259MaskAll,
    i8259UnmaskAll
};

struct i8259 Thei8259 = {
    &i8259Vtbl,
    { { NULL, NULL}, },

    {
      { PIC0_PORT, 0, 0, KPIC0MASK, 0x01 },
      { PIC1_PORT, 0, 0, KPIC1MASK, 0x01 }
    }
};


/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
    i8259 *pic = (i8259*)pThis;

    /* No more interrupts
     */
    __asm cli;

    /* MovePICs(0x8, 0x70); */
    IOSpaceWriteInt8((IO_PORT)(PIC0_PORT+1),pic->MaskTable[0].BiosInitialMask);
    IOSpaceWriteInt8((IO_PORT)(PIC1_PORT+1),pic->MaskTable[1].BiosInitialMask);

}

IPic *PicCreate(void)
{
    static i8259 *pic = NULL;

    /* Multi-callable sigh */
    if (pic) return (IPic *) pic;
    pic = &Thei8259;

    /* Get current (BIOS/DOS) PIC mask state
     */
    DeBios(pic);

    /* Thats the initial one
     */
    pic->MaskTable[0].BiosInitialMask = pic->MaskTable[0].BiosMask;
    pic->MaskTable[1].BiosInitialMask = pic->MaskTable[1].BiosMask;

#if 0
    /* DO NOT turn interrupts on until we did an EnableTimers.
     * Otherwise we get an INT15 from the PIT. Somehow. Uhu ?
     */
    __asm sti;
#endif

    return (IPic *) pic;
}
