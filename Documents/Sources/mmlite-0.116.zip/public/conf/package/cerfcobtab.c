/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <loaders/cobtab.h>

extern PIUNKNOWN DriverCfgCobMain(void);
extern PIUNKNOWN SerialCobMain(void);
extern PIUNKNOWN NullCobMain(void);
extern PIUNKNOWN UdcCobMain(void);
extern PIUNKNOWN UcbCobMain(void);
extern PIUNKNOWN UsbdserialCobMain(void);
extern PIUNKNOWN UsbdkeybdCobMain(void);
extern PIUNKNOWN UsbdmouseCobMain(void);
extern PIUNKNOWN protocolCobMain(void);
extern PIUNKNOWN Cs8900CobMain(void);
extern PIUNKNOWN SerplexCobMain(void);
extern PIUNKNOWN HostfsCobMain(void);

const struct PRECOB ThePreCobTable[] = {
  {_T("drivercfg.cob"), DriverCfgCobMain },
  {_T("drivers.cob"), DriversCobMain },
  {_T("sa.cob"), SerialCobMain },
  {_T("null.cob"), NullCobMain },
  {_T("udc.cob"), UdcCobMain },
  {_T("usbdserial.cob"), UsbdserialCobMain },
  {_T("usbdkeybd.cob"), UsbdkeybdCobMain },
  {_T("usbdmouse.cob"), UsbdmouseCobMain },
  {_T("ucb_cerf.cob"), UcbCobMain },
  {_T("cs8900.cob"), Cs8900CobMain },
  {_T("protocol.cob"), protocolCobMain },
  {_T("serplex.cob"), SerplexCobMain },
  {_T("hostfs.cob"), HostfsCobMain },
  {0,0}
};
