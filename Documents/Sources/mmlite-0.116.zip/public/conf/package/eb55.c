/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>

/* Select root "fs" file system */
PINAMESPACE BoardInitRomFs(void);
PINAMESPACE BoardInitHostFs(void);

PINAMESPACE BoardInitFileSystem(void)
{
#if 1
    PINAMESPACE Ns = BoardInitRomFs();
    if (Ns == NULL)
        Ns = BoardInitHostFs();
    return Ns;
#else
    return BoardInitHostFs();
#endif
}
