/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <tchar.h>      /* for StrFormat */
#include <wchar.h>      /* for wprintf, wcstol, etc */
#include <stdlib.h>
#include <base/cons.h>

void __rt_udiv(void);
void __udivsi3(void);
void __rt_udiv10(void);
void __rt_sdiv(void);
void __rt_sdiv10(void);

/* BUGBUG refine */
/* Should be called only from interrupt handlers (ie kernel mode, interrupts
 * disabled).  This is not enforced, but if called from any other mode the
 * duration of the call can vary greatly.  The only real guarantee is that
 * we will spend AT LEAST uSec microseconds inside this routine.
 */
extern void DelayLoop(INT32 LoopCount);

UINT DelayMultiplier = 10; /* platform should define/refine this */
UINT DelayShifter    = 0;  /* platform should define/refine this */
UINT DelayOverhead   = 0;  /* platform should define/refine this */

void Delay(UINT uSec)
{
    INT nLoops = (INT)uSec;
    /* Spell it out so the compiler does not promote expressions stupidly
     */
    nLoops = (nLoops * DelayMultiplier) - DelayOverhead;
    nLoops = nLoops >> DelayShifter;
    DelayLoop(nLoops);
}

struct BASERTL {
    const struct IBaseRtlVtbl *v;
    UINT RefCnt;
};

SCODE BaseRtlQueryInterface(PIBASERTL This, REFIID Iid, void **ppObject)
{
    UnusedParameter(This);
    UnusedParameter(Iid);
    UnusedParameter(ppObject);
    return E_NOT_IMPLEMENTED;
}

UINT BaseRtlAddRef(PIBASERTL This)
{
    UnusedParameter(This);
    return 1;
}

UINT BaseRtlRelease(PIBASERTL This)
{
    UnusedParameter(This);
    return 1;
}

#include "s_BaseRtl_v.c"
static const struct BASERTL _TheRtlObject = { &BaseRtlVtbl, 1 };
typedef ADDRESS *PADDRESS;
const PADDRESS RtlTable = (PADDRESS) &_TheRtlObject;

const PIBASERTL pTheBaseRtl = (PIBASERTL) &_TheRtlObject;
