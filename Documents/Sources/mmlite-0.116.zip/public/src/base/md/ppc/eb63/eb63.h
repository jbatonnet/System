/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Reference:
 * "AT91EB63 Evaluation Board, USER MANUAL"
 * PubNo 1359A Rev 02/00
 * Editor: Atmel Corporation, 2000 http://www.atmel.com
 *
 * Definitions specific to the EB63 board
 */

/* BUGBUG Most of it goes somewhere else, more globally
 */

/* Definitions that are common between C code and assembler
 * NB: Assembly code files are pre-processed by the C compiler
 */

#if defined(__ASSEMBLER__)

/* Assembly-only definitions
 */

PAGE_DIRECTORY_PHYSICAL_ADDRESS _EQU 02000H
PCR_ARRAY_PHYSICAL_ADDRESS _EQU 0A000H
HASHED_PAGE_TABLE_PROCESSOR0_PHYSICAL_ADDRESS _EQU 01FF00000H
HASHED_PAGE_TABLE_PROCESSOR1_PHYSICAL_ADDRESS _EQU 01FF40000H
HASHED_PAGE_TABLE_PHYSICAL_SIZE _EQU 040000H

PAGE_SIZE _EQU 01000H
PAGE_SIZE_LARGE _EQU 0400000H
PAGE_SHIFT _EQU 0000CH
PDI_SHIFT _EQU 00016H
PTI_SHIFT _EQU 0000CH
/*
 *  Special-purpose register definitions
 */
SPR_XER _EQU 00001H
SPR_LR _EQU 00008H
SPR_CTR _EQU 00009H
SPR_DSISR _EQU 00012H
SPR_DAR _EQU 00013H
SPR_DEC _EQU 00016H
SPR_SDR1 _EQU 00019H
SPR_SRR0 _EQU 0001AH
SPR_SRR1 _EQU 0001BH
SPR_ACCR _EQU 0001DH
SPR_SPRG0 _EQU 00110H
SPR_SPRG1 _EQU 00111H
SPR_SPRG2 _EQU 00112H
SPR_SPRG3 _EQU 00113H
SPR_ASR _EQU 00118H
SPR_TBL _EQU 0011CH
SPR_TBU _EQU 0011DH
SPR_PVR _EQU 0011FH
SPR_HSPRG0 _EQU 00130H
SPR_HSPRG1 _EQU 00131H
SPR_HDEC _EQU 00136H
SPR_RMOR _EQU 00138H
SPR_HRMOR _EQU 00139H
SPR_HSRR0 _EQU 0013AH
SPR_HSRR1 _EQU 0013BH
SPR_LPCR _EQU 0013EH
SPR_LPIDR _EQU 0013FH
SPR_IBAT0U _EQU 00210H
SPR_IBAT0L _EQU 00211H
SPR_IBAT1U _EQU 00212H
SPR_IBAT1L _EQU 00213H
SPR_IBAT2U _EQU 00214H
SPR_IBAT2L _EQU 00215H
SPR_IBAT3U _EQU 00216H
SPR_IBAT3L _EQU 00217H
SPR_DBAT0U _EQU 00218H
SPR_DBAT0L _EQU 00219H
SPR_DBAT1U _EQU 0021AH
SPR_DBAT1L _EQU 0021BH
SPR_DBAT2U _EQU 0021CH
SPR_DBAT2L _EQU 0021DH
SPR_DBAT3U _EQU 0021EH
SPR_DBAT3L _EQU 0021FH
SPR_IBAT4U _EQU 00230H
SPR_IBAT4L _EQU 00231H
SPR_IBAT5U _EQU 00232H
SPR_IBAT5L _EQU 00233H
SPR_IBAT6U _EQU 00234H
SPR_IBAT6L _EQU 00235H
SPR_IBAT7U _EQU 00236H
SPR_IBAT7L _EQU 00237H
SPR_DBAT4U _EQU 00238H
SPR_DBAT4L _EQU 00239H
SPR_DBAT5U _EQU 0023AH
SPR_DBAT5L _EQU 0023BH
SPR_DBAT6U _EQU 0023CH
SPR_DBAT6L _EQU 0023DH
SPR_DBAT7U _EQU 0023EH
SPR_DBAT7L _EQU 0023FH
SPR_HID0 _EQU 003F0H
SPR_HID1 _EQU 003F1H
SPR_IABR _EQU 003F2H
SPR_HID4 _EQU 003F4H
SPR_DABR _EQU 003F5H
SPR_HID5 _EQU 003F6H
SPR_HID6 _EQU 003F9H

/*
 *  Flags in the MSR register
 */
MSR_SF_MASK _EQU   08000000000000000H
MSR_HV_MASK _EQU   01000000000000000H
MSR_VEC_MASK _EQU  002000000H
MSR_POW_MASK _EQU  000040000H
MSR_IMPL_MASK _EQU 000020000H
MSR_ILE_MASK _EQU  000010000H
MSR_EE_MASK _EQU   08000H
MSR_PR_MASK _EQU   04000H
MSR_FP_MASK _EQU   02000H
MSR_ME_MASK _EQU   01000H
MSR_FE0_MASK _EQU  00800H
MSR_SE_MASK _EQU   00400H
MSR_BE_MASK _EQU   00200H
MSR_FE1_MASK _EQU  00100H
MSR_IP_MASK _EQU   00040H
MSR_IR_MASK _EQU   00020H
MSR_DR_MASK _EQU   00010H
MSR_PM_MASK _EQU   00004H
MSR_RI_MASK _EQU   00002H
MSR_LE_MASK _EQU   00001H


/*
 * Define the page directory entry bits for cached and uncached access and for
 * standard and large page access.
 *
 */
VALID_CACHED_PDE_BITS            _EQU     321h    ; WIMG=0010
VALID_CACHED_LARGE_PDE_BITS      _EQU     329h    ; WIMG=0010
VALID_UNCACHED_PDE_BITS          _EQU     351h    ; WIMG=0101
VALID_UNCACHED_LARGE_PDE_BITS    _EQU     359h    ; WIMG=0101

/*
 * Define the sizes of the L1 instruction and data cache lines.
 */
ICACHE_BLOCK_SIZE_BITS          _EQU     7       ; 128-byte cache line
DCACHE_BLOCK_SIZE_BITS          _EQU     7       ; 128-byte cache line
ICACHE_BLOCK_SIZE               _EQU     (1 SHL ICACHE_BLOCK_SIZE_BITS)
DCACHE_BLOCK_SIZE               _EQU     (1 SHL DCACHE_BLOCK_SIZE_BITS)

/*
 * Define the bit flags of the data storage interrupt status register (DSISR).
 */
DSISR_HTEG_MISS                 _EQU     1
DSISR_STORE_OPERATION           _EQU     6
DSISR_DABR_MATCH                _EQU     9

#else

/* C-only definitions
 */

/*
 * Some random info on this board.
 * 1- The LEDs are connected to port B, as follows:
 *    DS1-PB8 DS2-PB9 DS3-PB10 DS4-PB11 DS5-PB12 DS6-PB13 DS7-PB14 DS8-PB15
 *    Write a 1 to PioB->ClearData (e.g. set Status to 0) to turn the LED on.
 *    Write a 1 to PioB->SetData (e.g. set Status to 1) to turn the LED off.
 * 2- The LED DS9 is connected directly to the power line.
 * 3- The push-buttons are connected as follows:
 *    SW1-PB3 SW2-PB4 SW3-PB5 SW4-PA9(IRQ0)
 * 4- The RESET button S5 is connected directly to the reset line.
 * 5- The S7 white button connects to the NWAKEUP line.
 *
 * SRAM can be populated with either 256KB or 1MB:
 * - 2 x KM68V1002 (128Kx8) == 256KB
 * - 2 x KM68V4002 (512Kx8) == 1MB
 */

/* The boot code sets up these chip selects (in the EBI)
 * to enable memory accesses to the FLASH and SRAM chips
 */
#define FLASH_CHIP_SELECT 0
#define SRAM_CHIP_SELECT  1

/* The board uses a 25MHz crystal as reference clock.
 * There is a divisor between this signal and MCLKI,
 * normally set at 1.  For lower power consumption the
 * clock is reduced [and voltage is settable at 1.8V]
 */
#define Eb63Crystal (25*1000*1000)

/* The timer code uses TC0 and TC1 for timing purposes
 */
#define ThePIT (&Tc0->Channel0)
#define TheRTC (&Tc0->Channel1)

#define Eb63Clock Eb63Crystal

#endif
