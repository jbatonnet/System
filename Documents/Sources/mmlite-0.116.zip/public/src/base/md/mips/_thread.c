/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <string.h>             /* for memset prototype */
#include <mips_asm.h>           /* for CP0 bits */

extern UINT32 GetPsr(void);
UINT32 ExtensionControl = 0;

/* Initialize the machine-dependent part of a thread object.
 * The (new) thread should be set to execute the function START
 * with argument ARG.  No scheduling side-effects.
 */
void MachineThreadCreate(PITHREAD pThis, THREAD_FUNCTION pStart, 
                         THREAD_ARGUMENT Arg, PTR StackTop, UINT ArgCount,
                         UINT32 Flags)
{
    UINT32 *pStk = (UINT32 *)StackTop;
    CXTINFO *pCxt;

    assert(ArgCount == -1);

    /* NB: The compiler assumes that stacks are aligned.
     * We know for sure that they must be UINT64 aligned,
     * we dont know if they might have to be UINT128 aligned.
     * So make sure its properly aligned, just in case.
     */
#define ALGN 8
    pStk = (PTR)(((ADDRESS)pStk) & (~(ALGN-1)));

    /* Make room for a0.
     * NB: Calling convention wants room for all 4 regargs
     */
    pStk -= 4;

    /* Make room for context on stack
     * Thread's initial state will point there.
     */
    pCxt = (CXTINFO *)pStk;
    pCxt--;
    pTH(pThis)->CxtInfo = pCxt;

    memset(pCxt, 0, sizeof(*pCxt));

    /* Setup non-zero registers
     */
    pCxt->gpr[4] = (UINT32) Arg;          /* a0 */
    pCxt->pc = (UINT32) pStart;
    /* pCxt->gpr[28] = gp; */
    pCxt->gpr[29] = (UINT32) pStk;        /* sp */
    pCxt->gpr[31] = (UINT32) ThreadExit;  /* ra */

#ifdef TIGON
#else
    {
        UINT32 sr;
        sr = GetPsr();
        sr &= CP0_SR_CU3 | CP0_SR_CU2 | CP0_SR_CU1 | CP0_SR_CU0 |
              CP0_SR_RE | CP0_SR_BEV | CP0_SR_TS;
        sr |= CP0_SR_INT | CP0_SR_IEo| CP0_SR_IEp /* | CP0_SR_IEc dont! */;
        pCxt->sr = sr;
        pCxt->ec = (Flags & LOAD_IMAGE_ENABLE_EXTENSION0) ?
                    (CP0_EC_EN | CP0_EC_LD | CP0_EC_CLK) : 0;
        /* hackattack */
        Flags >>= 28;
        if (Flags & 1) /* priviledged */ pCxt->ec |= CP0_EC_PRIV;
        if (Flags & 2) /* peripheral  */ pCxt->ec |= CP0_EC_PER;
        if (Flags & 0xc) /* priority  */ pCxt->ec |= (Flags & 0xc) << 1;
#if 1
        if (pCxt->ec)
            ExtensionControl = /*CP0_EC_EN |*/ CP0_EC_LD | CP0_EC_CLK;
#endif
    }
#endif
}
