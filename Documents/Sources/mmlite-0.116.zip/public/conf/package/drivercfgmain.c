/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>

EXTERN_C PIUNKNOWN DriverCfgCobMain(void);

PIUNKNOWN CobMain(void)
{
    return DriverCfgCobMain();
}
