/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _machdep_h_
#define _machdep_h_

/*
 * Machine-dependent functions and definitions
 * which are not otherwise defined in fred.h
 *
 */
#define __MACHDEP_MEMFUNC
#define __MEMFUNC_ARE_INLINED 0
#define __SUPPORTS_COB_NAMESPACE 1
#define __HAS_UNCHECKED_FUNCTION_CALLING 1
#if _MINIMIZE
#define __NO_DEBUGGER 1
#endif

#define DEFAULT_STACK_SIZE 6000 //(3500) //1024        /* cuz printf big (2900 biggest on actual) */

#define MachineSpecificInfo(a,b) (E_NOT_IMPLEMENTED)
#define CurrentProcessorKind() (PROCESSOR_KIND_ARM)
#define CurrentProcessorOEM() (0)
extern UINT64 CurrentProcessorSpeed(void);

/* Enable stack overflow and usage checking
 */
#ifdef _DEBUG
#define CHECK_STACK_OVERFLOW 1
#define STACK_STATS 1
#endif

/* Enable idle-powersave
 */
extern void ArmMachineIdle(ADDRESS Arg);
#define MACHINE_IDLE(_arg_) ArmMachineIdle((ADDRESS)_arg_)

/* Munging with interrupt enables from C
 */

extern UINT32 IntOff(void);
extern UINT32 IntOn(void);
extern void SetPsr(UINT32 PsrValue);

#define TURN_INTERRUPTS_OFF(_s_) _s_ = IntOff()
#define RESTORE_INTERRUPTS(_s_)  SetPsr(_s_)
#define ENABLE_INTERRUPTS() ((void) IntOn())
#define DISABLE_INTERRUPTS() ((void) IntOff())

void FlushCache(void);

/* define image end address. Compiler dependent. */
#ifdef ADS
extern int Image$$ZI$$Limit[];
#define _end Image$$ZI$$Limit
#endif

#endif /* _machdep_h_*/
