/* activity2.c
 * Implementation of generic scheduling activities.
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#define OPTIMIZE
/* enable Base.h optimizations, since we're the "base" */

#include <mmlite.h>
#include <fred.h>
#include <assert.h>
#include <activif.h>
#include <base/activity.h>
/* #include <base/schedul.h> */
#include <schedulif.h>
#include <diagnostics.h>
#include <base/kconstraint2.h>

/* Global variables */
PACTINFO TheCurrentActivity = NULL;

/* Private function prototypes */

/* Interface method implementations */

SCODE MCT
Activity_QueryInterface( 
    PIACTIVITY pThis,
    /* [in] */ REFIID pIid,
    /* [out] */ void **ppUnk
    )
{
  return GenericQueryInterface((IUnknown *)pThis, pIid, ppUnk,
                               &IID_IActivity);
}
        
UINT MCT
Activity_AddRef(
    PIACTIVITY pThis
    )
{
  UINT RefCount;
  RefCount = AtomicInc(&pACT(pThis)->RefCount);
  return RefCount;
}
        
UINT MCT
Activity_Release(
    PIACTIVITY pThis
    )
{
  UINT RefCount;
  RefCount = AtomicDec(&pACT(pThis)->RefCount);

/* #if defined(STACK_STATS) */
/*   printf("ActivityRelease (0x%x)->%d stack usage: %d/%d\n", */
/*          (ADDRESS)pThis, RefCnt, */
/*          CheckStackUsage(pThis), pTH(pThis)->StackSize); */
/* #endif */

  if (RefCount == 0) {
    DBG(("Thread (0x%x) dead.\n", (ADDRESS)pThis));
    CurrentHeapDelayedFree(pThis);
  }

  return RefCount;
}
        
/* Disagreeable call this one. */
PIPROCESS MCT
Activity_GetProcess (
    PIACTIVITY pThis
    )
{
  PIPROCESS pPrc = Activity_Process(pThis);
  pPrc->v->AddRef(pPrc);
  return pPrc;
}

TIME MCT
Activity_GetTimeUsage(
    PIACTIVITY pThis
    )
{
  return CurrentTime();
}
        
void
Activity_UnlockTransform(
    PTR pMutex
    )
{
  Mutex_Unlock((PMUTEX)pMutex);
}

void
Activity_UnlockMutexes(
    PACTINFO pAct
    )
{
  assert(pAct != NULL);
  List_TransformData(Activity_GetMutexList(pAct), Activity_UnlockTransform);
}

void
Activity_Exit(
    PACTINFO pAct
    )
{
  PIPROCESS pPrc;

  /* Release ref on process.  Do it here, else we might get
   * in deadlock later: if the only two threads are this and
   * the one waiting-for the process to terminate then this
   * thread wont find an undertaker.
   * Yes it would have been better to do this in ThreadRelease.
   */
  pPrc = Activity_Process(pAct);

  pPrc->v->Release(pPrc);

  /* Let scheduler know this thread is gone
   */
  pTheScheduler->v->RemoveActivity(pTheScheduler, (PIACTIVITY)pAct);
}

