/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <assert.h>
#include <stdio.h>

#include <../cob/sampfac.h>  /* normally comes from inc, no .. needed */
#include "../cob/isampfac.c" /* normally comes from iidlib, no include needed */

#ifdef _DEBUG
/* debug prints, conditionally */
#define DPRINT(_s_) printf _s_
/* error prints, conditionally */
#define EPRINT(_s_) printf _s_
#else
#define DPRINT(_s_)
#define EPRINT(_s_) printf _s_
#endif

PRIVATE PISAMPLEFACTORY pTheSampleFactory = NULL;
PRIVATE PINAMESPACE pTheSampleFactoryNs = NULL;
PRIVATE PIUNKNOWN pTheSampleFactoryUnk = NULL;

/* Bind to sample factory and cache result */
PRIVATE PISAMPLEFACTORY GetSampleFactory(void)
{
    PINAMESPACE ns;
    PIUNKNOWN punk;
    PISAMPLEFACTORY sf;
    SCODE sc;

    if (pTheSampleFactory)
        return pTheSampleFactory;

    ns = CurrentNameSpace();
    sc = ns->v->Bind(ns,
                     _T("COB/cobsamp.cob"),
                     NAME_SPACE_READ,
                     &punk);
    ns = NULL; /* no ref */
    if (FAILED(sc)) {
        EPRINT(("Could not find COB/cobsamp.cob sc=%x\n", sc));
        goto Error1;
    }

    sc = punk->v->QueryInterface(punk, &IID_ISampleFactory, (void **) &sf);
    if (FAILED(sc)) {
        EPRINT(("COB/cobsamp.cob doesn't support ISampleFactory sc=%x\n", sc));
        goto Error2;
    }

    sc = punk->v->QueryInterface(punk, &IID_INameSpace, (void **) &ns);
    if (FAILED(sc)) {
        EPRINT(("COB/cobsamp.cob doesn't support INameSpace sc=%x\n", sc));
        goto Error3;
    }

    pTheSampleFactoryUnk = punk;
    pTheSampleFactoryNs = ns;
    pTheSampleFactory = sf;

    return pTheSampleFactory;

    /* Errors, undo what we did so far and return error */
  Error3:
    sf->v->Release(sf);
  Error2:
    punk->v->Release(punk);
  Error1:
    {
        PITHREAD th = CurrentThread();
        th->v->SetValue(th, THREAD_VALUE_LAST_ERROR, sc);
    }
    return NULL;
}

/* Return the factory's name space interface, initialize if necessary */
PRIVATE PINAMESPACE GetSampleNs(void)
{
    if (!pTheSampleFactoryNs)
        GetSampleFactory();

    return pTheSampleFactoryNs;
}

/* Drop cached references to the factory */
PRIVATE void DeleteSampleFactory(void)
{
    UINT Refs;

    if (!pTheSampleFactory)
        return;

    DPRINT(("DeleteSampleFactory\n"));

    pTheSampleFactory->v->Release(pTheSampleFactory);
    pTheSampleFactoryNs->v->Release(pTheSampleFactoryNs);
    /* Magic side effect:
     * Releasing the IUnknown of the sample factory will cause the
     * Cob Manager to unload the cob, assuming this is the last ref.
     */
    Refs = pTheSampleFactoryUnk->v->Release(pTheSampleFactoryUnk);
    DPRINT(("Released sample factory, %x refs remain\n", Refs));
}

/* One way of creating a null file, use the NameSpace::Bind */
PRIVATE PIFILE CreateNullFile1(void)
{
    /* This whole function is really the same as
     * BindToObject(GetSampleNs(), "null", &IID_IFile)
     */
    PIFILE file;
    PIUNKNOWN punk;
    PINAMESPACE ns;
    SCODE sc;

    ns = GetSampleNs();
    if (!ns)
        return NULL;

    sc = ns->v->Bind(ns,
                     _T("null"),
                     NAME_SPACE_READ | NAME_SPACE_WRITE | NAME_SPACE_CREATE,
                     &punk);
    if (FAILED(sc)) {
        EPRINT(("Could not create null file through name space sc=%x\n", sc));
        return NULL;
    }

    sc = punk->v->QueryInterface(punk, &IID_IFile, (void **) &file);
    punk->v->Release(punk); punk = NULL;
    if (FAILED(sc)) {
        EPRINT(("Null file is not my kind of file sc=%x\n", sc));
        return NULL;
    }

    return file;
}

/* Another way of creating a null file, use the method in ISampleFactory */
PRIVATE PIFILE CreateNullFile2(void)
{
    PIFILE file;
    PIUNKNOWN punk;
    PISAMPLEFACTORY sf;
    SCODE sc;

    sf = GetSampleFactory();
    if (!sf)
        return NULL;

    sc = sf->v->CreateNullFile(sf, &punk);
    if (FAILED(sc)) {
        EPRINT(("Could not create null file through factory sc=%x\n", sc));
        return NULL;
    }

    sc = punk->v->QueryInterface(punk, &IID_IFile, (void **) &file);
    punk->v->Release(punk); punk = NULL;
    if (FAILED(sc)) {
        EPRINT(("Null file is not my kind of file sc=%x\n", sc));
        return NULL;
    }

    return file;
}

#define SIZE 100

PRIVATE void NullFileTest(PIFILE File)
{
    SCODE sc;
    UINT Count;
    BYTE Buffer[SIZE];
    UINT64 Offset;

    Int64FromHighAndLow(Offset, 0, 0x10000);
    sc = File->v->ReadAt(File, Offset, Buffer, SIZE, &Count);
    DPRINT(("NullFileTest read %x@%llx, got %x sc=%x (expected 0 1)\n",
            SIZE, Offset, Count, sc));
    assert(sc == S_FALSE);
    assert(Count == 0);

    sc = File->v->WriteAt(File, Offset, Buffer, SIZE, &Count);
    DPRINT(("NullFileTest wrote %x@%llx, got %x sc=%x (expected %x 0)\n",
            SIZE, Offset, Count, sc, SIZE));
    assert(sc == S_OK);
    assert(Count == SIZE);
}

PRIVATE void ZeroFileTest(PIFILE File)
{
    SCODE sc;
    UINT Count;
    BYTE Buffer[SIZE];
    UINT64 Offset;

    Int64FromHighAndLow(Offset, 0, 0x10000);
    sc = File->v->ReadAt(File, Offset, Buffer, SIZE, &Count);
    DPRINT(("NullFileTest read %x@%llx, got %x sc=%x (expected %x 0)\n",
            SIZE, Offset, Count, sc, SIZE));
    assert(sc == S_OK);
    assert(Count == SIZE);

    sc = File->v->WriteAt(File, Offset, Buffer, SIZE, &Count);
    DPRINT(("NullFileTest wrote %x@%llx, got %x sc=%x (expected %x 0)\n",
            SIZE, Offset, Count, sc, SIZE));
    assert(sc == S_OK);
    assert(Count == SIZE);
}

int _tmain(int argc, _TCHAR **argv)
{
    PIFILE File;
    SCODE sc;
    UnusedParameter(argc);
    UnusedParameter(argv);

    DPRINT(("Test null file created through name space\n"));
    File = CreateNullFile1();
    NullFileTest(File);
    File->v->Release(File);

    DPRINT(("Test null file created through factory\n"));
    File = CreateNullFile2();
    NullFileTest(File);
    File->v->Release(File);

    DPRINT(("Test zero file created through name space\n"));
    /* Here's how we can use BindToObject() in order to save some code */
    sc = BindToObject(GetSampleNs(),
                      _T("zero"),
                      NAME_SPACE_READ | NAME_SPACE_WRITE | NAME_SPACE_CREATE,
                      &IID_IFile,
                      (void **) &File);
    if (FAILED(sc)) {
        EPRINT(("Could not create zero file sc=%x\n", sc));
    } else {
        ZeroFileTest(File);
        File->v->Release(File);
    }

    /* Drop any cached refs to factory */
    DeleteSampleFactory();

    DPRINT(("APPSAMP done...\n"));
    return 0;
}
