/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* Over a serial line, each packet is preceeded by an STH character,
 * terminated by an EOT and followed by a 2-byte CRC.
 * Special characters are ESC-aped inside a packet, including ESC itself.
 * The CRC avoids using special chars.
 */
#ifndef _DRIVER_SERPLEX_

#define _DRIVER_SERPLEX_

#if 1
#define USE_SERPLEX 1
#else
#define USE_SERPLEX 0
#endif

#define STH_CHAR '['
#define EOT_CHAR ']'
#define ESC_CHAR 'E'
#define COMP_CHAR 'C'

/* Well known channel ids */
#define InvalidSerplexAddr ((UINT8)(~0))
#define FSSerplexAddr      7
#define NICSerplexAddr     0
#define CONSerplexAddr     9

#endif