/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Reference:
 * "AT91EB55 Evaluation Board, User Guide"
 * PubNo 1709A Rev 06/01/0M
 * Editor: Atmel Corporation, 2002 http://www.atmel.com
 *
 * Definitions specific to the EB55 board
 */

/*
 * Some random info on this board.
 * 1- The LEDs are connected to port B, as follows:
 *    D1-PB8 D2-PB9 D3-PB10 D4-PB11 D5-PB12 D6-PB13 D7-PB14 D8-PB15
 *    Write a 1 to PioB->ClearData (e.g. set Status to 0) to turn the LED on.
 *    Write a 1 to PioB->SetData (e.g. set Status to 1) to turn the LED off.
 * 2- The LED D11 is connected directly to the 3.3V power line VCC3V3.
 * 3- The LED D10 is connected to NRST via a flip flop, can be cleared
 *    via the pushbutton S2 "CLR_RST". [NWDOVF goes there too?BUGBUG]
 * 4- The push-buttons are connected as follows:
 *    SW1-PB20 SW2-PA9 (IRQ0) SW3-PB17 SW4-PB19.
 * 5- The RESET button SW5 is connected directly to the reset line.
 * 6- The S1 white button connects to the NWAKEUP line.
 *
 * SRAM can be populated with either 256KB or 1MB:
 * - 2 x KM68V1002 (128Kx8) == 256KB
 * - 2 x KM68V4002 (512Kx8) == 1MB
 */

/* The boot code sets up these chip selects (in the EBI)
 * to enable memory accesses to the FLASH and SRAM chips
 */
#define FLASH_CHIP_SELECT 0
#define SRAM_CHIP_SELECT  1

/* The board uses a 16MHz 30ppm crystal for a 32MHz fast clock.
 * There is a divisor between this signal and MCLKI,
 * normally set at 1.  For lower power consumption there
 * is a slow clock from a 32,768 Hz 20ppm crystal.
 */
#define Eb55Crystal (32*1000*1000)
#define Eb55SlowCrystal (32768)

/* The timer code uses TC0 and TC1 for timing purposes
 */
#define ThePIT (&Tc0->Channel0)
#define TheRTC (&Tc0->Channel1)

/* The timer code auto-detects the clock frequency
 */
typedef struct _TIMER_CONFIG {
    TIME RtcClockTick;
    TIME PitMaxInterval;
    UINT8 PitShiftValue;
    UINT8 PitClockScaler;
    UINT32 ClockFrequency;  /* in Hz */
} TIMER_CONFIG;

extern TIMER_CONFIG EbTimerConfig[];

#define Eb55Clock EbTimerConfig[0].ClockFrequency

