/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <diagnostics.h>

extern PINAMESPACE RomFsNew( PTR StartAddress, UINT MaxSize);

/* RomFs initialization specific to board */
PINAMESPACE BoardInitRomFs(void)
{
    /* 0x01080000 ? */
    PINAMESPACE ns = RomFsNew( (PTR) 0x01180000, 0x80000 );
    if (!ns) DBGME(3,printf("BoardInitRomFs failed\n"));
    return ns;
}

