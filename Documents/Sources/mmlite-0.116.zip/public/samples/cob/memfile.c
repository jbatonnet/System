/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* Implements in-memory files. They can be read and written but the content
 * is not saved anywhere and there is no associated namespace.
 * The constructor is CreateMemFile().
 *
 * Writes past EOF expand the file. Reads past EOF fail.
 */
#include <mmlite.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

/* Component internal declarations */
#include "cobsamp.h"

#define CHECK_HEAP()
// CurrentHeap()->v->Validate(CurrentHeap(), 0, 0)

PRIVATE struct IFileVtbl MemFileVtbl;

typedef struct BLOCK {
    BYTE *Mem;
    UINT Size;
    struct BLOCK *Next;
} *PBLOCK;

/* Instance layout */
typedef struct _MEMFILE {
    struct IFileVtbl *v;
    UINT RefCnt;

    UINT Size;
    UINT Access;

    MUTEX mx;
    PBLOCK Blocks;
} *PMEMFILE;

/* Convert between interface and instance pointer and vice versa */
#define pMF(_i_) ((PMEMFILE)(_i_))
#define iMF(_p_) ((PIFILE)(_p_))

/* Maximum allowed size for any file. Somewhat arbitrary */
UINT64 MAX_SIZE = Int64Initializer(0, UINT_MAX);
/* Minimum allocation in bytes */
#define MIN_BLOCK 512

/* Internal constructor */
PRIVATE PMEMFILE MFNew(void)
{
    PMEMFILE x;

    x = (PMEMFILE) CurrentHeap()->v->Alloc(CurrentHeap(),
                                            HEAP_ZERO_MEMORY | HEAP_DEBUG_NAME("memfile:MFNew"),
                                            sizeof(*x),
                                            0);
    DPRINT(("MFNew => %x\n", x));
    if (x) {
        x->v = &MemFileVtbl;
        x->RefCnt = 1;

        x->Access = NAME_SPACE_READ | NAME_SPACE_WRITE;
        Mutex_Init(&x->mx);

        /* The factory keeps the module from going away */
        pTheFactory->v->AddRef(pTheFactory);
    }
    return x;
}

/* Internal destructor */
PRIVATE void MFDestroy(PMEMFILE x)
{
    PBLOCK b, bb;
    DPRINT(("MFDestroy\n"));

    CHECK_HEAP();
    /* Release block list */
    for (b = x->Blocks; b; b = bb) {
        if (b->Mem)
            free(b->Mem);
        bb = b->Next;
        free(b);
    }

    Mutex_Destroy(&x->mx);
    free(x);

    /* The factory keeps the module from going away */
    pTheFactory->v->Release(pTheFactory);
    CHECK_HEAP();
}

/* Exported MemFile constructor */
SCODE CreateMemFile(PIFILE *pNewFile)
{
    PMEMFILE x;

    DPRINT(("CreateMemFile\n"));

    x = MFNew();
    if (!x)
        return E_NOT_ENOUGH_MEMORY;

    *pNewFile = iMF(x);
    return S_OK;
}

/* IUnknown::QueryInterface method */
PRIVATE SCODE MCT MFQueryInterface(PIFILE This, REFIID Iid, void **ppObj)
{
    DPRINT(("MFQueryInterface x%x\n", This));
    return GenericQueryInterface((PIUNKNOWN) This, Iid, ppObj, &IID_IFile);
}

/* IUnknown::AddRef method */
PRIVATE UINT MCT MFAddRef(PIFILE This)
{
    UINT RefCnt = AtomicInc(&pMF(This)->RefCnt);
    DPRINT(("MFAddRef x%x ==> %d\n", This, RefCnt));
    return RefCnt;
}

/* IUnknown::Release method */
PRIVATE UINT MCT MFRelease(PIFILE This)
{
    UINT RefCnt = AtomicDec(&pMF(This)->RefCnt);
    DPRINT(("MFRelease x%x ==> %d\n", This, RefCnt));
    if (RefCnt == 0) {
        MFDestroy(pMF(This));
    }
    return RefCnt;
}

PRIVATE BOOL CheckAccess(PMEMFILE x, UINT Access)
{
    if ((Access & NAME_SPACE_READ) && !(x->Access & NAME_SPACE_READ))
        return FALSE;
    if ((Access & NAME_SPACE_WRITE) && !(x->Access & NAME_SPACE_WRITE))
        return FALSE;
    return TRUE;
}

SCODE CopyToBlock(PBLOCK b, const BYTE *pBuffer, UINT Size, UINT BlockOffset)
{
    PIHEAP Heap = CurrentHeap();

    assert(Size <= b->Size);
    CHECK_HEAP();
    if (!b->Mem) {
        b->Mem = Heap->v->Alloc(Heap, HEAP_DEBUG_NAME("tmpfs"), b->Size, 0);
        if (!b->Mem)
            return E_NOT_ENOUGH_MEMORY;
    }
    memcpy(b->Mem + BlockOffset, pBuffer, Size);
    CHECK_HEAP();
    return S_OK;
}

void CopyFromBlock(PBLOCK b, BYTE *pBuffer, UINT Size, UINT BlockOffset)
{
    if (b->Mem)
        memcpy(pBuffer, b->Mem + BlockOffset, Size);
    else
        memset(pBuffer, 0, Size); /* no data, return zeroes */
    CHECK_HEAP();
}

PBLOCK NewBlock(UINT Size)
{
    PIHEAP Heap = CurrentHeap();
    PBLOCK b = Heap->v->Alloc(Heap, HEAP_DEBUG_NAME("tmpfs"), sizeof(*b), 0);
    if (b) {
        memset(b, 0, sizeof(*b));
        b->Size = Size;
    }

    CHECK_HEAP();
    return b;
}

/* IFIle::ReadAt method. */
PRIVATE SCODE MCT MFReadAt(PIFILE This, UINT64 Offset, PBYTE pBuffer, UINT Size, UINT *pSizeRead)
{
    PBLOCK b, *prevbp;
    UINT bo, off, sz;
    SCODE sc = E_INVALID_PARAMETER; /* past EOF */

    PMEMFILE x = pMF(This);
    DPRINT(("MFRead x%x\n", This));
    CHECK_HEAP();

    if (!CheckAccess(x, NAME_SPACE_READ))
        return E_ACCESS_DENIED;

    off = Uint64ToUint32(Offset);

    *pSizeRead = 0;
    /* Deal with any existing blocks first */
    bo = 0;                     /* block offset from beginning of file */
    Mutex_Lock(&x->mx);
    /* Check for past EOF */
    if (off >= x->Size) {
        sc = S_FALSE;
        goto Out;
    }
    /* Truncate read to file size. XXX overflows? */
    if (Size + off > x->Size)
        Size = x->Size - off;

    for (prevbp = &x->Blocks, b = *prevbp; b; prevbp = &b->Next, b = *prevbp) {
        if (off >= bo && off < bo + b->Size) {
            /* There is some data within this block */
            sz = bo + b->Size - off;
            if (sz > Size)      /* don't return more than asked */
                sz = Size;
            if (off + sz > x->Size) /* don't return past EOF */
                sz = x->Size - off;
            CopyFromBlock(b, pBuffer, sz, off - bo);

            off += sz;
            pBuffer += sz;
            Size -= sz;
            *pSizeRead += sz;

            if (Size == 0) {
                Mutex_Unlock(&x->mx);
                CHECK_HEAP();
                return S_OK;
            }

            sc = S_FALSE;       /* at least some data is returned */
        }

        bo += b->Size;
    }

    /* EOF */
Out:
    Mutex_Unlock(&x->mx);
    CHECK_HEAP();
    return sc;
}

/* IFile::WriteAt method.  Don't store data anywhere.  Just say we did. */
PRIVATE SCODE MCT MFWriteAt(PIFILE This, UINT64 Offset, const BYTE *pBuffer,
                            UINT Size, UINT *pSizeWritten)
{
    PBLOCK b, *prevbp;
    UINT bo, off, sz;
    SCODE sc;

    PMEMFILE x = pMF(This);
    DPRINT(("MFWrite x%x\n", This));
    CHECK_HEAP();

    if (!CheckAccess(x, NAME_SPACE_WRITE))
        return E_ACCESS_DENIED;
 
    off = Uint64ToUint32(Offset);

    *pSizeWritten = 0;
    /* Deal with any existing blocks first */
    bo = 0;                     /* block offset from beginning of file */
    Mutex_Lock(&x->mx);
    /* UINT64_MAX means append at end of file */
    if (Int64Equal(Offset, UINT64_MAX))
        off = x->Size;
        
    for (prevbp = &x->Blocks, b = *prevbp; b && Size; prevbp = &b->Next, b = *prevbp) {
        if (off >= bo && off < bo + b->Size) {
            /* We can write some data within this block */
            sz = bo + b->Size - off;
            if (sz > Size)
                sz = Size;
            sc = CopyToBlock(b, pBuffer, sz, off - bo);
            CHECK_HEAP();
            if (sc != S_OK) {
                Mutex_Unlock(&x->mx);
                return sc;
            }

            off += sz;
            pBuffer += sz;
            Size -= sz;
            *pSizeWritten += sz;

            CHECK_HEAP();
            if (Size == 0) {
                if (off > x->Size)
                x->Size = off;
                Mutex_Unlock(&x->mx);
                return S_OK;
            }
        }

        bo += b->Size;
    }

    assert(b == NULL);
    assert(off >= bo);

    /* See if we need to insert a filler block */
    if (off > bo + MIN_BLOCK) {
        sz = off - bo;
        if (sz < MIN_BLOCK)
            sz = MIN_BLOCK;
        b = NewBlock(sz);
        CHECK_HEAP();
        if (!b) {
            Mutex_Unlock(&x->mx);
            return E_NOT_ENOUGH_MEMORY;
        }
        *prevbp = b;
        prevbp = &b->Next;
        if (off > x->Size)
            x->Size = off;

        bo += sz;
    }

    /* Finally we need to allocate a new block to hold the actual data */
    sz = off - bo + Size;
    if (sz < MIN_BLOCK)
        sz = MIN_BLOCK;
    b = NewBlock(sz);
    CHECK_HEAP();
    if (!b) {
        Mutex_Unlock(&x->mx);
        return E_NOT_ENOUGH_MEMORY;
    }

    *prevbp = b;
    if (off + Size > x->Size)
        x->Size = off + Size;
    sc = CopyToBlock(b, pBuffer, Size, off - bo);
    *pSizeWritten += Size;      /* value does not matter in error case */

    CHECK_HEAP();
    Mutex_Unlock(&x->mx);
    return sc;
}

/* IFile::SetFile method */
PRIVATE SCODE MCT MFSetSize(PIFILE This, UINT64 Size)
{
    PMEMFILE x = pMF(This);
    DPRINT(("MFSetSize x%x %lx\n", This, Size));

    if (Uint64Less(MAX_SIZE, Size))
        return E_ACCESS_DENIED;

    Mutex_Lock(&x->mx);
    x->Size = Uint64ToUint32(Size);
    Mutex_Unlock(&x->mx);
    CHECK_HEAP();
    return S_OK;
}

/* IFile::GetFile method */
PRIVATE SCODE MCT MFGetSize(PIFILE This, UINT64 *pSize)
{
    PMEMFILE x = pMF(This);
    DPRINT(("MFgetSize x%x\n", This));

    Mutex_Lock(&x->mx);
    Uint32ToUint64(*pSize, x->Size);
    Mutex_Unlock(&x->mx);
    return S_OK;
}

PRIVATE struct IFileVtbl MemFileVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    MFQueryInterface,
    MFAddRef,
    MFRelease,
    MFReadAt,
    MFWriteAt,
    MFSetSize,
    MFGetSize
};
