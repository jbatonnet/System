/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <mmmacros.h>
#include <tchar.h>
#include <loaders/cobtab.h>
#include <base/cons.h>

SCODE FirstApp(const _TCHAR *Args)
{
    METHOD_DECLARE_NOTHIS(eb63ds, FirstThread);
    PINAMESPACE ns = CurrentNameSpace();
    PIPROGRAM prog = NULL;

    UnusedParameter(Args);

    sc = BindToObject(ns, _T("COB/protocol.cob"), NAME_SPACE_READ,
                      &IID_IProgram, (void **) &prog);
    CHECKSC("load network stack");
    sc = prog->v->Main(prog, _T("start"));
    CHECKSC("protocol start");
    sc = prog->v->Main(prog, _T("dhcp"));
    CHECKSC("protocol dhcp");
    sc = prog->v->Main(prog, _T("lo0 127.0.0.1"));
    CHECKSC("protocol lo0");
    RELEASE_NULL(prog);

    sc = BindToObject(ns, _T("COB/http.cob"), NAME_SPACE_READ,
                      &IID_IProgram, (void **) &prog);
    CHECKSC("load http.cob");

    sc = prog->v->Main(prog, _T("http"));
    CHECKSC("start http server on port 80");
    RELEASE_NULL(prog);

    sc = BindToObject(ns,_T("COB/cimdb.cob"), NAME_SPACE_READ,
                  &IID_IProgram, (void **) &prog);
    CHECKSC("load cimdb");
    sc = prog->v->Main(prog,_T("-a 172.31.40.217"));
    CHECKSC("cimdb start");
    RELEASE_NULL(prog);

    sc = BindToObject(ns,_T("COB/dssp.cob"), NAME_SPACE_READ,
                  &IID_IProgram, (void **) &prog);
    CHECKSC("load dssp");
    sc = prog->v->Main(prog,_T(""));
    CHECKSC("dssp start");
    RELEASE_NULL(prog);

METHOD_CLEANUP;
    RELEASE(prog);
    SleepUntil(TIME_FOREVER);
    return sc;
}
