/* Copyright (c) Microsoft Corporation. All rights reserved. */

#include <lcd.h>

void Lcd_WriteStr(char *s)
{
#ifdef __GNUC__
    while(*s)
        Lcd_WriteChar(*s++);
#endif
}

static void Lcd_WriteHex4bit(unsigned char n)
{
	if (n < 10) {
		n += '0';
	} else {
		n += 'A' - 10;
	}
#ifdef __GNUC__
	Lcd_WriteChar(n);
#endif
}

void Lcd_WriteHexByte(unsigned char n)
{
	Lcd_WriteHex4bit((n & 0xf0) >> 4);
	Lcd_WriteHex4bit(n & 0x0f);
}

void Lcd_WriteHexShort(unsigned short n)
{
	Lcd_WriteHexByte((n >> 8) & 0xff);
	Lcd_WriteHexByte(n & 0xff);
}

void Lcd_WriteHexLong(unsigned long n)
{
	Lcd_WriteHexShort((n >> 16) & 0xffff);
	Lcd_WriteHexShort(n & 0xffff);
}

