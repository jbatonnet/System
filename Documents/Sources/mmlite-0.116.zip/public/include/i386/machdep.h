/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Machine-dependent functions and definitions 
 * which are not otherwise defined in fred.h
 *
 */
#define __MEMFUNC_ARE_INLINED (!_DEBUG)
#define __NEED_M_THDINFO 0
#define __SUPPORTS_COB_NAMESPACE 1

#define MachineSpecificInfo(a,b) (E_NOT_IMPLEMENTED)
#define CurrentProcessorKind() (PROCESSOR_KIND_IA32)
extern UINT CurrentProcessorOEM(void);
extern UINT64 CurrentProcessorSpeed(void);

#if defined(SIM)

/* Many files in the simulator need this one windows export,
 * don't drag the entire windows.h in just for it.
 */
#if !defined(_IMPORT_WINDOWS_H_)
extern unsigned int __stdcall GetCurrentThreadId(void);
#endif

/* Bigger stack in case we call into Win32 libraries */
#define DEFAULT_STACK_SIZE (4*2048)-8

extern unsigned int AtomicOrSwap(unsigned int * pTarget, unsigned int Bits);
extern unsigned int AtomicNandSwap(unsigned int * pTarget, unsigned int Bits);

#define SIMINT_DISABLED (1)
#define SIMINT_PENDING  (0x10)
#define SIMINT_PENDING1 (0x20)
#define SIMINT_PENDING2 (0x40)

extern volatile unsigned int SimInt_State;

extern void SimInt_CallPending(void);
extern unsigned int SimThreadId;

#define X86_FLAG_IF 0x0200
#define TURN_INTERRUPTS_OFF(_s_) \
{ \
  if (SimThreadId != GetCurrentThreadId()) DebugBreak(); \
  _s_ = AtomicOrSwap((void *) &SimInt_State, SIMINT_DISABLED); \
}

#define RESTORE_INTERRUPTS(_s_)  \
{ \
 if (!(_s_ & SIMINT_DISABLED)) { \
    ENABLE_INTERRUPTS(); \
  } else { \
    /* Do nothing */ \
  } \
}

#define ENABLE_INTERRUPTS() \
{ BOOL _x_; \
  if (!(SimInt_State & SIMINT_DISABLED)) DebugBreak(); \
  _x_ = AtomicCmpAndSwap((void *) &SimInt_State, SIMINT_DISABLED, 0); \
  if (!_x_) { \
      SimInt_CallPending(); \
  } \
}

#define DISABLE_INTERRUPTS()    __asm mov SimInt_State, SIMINT_DISABLED;

extern void NT_Idle(void);
#define MACHINE_IDLE(x) NT_Idle()

#else  /* SIM */

#define DEFAULT_STACK_SIZE (4*2048)-8

#define X86_FLAG_IF 0x0200
#define TURN_INTERRUPTS_OFF(_s_) \
  __asm { __asm pushfd  __asm pop eax  __asm mov _s_,eax  __asm cli }
#define RESTORE_INTERRUPTS(_s_)  { if (_s_ & X86_FLAG_IF) __asm sti }
#define ENABLE_INTERRUPTS()  __asm sti
#define DISABLE_INTERRUPTS() __asm cli

#if !defined(DebugBreak)
#define DebugBreak() __asm { __asm int 3 __asm }
#endif

#endif /* SIM */

#ifdef _DEBUG
/* Enable stack overflow and usage checking
 */
#define CHECK_STACK_OVERFLOW
#define STACK_STATS
#endif

/* OPTIMIZATION SECTION
 */
/* interrupt path: isr->scheduler */
extern void _Reschedule(void);
