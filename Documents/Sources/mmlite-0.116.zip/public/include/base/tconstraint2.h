/* Header file for src\base\tconstraint2.h
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef _OLDSCHED

#ifndef __TCONSTRAINT2_H__
#define __TCONSTRAINT2_H__

#include <base/urgency2.h>

/* Time Constraint struct is defined in baseif.xml */

#define pTC(_ptc_) ((PTIME_CONSTRAINT)(_ptc_))

#define END_PREVIOUS 0x4
#define CRITICALITY_MASK (_CRITICAL | _TIMESHARING)

#define /* TIME */                                                            \
TConstraint_GetStartTime(/* PKCONSTRAINT */ _ptc_)                            \
     (pTC(_ptc_)->Start)

#define /* void */                                                            \
TConstraint_SetStartTime(/* PKCONSTRAINT */ _ptc_,                            \
                        /* TIME */ _tStart_)                                  \
     (TConstraint_GetStartTime(_ptc_) = (_tStart_))

#define /* TIME */                                                            \
TConstraint_GetEstimateTime(/* PKCONSTRAINT */ _ptc_)                         \
     (pTC(_ptc_)->Estimate)

#define /* void */                                                            \
TConstraint_SetEstimateTime(/* PKCONSTRAINT */ _ptc_,                         \
                                  /* TIME */ _tEstimate_)                     \
     (TConstraint_GetEstimateTime(_ptc_) = (_tEstimate_))

#define /* TIME */                                                            \
TConstraint_GetDeadlineTime(/* PKCONSTRAINT */ _ptc_)                         \
     (pTC(_ptc_)->Deadline)

#define /* void */                                                            \
TConstraint_SetDeadlineTime(/* PKCONSTRAINT */ _ptc_,                         \
                          /* TIME */ _tDeadline_)                             \
     (TConstraint_GetDeadlineTime(_ptc_) = (_tDeadline_))

#define /* _CRITICALITY */                                                    \
TConstraint_GetCriticality(/* PTCONSTRAINT */ _ptc_)                          \
     ((pTC(_ptc_)->Criticality) & CRITICALITY_MASK)

#define /* BOOL */                                                            \
TConstraint_IsCritical(/* PKCONSTRAINT */ _ptc_)                              \
     (((pTC(_ptc_)->Criticality) & _CRITICAL) == _CRITICAL)

#define /* void */                                                            \
TConstraint_SetCriticality(/* TCONSTRAINT */ _ptc_,                           \
                          /* _CRITICALITY */ _c_)                             \
     ((pTC(_ptc_)->Criticality) |= ((_c_) & CRITICALITY_MASK))

#define /* void */                                                            \
TConstraint_SetCritical(/* PKCONSTRAINT */ _ptc_)                             \
     ((pTC(_ptc_)->Criticality) |= _CRITICAL)

#define /* void */                                                            \
TConstraint_ClearCritical(/* PKCONSTRAINT */ _ptc_)                           \
     ((pTC(_ptc_)->Criticality) &= ~_CRITICAL)

#define /* BOOL */                                                            \
TConstraint_IsTimeSharing(/* PKCONSTRAINT */ _ptc_)                           \
     (((pTC(_ptc_)->Criticality) & _TIMESHARING) == _TIMESHARING)

#define /* void */                                                            \
TConstraint_SetTimeSharing(/* PKCONSTRAINT */ _ptc_)                          \
     ((pTC(_ptc_)->Criticality) |= _TIMESHARING)

#define /* void */                                                            \
TConstraint_ClearTimeSharing(/* PKCONSTRAINT */ _ptc_)                        \
     ((pTC(_ptc_)->Criticality) &= ~_TIMESHARING)

#define /* BOOL */                                                            \
TConstraint_GetEndPrevious(/* PKCONSTRAINT */ _ptc_)                          \
     (((pTC(_ptc_)->Criticality) & END_PREVIOUS) == END_PREVIOUS)

#define /* void */                                                            \
TConstraint_SetEndPrevious(/* PKCONSTRAINT */ _ptc_)                          \
     ((pTC(_ptc_)->Criticality) |= END_PREVIOUS)

#define /* void */                                                            \
TConstraint_ClearEndPrevious(/* PKCONSTRAINT */ _ptc_)                        \
     ((pTC(_ptc_)->Criticality) &= ~END_PREVIOUS)

#define /* PTIME */                                                           \
TConstraint_GetTimeTaken(/* PTIME_CONSTRAINT */ _ptc_)                        \
     (pTC(_ptc_)->TimeTaken)

#define /* void */                                                            \
TConstraint_SetTimeTaken(/* PTIME_CONSTRAINT */ _ptc_,                        \
                        /* PTIME */ _pt_)                                     \
     (TConstraint_GetTimeTaken(_ptc_) = (_pt_))

void TConstraint_Init(PTIME_CONSTRAINT ptc);

#endif /* __TCONSTRAINT2_H__ */

#endif /* _OLDSCHED */
