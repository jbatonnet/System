/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define OPTIMIZE        /* enable Base.h optimizations, since we're the "base" */

#include <mmlite.h>
#include <fred.h>
#include <base/thread.h>
#include <base/schedul.h>
#include <schedulif.h>

/* Concrete class.
 *
 * WAITERS is used to queue threads waiting on this condition.
 *
 * NEXTCOND is used to link all conditions that cannot be immediately
 * signalled at interrupt time (by Condition_InterruptSignal), so
 * that they get signalled as soon as the scheduler lock is released.
 * It is also used to remember if the condition has been interrupt-signalled.
 */
typedef struct _COND { /* Internal definition */
#if NEWLIST
    PITHREAD Waiters;
#else
    PLISTNODE Waiters;
#endif
    struct _COND *NextCond;
} COND, *PCOND;

#define CD_SIGNALLED 1
#define CD_QUEUED 2


#if _UINTSIZE == 16
#define BAD_COND (0x8FF0 | CD_SIGNALLED)
#endif
#if _UINTSIZE == 32
#define BAD_COND (0x8FFBAD00 | CD_SIGNALLED)
#endif
#if _UINTSIZE == 64
#define BAD_COND (0x8FFFFFFFFFBAD000 | CD_SIGNALLED)
#endif

/* Use volatile here to ensure that the compiler does NOT optimize/move
 * any loads/stores. Conditions are used/modified from ISRs etc,
 * we don't want any values cached in registers.
 */
#define pCD(pCond) ((volatile COND *)(pCond))


/* Deferred points to list of conditions that have been signalled from an
 * interrupt.
 */
volatile PTR/*PCOND*/ DeferredConditionSignals = NULL;

/* Multiprocessor locking */
/* some compilers do not like empty decls e.g. ';' */
#if !defined(__ARMCC_VERSION) && !defined(ecog) && !defined(h8)
DEFINE_MPSPINLOCK(ConditionMpLock);
#endif

/* *** GetCondFirstWaiter
 *
 * Returns pointer to the first waiting thread, NULL if none.
 * Note that the first waiter is NOT !! removed from the list.
 */
#if !defined(__ARMCC_VERSION)
static INLINE 
#endif
#if NEWLIST
PITHREAD GetCondFirstWaiter(PCONDITION pCond)
{
    PITHREAD pThd;

    pThd = pCD(pCond)->Waiters;
    if (pThd != NULL) {
#if 0/*paranoia check*/
        if (pTH(pThd)->WaitObject != pCond) {
            printf("GetCondFirst %x %x ?\n", pCond, pThd);
        }
#endif

        return pThd;
    }

    return NULL;
}
#else
PITHREAD GetCondFirstWaiter(PCONDITION pCond)
{
    PLISTNODE plnFirst;
    PTHDINFO pThd;

    plnFirst = pCD(pCond)->Waiters;
    if (plnFirst != NULL) {

        pThd = GetThreadFrom(plnFirst,Queue);
#if 0/*paranoia check*/
        if (pTH(pThd)->WaitObject != pCond) {
            printf("GetCondFirst %x %x ?\n", pCond, pThd);
        }
#endif

        return iTH(pThd);
    }

    return NULL;
}
#endif


/* *** SetCondFirstWaiter
 *
 * Set the head of the Waiters list
 */
#if NEWLIST
#define SetCondFirstWaiter(_c_,_t_) \
    pCD(_c_)->Waiters = (_t_);
#else
#define SetCondFirstWaiter(_c_,_t_) \
    pCD(_c_)->Waiters = (_t_) ? & pTH(_t_)->Queue : NULL;
#endif


/* *** WaitCond
 *
 * Wait on a condition.
 * If not signalled put thread on a waiting queue.  If pMutex !=
 * NULL unlock the mutex.  If pTimeOut != NULL also put thread on sleep queue.
 * Called either from within IPC path or from vtbl function.
 * Preemption must be disabled.
 *
 * Note that relative timeouts are converted to absolute time in place.
 * That way if the caller of this function loops around (spurious wakeup)
 * it passes back a correct timeout.
 */
/*static*/ void WaitCond(PCONDITION pCond, PMUTEX pMutex, PTIME pTimeOut)
{
    PITHREAD pThd;
    UINT IntrState;
    UINT State;
    PITHREAD pThdFirst, pThdNewFirst;

    assert(!pTheScheduler->v->PreemptionIsEnabled(pTheScheduler));

    pThd = CurrentThread();

    DBGOUT(DBGCOND,CDLVL,dprintf(
         "WaitCond %08x Next %x Thd %08x Mutex %08x %hs",
         pCond,pCD(pCond)->NextCond,pThd,pMutex,(pTimeOut) ? "" : "\n"));
    DBGOUT(DBGCOND,CDLVL,if (pTimeOut) dprintf("TimeOut %08x%08x\n",
                          ((PUINT)pTimeOut)[1],((PUINT)pTimeOut)[0]));

    /* Put this thread on condition's queue.  Since interrupts are enabled,
     * a signal from an interrupt may come at any time.  This works because
     * the calls below, ConditionSignalDeferred modify different things.
     * And because noone else tries to queue up in parallel.
     * Notice that WaitForCondition will assert RescheduleNeeded().
     */
    pThdFirst = GetCondFirstWaiter(pCond);
    pThdNewFirst = pTheScheduler->v->WaitForCondition(pTheScheduler,
                                                      pThd,
                                                      pCond,
                                                      pThdFirst,
                                                      pTimeOut);
    SetCondFirstWaiter(pCond,pThdNewFirst);

    /* Now we are on the queue and all is well. But.  After we took
     * the scheduler lock, and before (and during) our enqueueing,
     * the condition might have been signalled. (It still could).
     * That routine (might have) found noone in the queue, so it only
     * left an indication that the event happened.
     * Cope with this now, making sure when the scheduler is unlocked
     * the DeferredCondition queue will include this condition.
     *
     * Notice that this also covers the case the condition had been
     * signalled before we took the lock (and noone else cared).
     */

    State = (UINT) pCD(pCond)->NextCond; /* make sure cache is hot */

    TURN_INTERRUPTS_OFF(IntrState);
    /* MMLITE_MP need to guard against other cpus */
    MpSpinLock(&ConditionMpLock);

    State = (UINT) pCD(pCond)->NextCond;

    if (State & CD_SIGNALLED) {

        /* Consume the signal.
         */
        pCD(pCond)->NextCond = (PCOND) (State & ~CD_SIGNALLED);

        /* Has been signalled from an interrupt.  If already waited it has
         * been put on the Deferred Condition Signal list, will be processed
         * soon.  Since this thread is now on the waiting list this thread
         * will be processed as well.  If not waited it wasn't put on the
         * deferred list.  Put it on the list now.
         */
         if (!(State & CD_QUEUED)) {
             pCD(pCond)->NextCond = (PCOND)
                 (((UINT) DeferredConditionSignals) | CD_QUEUED);
             DeferredConditionSignals = (PTR) pCond;
         }
    }

    MpSpinUnlock(&ConditionMpLock);
    RESTORE_INTERRUPTS(IntrState);

    if (pMutex != NULL) {
        Mutex_Unlock(pMutex);
    }

    /* Off we go to pick the next runnable thread (possibly us again)
     */
}

/* *** UnwaitCond
 *
 * Release one or more threads which are waiting on a condition.
 * Preemption must be disabled.
 */
static void UnwaitCond(PCONDITION pCond, BOOL fAll, SCODE sc)
{
    PITHREAD pThdFirst, pThdNewFirst;

    assert(!pTheScheduler->v->PreemptionIsEnabled(pTheScheduler));

    DBGOUT(DBGCOND,CDLVL,dprintf(
        "UnwaitCond %08x Next %x All %d sc %08x\n",
                                      pCond,pCD(pCond)->NextCond,fAll,sc));

    pThdFirst = GetCondFirstWaiter(pCond);
    if (pThdFirst == NULL) {
        /* There are no waiters. Set CD_SIGNALLED just as in
         * Condition_InterruptSignal. This makes the CD a binary semaphore.
         * this is AtomicOr((PUINT) &pCD(pCond)->NextCond, CD_SIGNALLED);
         */
        UINT old;
        if (!fAll) do {
            old = (UINT) pCD(pCond)->NextCond;
        } while (!AtomicCmpAndSwap((PUINT) &pCD(pCond)->NextCond,
                                   old,
                                   old | CD_SIGNALLED));
    } else {
        pThdNewFirst = pTheScheduler->v->WakeWaitingThreads(pTheScheduler,
                                                           pThdFirst,
                                                           sc,
                                                           fAll);
        SetCondFirstWaiter(pCond,pThdNewFirst);
    }
}

/* *** ConditionTimeoutThread
 *
 * The timeout expired for a thread waiting on a condition.
 * Release that thread.  All the work is done inside the scheduler,
 * all we have to do is to provide the first waiter on the condition,
 * and re-enque a possibly different new first waiter.
 * Preemption must be disabled.
 */
void ConditionTimeoutThread(PCONDITION pCond,
                            PITHREAD pThd,
                            TIMEOCOND_CALLBACK CallBack)
{
    PITHREAD pThdFirst, pThdNewFirst;

    assert(pCond != NULL);
    assert(!pTheScheduler->v->PreemptionIsEnabled(pTheScheduler));

    pThdFirst = GetCondFirstWaiter(pCond);
    if (pThdFirst != NULL) {
        pThdNewFirst = CallBack(pThdFirst,pThd);
        SetCondFirstWaiter(pCond,pThdNewFirst);
    }
}

/* This is called from context switch code.
 * Assumes preemption disabled, interrupts enabled.
 * Preemption disabled & uniprocessor implies noone
 * else can modify pCond->Waiters.
 */
void DrainDeferredConditions(void)
{
    PCOND pCond, pNext;
    PITHREAD pThdFirst, pThdNewFirst;

    assert(!pTheScheduler->v->PreemptionIsEnabled(pTheScheduler));

    /* There are no races in this test, noone but us removes
     * entries from the list.  We only worry about additions
     * that happen while we work on it.
     */
    while (DeferredConditionSignals != NULL) {

        /* Instead of atomically dequeueing (which is ok) we can
         * just take the whole list away in one shot, then process
         * individual elements without much concerns.  If there is
         * only one entry its the same thing.
         */
        do {
            pCond = (PCOND) DeferredConditionSignals;
        } while (!AtomicCmpAndSwap((PUINT) &DeferredConditionSignals,
                                   (UINT)  pCond,
                                   (UINT)  NULL));

        /* Now we have the whole list in hand.  Noone will try
         * to put back a condition we hold on to, because it has been
         * signalled already.  Therefore noone messes with us.
         */
        do {
            /* Dont think this should ever fail.. but.
             */
            if (pCond->Waiters != NULL) {

                pThdFirst = GetCondFirstWaiter((PCONDITION)pCond);

                pThdNewFirst = pTheScheduler->v->WakeWaitingThreads(
                                                        pTheScheduler,
                                                        pThdFirst,
                                                        S_OK,
                                                        FALSE);

                SetCondFirstWaiter(pCond,pThdNewFirst);

            } else {
                /* Weird, a condition signalled&queued with no waiters ??
                 */
/*              printf("DrainDeferred %x ?\n", pCond);*/
            }

            /* Move on to the next condition. Notice we kept this one busy
             * all the way to the end.  Let it go now.
             */
            pNext = (PCOND)
                (((UINT)pCD(pCond)->NextCond) & ~(CD_QUEUED | CD_SIGNALLED));

            pCond->NextCond = NULL;

            /* Are we done yet
             */
            pCond = pNext;

        } while (pCond != NULL);

        /* Now go back and check the list again, for any latecomers
         */
    }
}

#if 0 /* unused */
/* ThreadConditionCancel is called when a thread has timed out waiting on
 * a condition. (prototype removed from here).
 * It is also called from DeleteThread() (thread.c) when it finds
 * a thread that is being terminated while waiting on a condition.
 */

static void ConditionCancelWaiter(PITHREAD pThd)
{
    PCONDITION pCond;
    PITHREAD pThdFirst, pThdNewFirst;

    assert(!pTheScheduler->v->PreemptionIsEnabled(pTheScheduler));

    pCond = (PCONDITION) pTH(pThd)->WaitObject;

    DBGOUT(DBGCOND,1,dprintf("ConditionCancelWaiter Thd %08x Cond %08x\n",pThd,pCond));

    pThdFirst = GetCondFirstWaiter(pCond);
    if (pThdFirst != NULL) {
        pThdNewFirst = ThreadConditionCancel(pThdFirst,pThd);
        SetCondFirstWaiter(pCond,pThdNewFirst);
    }
}

/* Old alias */
#define ConditionTimeoutWaiter(_a_,_b_) ConditionCancelWaiter
#endif /* unused */

/* ==== Interface functions
 */

void Condition_Signal(PCONDITION pCondition)
{
    pTheScheduler->v->DisablePreemption(pTheScheduler,FALSE);
    UnwaitCond(pCondition,FALSE,S_OK);
    pTheScheduler->v->EnablePreemption(pTheScheduler,FALSE);
}


void Condition_Broadcast(PCONDITION pCondition)
{
    pTheScheduler->v->DisablePreemption(pTheScheduler,FALSE);
    UnwaitCond(pCondition,TRUE,S_OK);
    pTheScheduler->v->EnablePreemption(pTheScheduler,FALSE);
}

SCODE Condition_Wait(PCONDITION pCondition, PMUTEX pMutex, PTIME pTimeout)
{
    SCODE sc;
    TIME t;
    PITHREAD th = CurrentThread();

    /* Make a copy cuz its in-only */
    if (pTimeout) {
        t = *pTimeout;
        pTimeout = &t;
    }

    pTheScheduler->v->DisablePreemption(pTheScheduler,FALSE);

    WaitCond(pCondition, pMutex, pTimeout);

    pTheScheduler->v->EnablePreemption(pTheScheduler,FALSE);

    sc = th->v->GetValue(th, THREAD_VALUE_LAST_ERROR);

    /* BUGBUG the lock should be taken inside the scheduler
     * so that a signal can pick the right thread. Else
     * the thread wakes up, just to be blocked again here.
     */
    if (pMutex != NULL)
        Mutex_Lock(pMutex);

    return sc;
}

SCODE Condition_WaitAndBeginConstraint(PCONDITION pCondition,
                           PMUTEX pMutex, PTIME pTimeout, BOOL EndPrevious,
                           PTIME_CONSTRAINT pTimeConstraint, PTIME pTimeTaken)
{
    TIME t;

    /* Make a copy cuz its in-only */
    if (pTimeout) {
        t = *pTimeout;
        pTimeout = &t;
    }

    return pTheScheduler->v->ConditionTimedWaitAndBeginConstraint(
                                                pTheScheduler,
                                                pCondition,
                                                pMutex,
                                                pTimeout,
                                                EndPrevious,
                                                pTimeConstraint,
                                                pTimeTaken,
                                                WaitCond);
}


void Condition_Init(PCONDITION pCondition)
{
    pCD(pCondition)->NextCond = NULL;
    pCD(pCondition)->Waiters  = NULL;
}

void Condition_Destroy(PCONDITION pCondition)
{
    pCD(pCondition)->NextCond = (PCOND) BAD_COND;
    pCD(pCondition)->Waiters  = NULL;
}

/* Signal a condition, but from special context (a device ISR).
 * Only assumption that can be made here is *all* interrupts are disabled.
 * [Relaxing this assumption is not that hard though]
 * Returns TRUE if reschedule should happen.  Caller is supposed to return
 * that value to its caller; ultimately get back to the interrupt dispatcher.
 */
extern void LogIt(UINT Key, UINT Info);

BOOL Condition_InterruptSignal(PCONDITION pCond)
{
//    LogIt(13,0);

    /* Assume interrupts are disabled
     */
    /* MMLITE_MP need to guard against other cpus */
    MpSpinLock(&ConditionMpLock);

    /* If the condition is already signalled there is nothing to do (rare) */
    if (pCD(pCond)->NextCond == NULL) {

        /* Send the condition to the scheduler IFF there are waiters;
         * otherwise just set the signalled bit.  The bit also serves
         * as an indication to WaitCond that this condition has been
         * signalled.  This resolve races where a thread is about to
         * wait on the condition and it gets signalled from an interrupt
         */
        if (pCD(pCond)->Waiters) {

            pCD(pCond)->NextCond = (PCOND)
                (((UINT) DeferredConditionSignals) | CD_QUEUED);
            DeferredConditionSignals = (PTR) pCond;

            MpSpinUnlock(&ConditionMpLock);
            return TRUE;
        }

        /* There are no waiters, no need for scheduler
         */
        pCD(pCond)->NextCond = (PCOND) CD_SIGNALLED;
    }

    MpSpinUnlock(&ConditionMpLock);
    return (FALSE);
}
