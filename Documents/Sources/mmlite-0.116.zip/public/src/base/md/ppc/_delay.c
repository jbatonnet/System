/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>

/* Should be called only from interrupt handlers (ie kernel mode, interrupts
 * disabled).  This is not enforced, but if called from any other mode the
 * duration of the call can vary greatly.  The only real guarantee is that
 * we will spend AT LEAST uSec microseconds inside this routine.
 */
UINT DelayMultiplier = 10; /* platform should define/refine this */
UINT DelayShifter    = 0;  /* platform should define/refine this */
UINT DelayOverhead   = 0;  /* platform should define/refine this */

/* In assembler because compiler too dumb
 */
extern void Delay(UINT uSec);

