/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>

const struct PRECOB ThePreCobTable[] = {
#if 1
    NTUBIG_COBS
#else
    BASIC_NET_COBS
    BASIC_SOAP_COBS
    PRIVATE_SOAP_COBS
    {_T("simnic.cob"), SimNicCobMain }, \
    {_T("sernet.cob"), SerNetCobMain }, \
    {_T("serplex.cob"), SerplexCobMain }, \
    {_T("hostfs.cob"), HostfsCobMain },
#endif
    {0, 0}
};
