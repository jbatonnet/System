/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _I386_DOSX_H_
#define _I386_DOSX_H_ 1

#include <x86_cpu.h>

typedef struct {
    I386_GP_REGS gp;
    UINT32       eflags; /*sigh*/
} DOSX_CALLBACK_ARGUMENTS, *PDOSX_CALLBACK_ARGUMENTS;

typedef struct {
    UINT8               nBytes;
    unsigned char       CmdLine[1]; /* variable length */
} DOSX_COMMAND_LINE, *PDOSX_COMMAND_LINE;

typedef UINT (* DOSX_CALLBACK)( UINT IntNo,
                                PDOSX_CALLBACK_ARGUMENTS pArgsIn,
                                PDOSX_CALLBACK_ARGUMENTS pArgsOut );

typedef struct _DOSX_INTERFACE {
    UINT32              RelocationBase;
    UINT32              ImageSize;
    PDOSX_COMMAND_LINE  pCommandLine;
    DOSX_CALLBACK       CallbackRoutine;
} DOSX_INTERFACE, *PDOSX_INTERFACE;

extern void InitializeDosx( PDOSX_INTERFACE pIface);

extern void SafelyCallback( UINT IntNo,
                     PDOSX_CALLBACK_ARGUMENTS pIn,
                     PDOSX_CALLBACK_ARGUMENTS pOut );

extern PTR DosxPointer(void);   /* Really returns PDOSX_INTERFACE */
#define DosxCmdLine() ((PDOSX_INTERFACE) DosxPointer())->pCommandLine->CmdLine

#endif /* _I386_DOSX_H_ */
