/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Get a pointer to the current process heap. */
IHeap *pHeap = CurrentHeap();

/* Specify base address and size of desired block. */
void *pMem = (void *)0x0000dcba;  
UINT ExtractSize = 50;

/* Base address and size of block actually allocated */
void *ptr;   
UINT RealSize;

ptr = pHeap->Extract(HEAP_ZERO_MEMORY, pMem, ExtractSize);
if(ptr == NULL)    {
    _tprintf(_TEXT("Failed to allocate specified block.\n"));
    return 0;
}

/* Determine the actual size of the allocated memory block. */
RealSize = pHeap->Size(0, ptr);
if(ExtractSize <= RealSize)
    _tprintf(_TEXT("An extra %d bytes were allocated.\n"), 
             RealSize - ExtractSize);     
/* END_SAMPLE */
return 0;
}
