/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <machdep.h>
/* XXX Belongs somewhere else.
 * Assume there is only one interrupt dispatcher
 */
extern struct IPic *pThePic;

/*
 * Specification for functions in the machine-independent layer,
 * which the machine-dependent code can up-call.
 */

 /* Create the system heap.  Left to machdep code because messy otherwise.
  * The heap should account for all available memory, carved out of memory
  * that is already used or unavailable (like the 640K-1meg hole on PCs).
  * It does not have to account for all the memory in the system.
  * Returns a new heap as PIHEAP pointer.
  */
extern PIHEAP MachineHeapCreate(void);

/* Generic heap constructor called from MachineHeapCreate */
PIHEAP RTLCALLTYPE CreateHeapFrom(ADDRESS Mem,
                     UINT Flags, ADDR_SIZE InitSize, ADDR_SIZE MaxSize);

/* Base initialization/finalization.
 */
extern void BaseInit(void);
extern void BaseDelete(void);

/* What should the first thread do? Load init.exe? Whatever
 * Called from MD FirstThread.
 */
extern SCODE FirstApp(const _TCHAR *Args);

/* Terminate the system.  Whatever that means (=>machdep)
 */
extern void TheEnd(void);

 /* Initialize the machine-dependent part of a thread object.
  * The (new) thread should be set to execute the function START
  * and finally execute at RETURN once START finishes.
  * There are ARGCOUNT arguments on stack or when ARGCOUNT == -1
  * the single argument ARG is passed. No scheduling side-effects.
  */
extern void MachineThreadCreate(PITHREAD pThis, THREAD_FUNCTION pStart, THREAD_ARGUMENT Arg, PTR StackTop, UINT ArgCount, UINT32 Flags);
extern void MachineThreadTerminate(PITHREAD pThis);

/*
 * If anything needs to be done to start the system timer(s),
 * do it when this function is called.
 */
extern void EnableTimers(void);

/*
 * If anything needs to be done to stop the system timer(s),
 * do it when this function is called.  
 * Called on kernel (orderly) shutdown. 
 */
extern void DisableTimers(void);

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is machine-specific.
 */
extern TIME GetKernelTime (void);

 /* Set the hardware programmable interrupt timer (PIT) to
  * give us an interrupt in DELTA time units from now.
  * If pStateVariable is non-NULL, set it to FALSE and return
  * the previous value, with the timer interrupt off.
  * If it is null return FALSE;
  */
extern BOOL SetNextInterrupt( TIME Delta, BOOL *pStateVariable);

 /* Called to request a reschedule, with preemption disabled.
  * Does not context switch; that happens when preemption is enabled.
  */
extern void Reschedule(void);

 /* Upon thread termination, direct switch to a different thread.
  * Should just reload state and go.
  */
extern void LoadThreadContext(PITHREAD NextThread);

#if !defined(ThreadSetCurrent)  /* BUGBUG: Reconcile this with the OPTIMIZE macros in Base.h -JP */
extern void ThreadSetCurrent( PITHREAD pThread);
#endif

extern void CurrentHeapDelayedFree( PTR pMem);
extern void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg);

/* Interface to machine dependent low level trap installer (some platforms) */
extern void InstallIsr(UINT InterruptNumber, ADDRESS Isr,
                       UINT RawTrapNumber, UINT UserAccessible);

/* Multiprocessor locking. Interrupts must be off when a MpSpinlock is held */
#ifdef DEFINE_MPSPINLOCK /* allow MD override */
#elif MMLITE_MP
#define DEFINE_MPSPINLOCK(_name_) UINT _name_ = 0
extern void MpSpinLockInit(PUINT pLock);
extern void MpSpinLock(PUINT pLock);
extern void MpSpinUnlock(PUINT pLock);
#else
#define DEFINE_MPSPINLOCK(_name_)
#define MpSpinLockInit(_p_)
#define MpSpinLock(_p_)
#define MpSpinUnlock(_p_)
#endif

/* Debug support.
 */
#if defined(CHECK_STACK_OVERFLOW)
extern BOOL CheckStackOverflow(IThread *pThis);
#else
#define CheckStackOverflow(x) TRUE
#endif
#if defined(STACK_STATS)
extern INT CheckStackUsage(IThread *pThis);
#else
#define CheckStackUsage(x) 0
#endif

#define _INC_STDIO /* base only does printf, do not get confused */
extern INT printf(const char *format, ...);
EXTERN_C int __cdecl putchar(int c);
EXTERN_C int puts(const char *s);

#define DBGOUT(_x_,_y_,_z_)  /* wazzizfor? */
#include <assert.h>

/* define image end address. Compiler dependent.
 */
#ifndef _end
extern char _end[];
#endif
