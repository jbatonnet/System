/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _VM_H_
#define _VM_H_

extern const PINAMESPACE pTheFactory;

SCODE CreateZeroFile(PIFILE *ppFile);
SCODE CreateNullFile(PIFILE *ppFile);
SCODE CreateMemFile(PIFILE *ppFile);
SCODE CreateFilterFile(PIFILE pParent, UINT64 Offset, UINT64 Size, PIFILE *ppFile);

#ifdef _DEBUG
#define DPRINT(_s_)
#define EPRINT(_s_) printf _s_
#else
#define DPRINT(_s_)
#define EPRINT(_s_)
#endif
#endif /* _VM_H_ */
