/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include "at91m63200.h"
#include "eb63.h"
#define EBCLOCK Eb63Clock

/*** the rest is the same on eb55/eb63 ***/

#include <machdep.h>
#include <fred.h>
#include <base/debugger.h>

/* USE_SERPLEX is defined in ... */
#include <drivers/serp.h>

extern void gdbOutputString( const unsigned char *string, int len );

/* Use the USART0 line for console/serplexd and the USART1 line for debugging.
 */
#define ConPort Usart0
#define ConPortNo 0
#define DbgPort Usart1
#define DbgPortNo 1

/* *** ComPortReset
 *
 * Re-Initialize a COM port for low-level (polling) debugging use.
 *
 */
PRIVATE void 
ComPortReset(USART *Port, UINT Baud, UINT8 PortNo, BOOL Polling)
{
    UINT32 Divisor;

    /* Enable clock to the part */
    ThePmc->PerClockEnable = PMCPC_USART0 << PortNo;

    /* Better be slower than faster, roundup 
     * NB: ASYNC, else no x16;
     */
    Divisor = (EBCLOCK/8)/Baud;
    Divisor = (Divisor/2) + (Divisor&1);
    Port->Baud = Divisor;

    /* 8 bit, no parity, 1 stop */
    Port->Mode = USM_CLK_MCKI | USM_BPC_8 | USM_NONE | USM_1STOP;

    if (Polling) {
        /* disable all interrupts */
        Port->IntrDisable = ~0;

        /* disable DMA stuff */
        Port->RxPointer =
        Port->TxPointer =
        Port->RxTimeout =
        Port->TxTimeout =
        Port->RxCounter =
        Port->TxCounter = 0;
    }

    /* Enable rx/tx and clear any leftover status bits */
    Port->Control = USC_RXEN | USC_TXEN | USC_RSTSTA | USC_STPBRK;

    /* Turn on external pins */
    PioA->Disable = ((PIOA_TXD0|PIOA_RXD0) << (PortNo*3));
}

/* More auto-init
 */
PRIVATE char DbgioInited = 0;
#define LIGHTLY 1
#define HEAVILY 2

PRIVATE void
ComPortInit(char How, USART *Port, UINT8 PortNo)
{
    if ((DbgioInited & (How << (PortNo*2))) == 0) {
        DbgioInited |= (How << (PortNo*2));
        ComPortReset(Port, 38400, PortNo, (How == HEAVILY));
    }
}

/* *** ComPortPut
 *
 * Write a byte to the specified port.
 */
void ComPortPut(USART *Port, UINT8 Byte)
{
    /* wait until we can transmit */
    while ((Port->ChannelStatus & USI_TXEMPTY) == 0)
        continue;

    Port->TxData = Byte;
}


UINT ComPortErrors = 0;

/* *** ComPortGet
 *
 * Read a byte from the specified port.
 * Returns FALSE if there was no byte ready
 * to be read, or in case of error.
 */
BOOL ComPortGet(USART *Port, UINT8 *pByte)
{
    UINT32 Status = Port->ChannelStatus;

    /* See if anything available */
    if (Status & USI_RXRDY) {
        *pByte = (UINT8) Port->RxData;

        /* Check for errors */
        if (Status & (USI_RXBRK|USI_OVRE|USI_FRAME|USI_PARE)) {
            ComPortErrors++;
            if ((Status & USI_OVRE) == 0)   /* Overrun? */
                return FALSE;           /*  no, parity or framing error */
        }

        return TRUE;
    }

    return FALSE;
}

/* Called possibly more than once at startup
 * NB: This really means the console
 */
void DbgPortInit(void)
{
#if 0
    /* DONT do this. The RESET state of this register is 0x18 */

    /* wait for any characters to drain */
    while ((ConPort->ChannelStatus & USI_TXEMPTY) == 0)
        continue;
#endif

    ComPortReset(ConPort, 38400, ConPortNo, TRUE);
}

#define dputc DCPutChar
void dputc(unsigned char c)
{
    ComPortInit(LIGHTLY,ConPort,ConPortNo);

#if USE_SERPLEX
    /* Wrap the bytes into serplex frames */
    ComPortPut(ConPort, STH_CHAR);
    ComPortPut(ConPort, CONSerplexAddr);
    if ((c == STH_CHAR) || (c == EOT_CHAR) 
        || (c == ESC_CHAR) || (c == COMP_CHAR)) 
    {
        ComPortPut(ConPort,ESC_CHAR);
    }
#endif

    if (c == '\n')
        ComPortPut(ConPort, '\r');
    ComPortPut(ConPort, c);

#if USE_SERPLEX
    ComPortPut(ConPort, EOT_CHAR);
    /* Fix checksum on account of STX chars */
    if (c == STH_CHAR)
        c++;
    if (c == '\n')
        c += '\r';
    ComPortPut(ConPort, c);
    ComPortPut(ConPort, 0);
#endif
}

unsigned char dgetc(int echo)
{
    unsigned char c;

    while (!ComPortGet(ConPort, &c)) {
        //SleepUntil(TIME_ORIGIN);
        continue;
    }

    if (echo == TRUE)       
        dputc(c);

    if (/*DebuggerAttached &&*/ (c == 3)) /* ^C , likely from GDB */
        DebugBreak();

    return c;
}

void putDebugChar(unsigned char c)
{
    ComPortInit(LIGHTLY,DbgPort,DbgPortNo);

    ComPortPut(DbgPort, c);
}

int getDebugChar(void)
{
    unsigned char c;

    ComPortInit(HEAVILY,DbgPort,DbgPortNo);

    while (!ComPortGet(DbgPort, &c))
        continue;

    return c;
}
