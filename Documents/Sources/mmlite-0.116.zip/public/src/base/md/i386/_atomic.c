/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* *** AtomicCmpAndSwap
 *
 * Compare *pTarget with OldVal.  If equal, set *pTarget to NewVal,
 * return TRUE; else return FALSE.
 */
#pragma warning(disable:4035)   /* disable warning C4035: no return value */
BOOL AtomicCmpAndSwap(PUINT pTarget, UINT OldVal, UINT NewVal)
{
    /* This works on 486 and higher processors */
    __asm {
        mov eax,OldVal;
        mov ecx,pTarget;
        mov edx,NewVal;
#if 0 /* compilerbug */
        lock cmpxchg [ecx],edx; /* ZF==1 IFF exchanged ok */
#else
        __emit 0xf0;   /* lock prefix */
        __emit 0x0f;   /* opcode.1 */
        __emit 0xb1;   /* opcode.2 */
        __emit 0x11;   /* /r: [ecx],edx */
#endif
        mov eax,0;
        jnz didnot;
        inc eax;
    didnot:
    }
}

/* *** AtomicSwap
 *
 * Atomically swaps NewCount with *pCount and returns the old value.
 */
UINT AtomicSwap(PUINT pCount, UINT NewCount)
{
    __asm {
        mov ecx,pCount;
        mov eax,NewCount;
        lock xchg [ecx],eax;
    }
}
#pragma warning(default:4035)   /* reenable warning C4035   */
