/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains an IID for ISampleFactory.
 * The object should be statically linked into each application so it can be
 * used for interface version checking.
 * Each time you revise the interface you need to generate a new IID.
 * uuidgen -s does it.
 * IIDs go into src/iidlib.  i didn't put this there as it is just a sample.
 */
#include <mmlite.h>

const struct IID IID_ISampleFactory = { /* fd07b108-7529-11d3-8c5c-00e0291551e5 */
    0xfd07b108, 0x7529, 0x11d3,
    {0x8c, 0x5c, 0x00, 0xe0, 0x29, 0x15, 0x51, 0xe5}
  };
