/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __MMLITE_MD_H__
#define __MMLITE_MD_H__

typedef signed char INT8;       /* size is 1 */
typedef unsigned char UINT8;    /* size is 1 */
typedef short INT16;            /* size is 2 */
typedef unsigned short UINT16;  /* size is 2 */
typedef long INT32;              /* size is 4 */
typedef unsigned long UINT32;    /* size is 4 */
/* in case we do not want the compiler supported ones (almost never) */
#if defined(__NO_BUILTIN_INT64)
typedef struct _INT64 INT64;
typedef struct _UINT64 UINT64;
#else
typedef signed __int64 INT64;
typedef unsigned __int64 UINT64;
#endif

typedef INT32 INT;
typedef UINT32 UINT;

#ifdef _MSC_VER
/* VC7 complains about volatile r-values */
#pragma warning(disable:4197)
#endif

#define _UINTSIZE        ( 32 )
#ifdef _OLDSCHED
#define _MUTEX_STATE_SIZE       ( 1 )
#define _CONDITION_STATE_SIZE   ( 2 )
#else
#define _MUTEX_STATE_SIZE       ( 5 )
#define _CONDITION_STATE_SIZE   ( 3 )
#endif

#if !defined(__NO_BUILTIN_INT64)  /* int64con.c causes this because msr */
struct  _FPAINFO {
    UINT64 fpr[32];
    UINT64 fpscr;
};

struct  _CXTINFO {
    UINT64 gpr[32];
    UINT64 lr;
    UINT64 pc;
    UINT64 ctr;
    UINT64 cr;
    UINT64 xer;
    UINT64 msr;
#define PPC_MSR_SF   0x8000000000000000
#define PPC_MSR_HV   0x1000000000000000
#define PPC_MSR_VEC  0x02000000
#define PPC_MSR_POW  0x00040000
#define PPC_MSR_IMPL 0x00020000
#define PPC_MSR_ILE  0x00010000
#define PPC_MSR_EE   0x8000
#define PPC_MSR_PR   0x4000
#define PPC_MSR_FP   0x2000
#define PPC_MSR_ME   0x1000
#define PPC_MSR_FE0  0x0800
#define PPC_MSR_SE   0x0400
#define PPC_MSR_BE   0x0200
#define PPC_MSR_FE1  0x0100
#define PPC_MSR_IP   0x0040
#define PPC_MSR_IR   0x0020
#define PPC_MSR_DR   0x0010
#define PPC_MSR_PM   0x0004
#define PPC_MSR_RI   0x0002
#define PPC_MSR_LE   0x0001
};
#endif

//#define __DebugBreak() __asm ( __asm int 3 __asm }

#define _DCACHELINESIZE 128      /* Size in bytes of data-cache line. */
#define _PAGE_SIZE (4096)
#define _PAGE_SHIFT (12)


#endif /* MMLITE_MD_H */
