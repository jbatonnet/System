/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define _DEBUG 1
#include <mmlite.h>
#include <fred.h>
#include <mmhal.h>
#include <base/debugger.h>
#include "ppc_traps.h"

#ifndef USE_KD
#define USE_KD 1
#endif

extern UINT32 nImiss, nDmiss;

#if defined(_DEBUG)
#define DBG(_x_) printf _x_
typedef char *MYSTRING;
MYSTRING TrapMsg = "\t*** Caught a %s Interrupt\n";
MYSTRING TrapNames[TRAP_COUNT] = {
    "Program",
    "External",
    "Floating Point Processor Unavailable",
    "Vector Processor Unavailable",
    "Data Storage",
    "Instruction Storage",
    "Alignment",
    "System Call",
    "Trace",
    "Maintenance",
    "VMX Assist",
    "Thermal",
    "Data Segment",
    "Instruction Segment",
    "Performance Monitor",
    "Instruction Address",
    "System Management",
    "Software Patch",
    "Storage Violation"
};
#else
#define DBG(_x_)
#endif

typedef BOOL (* TRAP_HANDLER)(PCXTINFO *pContext, UINT32 Cause);

/* Installable trap handler returns TRUE if debugger action is required */
PRIVATE TRAP_HANDLER TrapHandler = NULL;

/* Install/Remove an interrupt handler entry */
void InstallIsr( UINT InterruptNumber, ADDRESS Isr,
                UINT RawTrapNumber, UINT UserAccessible)
{
    /* XXX Only used for Trap for now */
    TrapHandler = (TRAP_HANDLER) (PTR) Isr;
}

#if USE_KD
#else
void Debugger(PCXTINFO pContext, UINT32 Cause)
{
    printf("Terminating thread %x, cause %d\n",CurrentThread(),Cause);
    ThreadExit();
}
UINT DebuggerNotifyLoad(const _TCHAR *ModuleName,
                        ADDRESS LoadStart,
                        ADDRESS LoadEnd,
                        PTR Unused)
{return 0;}
void DebuggerNotifyUnload(const _TCHAR *ModuleName, ADDRESS LoadStart,
                          UINT Token)
{}
void DebuggerOutputString( const unsigned char *String, int nBytes )
{}
void DebuggerInputString( insigned char *String, UINT nMaxBytes)
{}
#endif

/* The current processor took a trap that the first level handlers
 * cannot resolve.
 */
PCXTINFO CurrentProcessorTrap(PCXTINFO pContext, UINT32 Cause)
{
    BOOL DebuggerNeeded = TRUE;
    PPCR pcr = CurrentProcessor();

    (void) CheckStackOverflow(CurrentThread());

    if (Cause == TRAP_SV)
        Cause = pcr->SegvCause;
    if (TrapHandler != NULL)
        DebuggerNeeded = (*TrapHandler)(&pContext,Cause);
    if (DebuggerNeeded) {
        if (!DebuggerAttached) {
            DBG((TrapMsg, TrapNames[Cause]));
            DBG(("\t*** pc %lx msr %lx lr %lx\n",
                 pContext->pc, pContext->msr, pContext->lr));
            DBG(("\t*** stack usage: %d\n", CheckStackUsage(CurrentThread())));
            DBG(("\t*** TLB I=%d D=%d\n", nImiss, nDmiss ));
            DBG(("\t*** PCR = r2=%lx r5=%lx r6=%lx dar=%lx dsisr=%x segv=%x\n",
                 pcr->Gpr2Save, pcr->Gpr5Save, pcr->Gpr6Save,
                 pcr->DarSave, pcr->DsisrSave, pcr->SegvCause));
        }
        Debugger(pContext,Cause);
    }
    return pContext;
}



