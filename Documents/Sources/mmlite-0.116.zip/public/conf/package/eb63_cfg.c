/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>
#include <drivers/serp.h>

#define isSEAL 0
#define USE_SERPLEX 1

const DRIVER_CONFIG DriverConfigs[] = {
#if 1
  {_T("null"), _T("COB/null.cob"), DEVICE_FLAGS_MANUAL_START, },

  /* Serial flash */
  {_T("sflash"), _T("COB/db161.cob"), DEVICE_FLAGS_MANUAL_START, },
  /* Flash */
  {_T("flash"),_T("COB/bv16.cob"),DEVICE_FLAGS_MANUAL_START,0x01000000,0,NULL,NULL,0,0,},
  {_T("flash_std"),_T("COB/bv16.cob"),DEVICE_FLAGS_MANUAL_START,0x01000000,0,NULL,NULL,0x080000,0,},
  {_T("flash_user"),_T("COB/bv16.cob"),DEVICE_FLAGS_MANUAL_START,0x01000000,0,NULL,NULL,0x180000,1,},
#endif

  {_T("com1"), _T("COB/eb63usart.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_LEVEL_TRIGGER|DEVICE_FLAGS_POSITIVE_LEVEL|DEVICE_FLAGS_MANUAL_START, 0xfffc0000, 2, NULL, NULL, 38400, },
  {_T("com2"), _T("COB/eb63usart.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_LEVEL_TRIGGER|DEVICE_FLAGS_POSITIVE_LEVEL|DEVICE_FLAGS_MANUAL_START, 0xfffc4000, 3, NULL, NULL, 38400, },
  /* the third m63200 serial line (0xfffc8000,4) is not connected */

  {_T("hostname.txt"), _T("COB/db161.cob"), 0, },
  /* NB: must come after com2 in table */

#if USE_SERPLEX
  /* Console, hostfs and sernet share one serial port. Run serplexd.exe on NT side. */
  {_T("serplex6a"), _T("COB/serplex.cob"), DEVICE_FLAGS_MANUAL_START | DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, FSSerplexAddr, },
  {_T("srfs"), _T("COB/hostfs.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("serplex6a"), },

  /* public channel */
  {_T("serplex6d"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, NICSerplexAddr, },
  {_T("sr0"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6d"), NULL,},
//#if !isSEAL && 0
  /* secure channel */
  {_T("serplex6b"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com2"), NULL, 0, NICSerplexAddr, },
#ifdef EB63BIG2
  {_T("sr1"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6b"), _T("192.168.0.21"),},
#else
  {_T("sr1"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6b"), _T("192.168.0.20"),},
#endif
//#endif

  {_T("serplex6c"), _T("COB/serplex.cob"), DEVICE_FLAGS_MANUAL_START | DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, CONSerplexAddr, },

#else
  /* Run hostfsd.exe on NT side */
  {_T("serplex6a"), _T("COB/serplex.cob"), DEVICE_FLAGS_MANUAL_START | DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, FSSerplexAddr, },
  /* Without serplex. Must run hostnic.exe on NT side */
  {_T("sr0"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER, 0, 0, _T("com1"), },
#endif

  /* only on simulator */
#if defined(mips)
  {_T("display"), _T("COB/gianofb.cob"), 0, 0xffd00000, 0xffd80000, NULL, },
#endif
#if 0
  {_T("Wave0"), _T("COB/gsound.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_POSITIVE_LEVEL, 0xfff08000, 16, NULL, NULL, },
#endif

  /* only on TAMU boards */
#if 0
  {_T("sl811"), _T("COB/sl811.cob"),
       DEVICE_FLAGS_NO_THREAD | DEVICE_FLAGS_INTERRUPTS |
       DEVICE_FLAGS_LEVEL_TRIGGER | DEVICE_FLAGS_POSITIVE_LEVEL,
       0x20000000, 30, 0, },
  {_T("usb0"),  _T("COB/usbhub.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
       _T("sl811"), NULL, 0, },
  /* by hand:
   * sr0.exe sl811 COB\sl811.cob b2 20000000 30
   * sr0.exe usb0 COB\usbhub.cob 80 0 0 sl811
   */
#endif
  {NULL,}
};
