/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

/* Sets the default stack size to 4K. */
int _tmain()
{
    IProcess *pPrc;    /* Pointer to process object.*/
    SCODE StatusCode;

    pPrc = CurrentProcess();    /* Get current process.*/

    StatusCode = pPrc->Init( 4*1024, NULL, NULL, NULL);

    if (FAILED(StatusCode)) {
        _tprintf(_TEXT("Can't set default stack size, sc = x%x\n"),
                 StatusCode);
        exit(0);
    }
    _tprintf(_TEXT("StackSize set to 4K for process (%08x).\n"),
             (ADDRESS) pPrc);

    return 0;
}
