/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <mmmacros.h>
#include <string.h>
#include <fred.h>
#include <x86_cpu.h>
#include <_dosx.h>
#include "_pic.h"

DOSX_INTERFACE Dosx;
extern INT *bstack;     /* in main.c */

void InitializeDosx( PDOSX_INTERFACE pIface)
{
    Dosx = *pIface;
}

/* Return a pointer to the info DOSX passed to us.
 */
PTR /*PDOSX_INTERFACE*/ DosxPointer(void)
{
    return (PTR) &Dosx;
}

/* Extract the command line */
const char *BootCmdLine(void)
{
    return NULL; //(const char*) DosxCmdLine();
}

/* Say we are NOT a simulator
 */
UINT CurrentProcessorOEM(void)
{
    /* Somewhere in the BIOS I suppose.. */
    return 0;
}

BOOL ProbeGateA20Behavior()
{
    UINT a, b, c, d;
    UINT *p1 = (UINT*) 0x300000;
    UINT *p2 = (UINT*) 0x400000;
    a = *p1;
    b = *p2;
    *p1 = 0xdeadfeed;
    c = *p1;
    d = *p2;
    *p1 = a;
    printf("GateA20 test a=%x b=%x c=%x d=%x\n", a, b, c, d);
    if (a != c)
        return TRUE;
    else
        return FALSE;
}

void GateA20(BOOL enable)
{
#if 0
    UINT8 val;

    ProbeGateA20Behavior();

    DBG(("%sabling A20 from keyboard\n", enable ? "en" : "dis"));

    /* Write to keyboard controller output port to enable A20 line */
    while (IOSpaceReadInt8( (IO_PORT) 0x64 ) & 2)
        ;
    IOSpaceWriteInt8( 0x64, 0xd1);

    while (IOSpaceReadInt8( (IO_PORT) 0x64 ) & 2)
        ;
    if (enable)
        IOSpaceWriteInt8( 0x60, 0xdf);
    else
        IOSpaceWriteInt8( 0x60, 0xdd);

    while (IOSpaceReadInt8( (IO_PORT) 0x64 ) & 2)
        ;

    /* Then do the "fast A20" too (bit 0=1 reset, bit 1=1 enabled) */
    val = IOSpaceReadInt8( (IO_PORT) 0x92);

    if (val & 2) {
        if (!enable) {
            DBG(("Disable fast A20\n"));
            val &= 0xfc;
            IOSpaceWriteInt8( (IO_PORT) 0x92, val);
        }
    } else if (enable) {
        DBG(("Enable fast A20\n"));
        val |= 2;
        val &= 0xfe;
        IOSpaceWriteInt8( (IO_PORT) 0x92, val);
    }

#if 0
    /* Finally try BIOS */
    {
        DOSX_CALLBACK_ARGUMENTS Args;
        /* Find out how much extended memory we got, if any
         */
        Args.gp.eax.r8.rh = (UINT8)0x2401;
        SafelyCallback(0x15, &Args, &Args);
        DBG(("Enabled A20 from BIOS ret=x%x\n", Args.gp.eax.r8.rh));
    }
#endif

    /* Some cache flushing required ... */
    __asm {
        wbinvd
    }
#endif
}

/* Create the system heap.  Left to machdep code because messy otherwise.
 * The heap should account for all available memory, carved out of memory
 * that is already used or unavailable (like the 640K-1meg hole on PCs).
 * It does not have to account for all the memory in the system.
 * Returns a PIHEAP pointer.
 */
PIHEAP MachineHeapCreate( void )
{
    ADDRESS MemBase, MemTop;
    ADDR_SIZE MemSize;
    PIHEAP pIHeap;
#define _HOLE_STARTS 0xa0000
#define _HOLE_SIZE (0x100000-0xa0000)
#define _RELOCATED_HOLE (_HOLE_STARTS-Dosx.RelocationBase)

    //#define _USE_ALL_MEMORY 1
#if _USE_ALL_MEMORY
    DOSX_CALLBACK_ARGUMENTS Args;
    /* Find out how much extended memory we got, if any
     */
    Args.gp.eax.r8.rh = (UINT8)0x88;
    SafelyCallback(0x15, &Args, &Args);
    if ((Args.eflags & X86_FLAG_CF) == 0) {
        /* Add low mem back in, careful about overflows here */
        MemTop = (Args.gp.eax.r32.erx + 1024);
        /* Take relocation away */
        MemTop -= (Dosx.RelocationBase / 1024);
        /* Turn into an address now */
        MemTop = (MemTop * 1024) + (Dosx.RelocationBase % 1024);
    } else
        MemTop = _RELOCATED_HOLE;
#else
    /* Only use the low 640 K
     */
    MemTop = _RELOCATED_HOLE;
#endif

#if 1
    MemBase = 0x200000;
    MemTop = 0x4000000; /* 64 MB, 0x40000000 = 1GB */
    MemSize = MemTop - MemBase - 0x40000; /* 1 GB - some */
#elif 1
    MemBase = 0x200000;
    MemSize = MemTop - MemBase; /* 128 KB of "BIOS" on HV */
#else
    MemBase = Dosx.ImageSize;
    MemSize = MemTop - MemBase;
#endif

    DBG(("Creating heap, base=%x size=%x\n", MemBase, MemSize));
    pIHeap = CreateHeapFrom(MemBase, 0, MemSize, MemSize);

#if 0
    /* Carve out "the hole"
     */
    if (MemTop > _RELOCATED_HOLE && MemBase < _RELOCATED_HOLE) {
        pIHeap->v->Extract(pIHeap, HEAP_NO_SERIALIZE,
                           (PTR)_RELOCATED_HOLE,
                           _HOLE_SIZE);
    }
#endif

    return pIHeap;
}

static int *saved_esp;
__declspec(naked) void CallBackHelper(void)
{
    /* Switch to bios stack and call dos extender.  Args are already pushed */
    __asm {
        pushad;
        mov saved_esp,esp;
        mov esp,bstack;
        /* Dosx.CallbackRoutine(IntNo, pIn, pOut); */
        call Dosx.CallbackRoutine;
        mov esp,saved_esp;
        popad;
        ret;
    }
}

/* Make a call to DOS/BIOS, i.e. execute an INT<N> instruction
 * in real mode, with the PIN register arguments.
 * Return the resulting register state in POUT.
 * In between, do anything necessary to restore the machine state
 * to what the DOS extender had it.
 */
extern INT16 __cdecl PITRead (void);
extern void PITWrite (UINT nTicks);
extern void DisableTimers( void ), EnableTimers( void );

void SafelyCallback( UINT IntNo,
                     PDOSX_CALLBACK_ARGUMENTS pIn,
                     PDOSX_CALLBACK_ARGUMENTS pOut )
{
#ifdef USE_OLD_PIC
    UINT Eflags;
    INT16 oPIT;
#endif
    IDT_POINTER Kidt;
    INT32 *in, *out, *oldbstack;

    /* No interrupts: the bios stack is global.
     */
#ifdef USE_OLD_PIC
    Eflags = PicToBios();
#endif

    /* Put the PIT/RTC back the way BIOS had them
     */
#ifdef USE_OLD_PIC
    oPIT = PITRead();
#endif
    DisableTimers();

    __asm {
        sidt    Kidt;
    }

    /* Push arguments to bios stack
     */
    oldbstack = bstack;
    bstack -= sizeof(*pIn) / sizeof(int);
    memmove(bstack, pIn, sizeof(*pIn));
    in = bstack;

    bstack -= sizeof(*pOut) / sizeof(int);
    out = bstack;

    *--bstack = (int) out; /* BUGBUG: compensate for relo base? */
    *--bstack = (int) in;
    *--bstack = IntNo;

    /* Make the call
     */
    CallBackHelper();

    /* Copy return args back to our stack
     */
    if (pOut)
      memmove(pOut, out, sizeof(*pOut));

    /* Restore bios stack
     */
    bstack = oldbstack;

    __asm {
        lidt    Kidt;
    }

    /* Restart PIT/RTC from where they left (more or less)
     */
    EnableTimers();
#ifdef USE_OLD_PIC
    PITWrite(oPIT);
#endif

    /* And we are back in business.
     */
#ifdef USE_OLD_PIC
    PicFromBios(Eflags);
#else
#endif
}
