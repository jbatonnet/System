/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Specifications for object constructors. (this is not C++).
 */

#ifdef _OLDSCHED
extern SCODE MCT ThreadCreate( 
            PIPROCESS pProcess,
            THREAD_FUNCTION pStart,
            THREAD_ARGUMENT Arg,
            ADDR_SIZE StackSize,
            UINT32 Flags,
            /*optional*/     PIVMVIEW pVmView,
            /*optional,out*/ PTR *pStack,
            /*optional,out*/ IThread **ppNewThread);
#endif

extern SCODE ModuleCreate(const _TCHAR * pImage,
                   const _TCHAR * pArgs,
                   PBYTE StartAddress,
                   UINT AddressSize,
                   MODULEENTRY EntryPoint,
                   PTR ExportData, /* array allocated by caller w/ image */
                   UINT ExportSize,
                   PIMODULE *ImportedModules, /* callee allocated array */
                   UINT nImportedModules,
                   ADDRESS Metadata,
                   UINT32 EntryPointToken,
                   UINT32 Flags,
                   PIMODULE *ppIModule);

extern PIPROCESS InitializeIModule(PIHEAP pHeap, PINAMESPACE pNameSpace);

extern PINAMESPACE NameSpaceNew(const _TCHAR *);

extern struct IPic *PicCreate(void);
extern void PicDelete( struct IPic *pThis );

PINAMESPACE RomFsNew( PTR BaseOfMemory, UINT Size);

extern PINAMESPACE InitMemoryFileSystem(void);

extern SCODE RunSoapServer(const _TCHAR *Url,  BOOL Wait);
SCODE FirstApp(const _TCHAR *Args);
SCODE InitConsole(const _TCHAR *DriverName);

/* For MD code: start a specific driver, e.g. serial line console */
SCODE StartDriver(const _TCHAR *Name);

/* Find preloaded COB before CobInit has been called - for boot - Bind lite */
SCODE CobPreLookup(const _TCHAR *CobName, PIUNKNOWN *ppUnk);
