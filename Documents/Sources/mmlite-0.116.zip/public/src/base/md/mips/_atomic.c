/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * To be implemented in separate assembly file
 * [or does this compiler support inline asm ?]
 */

#ifdef TIGON
/* *** AtomicCmpAndSwap
 *
 * Compare *pTarget with OldVal.  If equal, set *pTarget to NewVal,
 * return TRUE; else return FALSE.
 */
BOOL AtomicCmpAndSwap(PUINT pTarget, UINT OldVal, UINT NewVal)
{
    UINT OldCount;
    UINT32 istate;
    BOOL ret;

    /* Tigon does not support LL/SC
     * We don't have interrupts either, but the macro takes the h/w semaphore
     * and increments a counter. The other CPU and host machine look at those
     * and avoid messing with us. The sempahore also guarantees atomicity wrt.
     * atomic accesses from the other CPU. The interrupt stuff needs to know
     * which CPU we are on though.
     */
    TURN_INTERRUPTS_OFF(istate);
    OldCount = *pTarget;
    if (OldCount == OldVal) {
        *pTarget = NewVal;
        ret = TRUE;
    } else {
        ret = FALSE;
    }
    RESTORE_INTERRUPTS(istate);
    return ret;
}
#else
/* In _start.s
 */
extern BOOL AtomicCmpAndSwap(PUINT pTarget, UINT OldVal, UINT NewVal);
#endif

/* *** AtomicSwap
 *
 * Atomically swaps NewCount with *pCount and returns the old value.
 */
UINT AtomicSwap(PUINT pCount, UINT NewCount)
{
    UINT OldCount;

    for (;;) {
        OldCount = *pCount;
        if (AtomicCmpAndSwap(pCount, OldCount, NewCount))
            return NewCount;
    }
}

