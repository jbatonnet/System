/* Copyright (c) Microsoft Corporation. All rights reserved. */

char _end[1];
