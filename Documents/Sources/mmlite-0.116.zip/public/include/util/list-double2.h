/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Circular inlined lists                                            --jvh 2004
   - head is single pointer               (saves space when many heads)
   - node is double pointer
   - each pointer points to an app struct (makes it easy to follow list in dbg)
   - each app struct contains a list node (could be multiple)
   - the offset to the list node is specified explicitly

A visualization attempt:

head -> first <-> middle <-> last <--+
           <-------------------------+

... and trying to be more complete:

        <-----------------------------------------+
head--> first <--  +--> middle <--  +--> last <-  +  -+
      +-link-------+  --link--------+  --link-----+   +
      +                                               +
      +-----------------------------------------------+

  In all of the APIs below "Offset" is how far into the app structure
  the link node is located (in bytes).
*/

#ifndef _UTIL_LIST_DOUBLE2
#define _UTIL_LIST_DOUBLE2 1

#include <mmmacros.h>

typedef struct _LIST_NODE_LINK {
    PTR pNext;
    PTR pPrev;
} *PLIST_NODE_LINK;

#define ListNodeDeclare(ContainingStruct, Field) \
struct { \
    struct ContainingStruct *pNext; \
    struct ContainingStruct *pPrev; \
} Field

typedef PTR LIST_HEAD, *PLIST_HEAD;

#define ListNodeGetLink(Offset, pItem) \
    ((PLIST_NODE_LINK) (((char *) pItem) + Offset))

#define ListNodeNext(Offset, pItem) \
    (ListNodeGetLink(Offset, pItem)->pNext)

#define ListNodePrev(Offset, pItem) \
    (ListNodeGetLink(Offset, pItem)->pPrev)

#define /*BOOL*/ ListNodeIsAlone(Offset, pItem) \
    (ListNodeNext(Offset, pItem)==pItem && ListNodePrev(Offset, pItem)==pItem)

#define ListNodeInit(Offset, pItem) \
    MACRO_BEGIN \
    PLIST_NODE_LINK pLink = ListNodeGetLink(Offset, pItem); \
    pLink->pNext = pItem; \
    pLink->pPrev = pItem; \
    MACRO_END

#define ListNodeInitializer(ContainingObject) \
    {&ContainingObject, &ContainingObject}

void ListAddFirst(PTR pHead, UINT Offset, PTR pNew);
void ListAddLast(PTR pHead, UINT Offset, PTR pNew);
void ListAddBefore(PTR pHead, UINT Offset, PTR pItem, PTR pNew);
void ListAddAfter(PTR pHead, UINT Offset, PTR pItem, PTR pNew);
PTR ListRemoveFirst(PTR pHead, UINT Offset);
//PTR ListRemoveLast(PTR pHead, UINT Offset);
void ListRemoveItem(PTR pHead, UINT Offset, PTR pItem);

/* List walking function, traversing, searching, sorting */
typedef UINT LIST_WALK;
#define LIST_WALK_ITERATE      0 /* Iterate over entire list */
#define LIST_WALK_SEARCH       1 /* Return matching item */
#define LIST_WALK_ADD          2 /* pArg is new item, add before match */
#define LIST_WALK_ADD_AFTER    3 /* pArg is new item, insert after match */
#define LIST_WALK_REMOVE       4 /* Remove matching item from list */
#define LIST_WALK_SCODE        5 /* Trans+Walk return SCODE, go until FAILED */
#define LIST_WALK_BESTFIT      6 /* Find the best matching item */
#define LIST_WALK_LARGEST      7 /* Find the largest value in the list */
/* The following can be used in conjuction with the others */
#define LIST_WALK_SORTED    0x100 /* >= is match, rather than just == 0 */
#define LIST_WALK_BACKWARDS 0x200 /* Iterate backwards */

/* ListWalk iterates over a list. It can be used for example to:
 *
 * Apply some argument to each node
 *     ListWalk(p,o, LIST_WALK_ITERATE, Applier, SomeArg)      [returns NULL]
 * Delete the entire list (caveat: does not clear head)
 *     ListWalk(p,o, LIST_WALK_ITERATE, Deleter, Heap)         [returns NULL]
 * Apply argument until failure, then stop and return error code
 *     ListWalk(p,o, LIST_WALK_SCODE, Applier, SomeArg)        [returns SCODE]
 *
 * Get a node with specific value
 *     ListWalk(p,o, LIST_WALK_SEARCH, NodeCmp, ReferenceNode) [returns OBJECT]
 * Get first node with value >= reference                      [returns OBJECT]
 *     ListWalk(p,o, LIST_WALK_SEARCH|LIST_WALK_SORTED, NodeCmp, ReferenceNode)
 * Get item with best score from Transform:                    [returns OBJECT]
 *   ret < 0: node not eligible for return
 *   ret = 0: exact match, return immediately
 *   ret > 0: partial match, smaller values are better
 *     ListWalk(p,o, LIST_WALK_BESTFIT, NodeCmp, ReferenceNode)
 * Get the largest item in the list. The pArg of Transform is the largest item
 * so far, or the argument to ListWalk initially. If none is larger, returns
 * the initial pArg node.
 *     ListWalk(p,o, LIST_WALK_LARGEST, NodeCmp, InitialLargest) [ret   OBJECT]
 *
 * Remove and get a node with specific value
 *     ListWalk(p,o, LIST_WALK_REMOVE, NodeCmp, ReferenceNode) [returns OBJECT]
 * Remove and get first node with value >= reference           [returns OBJECT]
 *     ListWalk(p,o, LIST_WALK_REMOVE|LIST_WALK_SORTED, NodeCmp, ReferenceNode)
 *
 * Insert node before node with specific value
 *     ListWalk(p,o, LIST_WALK_ADD, NodeCmp, ReferenceNode)    [returns NULL]
 * Insert node after node with specific value                  [returns NULL]
 *     ListWalk(p,o, LIST_WALK_ADD_AFTER, NodeCmp, ReferenceNode)
 * Sorted Insert: Insert node before node with value >= ref    [returns NULL]
 *     ListWalk(p,o, LIST_WALK_ADD|LIST_WALK_SORTED, NodeCmp, ReferenceNode)
 *
 * The Transform function is like strcmp -> zero is equal, negative is a<b.
 */

/* returns item matched (SEARCH,REMOVE,BESTFIT,LARGEST),
 * or status code (SCODE),
 * or NULL otherwise.
 */
PTR ListWalk(PTR pHead, UINT Offset, LIST_WALK Function,
             INT (*Transform)(PTR pItem, PTR pArg), PTR pArg);

/* Typed version where the Transformer takes two explicitly typed objects */
#define ListWalkT(_type_, _off_, _type2_,    _head_, _func_, _trans_, _arg_) \
    ((_type_ * (*)(_type_ **, UINT, LIST_WALK, INT (*)(_type_ *, _type2_ *), _type2_ *)) (ADDRESS) ListWalk)(_head_, _off_, _func_, _trans_, _arg_)

/* Copy list using Copier and return new head.
 * Upon failure calls Deleter for nodes already copied and returns NULL.
 * pArg might be heap etc.
 */
PTR ListCopy(const void *pHead, UINT Offset,
             PTR (*Copier)(PTR pItem, PTR pArg),
             INT (*Deleter)(PTR pItem, PTR pArg),
             PTR pArg);

/* Delete list using Deleter.
 * Calls ListWalk but also zeros the head.
 */
#define ListDelete(_pHead_, _Offset_, _Deleter_, _pArg_) \
    MACRO_BEGIN \
        ListWalk((_pHead_),(_Offset_),LIST_WALK_ITERATE,(_Deleter_),(_pArg_));\
        *(PLIST_HEAD)(_pHead_) = NULL; \
    MACRO_END


/* This is really an internal function but is used by cb_sched...
 * Remove a node from a list.
 * Returns pointer to the next node; NULL if this was the only node.
 */
PTR ListNodeRemove(UINT Offset, PTR pNode);

#endif /*_UTIL_LIST_DOUBLE2*/
