Copyright (c) Microsoft Corporation. All rights reserved.

This is the readme file for the tablet web service client application. 
The application collects the points of a stroke made in the drawing area 
of the application and sends the data in a SOAP message to the specified 
service.


Running the application.

The application can be run on Microsoft Windows Vista or on Microsoft 
Windows XP with the Microsoft .NET Framework version 3.0 (formerly WinFX, 
version 3.0 Beta 2 or higher recommended). 
The .NET framework 3.0 can be downloaded from 
http://msdn.microsoft.com/windowsvista/downloads/products/getthebeta/#runWinFXApps 
(link checked 06/21/2006).
to run the application the following files are required:
1. tabletWCF.exe		the executable
2. tabletWCF.exe.config		configuration settings for the executable
3. Microsoft.Ink.dll		dynamic link library that contains the 
				tablet drawing and capture functionality 


Application settings.

The application settings are in XML format in the tabletWCF.exe.config 
file for the release binary and in the app.config file for the debug 
version (the settings from app.config file are transferred to the 
tabletWCF.exe.config file located in the release binary folder when the 
application is compiled). The only suggested change to the configuration 
file is the IP address of the service. The address should match the IP 
address of the device where the service is running on. 


Compiling the application.

To compile the application using Microsoft Visual Studio the following steps
must be taken (the following instructions are valid for Windows XP):

1. Download the Windows SDK for windows Vista from http://www.microsoft.com/downloads/details.aspx?FamilyId=13F8E273-F5EA-4B7B-B022-97755838DB94&displaylang=en 
(link checked 06/21/2006)
2. Uninstall any pre-releases of the Microsoft WinFX Runtime Components 3.0, 
the WinFX SDK, the Platform SDK, the Windows SDK, the .NET Framework 
redistributable, Microsoft Visual Studio.
2. Install the .NET framework 3.0 (or WinFX runtime components, version 3.0 
Beta 2 or higher), assuming this has not already been done.
3. Install the Windows SDK for Vista (the latest version at the time when 
this readme was written was Microsoft Windows Software Development Kit (SDK) 
for Beta 2 of Windows Vista and WinFX Runtime Components).
4. Install Microsoft Visual Studio 2005.


The following steps may be needed before the solution can be compiled:

1. Add project reference to the following files:
	microsoft.ink.dll, which may be located in the folder 
	C:\Program Files\Reference Assemblies\Microsoft\Tablet PC\v6.0

	System.ServiceModel.dll, which may be located in the folder 
	C:\WINDOWS\WinFX\v3.0\Windows Communication Foundation

	System.Runtime.Serialization.dll, which may be located in the folder 
	C:\WINDOWS\WinFX\v3.0\Windows Communication Foundation


References can be added by following these steps:
1. When the project has been opened select the "Add reference" menu 
	option from the "Project" menu.
2. Click on the "Browse" tab in the dialog that opened.
3. Browse to the desired folder.
4. Click on the desired file and press OK. 



06/21/2006
J�rgo Preden
