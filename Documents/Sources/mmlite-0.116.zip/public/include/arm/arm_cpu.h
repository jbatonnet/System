/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* ARM processor specific defines */

#ifndef __ARM_CPU_H__
#define __ARM_CPU_H__ 1

/* ARM v3 MMU */

/* page table base register points to first level page w/ 16KB alignment */
#define ARM_PTB_MASK 0xffffc000

/* first level page table 16KB page, 16KB alignment */
#define ARM_PDE_TYPE_MASK 3
#define ARM_PDE_TYPE_INVALID 0
#define ARM_PDE_TYPE_PTE 1
#define ARM_PDE_TYPE_SECTION 2
#define ARM_PDE_TYPE_RESERVED 3
#define ARM_PDE_DOMAIN_MASK 0x1e0
#define ARM_PDE_DOMAIN(_d_) ((_d_) << 5)
#define ARM_PDE_MASK 0xfffffc00  /* 1KB alignment */
#define ARM_PDE_ENTRIES 4096     /* pdes on first level page */
#define ARM_PDE_PAGE_SIZE 16384  /* N*4 */

/* Second level entry 1KB page, 1KB alignment */
#define ARM_PTE_TYPE_MASK 3
#define ARM_PTE_TYPE_INVALID 0
#define ARM_PTE_TYPE_LARGE 1
#define ARM_PTE_TYPE_SMALL 2
#define ARM_PTE_TYPE_RESERVED 3
#define ARM_PTE_ENTRIES 256     /* ptes on second level page */
#define ARM_PTE_PAGE_SIZE 1024  /* N*4 */


#define ARM_PTE_BUFFER 4
#define ARM_PTE_CACHE 8
#define ARM_PTE_AP_MASK       0xff0
/* Protection bits are replicated four times and encode some protections */
/* r/o for both user & kernel (assume S=0 R=1 in CP15) */
#define ARM_PTE_AP_READ       0
/* r/w for kernel, various for user */
#define ARM_PTE_AP_USER_NONE  0x550
#define ARM_PTE_AP_USER_READ  0xaa0
#define ARM_PTE_AP_USER_WRITE 0xff0
/* pages must be 64KB/4KB aligned */
#define ARM_PTE_LARGE_MASK 0xffff0000
#define ARM_PTE_SMALL_MASK 0xfffff000

#endif /* __ARM_CPU_H__ */
