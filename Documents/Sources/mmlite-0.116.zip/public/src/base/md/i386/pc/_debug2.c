/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <x86_cpu.h>
#include <fred.h>
#include <_dosx.h>
#include <base/debugger.h>

#define SerialLinePrint 1

#if !SerialLinePrint
/* generic puts, repeated here so that all i386 are the same */
int puts(const char *s)
{
    if (s == NULL) return -1;

    while (*s != 0)                     /* Print on console (local) */
        putchar(*s++);

    return 0;
}

void DCPutChar( UINT8 c)
{
    DOSX_CALLBACK_ARGUMENTS args;
    memset(&args,0,sizeof args);
    args.gp.eax.r16.rx = (UINT16)(c | 0xe00);
    args.gp.ebx.r16.rx = 1;
    SafelyCallback(0x10, &args, &args );
}

int DCGetChar( BOOL DoEcho )
{
    UINT8       c;
    DOSX_CALLBACK_ARGUMENTS InArgs;

    for (;;) {
        /* Poll */
        memset(&InArgs, 0, sizeof InArgs);
        InArgs.gp.eax.r8.rh = 1;
        SafelyCallback(0x16, &InArgs, &InArgs);

        if ((InArgs.eflags & X86_FLAG_ZF) == 0) {
            /* Go and get it */
            InArgs.gp.eax.r16.rx = 0;
            SafelyCallback(0x16, &InArgs, &InArgs);
            c = InArgs.gp.eax.r8.rl;
            if ( DoEcho )
                DCPutChar(c);
            break;
        } else {
            SleepUntil(0);
        }
    }

    return c;
}

#else  /* !SerialLinePrint */
#define COM1    0x3f8
#define COM2    0x2f8
#define COM     COM2

void InitSerialLine()
{
#define COM1_BASE           0x03F8
#define COM2_BASE           0x02F8

#define IoPortBase          COM1_BASE
#define comTxBuffer         0x00
#define comRxBuffer         0x00
#define comDivisorLow       0x00
#define comDivisorHigh      0x01
#define comIntEnable        0x01
#define comIntId            0x02
#define comFIFOControl      0x02
#define comLineControl      0x03
#define comModemControl     0x04
#define comLineStatus       0x05


    IOSpaceWriteInt8((IO_PORT)(COM+comLineControl),  0x80);	// Access Baud Divisor
    IOSpaceWriteInt8((IO_PORT)(COM+comDivisorLow),   0x01);	// 115200
    IOSpaceWriteInt8((IO_PORT)(COM+comDivisorHigh),  0x00);
    IOSpaceWriteInt8((IO_PORT)(COM+comFIFOControl),  0x01);	// Enable FIFO if present
    IOSpaceWriteInt8((IO_PORT)(COM+comLineControl),  0x03);	// 8 bit, no parity
    IOSpaceWriteInt8((IO_PORT)(COM+comIntEnable),    0x00);	// No interrupts, polled
    IOSpaceWriteInt8((IO_PORT)(COM+comModemControl), 0x03);	// Assert DTR, RTS
}

void DCPutChar( UINT8 c)
{
    static BOOL inited = 0;

    UINT Eflags;
    TURN_INTERRUPTS_OFF(Eflags);
    if (!inited) {
        //InitSerialLine();
        inited = TRUE;
    }

    while ((IOSpaceReadInt8( (IO_PORT)COM+5 ) & 0x20) == 0)
        ;
    IOSpaceWriteInt8( COM, c);
    RESTORE_INTERRUPTS(Eflags);
}

#define __HAS_MACHINE_PUTS 1
int puts(const char *s)
{
    UINT Eflags;
    unsigned char c;

    if (s == NULL) return -1;

    TURN_INTERRUPTS_OFF(Eflags);
    while ((c = *s++) != 0) {
        if (c == '\n')
            DCPutChar('\r');
        DCPutChar(c);
    }
    RESTORE_INTERRUPTS(Eflags);

    return 0;
}

int DCGetChar( BOOL DoEcho )
{
    UINT8       c = 0;
    UINT        Eflags =0;

    TURN_INTERRUPTS_OFF(Eflags);
    do {
        c = IOSpaceReadInt8((IO_PORT) COM+5);
        SleepUntil(0);
    } while( ((c) & 0x01) == 0 );

    c = IOSpaceReadInt8((IO_PORT) COM);
    RESTORE_INTERRUPTS(Eflags);

    if ( DoEcho )
      DCPutChar(c);

    return c;
}

#endif /* !SerialLinePrint */

/* Donno, void */
PUBLIC UINT DebuggerNotifyLoad(const _TCHAR *ModuleName,
                               ADDRESS LoadAddress,
                               ADDRESS LoadEnd,
                               PTR Unused)
{return 0;}
void DebuggerNotifyUnload(const _TCHAR *ModuleName, ADDRESS LoadStart,
                          UINT Token)
{}
