/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define OPTIMIZE        /* enable Base.h optimizations, since we're the "base" */

#include <stdio.h>
#include <mmlite.h>
#include <wchar.h>

#include "_debug.c"

/* MI debug code here */

#define FMT_BUF_SIZE    128             /* Fill this much before flush  */

typedef struct _STRFMTBUF {
    STRINGER How;
    void *   Where;
    _TCHAR *     pBuf;
    _TCHAR *     pEnd;
    _TCHAR   Buffer[FMT_BUF_SIZE+1];    /* Leave room for _EOS */
} STRFMTBUF, *PSTRFMTBUF;


/*PRIVATE*/ void FillFmtBuf(PSTRFMTBUF pFmtBuf, _TCHAR Char)
{
    if (Char == _EOS) {  /* Forcing to flush the buffer */
        if (pFmtBuf->pBuf != pFmtBuf->Buffer) {
            *pFmtBuf->pBuf = _EOS;
            (*pFmtBuf->How)(pFmtBuf->Where,pFmtBuf->Buffer);
            pFmtBuf->pBuf = pFmtBuf->Buffer;
        }
        return;
    }

    if (pFmtBuf->pBuf >= pFmtBuf->pEnd) { /* Buffer full, flush */
        *pFmtBuf->pBuf = _EOS;
        (*pFmtBuf->How)(pFmtBuf->Where,pFmtBuf->Buffer);
        pFmtBuf->pBuf = pFmtBuf->Buffer;
    }

    *pFmtBuf->pBuf++ = Char;
}

/* Formats the string specified by pVal and store the result in a STRFMTBUF.
 * MinLen is mimimum field width, MaxLen is maximum string length.
 * Note that if MaxLen == -1, then string is _EOS-terminated;
 * if MaxLen >= 0, then string is _EOS or length terminated,
 * whichever comes first (need not be _EOS-terminated!).
 * String is left justified if MinLen >=0, right justified otherwise.
 * Note that it is OK to have MaxLen < MinLen.
 * The STRFMTBUF, pointed by pBuf, flushes itself when it is full.
 *
 * NextChar is the function to iterate through the source string (pVal), not
 * the destination buffer.  So the destination string must be a TCHAR array
 * but pVar can point to either single byte characters or unicode etc.
 */
PRIVATE void StrToBuf(_TCHAR * pVal, _TCHAR (* NextChar)(_TCHAR ** pp),
              PSTRFMTBUF pBuf, INT MinLen, INT MaxLen, _TCHAR Fill)
{
    _TCHAR Char;
    INT Len;

    /* Check if padding on the left is needed.
     */
    if (MinLen > 0) {
        _TCHAR * pTmp = pVal;

        for (Len = 0; MaxLen == -1 || Len < MaxLen; Len++)
            if ((Char = NextChar(&pTmp)) == _EOS)
                break;

        for (; Len < MinLen; Len++)
            FillFmtBuf(pBuf, Fill);
    }

    /* Copy the characters.
     */
    for (Len = 0; MaxLen == -1 || Len < MaxLen; Len++) {
        if ((Char = NextChar(&pVal)) == _EOS)
            break;
        FillFmtBuf(pBuf, Char);
    }

    /* Check if padding on the right is needed.
     */
    if (MinLen < 0) {
        MinLen = -MinLen;

        for (; Len < MinLen; Len++)
            FillFmtBuf(pBuf, Fill);
    }
}


/* Converts the digits of the given Val argument to a null-terminated _TCHAR
 * string and stores the result in *pBuf.  Note that pBuf points to the END
 * of the buffer on entrance.  Return the pointer to the begining of string.
 */
PRIVATE _TCHAR * UintToStr(UINT Val, UINT Base, _TCHAR * pBuf)
{
    UINT Digit;

    *pBuf = _EOS;            /* pBuf points to the end of buffer */

    do {
        /* NOTE: could calculate both at once: div(Val, Base) */
        Digit = Val % Base;
        Val = Val / Base;

        --pBuf;
        if (Digit > 9)
            *pBuf = (_TCHAR)(Digit - 10 + _TEXT('a'));
        else
            *pBuf = (_TCHAR)(Digit + _TEXT('0'));
    } while (Val > 0);

    return pBuf;
}


/* Ditto for 64bit values.
 * Converts the digits of the given Val argument to a null-terminated _TCHAR
 * string and stores the result in *pBuf.  Note that pBuf points to the END
 * of the buffer on entrance.  Return the pointer to the begining of string.
 */
PRIVATE _TCHAR * Int64ToStr(INT64 _Val, UINT Base, _TCHAR * pBuf)
{
    /* Do all the aritmetic in unsigned.
     * Possible minus sign are handled by caller
     */
    UINT Digit;
    UINT64 q, r, Val;
    Val = Int64ToUint64(_Val);

    *pBuf = _EOS;                       /* pBuf points to the end of buffer */

    do {
        q = Uint64DividedByUint32(Val,Base);
        r = Uint64TimesUint32(q,Base);
        r = Uint64Subtract(Val,r);
        Digit = Uint64ToUint32(r);        /* Val % Base; at long last */

        Val = q;                        /* Val /= Base; */
        --pBuf;

        if (Digit > 9)
            *pBuf = (_TCHAR)(Digit - 10 + _TEXT('a'));
        else
            *pBuf = (_TCHAR)(Digit + _TEXT('0'));

    } while (!Int64IsZero(Uint64ToInt64(Val)));

    return pBuf;
}

#if defined(_UNICODE)
#define NextTypedChar NextUnicodeChar
#else
#define NextTypedChar NextAsciiChar
#endif

PRIVATE _TCHAR NextAsciiChar(_TCHAR ** pp)
{
    return (_TCHAR)((char)*((*(char**)pp)++));
}

PRIVATE _TCHAR NextUnicodeChar(_TCHAR ** pp)
{
    return (_TCHAR)((wchar_t)*((*(wchar_t**)pp)++));
}

/* Size of ScratchBuf below should be at least _UINTSIZE + 1 becuase it
 * is used to format integers.  However, it also is used to format ASCII
 * strings (e.g., "%hs").  And in the future we might want to expand
 * StrFormat to do IPIDs in which case it may need to grow to 128 + 1.
 */
#define SCRBUFSIZE  FMT_BUF_SIZE+1  /* Plus room for _EOS */

/* printf like formatting. Only supports:
 *
 * %[-][0][<len>[.<len>][<T>]<X>
 *
 * <T> =    h - Short version of <X>, e.g., %hc is always single-byte char
 *          l - Long version of <X>, e.g., %ls is always wide char string
 *
 * <X> =    d - Decimal
 *          u - Unsigned decimal
 *          x - Unsigned hexdecimal
 *          s - String
 *          c - Character
 *
 * <len> = [*|digits]
 *
 * Note that the Fmt parameter is usually a simple pointer to a format
 * string of TCHARs but it can also be a pointer to a STRFORMAT_ESCAPE
 * structure which is a way to allow the format string to be the non-default
 * character type.
 */
void StrFormat(STRINGER How, void *Where, const _TCHAR *Fmt, va_list Argp)
{
    INT64 Val64;
    INT   Val, MinLen, MaxLen, Type, DefCharType = 0;
    _TCHAR *pVal, *pEnd, *Format;
    _TCHAR Char, FillChar;
    _TCHAR (* NextFormatChar)(_TCHAR ** pp);
    _TCHAR ScratchBuf[SCRBUFSIZE]; /* Includes Sign (for ints) and _EOS */
    STRFMTBUF StrFmtBuf;

    Format = (_TCHAR *) Fmt;
    pEnd = ScratchBuf + sizeof(ScratchBuf)/sizeof(_TCHAR) - 1;

#if defined(_UNICODE)
    /* NOTENOTE - To save space for debug messages, we allow the format to be
     * an ASCII string even if the code is compiled with _UNICODE flag on.
     * In that case, Fmt points to a STRFORMAT_ESCAPE structure which is
     * detected by first 16 bits being UNICODE_NOT_A_CHARACTER (0xFFFF).
     */
    if (((STRFORMAT_ESCAPE *)Format)->flag == UNICODE_NOT_A_CHARACTER) {
        DefCharType = -1;
        NextFormatChar = NextAsciiChar;
        Format = (_TCHAR *) ((STRFORMAT_ESCAPE *)Format)->ptr;
    } else {
        NextFormatChar = NextTypedChar;
    }
#else /* !_UNICODE */
    /* NOTENOTE - The opposite is true if _UNICODE is turned off.  We still
     * want a way to print unicode strings without adding the overhead to the
     * system of having all TCHARs turn into 2 bytes.
     */
    if (((STRFORMAT_ESCAPE *)Format)->flag == ASCII_NOT_A_CHARACTER) {
        DefCharType = 1;
        NextFormatChar = NextUnicodeChar;
        Format = (_TCHAR *) ((STRFORMAT_ESCAPE *)Format)->ptr;
    } else {
        NextFormatChar = NextTypedChar;
    }
#endif

    StrFmtBuf.How   = How;
    StrFmtBuf.Where = Where;
    StrFmtBuf.pBuf  = StrFmtBuf.Buffer;
    StrFmtBuf.pEnd  = StrFmtBuf.Buffer
                      + sizeof(StrFmtBuf.Buffer)/sizeof(_TCHAR) - 1;

    for (;;) {
        for (;;) {
            Char = NextFormatChar(&Format);
            if (Char == _TEXT('%')) {
                Char = NextFormatChar(&Format); /* Skip '%' */
                if (Char != _TEXT('%'))
                    break;                      /* Something interesting */
            }

            FillFmtBuf(&StrFmtBuf, Char);       /* Copy normal characters */

            if (Char == _EOS)
                return;
        }

        /* Interpret formatting info
         * [-][0][<len>[.<len>]  <len> = [*|digits]
         */
        if (Char == _TEXT('-')) {
            Char = NextFormatChar(&Format);
            Type = -1;                          /* Right padding */
        } else {
            Type = 0;                           /* Left padding */
        }

        if (Char == _TEXT('0')) {
            Char = NextFormatChar(&Format);
            FillChar = _TEXT('0');
        } else {
            FillChar = _TEXT(' ');
        }

        if (Char == _TEXT('*')) {
            MinLen = va_arg(Argp,INT);
            Char = NextFormatChar(&Format);
        } else {
            MinLen = 0;
            while (Char >= _TEXT('0') && Char <= _TEXT('9')) {
                MinLen = MinLen * 10 + (INT)(Char - _TEXT('0'));
                Char = NextFormatChar(&Format);
            }
        }

        /* Encode left/right padding in the mininum-field width specification.
         * (Left/right padding is meaningless if mininum-field width is
         * zero, because then there won't be any padding!)
         */
        if (Type != 0)
            MinLen = -MinLen;

        if (Char == _TEXT('.')) {
            Char = NextFormatChar(&Format);

            if (Char == _TEXT('*')) {
                MaxLen = va_arg(Argp,INT);
                Char = NextFormatChar(&Format);
            } else {
                MaxLen = 0;
                while (Char >= _TEXT('0') && Char <= _TEXT('9')) {
                    MaxLen = MaxLen * 10 + (INT)(Char - _TEXT('0'));
                    Char = NextFormatChar(&Format);
                }
            }
        } else {
            MaxLen = -1;/* -1 means no specific max, just stop at the null */
        }

        if (Char == _TEXT('h')) {
            Char = NextFormatChar(&Format);
            Type = -1;  /* Short form of data type */
        } else if (Char == _TEXT('l')) {
            Char = NextFormatChar(&Format);
            /* Allow %llx etc. for INT64 printing but ignore the second 'l' */
            if (Char == _TEXT('l'))
                Char = NextFormatChar(&Format);
            Type = 1;   /* Long form of data type */
        } else {
            Type = 0;   /* Default data type */
        }

        /* NOTENOTE - IDTGNU compiler generates jump table for switch
         * statement, which breaks when code run at mapped addresses.
         * Use if else instead.
         */

        if (Char == _TEXT('d')) {       /* Decimal value */
            if (Type == 1) {
                Val64 = va_arg(Argp,INT64);

                if (Int64IsNegative(Val64)) {
                    INT64 Zero64;
                    Int32ToInt64(Zero64,0);
                    Val64 = Int64Subtract(Zero64,Val64);
                    pVal = Int64ToStr(Val64, 10, pEnd);
                    *--pVal = _TEXT('-'); 
                } else {
                    pVal = Int64ToStr(Val64, 10, pEnd);
                }
            } else {
                Val = va_arg(Argp,INT);

                if (Type == -1)
                    Val = (INT)((INT16) Val);

                if (Val < 0) {
                    pVal = UintToStr((UINT)-Val, 10, pEnd);
                    *--pVal = _TEXT('-'); 
                } else {
                    pVal = UintToStr((UINT)Val, 10, pEnd);
                }
            }

            StrToBuf(pVal, NextTypedChar, &StrFmtBuf, MinLen, MaxLen, FillChar);
        } else if (Char == _TEXT('u')) {       /* Unsigned decimal value */
            if (Type == 1) {
                Val64 = va_arg(Argp,INT64);
                pVal = Int64ToStr(Val64, 10, pEnd);
            } else {
                Val = (INT) va_arg(Argp,UINT);

                if (Type == -1)
                    Val = (INT)((UINT16) Val);

                pVal = UintToStr((UINT)Val, 10, pEnd);
            }
            StrToBuf(pVal, NextTypedChar, &StrFmtBuf, MinLen,MaxLen, FillChar);
        } else if (Char == _TEXT('x') || Char == _TEXT('X') /* Unsign hex */
                   || Char == _TEXT('p'))                   /* pointer */
        {
            if (Type == 1) {
                Val64 = va_arg(Argp,INT64);
                pVal = Int64ToStr(Val64, 16, pEnd);
                if (Char == _TEXT('X'))
                    MinLen = 16;
            } else {
                Val = (INT) va_arg(Argp,UINT);

                if (Type == -1)
                    Val = (INT)((UINT16) Val);

                pVal = UintToStr((UINT)Val, 16, pEnd);

                if (Char == _TEXT('X'))
                    MinLen = 8;
            }

            StrToBuf(pVal, NextTypedChar, &StrFmtBuf, MinLen,MaxLen, FillChar);
        } else if (Char == _TEXT('c')) {
            /* NOTENOTE - there is this alignment problem for
             * mixing single-byte chars with double-byte chars.
             * We don't want to handle it at this time.
             */
            Val = va_arg(Argp,INT);

            if (Type == -1 || (Type == 0 && DefCharType == -1))
                Val &= 0xff;    /* ASCII char */

            FillFmtBuf(&StrFmtBuf, (_TCHAR)Val);
        } else if (Char == _TEXT('s')) {
            _TCHAR (* NextStringChar)(_TCHAR ** pp);

            pVal = (_TCHAR *) va_arg(Argp,_TCHAR *);

            if (pVal == NULL) { /* null string pointer */
                pVal = _TEXT("<NULL>");
                NextStringChar =  NextTypedChar;
            } else if (Type == -1 || (Type == 0 && DefCharType == -1)) {
                /* ASCII string */
                NextStringChar = NextAsciiChar;
            } else if (Type == 1 || (Type == 0 && DefCharType == 1)) {
                /* UNICODE string */
                NextStringChar = NextUnicodeChar;
            } else {
                NextStringChar = NextTypedChar;
            }
            StrToBuf(pVal, NextStringChar, &StrFmtBuf, MinLen,MaxLen,FillChar);
        } else {
            /* Syntax error occured, we might have dropped some of
             * the characters we encountered so far, but that's ok.
             */
            FillFmtBuf(&StrFmtBuf, _TEXT('%'));
            FillFmtBuf(&StrFmtBuf, Char);
            if (Char == _EOS)
                return;
        }
    }
}


/* NOTENOTE - the old contents of String are scratched over
 * in _UNICODE environment.  Currently, only StrFormat() and
 * KrnObjDebugPrint() call PrintBuf().  And neither cares about
 * keeping old contents intact because StrFormat() uses its own
 * internal buffer, and KrnObjDebugPrint() allocated the buffer
 * on the server thread stack (copied from client thread).
 *
 * Not in the RTL but needs RTLCALLTYPE because must be
 * typed as STRINGER.
 */
PRIVATE void RTLCALLTYPE PrintBuf(void* Where, _TCHAR * String)
{
#if defined(_UNICODE)
    _TCHAR *  pStr = String;
    char* pCh = (char *) String;
    while ((*pCh = (char) *pStr) != 0) {
        pCh++, pStr++;
    }
#endif
    UnusedParameter(Where);
    puts((char *) String);
}


#define BATCH_PRINTFS 0

#if BATCH_PRINTFS
#undef dprintf
INT dprintf(const char *format, ...)
#else
#undef printf
INT printf(const char *format, ...)
#endif
{
    va_list args;
    STRINGER pb;

#if defined(_UNICODE)
    STRFORMAT_ESCAPE Format;

    Format.flag = UNICODE_NOT_A_CHARACTER;
    Format.ptr  = format;
    format = (const char *) &Format;
#endif

    pb = PrintBuf;

    va_start(args,format);              /* Initialize variable arguments */
    StrFormat(pb,NULL,(_TCHAR *)format,args);
    va_end(args);                       /* Reset variable arguments      */

    return 0;
}

#if BATCH_PRINTFS

#ifdef _MSC_VER
#pragma warning(disable:4212)
#endif

#define NL 64
static struct l {
    const char *f;
    UINT args[7];
} PrintLog[NL];
static UINT LastPrint = 0;

void fflush(BOOL Forced)
{
    UINT i;
    BOOL ItWas = pTheScheduler->v->DisablePreemption(pTheScheduler,TRUE);

    if (Forced || LastPrint >= NL) {
        for (i = 0; i < LastPrint && PrintLog[i].f; i++)
            dprintf(PrintLog[i].f,
                    PrintLog[i].args[0],
                    PrintLog[i].args[1],
                    PrintLog[i].args[2],
                    PrintLog[i].args[3],
                    PrintLog[i].args[4],
                    PrintLog[i].args[5],
                    PrintLog[i].args[6]);
        LastPrint = 0;
    }

    pTheScheduler->v->EnablePreemption(pTheScheduler, ItWas);
}

int __cdecl printf(const char *format, UINT a1, UINT a2, UINT a3,
                   UINT a4, UINT a5, UINT a6, UINT a7)
{
    UINT i;

 retry:
    i = AtomicInc(&LastPrint);
    i--;

    if (i >= NL) {
        fflush( FALSE );
        goto retry;
    }
    
    PrintLog[i].f = format;
    PrintLog[i].args[0] = a1;
    PrintLog[i].args[1] = a2;
    PrintLog[i].args[2] = a3;
    PrintLog[i].args[3] = a4;
    PrintLog[i].args[4] = a5;
    PrintLog[i].args[5] = a6;
    PrintLog[i].args[6] = a7;
    return 0;
}
#else
/* void fflush(BOOL Forced) { UnusedParameter(Forced); } */
#endif


#ifndef __HAS_MACHINE_PUTCHAR
/* More Debugging I/O
 */

int putchar( int c )
{
    if (c == '\n')
        DCPutChar('\r');
    DCPutChar((UINT8) c);

    return c;
}
#endif

#ifdef _UNICODE
_TINT __cdecl putwchar(_TINT c)
{
    return (_TINT)putchar((char) c);
}
#endif

#ifndef __HAS_MACHINE_PUTS
INT puts(const char *s)
{
    if (s == NULL) return -1;

    while (*s != 0)                     /* Print on console (local) */
        putchar(*s++);

    return 0;
}
#endif

#ifndef __HAS_MACHINE_GETS
char *gets(char *buf)
{
    char *b = buf;
    int ret = 0;
    unsigned char c;

    for (;;) {
        c = dgetc(TRUE);
        if (c == '\n' || c == '\r')
            break;
        *buf++ = c;
        ret++;
    }
    *buf = 0;
    return b;
}

#endif
