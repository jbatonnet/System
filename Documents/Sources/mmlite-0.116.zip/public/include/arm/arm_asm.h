/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* Doc: register names for some compilers
 *
 * "a1", "a2", "a3", "a4"   ==> "r0", "r1", "r2", "r3"
 * "v1", "v2", "v3", "v4"   ==> "r4", "r5", "r6", "r7"
 * "v5", "v6", "sl", "fp"   ==> "r8", "r9", "r10", "r11"
 * "ip", "sp", "lr", "pc"   ==> same
 */

/* Macros for portability across assemblers
 */
#if defined(__GNUC__)

#define _ENTRY
#define _IMPORT(n)
#define _CODE(n)         .text
#define _BSS(n)          .bss
#define _DATA(n)         .data
#define _DCD             .int
#define _EQU             =
#define _SKIP            .skip
/* .align would work also methinks */
#define _ALIGN(n)        .balign n
#if 1
#define _EXPORT(n)       .global n
#define _FUNCTION(n)     n##:  .type n,function
#define _F(n)            n
#else
#define _EXPORT(n)       .global _##n
#define _FUNCTION(n)     _##n##:  .type _##n,function
#define _F(n)            _##n
#endif
#define _L(n)            n
#define _LABEL(n)        n##:
#define _END

#else
#if defined(_MSC_VER)

#define _ENTRY           
#define _IMPORT(n)       IMPORT n
#define _CODE(n)         AREA |.text|, CODE
#define _BSS(n)          AREA |.bss|, NOINIT
#define _DATA(n)         AREA |.data|, DATA
#define _DCD             DCD
#define _EQU             EQU
#define _SKIP            %
#define _ALIGN(n)        ALIGN n
#define _EXPORT(n)       EXPORT n
#define _FUNCTION(n)     n
#define _F(n)            n
#define _L(n)            n
#define _LABEL(n)        _FUNCTION(n)
#define _END             END


#else

#define _ENTRY           ENTRY
#define _IMPORT(n)       IMPORT n
#define _CODE(n)         AREA |##n##|, CODE
#define _BSS(n)          AREA |.bss##n##|, NOINIT
#define _DATA(n)         AREA |.data|, DATA
#define _DCD             DCD
#define _EQU             EQU
#define _SKIP            %
#define _ALIGN(n)        ALIGN n
#define _EXPORT(n)       EXPORT n
#define _FUNCTION(n)     ZAPTOHERE##n
#define _F(n)            n
#define _L(n)            n
#define _LABEL(n)        _FUNCTION(n)
#define _END             END

#endif
#endif
