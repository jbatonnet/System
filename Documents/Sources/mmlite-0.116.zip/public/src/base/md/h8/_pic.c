/* Copyright (c) Microsoft Corporation. All rights reserved. */
//#include "linkage.h"
#include <mmlite.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <fred.h>
#include <mmhal.h>
//#include <schedulif.h>
//#include <irq.h>

/* Vector table
 */
//typedef void *TRAP_CODE;/*fornow*/
//#define NUM_VECTORS 37
//__attribute__ ((section (".vect")))
//TRAP_CODE idt[NUM_VECTORS] = {0,};

/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
}

extern void TimerInterrupt(void);
extern void start(void);

IPic *PicCreate(void)
{
    /* Set timer isr
     */
//    idt[IRQ_ID_RESET] = start;
//    idt[IRQ_ID_SYSTEM_TIMER] = TimerInterrupt;

//    Moncall(MONCALL_SET_VECTOR_TABLE,(UINT)&idt,NUM_VECTORS);

    return NULL;
}
