/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include "x86_cpu.h"

/* Initialize the machine-dependent part of a thread object.
 * The (new) thread should be set to execute the function START
 * with argument ARG.  No scheduling side-effects.
 * If HasArg==FALSE Arg is instead the return link and there is no arg.
 */
void MachineThreadCreate(PITHREAD pThis, THREAD_FUNCTION pStart, 
                         THREAD_ARGUMENT Arg, PTR StackTop, UINT ArgCount,
                         UINT32 Flags)
{
    UINT32 *pStk = (UINT32 *)StackTop;
    UINT16 DataSegment, CodeSegment, FSeg, ESeg, GSeg;
    CXTINFO *pCxt;

    if (ArgCount == -1) {
        /* Zero the top so VS7 debugger doesn't think it's a stack frame */
        *pStk = 0;

        /* Push arguments on stack
         */
        *(--pStk) = (UINT32) Arg;

        *(--pStk) = (UINT32) ThreadExit;
    } else {
          /* Push link register. Arg is where to return. */
          *(--pStk) = (UINT32) Arg;
    }

    /* Make room for context on stack
     * Thread's initial state will point there.
     */
    /* if (UserMode) pCxt = (CXTINFO *)pStk; else */
    pCxt = (CXTINFO *)(pStk+2); /* KernelMode: The cxt is two UINT32s short */

    pCxt--;
    pTH(pThis)->CxtInfo = pCxt;

    /* Get current segments
     */
    __asm {
        mov ax,ds;
        mov DataSegment,ax;
        mov ax,cs;
        mov CodeSegment,ax;
        mov ax,es;
        mov ESeg,ax;
        mov ax,fs;
        mov FSeg,ax;
        mov ax,gs;
        mov GSeg,ax;
    }

    /* if (UserMode) CodeSegment |= 3;  //Ring 3 */

    /* Setup non-zero registers
     */
    pCxt->EIP = (UINT32) pStart;
    pCxt->EFL = X86_FLAG_IF | X86_FLAG_IOPL;

    /* Setup non-zero segments
     */
    pCxt->FS = (UINT32) FSeg;
    pCxt->GS = (UINT32) GSeg;
    pCxt->ES = (UINT32) ESeg;
    pCxt->DS = (UINT32) DataSegment;
    pCxt->CS = (UINT32) CodeSegment;

    /* Set other registers to zero in case the stack is pre-filled with junk */
    pCxt->pFpa = NULL;
    pCxt->EDI = pCxt->ESI = pCxt->EBP = pCxt->PAD = 0;
    pCxt->EBX = pCxt->EDX = pCxt->ECX = pCxt->EAX = 0;

    /* If we are returning to kernel mode (ring0) the stack actually begins
     * at pCxt->ESP.  If we are returning to user mode need to adjust. BUGBUG.
     */
    /* if (UserMode) { pCxt->ESP = (UINT32) pStk; pCxt->SS = (UINT32) DataSegment; } */
}
