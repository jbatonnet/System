/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef _OLDSCHED

#ifndef __URGENCY2_H__
#define __URGENCY2_H__

#include <mmlite.h>

/* Criticality constants defined in conf\baseif.xml */

typedef struct _URGENCY {
  TIME tRestartBy;		/* [KernelTime] */
  _CRITICALITY Criticality;
} URGENCY, *PURGENCY;

#define pU(_pu_) ((PURGENCY)(_pu_))

#define /* TIME */                                                            \
Urgency_GetRestartBy(/* PURGENCY */ _pu_)                                     \
     (pU(_pu_)->tRestartBy)

#define /* void */                                                            \
Urgency_SetRestartBy(/* PURGENCY */ _pu_,                                     \
                    /* TIME */ _tRestartBy_)                                  \
     (Urgency_GetRestartBy(_pu_) = (_tRestartBy_))

#define /* _CRITICALITY */                                                    \
Urgency_GetCriticality(/* PURGENCY */ _pu_)                                   \
     (pU(_pu_)->Criticality)

#define /* void */                                                            \
Urgency_SetCriticality(/* PURGENCY */ _pu_,                                   \
                      /* _CRITICALITY */ _nc_)                                \
     (Urgency_GetCriticality(_pu_) = (_nc_))

#define /* BOOL */                                                            \
Urgency_IsCritical(/* PURGENCY */ _pu_)                                       \
     ((Urgency_GetCriticality(_pu_) & _CRITICAL) == _CRITICAL)

#define /* void */                                                            \
Urgency_SetCritical(/* PURGENCY */ _pu_)                                      \
     (Urgency_GetCriticality(_pu_) |= _CRITICAL)

#define /* void */                                                            \
Urgency_ClearCritical(/* PURGENCY */ _pu_)                                    \
     (Urgency_GetCriticality(_pu_) &= ~_CRITICAL)

#define /* BOOL */                                                            \
Urgency_IsTimeSharing(/* PURGENCY */ _pu_)                                     \
     ((Urgency_GetCriticality(_pu_) & _TIMESHARING) == _TIMESHARING)

#define /* void */                                                            \
Urgency_SetTimeSharing(/* PURGENCY */ _pu_)                                   \
     (Urgency_GetCriticality(_pu_) |= _TIMESHARING)

#define /* void */                                                            \
Urgency_ClearTimeSharing(/* PURGENCY */ _pu_)                                 \
     (Urgency_GetCriticality(_pu_) &= ~_TIMESHARING)

#define /* void */                                                            \
Urgency_Init(/* PURGENCY */ _pu_)                                             \
     Urgency_SetRestartBy((_pu_), CurrentTime());                             \
     Urgency_SetCriticality((_pu_), _TIMESHARING)

#define /* void */                                                            \
Urgency_Copy(/* PURGENCY */ _puDest_,                                         \
            /* PURGENCY */ _puSource_)                                        \
     Urgency_SetRestartBy((_puDest_), Urgency_GetRestartBy(_puSource_));      \
     Urgency_SetCriticality((_puDest_), Urgency_GetCriticality(_puSource_))

BOOL Urgency_EQ(
     PURGENCY pu1,
     PURGENCY pu2
     );

BOOL Urgency_GT(
     PURGENCY pu1,
     PURGENCY pu2
     );

BOOL Urgency_GTEQ(
     PURGENCY pu1,
     PURGENCY pu2
     );

#endif /* __URGENCY2_H__ */

#endif /* _OLDSCHED */
