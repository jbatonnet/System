/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef _SCI_H_
#define _SCI_H_

void Sci_Init(void);
int Sci_ReadChar(void);
void Sci_WriteChar(unsigned char data);

void Sci_WriteStr(char *s);
int Sci_ReadStr(char *buff, unsigned int bufflen);

void Sci_WriteHexByte(unsigned char n);
void Sci_WriteHexShort(unsigned short n);
void Sci_WriteHexLong(unsigned long n);

void Sci_WaitEnter(void);

#endif
