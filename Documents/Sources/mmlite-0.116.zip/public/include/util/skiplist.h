/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Skiplists. When MAX_DEPTH=1 behaves as single linked list         --jvh 2006
   - head has MAX_DEPTH elements
   - node is variable size
   - each pointer points to an app struct (makes it easy to follow list in dbg)
   - the nodes are ordered from furthest to nearest
   - all but the last next pointer has the zero bit set to recognize the size
   - in the single list case no zero bits are set
   - each app struct contains a varaible size list node (could be multiple)
   - the offset to the list node is specified explicitly
   - the search state points to the list nodes of the previous nodes (or head)
   - the search state also contains a direct current pointer and depth
   - the search state must be completed before insertions and deletions
   - instead of the usual declare small and extend, we declare big and shrink
     this is so as to make the dbugger show all the links.

A visualization attempt:

head ------------------> d
     -------> b --> c ->
     -> a -->   -->

  In all of the APIs below "Descriptor" is the offset how far into the app
  structure the link node is located (in bytes) combined with the maximum
  depth.
*/

#ifndef _UTIL_SKIPLIST
#define _UTIL_SKIPLIST 1

#include <mmmacros.h>

#define SKIPLIST_MAX_DEPTH 8

typedef UINT16 SKIPLIST_DESC;

/* 10 bits for offset and 6 for depth = fits in 16b bits (arbitrary) */
#define SKIPLIST_DESCRIPTOR(ContainingStruct, Field, MaxDepth) \
  (offsetof(ContainingStruct, Field) | (MaxDepth << 8))

#define SKIPLIST_OFFSET(_d_) ((_d_) & 0xff)
#define SKIPLIST_MAX(_d_) (((_d_) >> 8) & 0xff)

//typedef PTR (*SKIPLIST_NODE_SMALL)[1];

typedef struct _SKIPLIST_NODE {
    PTR Next[SKIPLIST_MAX_DEPTH];
} SKIPLIST_NODE;

/* The name is here just for the benefit of compiler errors */
#define SkipListNodeDeclare(ContainingStruct, Field, Max) \
struct __ ## ContainingStruct ## _ ## Field ## _ ## Max { \
    struct ContainingStruct *Next[Max]; \
} Field

typedef struct _SKIPLIST_SEARCH_STATE {
    PTR Current;
    UINT Depth;
    SkipListNodeDeclare(_SKIPLIST_NODE, Prev, SKIPLIST_MAX_DEPTH);
} SKIPLIST_SEARCH_STATE;

#define SkipListNodeGetLink(Desc, pItem) \
    ((SKIPLIST_NODE*) (((char *) pItem) + SKIPLIST_OFFSET(Desc)))

void SkipListNodeInit(PTR node, UINT NodeDepth);

#define SKIPLIST_FLAGS_MORE 1
#define SKIPLIST_PTR(_l_) ((PTR)((ADDRESS)(_l_) & ~SKIPLIST_FLAGS_MORE))
#define SKIPLIST_MORE(_p_) ((PTR)((ADDRESS)(_p_) | SKIPLIST_FLAGS_MORE))
#define SKIPLIST_COPY_MORE_FLAG(_next_,_p_) \
    ((PTR)((ADDRESS)(_p_) | ((ADDRESS)(_next_) & SKIPLIST_FLAGS_MORE)))

/* returns item matched (SEARCH,REMOVE), NULL otherwise */
PTR SkipListSearch(SKIPLIST_DESC Desc, SKIPLIST_SEARCH_STATE *ss,
             INT (*Transform)(PTR pItem, PTR pArg), PTR pArg);

#endif /*_UTIL_SKIPLIST*/
