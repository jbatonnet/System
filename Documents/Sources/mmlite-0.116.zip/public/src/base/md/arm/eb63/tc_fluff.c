/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Experimenting with the timer/counter chip on this part.
 */
    /* Need all 3 clocks */
    ThePmc->PerClockEnable = ThePmc->PerClockStatus|PMCPC_TC0|PMCPC_TC1|
        PMCPC_TC2|PMCPC_PIOB|PMCPC_PIOA;

#if 0
    /* Find the ratio between MCLKI and an external clock reference
     */

    /* Enable the 25/16MHz external signal on pin PB20/TIOA0 as XC1 */
    PioB->Disable = PIOB_TIOA0;
    PioB->OutDisable = PIOB_TIOA0;
    PioB->FilterDisable = PIOB_TIOA0;

    T0->Mode = TCHM_MCKI_2 | TCHM_LDBSTOP | /*? TCHM_LDBDIS | */
        TCHM_AA_FALL | TCHM_AB_FALL;
    T0->IntrDisable = ~0;
    T0->Counter = 0;
    T0->A =
    T0->B = 
    T0->C = 0;
    T0->Control = TCHC_ENABLE;
    s = T0->Status;

    /* This one doesnt work and methinks it should */
    Tc0->BlockMode = TCBM_1_TIOA0; /* xc1 is TIOA0 */

    T1->Mode = TCHM_WAVE | TCHM_XC1;
    T1->IntrDisable = ~0;
    T1->Counter = 0;
    T1->A =
    T1->B =
    T1->C = 0;
    T1->Control = TCHC_ENABLE;
    s = T1->Status;

{
    int i, j;
#define NP 16
    for (j = 0; j < NP; j++) {
        /* Start all counters */
        Tc0->BlockControl = TCBC_SYNCRHO;
        Delay(5);

        for (i = 0; i < 0x10000; i++) {
            s = T0->Status;/*  a destructive read */
            if (s & TCHI_B_LOAD) break;
        }
        printf("%s %d %d [%d %x %x]\n", (s & TCHI_B_LOAD) ? "YES!" : "nope",
               T0->A, T0->B, T0->Counter, s, i);
    }
}
#endif

#if 0
    /* Works, watch PB20 via Timer 0 in capture mode
     */
    T0->Mode = TCHM_MCKI_2;
    T0->IntrDisable = ~0;
    T0->Counter = 0;
    T0->A =
    T0->B = 0;
    T0->C = 0x8000;
    T0->Control = TCHC_ENABLE;

    /* Enable the 25/16MHz external signal on pin PB20/TIOA0 as XC1 */
    PioB->Disable = PIOB_TIOA0;
    PioB->OutDisable = PIOB_TIOA0;
    PioB->FilterDisable = PIOB_TIOA0;

    /* Start all counters */
    Tc0->BlockControl = TCBC_SYNCRHO;

{
#if 0
/* Despite the doc, this doesnt work */
#define w PioB->DataStatus
#define bibi PIOB_TIOA0
#else
/* This one does */
#define w T0->Status
#define bibi TCHS_TIOA
#endif

#if 1
#define NP 16
    UINT16 cnts[16], *pcnt = cnts;
    int i, j;
    UINT status;

    s = w & bibi;
    for (i = 0; i < NP; i++) {
        for (j = 0; j < 0x10000; j++)
            if ((w & bibi) != s) break;
        s = w & bibi;
        if (j < 0x10000)
            *pcnt++ = T2->Counter;
        else
            *pcnt++ = 0;
    }
    printf("cnts:");
    for (i = 0; i < NP; i++)
        printf(" %x", cnts[i]);
    
    printf("\ndeltas:");
    for (i = 1; i < NP; i++)
        printf(" %d", cnts[i]-cnts[i-1]);
    printf("\n");
#else
    for (;;) {
        printf("%x\n", w & bibi);
    }
#endif
}

#endif


#if 0
    /* WORKS.  Cascade timer 0 to 1, 2 irrelevant
     */
    T0->Mode = TCHM_WAVE | TCHM_MCKI_2 | TCHM_CA_TOGGLE | TCHM_TRG_RC;
    T0->IntrDisable = ~0;
    T0->Counter = 0;
    T0->A =
    T0->B = 0;
    T0->C = 0x80;
    T0->Control = TCHC_ENABLE;

    /* Enable the 25/16MHz external signal on pin PB20/TIOA0 as XC1 */
    PioB->Enable = PIOB_TIOA0;
    PioB->OutDisable = PIOB_TIOA0;
    PioB->FilterDisable = PIOB_TIOA0;

    Tc0->BlockMode = TCBM_1_TIOA0; /* xc1 is TIOA0 */

    T1->Mode = TCHM_WAVE | TCHM_XC1;
    T1->IntrDisable = ~0;
    T1->Counter = 0;
    T1->A =
    T1->B =
    T1->C = 0;
    T1->Control = TCHC_ENABLE;

    /* Start all counters */
    Tc0->BlockControl = TCBC_SYNCRHO;

#endif

#if 0
    /* WORKS.  Cascade 1 to 2, disable 0
     */
    T0->Mode = TCHC_DISABLE;

    Tc0->BlockMode = TCBM_2_TIOA1; /* xc2 is TIOA1 */

    T1->Mode = TCHM_WAVE | TCHM_MCKI_2 | TCHM_CA_TOGGLE | TCHM_TRG_RC;
    T1->IntrDisable = ~0;
    T1->Counter = 0;
    T1->A =
    T1->B = 0;
    T1->C = 0x8000;
    T1->Control = TCHC_ENABLE;


    /* Tmclki */
    T2->Mode = TCHM_WAVE | TCHM_XC2;
    T2->IntrDisable = ~0;
    T2->Counter = 0;
    T2->A =
    T2->B =
    T2->C = 0;
    T2->Control = TCHC_ENABLE;

    /* Start all counters */
    Tc0->BlockControl = TCBC_SYNCRHO;


#endif

