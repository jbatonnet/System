/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>

const struct PRECOB ThePreCobTable[] = {
    HYPERBIG_COBS
    {0, 0}
};
