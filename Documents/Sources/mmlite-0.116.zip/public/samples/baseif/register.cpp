/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* BEGIN_SAMPLE */
UINT TestRefs = 0;

/* MyObject implements only IUnknown. */
struct MyObject: IUnknown {
    SCODE MCT QueryInterface(REFIID riid, void **ppvObject);
    UINT MCT AddRef(void);
    UINT MCT Release(void);
};

SCODE MCT MyObject::QueryInterface(REFIID riid, void **ppvObject)
{
    if (UuidCmp(IID_IUnknown, riid)) {
        this->AddRef();
        *ppvObject = this;
        return S_OK;
    } else {
        *ppvObject = NULL;
        return E_NO_INTERFACE;
    }
}

UINT MCT MyObject::AddRef(void)
{
    UINT Refs = AtomicInc(&TestRefs);
    _tprintf(_TEXT("refs=%d (after inc in AddRef)\n"), Refs);
    return Refs;
}

UINT MCT MyObject::Release(void)
{
    UINT Refs = AtomicDec(&TestRefs);
    _tprintf(_TEXT("refs=%d (after dec in Release)\n"), Refs);
    return Refs;
}

int _tmain()
{
    PIUNKNOWN pObject;

    /* Pointer and reference to the current namespace */
    INameSpace *pNS = CurrentNameSpace();

    /* Initialize an unknown object as MyObject */
    IUnknown *pUnknwn = new MyObject; 

    SCODE StatusCode;
    _TCHAR *pName = _TEXT("MyObject");
    StatusCode = pNS->Register(pName, pUnknwn, 0, NULL);
    if(FAILED(StatusCode)) {
        _tprintf(_TEXT("Registering %s failed with error code %08x.\n"),
                      pName, StatusCode);
        exit(0);
    }
    _tprintf(_TEXT("Registering %s succeeded.\n"), pName);
 
    /* Verify that MyObject is registered in system namespace. */
    StatusCode = pNS->Bind(pName, 0, &pObject);
    if (StatusCode != S_OK) {
        _tprintf(_TEXT("Error in registering object name!\n"));
        exit(0);
    }
    _tprintf(_TEXT("Succeeded in registering object name.\n"));

    /* Other threads use the object. */
    /* ... */
    return 0;
}
/* END_SAMPLE */

void * __cdecl operator new(size_t size)
{
    PTR p = malloc(size);
    if (p)
        memset(p, 0, size);
    return p;
}

void __cdecl operator delete(void *p)
{
    free(p);
}
