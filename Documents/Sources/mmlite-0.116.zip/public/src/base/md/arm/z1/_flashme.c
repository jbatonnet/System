/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Test program for the Atmel AT49BV1604(T) FLASH memory device
 * [as used in the EB63 dev board for the AT91M63200 ARM chip]
 * Extended for use with Atmel AT49BV/LV8011(T)
 */
#include <mmlite.h>
#include <stdio.h>
#include <tchar.h>

#define paranoia 0

/* Product ID codes
 */
#define MANUF_ATMEL  0x1f
#define DEVICE_16x4  0xc0
#define DEVICE_16x4T 0xc2
#define DEVICE_8011  0xcb
#define DEVICE_8011T 0x4a

/* Sector size maps
 * WARNING: If the USER-BOOT strap is used these maps are wrong !!
 */
#define nDELTAS 6
typedef const struct _SMAP {
    struct {
        UINT8 nSectors;
        UINT8 nKB;
    } Deltas[nDELTAS];
    UINT8 DeviceCode;
    UINT8 TotalSectors;
    _TCHAR *Warning;
    _TCHAR *DeviceName;
} SMAP, *PSMAP;

#define nMAPS 4
const struct _SMAP SectorMaps[nMAPS] = {

#if 0
    /* If the FLASH is mapped normally [E7=="STD"]
     */
    {
     {{8,8},{2,32},{30,64},{0,0},{0,0},{0,0}},
     DEVICE_16x4, 40,
     _TEXT("Strap E7 is in the STD position"),
     _TEXT("AT49BV1604/1614")
    },
    {
     {{30,64},{2,32},{8,8},{0,0},{0,0},{0,0}},
     DEVICE_16x4T, 40,
     _TEXT("Strap E7 is in the STD position"),
     _TEXT("AT49BV1604T/1614T")
    },
#else
    /* With the funny toggle to the A20 line [E7=="USER"]
     */
    {
     {{16,64},{8,8},{2,32},{14,64},{0,0},{0,0}},
     DEVICE_16x4, 40,
     _TEXT("Strap E7 in the USER position"),
     _TEXT("AT49BV1604/1614")
    },
    {
     {{14,64},{2,32},{8,8},{16,64},{0,0},{0,0}},
     DEVICE_16x4T, 40,
     _TEXT("Strap E7 in the USER position"),
     _TEXT("AT49BV1604T/1614T")
    },
#endif
    /* This one is on-chip and we dont play any tricks
     */
    {
     {{1,16},{1,32},{4,8},{1,32},{1,16},{14,64}},
     DEVICE_8011, 22,
     _TEXT("everything ok"),
     _TEXT("AT49BV/LV8011")
    },
    {
     {{14,64},{1,16},{1,32},{4,8},{1,32},{1,16}},
     DEVICE_8011T, 22,
     _TEXT("everything ok"),
     _TEXT("AT49BV/LV8011T")
    },
};

/* Returns the size in KBytes of a given sector,
 * or -1 for bad arguments.
 */
int KBinSector(PSMAP SecMap, UINT SecNo)
{
    int i, s = SecNo;

    for (i = 0; i < nDELTAS; i++) {
        if (SecNo < SecMap->Deltas[i].nSectors)
            return SecMap->Deltas[i].nKB;
        SecNo -= SecMap->Deltas[i].nSectors;
    }

#if paranoia
    _tprintf(_TEXT("KS: Bad SecNo x%x\r\n"), s);
#endif
    s = 0;
    return -1;
}

#define SectorSize(_map_,_sector_) (1024 * KBinSector(_map_,_sector_))

/* Whats the starting offset of sector N
 */
ADDRESS SectorStart(PSMAP SecMap, int SecNo)
{
    int i, s = SecNo;
    ADDRESS Offset = 0;

    for (i = 0; i < nDELTAS; i++) {
        if (SecNo < SecMap->Deltas[i].nSectors)
            return 1024 * (Offset + (SecMap->Deltas[i].nKB * SecNo));
        SecNo -= SecMap->Deltas[i].nSectors;
        Offset += SecMap->Deltas[i].nSectors * SecMap->Deltas[i].nKB;
    }

#if paranoia
    _tprintf(_TEXT("SS: Bad SecNo x%x\r\n"), s);
#endif
    s = 0;
    return ~0;
}

/* Whats the ending offset (exclusive) of sector N
 */
ADDRESS SectorEnd(PSMAP SecMap, int SecNo)
{
    ADDRESS Offset = SectorStart(SecMap,SecNo);
    if (Offset != ~0)
        return Offset + (1024 * KBinSector(SecMap,SecNo));
#if paranoia
    _tprintf(_TEXT("SE: Bad SecNo x%x\r\n"), SecNo);
#endif
    return ~0;
}

/* What sector number corresponds to a given offset
 */
UINT SectorNumber(PSMAP SecMap, ADDRESS Offset)
{
    UINT i;
    UINT SecNo = 0;
    ADDRESS s = Offset;

    Offset /= 1024;
    for (i = 0; i < nDELTAS; i++) {
        if (Offset < (UINT)
            ((SecMap->Deltas[i].nSectors * SecMap->Deltas[i].nKB)))
            return SecNo + (Offset / SecMap->Deltas[i].nKB);
        SecNo += SecMap->Deltas[i].nSectors;
        Offset -= SecMap->Deltas[i].nSectors * SecMap->Deltas[i].nKB;
    }

#if paranoia
    _tprintf(_TEXT("SN: Bad Offset x%x\r\n"), s);
#endif
    s = 0;
    return ~0;
}

void SaySectors(PSMAP Map)
{
#if paranoia
    UINT SecNo;
    ADDRESS Offset;

    _tprintf(_TEXT("SectorMap for DeviceCode x%x\r\n"), Map->DeviceCode);
    for (SecNo = 0; SecNo <= Map->TotalSectors; SecNo++) {
        _tprintf(_TEXT("SecNo %2d: %2d KB at x%06x..x%06x\r\n"), SecNo,
                 KBinSector(Map,SecNo), 
                 SectorStart(Map,SecNo), 
                 SectorEnd(Map,SecNo)
                 );
    }

    _tprintf(_TEXT("Reverse SectorMap for DeviceCode x%x\r\n"), Map->DeviceCode);
    Offset = 0;
    SecNo = ~0;
    do {
        UINT Sec;
        Sec = SectorNumber(Map,Offset);
        if (Sec != SecNo) {
            SecNo = Sec;
            _tprintf(_TEXT("Offset x%x => Sector %d\r\n"), Offset, SecNo);
        }
        Offset += 1024;
    } while (SecNo != ~0);
#endif
}

/* Use 8/32bit accesses. If not StrongARM, the ARM processor doesnt have the
 * 16bit load/store operations. Which means a 16bit store gets compiled
 * into two 8bit stores. A 16bit load becomes a 32bit load, meaning
 * two 16bit loads if the bus is a 16bit bus.
 * This can make for very confusing results and/or strange code.
 *
 * Also, to make things even more confusing. The EB63 board uses the part
 * in 16bit mode. Addresses are shifted down one line, the processor's
 * A0 line (pA0) is not connected, pA1 goes to A0, pA2 to A1...pA20->A19.
 * The data bus is mapped normally, pD0->D0..pD15->D15.
 *
 * Keeping this all in mind.. it can be done. Sigh.
 */
typedef volatile UINT8 *WRITE_POINTER;

#if defined(arm) && defined(__GNUC__)
#define WriteREALLYIt(_where_,_what_) \
  __asm__ volatile ("strh %1,[%0]" :: "r" (_where_), "r" (_what_) )
#else
#define WriteREALLYIt(_where_,_what_) *(_where_) = _what_
#endif

/* Enter the Product ID mode for the Atmel part
 */
void ProductIdEnter(WRITE_POINTER pBase)
{
    pBase[0x5555*2] = 0xaa;
    pBase[0x2aaa*2] = 0x55;
    pBase[0x5555*2] = 0x90;
}

/* Exit the Product ID mode for the Atmel part
 */
void ProductIdExit(WRITE_POINTER pBase)
{
    pBase[0x5555*2] = 0xf0;
}

void WordProgram(WRITE_POINTER pBase, BOOL Verbose,
                 ADDRESS Offset, UINT16 Value)
{
    volatile UINT32 *pBase32 = (volatile UINT32 *)pBase;
    UINT8 Data, Data1;
    UINT16 i, Data16;

    Data16 = pBase[Offset] | (pBase[Offset+1] << 8);
    if (Verbose) {
        _tprintf(_TEXT("Location x%x was x%x\r\n"), 
                 (ADDRESS) &pBase[Offset], Data16);
    }

    if (Data16 != 0xffff)
        _tprintf(_TEXT("Offset %x not ERASED, wont take.\r\n"),Offset);

    pBase[0x5555*2] = 0xaa;
    pBase[0x2aaa*2] = 0x55;
    pBase[0x5555*2] = 0xa0;
#if 0
    /* Now for the tricky part..
     * This generates two write transactions, regardless.
     * Make sure we know whats in the second transaction.
     * Which will be ignored, since we dont have VPP connected.
     * Yes, sleazy.
     */
    pBase32[Offset/4] = Value | (Value << 16);
#else
    pBase32 = NULL;
    WriteREALLYIt((UINT16*)(pBase+Offset),Value);
#endif

    /* Wait until the operation is completed
     * It should take about 20/50 usecs.
     */
    Delay(50);

    Data = 0;
    Data1 = ~Data;
    for (i = 0; Data != Data1; i++) {
        Data  = pBase[Offset];
        Data1 = pBase[Offset];
        if (i == 0xffff) break;
    }

    Data16 = pBase[Offset] | (pBase[Offset+1] << 8);
    if (Verbose) {
        _tprintf(_TEXT("Location x%x is now x%x\r\n"), 
                 (ADDRESS) &pBase[Offset], Data16);
    }
             
    if (Data16 != Value)
        _tprintf(_TEXT("That didnt work, try again.. [%x != %x]\r\n"), 
                 Data16, Value);
}

/* Erase one sector of the Atmel part
 */
void SectorErase(PSMAP Map, WRITE_POINTER pBase, int SecNo)
{
    ADDRESS Offset;
    UINT8 Data, Data1;
    UINT16 i;
    TIME t;

    Offset = SectorStart(Map,SecNo);

    _tprintf(_TEXT("Erasing sector %d [offset x%x] ..."), SecNo, Offset);

    pBase[0x5555*2] = 0xaa;
    pBase[0x2aaa*2] = 0x55;
    pBase[0x5555*2] = 0x80;
    pBase[0x5555*2] = 0xaa;
    pBase[0x2aaa*2] = 0x55;
    pBase[Offset] = 0x30;

    /* Sleep for at least 200 msec
     */
    Int32ToInt64(t,TIME_RELATIVE(TIME_MILLIS(200)));
    SleepUntil(t);

    /* Wait until the erase is actually completed
     */
    Data = 0;
    Data1 = ~Data;
    for (i = 0; Data != Data1; i++) {
        Data  = pBase[Offset];
        Data1 = pBase[Offset];
        if (i == 0xffff) break;
    }

    if (Data == Data1)
        _tprintf(_TEXT("done.\r\n"));
    else
        _tprintf(_TEXT(" NOT completed [%x != %x]\r\n"), Data, Data1);
}

/* Apply the write-lock to a sector (dont!)
 */
void SectorLock(PSMAP Map, WRITE_POINTER pBase, int SecNo)
{
    ADDRESS Offset;
    UINT8 Data, Data1;
    UINT16 i;

    Offset = SectorStart(Map,SecNo);

    _tprintf(_TEXT("Locking sector %d [offset x%x] ..."), SecNo, Offset);

    pBase[0x5555*2] = 0xaa;
    pBase[0x2aaa*2] = 0x55;
    pBase[0x5555*2] = 0x80;
    pBase[0x5555*2] = 0xaa;
    pBase[0x2aaa*2] = 0x55;
    pBase[Offset] = 0x40;

    /* Wait until the lock is complete.
     * Dont know how long this will take, assume some 20/50usec ?
     */
    Data = 0;
    Data1 = ~Data;
    for (i = 0; Data != Data1; i++) {
        Data  = pBase[Offset];
        Data1 = pBase[Offset];
        if (i == 0xffff) break;
    }

    if (Data == Data1)
        _tprintf(_TEXT("done.\r\n"));
    else
        _tprintf(_TEXT(" NOT completed [%x != %x]\r\n"), Data, Data1);
}



/* Use the last sector for our testing
 */
void WriteTest(PSMAP Map, ADDRESS FlashBase)
{
    WRITE_POINTER pBase = (WRITE_POINTER) FlashBase;
    int i;
#define test_offset (0x200000-0x10+4)
    _tprintf(_TEXT("Write-testing at offset x%x\r\n"), test_offset);
    WordProgram(pBase,TRUE,test_offset,0x1155);
    /* Dump some around it */
    for (i = test_offset-4; i < test_offset+4; i++)
        _tprintf(_TEXT(" %2x"), pBase[i]);
    _tprintf(_TEXT("\r\n"));
}

BOOL EraseTest(PSMAP Map, ADDRESS FlashBase)
{
    WRITE_POINTER pBase = (WRITE_POINTER) FlashBase;
    ADDRESS Offset;
    BOOL Ok;
    int i, n, SecNo;

    /* Use the same last sector
     */
    SecNo = SectorNumber(Map,test_offset);

    SectorErase(Map,pBase,SecNo);

    /* Verify it reads as all 0xffs
     */
    Offset = SectorStart(Map,39);
    n = SectorSize(Map,39);

    Ok = TRUE;
    for (i = 0; i < n; i++)
        if (pBase[Offset+i] != 0xff) {
            _tprintf(_TEXT("@%x: %x not erased\r\n"),
                     (ADDRESS) &pBase[Offset+i], pBase[Offset+i]);
            Ok = FALSE;
        }

    if (Ok) {
        WriteTest(Map,FlashBase);
    } else {
        _tprintf(_TEXT("This didnt work, stopping here.\r\n"));
        return FALSE;
    }

    return TRUE;
}

/* Identify the sector map for a given chip.
 * Argument is the base address of the device
 * [or suitably aligned alias thereof].
 * Returns NULL if failed
 */
PSMAP FlashIdentify(ADDRESS FlashBase)
{
    WRITE_POINTER pBase = (WRITE_POINTER) FlashBase;
    UINT8 Mid, Did;
    int i;

    ProductIdEnter(pBase);
    Mid = pBase[0*2];
    Did = pBase[1*2];
    ProductIdExit(pBase);

    _tprintf(_TEXT("ManufacturerId: x%x  DeviceId: x%x\r\n"), Mid, Did);

    for (i = 0; i < nMAPS; i++)
        if (SectorMaps[i].DeviceCode == Did)
            return SectorMaps+i;
    return NULL;
}

/* Lock sector 0 of the FLASH.
 */
void LockSectorZero(PSMAP Map, ADDRESS FlashBase)
{
    WRITE_POINTER pBase = (WRITE_POINTER) FlashBase;

    SectorLock(Map,pBase,0);
}

/* Print the list of locked sectors (if any)
 */
void PrintLockedSectors(PSMAP Map, ADDRESS FlashBase)
{
    WRITE_POINTER pBase = (WRITE_POINTER) FlashBase;
    UINT SecNo;
    ADDRESS Offset;
    UINT8 Data, Data1;
    UINT8 Mid, Did;
    BOOL SomeLocked = FALSE;

    for (SecNo = 0; ; SecNo++) {
        Offset = SectorStart(Map,SecNo);
        if (Offset == ~0)
            break;

        ProductIdEnter(pBase);
        /* Lockout info is at address 2 of the given sector, meaning A0=0 A1=1.
         */
        Data = pBase[Offset+(0x0002*2)];
        Data1 = pBase[Offset+(0x0003*2)];

        Mid = pBase[0*2];
        Did = pBase[1*2];
        ProductIdExit(pBase);

        if (Data & 1) {
            _tprintf(_TEXT("SecNo x%d at Offset x%x is locked.\r\n"),
                     SecNo, Offset);
            SomeLocked = TRUE;
        } else {
#if paranoia
            _tprintf(_TEXT("%d@%x: %x %x [%x %x]\r\n"), 
                     SecNo, Offset, Data1, Data, Mid, Did);
#endif
        }
    }
    if (!SomeLocked)
        _tprintf(_TEXT("None of the sectors are locked.\r\n"));
}

/* Put a file in the second part of the FLASH
 * This is used for testing BOOT code on the EB63 board.
 */
void JustDoIt(PSMAP Map, ADDRESS FlashBase, ADDRESS Offset, PUINT16 Src, INT nBytes)
{
    WRITE_POINTER pBase = (WRITE_POINTER) FlashBase;
    size_t n, i;
    UINT CurSector;

    _tprintf(_TEXT("FLASHing %d bytes from %x to %x+%x.\r\n"),
             nBytes,(ADDRESS)Src,FlashBase,Offset);

    /* Print the warning, we got burned by this.
     */
    _tprintf(_TEXT("Is %s ? "),Map->Warning);
#if 0
    i = getchar();
    _tprintf(_TEXT("\r\n"));
    if ((i != _T('y')) && (i != _T('Y'))) {
        _tprintf(_TEXT("No harm done.\r\n"));
        return;
    }
#endif

    CurSector = ~0;
    for (;nBytes > 0;) {
        n = 1024;
        nBytes -= n;

        i = SectorNumber(Map,Offset);
        if (i != CurSector) {
            CurSector = i;
            SectorErase(Map,pBase,CurSector);
        }

        _tprintf(_TEXT("#"));
        for (i = 0; i < n/2; i++) {
            WordProgram(pBase,FALSE,Offset,*Src);
            Offset += 2;
            Src++;
        }
    }
    _tprintf(_TEXT(" done.\r\n"));

}

int FlashMe(ADDRESS Flash, ADDRESS SrcAddress, UINT nBytes)
{
    PSMAP Map;
    ADDRESS Offset;

    Offset = 0;

    _tprintf(_TEXT("Checking FLASH @%x\r\n"), Flash);
    Map = FlashIdentify(Flash);

    if (Map) {
        _tprintf(_TEXT("Flash was recognized, type %s\r\n"), Map->DeviceName);
        SaySectors(Map);
        /*LockSectorZero(Map,Flash);*/
        PrintLockedSectors(Map,Flash);
#if 0
        EraseTest(Map,Flash);
#endif
        JustDoIt(Map,Flash,Offset,(PUINT16)SrcAddress,nBytes);
    } else
        _tprintf(_TEXT("Test FAILED\r\n"));

    return 0;
}

