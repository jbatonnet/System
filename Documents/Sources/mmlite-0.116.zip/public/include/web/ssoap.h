/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef __SSOAP__
#define __SSOAP__

/************************
 * AES stuff
 ***********************/
#define INIT_SKEY            InitAESSessionKey
#define SKEY_STRENGTH   128
#define CHUNKSIZE       16
//(SKEY_STRENGTH/8)

#define SKEY ((UINT32)'S'+((UINT32)'K'<<8)+((UINT32)'E'<<16)+((UINT32)'K'<<24))

typedef struct {
    UINT magic;
    BYTE Key[SKEY_STRENGTH/8]; //128-bit aes key
    UINT KeyStrength;
    //TIME TimeStamp; //Not used yet. Just for future.
} SESSIONKEY, *PSESSIONKEY;

/* XXX shouldn't initialize a array here */
static const BYTE InitAESSessionKey[CHUNKSIZE] = {
    0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7,
};


/****************************
 * RSA stuff
 ******************************/
#include <crypto.h>
#include <util/list-double2.h>
#include <wsif.h>
#include <sampleif.h>

#define RSAKEYSTRENGTH      1024
#define RSAKEYSIZE_1024     0x88   /* 136, 1024 bits + 8-byte zero pading */

#define RSA1 ((UINT32)'R'+((UINT32)'S'<<8)+((UINT32)'A'<<16)+((UINT32)'1'<<24))
#define RSA2 ((UINT32)'R'+((UINT32)'S'<<8)+((UINT32)'A'<<16)+((UINT32)'2'<<24))

/* CERTIZE is the size of the signed certificate, which is 2 times 1024/8 bytes
 * The size of CERTIFICATE is (CERTSIZE - 4) bytes.
 */
#define CERTSIZE            256    /* in bytes. 2 times 1024/8 */
#define KEY_HEADER_SIZE     20    /* in bytes. 2 times 1024/8 */

typedef void *PBSAFE_KEY;

typedef struct {
    CERTIFICATE     Cert;
    BYTE            SignedCert[CERTSIZE];
    UINT            PriKeySize;
    PBSAFE_KEY      PriKey;
    UINT            PubKeySize;
    PBSAFE_KEY      PubKey;
    PBSAFE_KEY      OwnerPubKey; /* If NULL, no owner yet. With the same size of PubKey */
} SELFINFO, *PSELFINFO;

extern BOOL GenRsaKeyPair (PBSAFE_KEY *prv, PBSAFE_KEY *pub, int length);
extern PICYPHER GetCypher(_TCHAR *CobName, UINT KeyStrength);
SCODE MCT AESBuffer(UINT  Strength, const BYTE *Key,
                    PIBUFFER File, CYPHER_OPS Operation);
#endif
