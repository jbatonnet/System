/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef _BASE_COBDESC_H_
#define _BASE_COBDESC_H_ 1

#include <mmlite.h>

/* When sign bit is set, this object should not be freed */
#define REFCNT_STATIC (1<<(_UINTSIZE-1))
/* The next bit is used in tokenizer etc to indicate validity */
#define REFCNT_FLAG1 (1<<(_UINTSIZE-2))
/* And another bit for various random use */
#define REFCNT_FLAG2 (1<<(_UINTSIZE-3))
/* And one for future use */
#define REFCNT_FLAG3 (1<<(_UINTSIZE-4))

#define REFCNT_FLAGS_MASK (REFCNT_STATIC|REFCNT_FLAG1|REFCNT_FLAG2|REFCNT_FLAG3)

typedef SCODE Destroy_METHOD_FUNC(PIUNKNOWN pUnk);
typedef SCODE (*Destroy_METHOD_TYPE)(PIUNKNOWN pUnk);

struct _ClassDesc {
    const _TCHAR *ClassName;
    const struct IID *ClassId;
    const _TCHAR *SuperClass;
    const struct IID *SuperId;
    Destroy_METHOD_TYPE Destroy; /* destructor */
    UINT Size;                   /* size of total struct in bytes */
    UINT Count;
    struct {
        struct IUnknownVtbl *v;
        const UINT8 *FrameSizes; /* sizeis(MethodCount) */
        const struct IID *Iid;
        UINT MethodCount;
        UINT Offset;
    } iface[1];
    /* Variable size */
};

#define CLASSDESC(_name_,_count_) \
struct _name_ ## _ClassDesc { \
    const _TCHAR *ClassName; \
    const struct IID *ClassId; \
    const _TCHAR *SuperClass; \
    const struct IID *SuperId; \
    Destroy_METHOD_TYPE Destroy; /* destructor */ \
    UINT Size;                   /* size of total struct in bytes */ \
    UINT Count; \
    struct { \
        struct IUnknownVtbl *v; \
        const UINT8 *FrameSizes; \
        const struct IID *Iid; \
        UINT MethodCount; \
        UINT Offset; \
    } iface[(_count_)]; \
} _name_ ## _ClassDesc

struct _CobDesc {
    const _TCHAR *Name;
    UINT Count;
    struct _ClassDesc *Classes[10];
    /* Variable size */    
};

#define COBDESC(_name_,_count_) \
struct _name_ ## _CobDesc { \
    const _TCHAR *Name; \
    UINT Count; \
    struct _ClassDesc *Classes[(_count_)]; \
} _name_ ## _CobDesc

struct CUnknownVtbl {
    const struct _ClassDesc *classd;
    struct IUnknownVtbl v;
};

struct CUnknown {
    const struct IUnknownVtbl *v;
    UINT RefCnt;
};

struct _DefCob {
    struct CUnknown super;
    struct _CobDesc *cobd;
};

#endif /*_BASE_COBDESC_H_*/

