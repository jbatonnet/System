/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains sample implementations of /dev/zero and /dev/null.
 * The constructors are CreateZeroFile() and CreateNullFile() respectively.
 *
 * When written, both drop data on the floor.
 * When read, zero returns zeroed data, where null returns end-of-file.
 *
 * This file also demonstrates how two different implementations can share
 * code when the implementations are similar enough, in particular the layout
 * of an instance must be the same. But that is internal to this file.
 * What we see here is essentially a simple inheritance scheme,
 * where NullFile inherits from ZeroFile but overrides the ReadAt method.
 */
#include <mmlite.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* Make sure PRIVATE is static so we avoid conflicting symbols */
#undef PRIVATE
#define PRIVATE static

/* Component internal declarations */
#include "cobsamp.h"

PRIVATE struct IFileVtbl ZeroFileVtbl;
PRIVATE struct IFileVtbl NullFileVtbl;

/* Instance layout */
typedef struct _ZEROFILE {
    /* Common part */
    struct IFileVtbl *v;
    UINT RefCnt;

    /* Implementation specific part */
    UINT64 Size;
    UINT Access;
} *PZEROFILE;

/* Convert between interface and instance pointer and vice versa */
#define pZF(_i_) ((PZEROFILE)(_i_))
#define iZF(_p_) ((PIFILE)(_p_))

/* Internal constructor */
PRIVATE PZEROFILE ZFNew(void)
{
    PZEROFILE x;

    x = (PZEROFILE) CurrentHeap()->v->Alloc(CurrentHeap(),
                                            HEAP_ZERO_MEMORY,
                                            sizeof(*x),
                                            0);
    DPRINT(("ZFNew => %x\n", x));
    if (x) {
        x->v = &ZeroFileVtbl;
        x->RefCnt = 1;

        Int64FromHighAndLow(x->Size, ~(UINT32)0, ~(UINT32)0) ; /* MAXUINT64 */
        x->Access = NAME_SPACE_READ | NAME_SPACE_WRITE;

        /* The factory keeps the module from going away */
        pTheFactory->v->AddRef(pTheFactory);
    }
    return x;
}

/* Internal destructor */
PRIVATE void ZFDestroy(PZEROFILE x)
{
    DPRINT(("ZFDestroy\n"));
    CurrentHeap()->v->Free(CurrentHeap(), 0, (PTR) x);

    /* The factory keeps the module from going away */
    pTheFactory->v->Release(pTheFactory);
}

/* Exported ZeroFile constructor */
SCODE CreateZeroFile(PIFILE *pNewFile)
{
    PZEROFILE x;

    DPRINT(("CreateZeroFile\n"));

    x = ZFNew();
    if (!x)
        return E_NOT_ENOUGH_MEMORY;

    *pNewFile = iZF(x);
    return S_OK;
}

/* Exported NullFile constructor */
SCODE CreateNullFile(PIFILE *pNewFile)
{
    PZEROFILE x;

    DPRINT(("CreateNullFile\n"));

    x = ZFNew();
    if (!x)
        return E_NOT_ENOUGH_MEMORY;

    /* Override Vtbl with different implementation */
    x->v = &NullFileVtbl;

    *pNewFile = iZF(x);
    return S_OK;
}

/* IUnknown::QueryInterface method */
PRIVATE SCODE MCT ZFQueryInterface(PIFILE This, REFIID Iid, void **ppObj)
{
    DPRINT(("ZFQueryInterface x%x\n", This));
    return GenericQueryInterface((PIUNKNOWN) This, Iid, ppObj, &IID_IFile);
}

/* IUnknown::AddRef method */
PRIVATE UINT MCT ZFAddRef(PIFILE This)
{
    UINT RefCnt = AtomicInc(&pZF(This)->RefCnt);
    DPRINT(("ZFAddRef x%x ==> %d\n", This, RefCnt));
    return RefCnt;
}

/* IUnknown::Release method */
PRIVATE UINT MCT ZFRelease(PIFILE This)
{
    UINT RefCnt = AtomicDec(&pZF(This)->RefCnt);
    DPRINT(("ZFRelease x%x ==> %d\n", This, RefCnt));
    if (RefCnt == 0) {
        ZFDestroy(pZF(This));
    }
    return RefCnt;
}

/* Utility functions for parameter checks */
PRIVATE BOOL CheckSize(PZEROFILE x, UINT64 Offset, UINT Size)
{
    INT64 s;

    Int32ToInt64(s, Size);
    
    /* Beware of integer overflow: Offset + Size might be > MAXUINT64
     * So do comparison in two parts.  The Int64Stuff makes this harder...
     */

    /* if (Offset > x->Size)... */
    if (Uint64Less(x->Size, Offset) && !Int64Equal(x->Size, Offset))
        return FALSE;

    /* if (Offset + Size > x->Size)... */
    s = Int64Add(s, Uint64ToInt64(Offset));
    if (Uint64Less(x->Size, Int64ToUint64(s)) && !Int64Equal(x->Size, Offset))
        return FALSE;
    return TRUE;
}

PRIVATE BOOL CheckAccess(PZEROFILE x, UINT Access)
{
    if ((Access & NAME_SPACE_READ) && !(x->Access & NAME_SPACE_READ))
        return FALSE;
    if ((Access & NAME_SPACE_WRITE) && !(x->Access & NAME_SPACE_WRITE))
        return FALSE;
    return TRUE;
}

/* IFIle::ReadAt method.  ZeroFile: Read zeros */
PRIVATE SCODE MCT ZFReadAt(PIFILE This, UINT64 Offset, PBYTE pBuffer, UINT Size, UINT *pSizeRead)
{
    PZEROFILE x = pZF(This);
    DPRINT(("ZFRead x%x\n", This));

    if (!CheckSize(x, Offset, Size))
        return E_INVALID_PARAMETER;

    if (!CheckAccess(x, NAME_SPACE_READ))
        return E_ACCESS_DENIED;

    /* Reading by zeroing */
    memset(pBuffer, 0, Size);

    *pSizeRead = Size;
    return S_OK;
}

/* IFile::ReadAt method.  NullFile: Read EOF */
PRIVATE SCODE MCT NFReadAt(PIFILE This, UINT64 Offset, PBYTE pBuffer,
                           UINT Size, UINT *pSizeRead)
{
    PZEROFILE x = pZF(This);
    UnusedParameter(pBuffer);
    DPRINT(("NFRead x%x\n", This));

    if (!CheckSize(x, Offset, Size))
        return E_INVALID_PARAMETER;

    if (!CheckAccess(x, NAME_SPACE_READ))
        return E_ACCESS_DENIED;

    /* Reading by ignorance */
    *pSizeRead = 0;
    return S_FALSE;
}

/* IFile::WriteAt method.  Don't store data anywhere.  Just say we did. */
PRIVATE SCODE MCT ZFWriteAt(PIFILE This, UINT64 Offset, const BYTE *pBuffer,
                            UINT Size, UINT *pSizeWritten)
{
    PZEROFILE x = pZF(This);
    UnusedParameter(pBuffer);
    DPRINT(("ZFWrite x%x\n", This));

    if (!CheckSize(x, Offset, Size))
        return E_INVALID_PARAMETER;

    if (!CheckAccess(x, NAME_SPACE_WRITE))
        return E_ACCESS_DENIED;

    *pSizeWritten = Size;
    return S_OK;
}

/* IFile::SetFile method */
PRIVATE SCODE MCT ZFSetSize(PIFILE This, UINT64 Size)
{
    PZEROFILE x = pZF(This);
    DPRINT(("ZFSetSize x%x %lx\n", This, Size));

    x->Size = Size;
    return S_OK;
}

/* IFile::GetFile method */
PRIVATE SCODE MCT ZFGetSize(PIFILE This, UINT64 *pSize)
{
    PZEROFILE x = pZF(This);
    DPRINT(("ZFgetSize x%x\n", This));

    *pSize = x->Size;
    return S_OK;
}

/* The v-tables are the same except for ReadAt */

PRIVATE struct IFileVtbl ZeroFileVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    ZFQueryInterface,
    ZFAddRef,
    ZFRelease,
    ZFReadAt,
    ZFWriteAt,
    ZFSetSize,
    ZFGetSize
};

PRIVATE struct IFileVtbl NullFileVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    ZFQueryInterface,
    ZFAddRef,
    ZFRelease,
    NFReadAt,
    ZFWriteAt,
    ZFSetSize,
    ZFGetSize
};
