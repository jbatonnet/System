/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __MMLITE_MD_H_
#define __MMLITE_MD_H_

typedef signed char INT8;
typedef unsigned char UINT8;
typedef short INT16;
typedef unsigned short UINT16;
typedef signed int INT32;
typedef unsigned int UINT32;

/* in case we do not want the compiler supported ones (almost never) */
#if defined(__NO_BUILTIN_INT64)
typedef struct _INT64 INT64;
typedef struct _UINT64 UINT64;
#elif defined(__GNUC__) && 0 /* no can do yet. assy assumes retval on stack */
typedef signed long long INT64;
typedef unsigned long long UINT64;
#elif defined(ADS) && 1 // /* needs more crt runtime redefines */
typedef signed __int64 INT64;
typedef unsigned __int64 UINT64;
#else
typedef struct _INT64 INT64;
typedef struct _UINT64 UINT64;
#define __NO_BUILTIN_INT64 1       /* No compiler support */
#endif

typedef INT32 INT;
typedef UINT32 UINT;

#define _UINTSIZE ( 32 )
#ifdef _OLDSCHED
#define _MUTEX_STATE_SIZE       ( 1 )
#define _CONDITION_STATE_SIZE   ( 2 )
#else
#define _MUTEX_STATE_SIZE       ( 5 )
#define _CONDITION_STATE_SIZE   ( 3 )
#endif

struct  _CXTINFO {
    UINT32 CPSR;
    UINT32 R0;
    UINT32 R1;
    UINT32 R2;
    UINT32 R3;
    UINT32 R4;
    UINT32 R5;
    UINT32 R6;
    UINT32 R7;
    UINT32 R8;
    UINT32 R9;
    UINT32 R10;
    UINT32 R11;
    UINT32 R12;
    UINT32 SP;
    UINT32 R14;
    UINT32 PC;
};

/* Frequently needed processor dependent constants. */
#define _DCACHELINESIZE (64)  /* Size in bytes of data-cache line. */
#define _PAGE_SIZE (4096)
#define _PAGE_SHIFT (12)

#endif  /*__MMLITE_MD_H_*/
