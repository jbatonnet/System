/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Included to generated SOAP metadata */

#ifndef _GENTYPE_INFO_H_
#define _GENTYPE_INFO_H_

#include <string.h>
#include <stdlib.h>
#include <mmlite.h>
#include <netif.h>
#include <winsock.h>
#include <util/list-double2.h>
//#include "soap.h"
#include <wsif.h>
#include <soapif.h>
#include <wsifhelp.h>
#include <sampleif.h>
#ifdef _WITH_PRIVATE_INCLUDES
#include <cimif.h>
#endif
#include <web/typeinfo.h>
#include "web/tokens.h"

#define IN ARGUMENT_DESCR_FLAGS_IN
#define OUT ARGUMENT_DESCR_FLAGS_OUT

/* ME is same as MEs but the later returns SCODE */
#define ME   {ENTRY_TYPE_METHOD, ENTRY_FLAGS_CONST, 1}
#define MEs  {ENTRY_TYPE_METHOD, ENTRY_FLAGS_CONST|ENTRY_FLAGS_METHOD_SCODE, 1}
#define MEsn {ENTRY_TYPE_METHOD, ENTRY_FLAGS_CONST|ENTRY_FLAGS_METHOD_SCODE|ENTRY_FLAGS_NAMELESS, 1}
#define MEsnc {ENTRY_TYPE_METHOD, ENTRY_FLAGS_CONST|ENTRY_FLAGS_METHOD_SCODE|ENTRY_FLAGS_NAMELESS|ENTRY_FLAGS_METHOD_CIMCOMPAT, 1}
#define AE  {ENTRY_TYPE_ARG, ENTRY_FLAGS_CONST, 1}
#define IE  {ENTRY_TYPE_INTERFACE, ENTRY_FLAGS_CONST, 1}
#define SE  {ENTRY_TYPE_STRUCT, ENTRY_FLAGS_CONST, 1}
#define SEn {ENTRY_TYPE_STRUCT, ENTRY_FLAGS_CONST|ENTRY_FLAGS_NAMELESS, 1}
#define SEnf {ENTRY_TYPE_STRUCT, ENTRY_FLAGS_CONST|ENTRY_FLAGS_NAMELESS|ENTRY_FLAGS_FULLY_QUALIFIED, 1}
#define SEf {ENTRY_TYPE_STRUCT, ENTRY_FLAGS_CONST|ENTRY_FLAGS_FULLY_QUALIFIED, 1}
#define FE  {ENTRY_TYPE_FIELD, ENTRY_FLAGS_CONST, 1}
#define TE  {ENTRY_TYPE_STRING, ENTRY_FLAGS_CONST, 1}
#define TEu {ENTRY_TYPE_STRING, ENTRY_FLAGS_CONST|ENTRY_FLAGS_UNQUALIFIED, 1}
#define NE  {ENTRY_TYPE_NS_TABLE, ENTRY_FLAGS_CONST, 1}
#define XE  {ENTRY_TYPE_XNS, ENTRY_FLAGS_CONST, 1}

#define STR(_prefix_, _value_) const struct _ ## _prefix_ ## _ ## _value_ {ANY_ENTRY any; _TCHAR Str[sizeof( # _value_)];} _prefix_ ## _ ## _value_ = {TE, _T( # _value_ )}
#define STRTAB_BEGIN(_prefix_, _count_) PRIVATE const struct { ANY_ENTRY any; INT Count; CPANY_ENTRY Table[_count_]; } _prefix_ ## _ns_table = { NE, _count_, {
#define STRTAB_END }};


/* Support for old packaging mechanism */
#define PREDEFINED_NAMESPACES &pre_ns_8

/* Forward. XXX generate */
extern const struct XMLNAMESPACE IWsManagement_ifd_namespace_1;

extern const struct _METHOD_DESCR IProgram_iface_table[4];
extern const struct XMLNAMESPACE IWsShell2_ifd_namespace_1;

extern const struct XMLNAMESPACE pre_ns_8;
extern const struct XMLNAMESPACE IProgram_ifd_namespace_prog;

extern const struct XMLNAMESPACE ICIM_RecordLog_ifd_namespace_1;
#endif /*_GENTYPE_INFO_H_*/
