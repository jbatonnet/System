/* Header file for src\util\list-double.c
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

/* You can only use one list implementation in each module */
#ifndef __LIST_DOUBLE_H__
#define __LIST_DOUBLE_H__

#include <util/util.h>

/* Doubly-linked list node, pointer, and pointer-to-pointer type defines */
typedef struct _DNODE DNODE, *PDNODE;

/* Doubly-linked list and pointer type defines */
typedef struct _DLIST DLIST, *PDLIST;

/* Macros for casting */
#define pDN(_pdn_) ((PDNODE)(_pdn_))
#define pDL(_pdl_) ((PDLIST)(_pdl_))


/* Data structure for doubly-linked list nodes. */
struct _DNODE {
  PDNODE pdnPrev;  /* Previous node in a doubly-linked list */
  PDNODE pdnNext;  /* Next node in a doubly-linked list */
  PTR pData;     /* Data payload of this list node */
};

/* Data structure for doubly-linked circular lists
 * If the list is empty, pdnHead == NULL.
 * If the list not empty, (pdnHead,pdnHead->pdnNext,pdnHead->pdnPrev) != NULL
 * If the list has one element, pdnHead == pdnHead->pdnNext == pdnHead->pdnPrev
 */
struct _DLIST {
  PDNODE pdnHead;
};

/*** Node read macros ***/

#define /* PTR */                                                             \
DNode_GetData(/* PNODE */ _pdn_)                                              \
  (pDN(_pdn_)->pData)

#define /* PNODE */                                                           \
DNode_GetPrev(/* PNODE */ _pdn_)                                              \
  (pDN(_pdn_)->pdnPrev)

#define /* PNODE */                                                           \
DNode_GetNext(/* PNODE */ _pdn_)                                              \
  (pDN(_pdn_)->pdnNext)

#define /* BOOL */                                                            \
DNode_IsAlone(/* PDNODE */ _pdn_)                                             \
  (DNode_GetNext(pDN(_pdn_)) == (_pdn_))


/*** Node write macros ***/

#define /* void */                                                            \
DNode_Init(/* PDNODE */ _pdn_, /* PTR */ _ptr_)                               \
  DNode_SetPrev(_pdn_, _pdn_);                                                \
  DNode_SetNext(_pdn_, _pdn_);                                                \
  DNode_SetData(_pdn_, _ptr_)

#define /* void */                                                            \
DNode_SetData(/* PDNODE */ _pdn_, /* PTR */  _pData_)                         \
  DNode_GetData(_pdn_) = (_pData_)

#define /* void */                                                            \
DNode_SetNext(/* PDNODE */ _pdn_, /* PDNODE */ _pdnNext_)                     \
  (DNode_GetNext(_pdn_) = pDN(_pdnNext_))

#define /* void */                                                            \
DNode_SetPrev(/* PDNODE */ _pdn_, /* PDNODE */ _pdnPrev_)                     \
  (DNode_GetPrev(_pdn_) = pDN(_pdnPrev_))

#define /* void */                                                            \
DNode_Link(/* PDNODE */ _pdnPrev_, /* PDNODE */ _pdnNext_)                    \
  DNode_SetNext(_pdnPrev_, _pdnNext_);                                        \
  DNode_SetPrev(_pdnNext_, _pdnPrev_)


/*** List read macros ***/

#define /* PDLIST */                                                          \
DList_GetHead(/* PDLIST */ _pdl_)                                             \
  (pDL(_pdl_)->pdnHead)

#define /* PDLIST */                                                          \
DList_GetTail(/* PDLIST */ _pdl_)                                             \
  (DList_GetHead(_pdl_)->pdnPrev)


/*** List write macros ***/

#define /* void */                                                            \
DList_SetHead(/* PDLIST */ _pdl_, /* PDNODE */ _pdnNewHead_)                  \
    (pDL(_pdl_)->pdnHead = pDN(_pdnNewHead_))

#define /* BOOL */                                                            \
DList_IsEmpty(/* PDLIST */ _pdl_)                                             \
    (DList_GetHead(_pdl_) == NULL)

#define /* void */                                                            \
DList_Init(/* PDLIST */ _pdl_)                                                \
    DList_SetHead((_pdl_), NULL)

/*** Exported node methods ***/

PDNODE DNode_Push(
    PDNODE pdnStackHead,
    PDNODE pdnNew
    );

PDNODE DNode_Pop(
    PDNODE pdnStackHead
    );

void DNode_InsertAfter(
    PDNODE pnInsertAfter,
    PDNODE pnNew
    );

void DNode_RemoveAfter(
    PDNODE pnPrevious
    );

PDNODE DNode_StackRemove(
    PDNODE pdnStackHead,
    PDNODE pdnRemove
    );

PDNODE DNode_StackClear(
    PDNODE pdnStackHead
    );

/*** Exported list methods ***/

void DList_Clear(
    PDLIST pdlThis
    );

void DList_HeadAdd(
    PDLIST pdlThis,
    PDNODE pdnNew
    );

void DList_TailAdd(
    PDLIST pdlThis,
    PDNODE pdnNew
    );

PDNODE DList_HeadRemove(
    PDLIST pdlThis
    );

PDNODE DList_TailRemove(
    PDLIST pdlThis
    );

void DList_Remove(
    PDLIST pdlThis,
    PDNODE pdnRemove
    );

PDNODE DList_FindData(
    PDLIST pdlThis,
    PTR pFindData
    );

PDNODE DList_FindDataAndRemove(
    PDLIST pdlThis,
    PTR pFindData
    );

PTR DList_FindDataMax(
    PDLIST pdlThis,
    BOOL (* CompareGT)(PTR, PTR)
    );

PTR DList_RemoveDataMax(
    PDLIST pdlThis,
    BOOL (* CompareGT)(PTR, PTR)
    );
    
void DList_TransformData(
    PDLIST pdlThis,
    void (* Transform)(PTR)
    );
    
void DList_TransformDataWithArg(
    PDLIST pdlThis,
    void (* Transform)(PTR, PTR),
    PTR pArg
    );

void DList_InsertSortedDescending(
    PDLIST pdlThis,
    BOOL (* CompareGT)(PTR, PTR),
    PDNODE pnNew
    );

#endif /* __LIST_DOUBLE_H__ */
