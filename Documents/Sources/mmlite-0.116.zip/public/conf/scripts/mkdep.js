// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Script to do dependency processing --jvh 2001
//
//----------- Globals --------------------------------------------//
var incdir = null;
var verbose = 0;
var debug = false;
var ofs = null;
var scriptpath = null;
var suffix;
var recursive = false;
var excludeglob;
var excludedirs;
var incdirs;
var replace0;
var replace1;
var extensions;
var rootpath = "";
var backslash = false;
var outputfile = null;

var incstack;           // for diagnostics and for avoiding runaway recursion

var depdata = "";
var depcache;

//----------- Main --------------------------------------------//
function usage() {
  alert("USAGE: mkdep [-v]* (verbose) [-V] (debug) [-bs] (backslashes in output) [-x object-suffix]* (.obj etc) [-I path] (include path) [-r replace with] (rewrite putput paths) [-s source-path] (root of interesting source tree) [-x exclude pattern] (anti-wildcard) [-K -I path...] (kill-include-path) source-files\n");
}

// main()
if (WScript != null) {
    main();
}

function main() {
  var xmlcollectionfile = "";

  ofs = WScript.CreateObject("Scripting.FileSystemObject");
  var scriptpath = ofs.getParentFolderName(WScript.scriptFullName);

  var dirs = new Array();

  incdirs = new Array();
  excludeglob = new Array();
  excludedirs = new Array();
  extensions = new Array();
  replace0 = new Array();
  replace1 = new Array();
  depcache = new ActiveXObject("Scripting.Dictionary");
  incstack = new Array();

  var args = WScript.arguments;
  var consumedargs = 0;
  var kill = false;
  for (var i = 0; i < args.length; i++) {
    if (args.item(i).substring(0,1) == "-") {
      consumedargs++;
      var opt = args.item(i).substr(1);
      var item;
      if (opt.substring(0,4) == "INC=") // Special for h8_hew tools
          item = opt.substr(4).replace(/\\/g, "/");
      else
          item = opt.substr(1).replace(/\\/g, "/");
      if (opt.substring(0,1) == "I") {
	if (kill) {
	  for (j = 0; j < incdirs.length; j++) {
	    if (incdirs[j] == item) {
	      //echo("Deleting " + item);
	      incdirs[j] = null;
	    }
	  }
	} else {
	  incdirs.push(item);
        }
        continue;
      }
      switch(opt) {
      case "s":                 // src dir
        if (args.length - i < 2)
          usage();
        srcdir = args.item(++i).replace(/\\/g, "/");
        consumedargs++;
        break;
      case "o":                 // output file
        if (args.length - i < 2)
          usage();
        outputfile = args.item(++i).replace(/\\/g, "/");
        consumedargs++;
        break;
      case "x": {               // extension
        if (args.length - i < 2)
          usage();
        extensions.push(args.item(++i));
        consumedargs++;
        break;
      }
      case "xp": {               // eXclude leaf pattern
        if (args.length - i < 2)
          usage();
        var xname = args.item(++i);
        xname = xname.replace(/\./gm, "[.]");
        xname = xname.replace(/\*/gm, ".*");
        xname = xname.replace(/\?/gm, ".");
        xname = "([/\\\\]|^)" + xname;

        excludeglob = excludeglob.concat(new RegExp(xname, ""));
        consumedargs++;
        xname = null;
        break;
      }
      case "e": {               // Exclude dir
        if (args.length - i < 2)
          usage();
        var xname = args.item(++i);
        xname = xname.replace(/\\/gm, "/");
        xname = xname.replace(/\./gm, "[.]");
        xname = xname.replace(/\*/gm, ".*");
        xname = xname.replace(/\?/gm, ".");
        xname = "^" + xname;

        excludedirs = excludedirs.concat(new RegExp(xname, ""));
        consumedargs++;
        xname = null;
        break;
      }
      case "d":                 // add dir to input list
        if (args.length - i < 2)
          usage();
        i++;
        dirs.push(args.item(i).replace(/\\/g, "/"));
        consumedargs++;
        break;
      case "r":                 // replace
        if (args.length - i < 3)
          usage();
        replace0.push(args.item(++i).replace(/\\/g, "/"));
        replace1.push(args.item(++i));
        consumedargs += 2;
        break;
      case "bs":                 // use backslashes in output makefile
        backslash = true;
        break;
      case "K":                 // kill includes on the cmd line from now on
        kill = true;
        break;
      case "v":                 // Verbose
        verbose++;
        break;
      case "V":                 // debug VVERRY Verbose
        debug = true;
        break;
      default:
        alert("unknown option '" + opt + "'");
      }
    }
  }

  if (args.length - consumedargs < 1)
    usage();

  if (debug) {
    echo("------------------------------");
    echo ("srcdir = " + srcdir);
    echo ("output = " + outputfile);
    echo ("dirs= (" + dirs.length + ") " + dirs.join(" : "));
    echo ("incdirs= (" + incdirs.length + ") " + incdirs.join(" : "));
    echo ("extensions= (" + extensions.length + ") " + extensions.join(" : "));
    echo ("excludedirs= (" + excludedirs.length + ") "
          + excludedirs.join(" : "));
    echo ("excludeglob= (" + excludeglob.length + ") "
          + excludeglob.join(" : "));
    echo ("replace0= (" + replace0.length + ") " + replace0.join(" : "));
    echo ("replace1= (" + replace1.length + ") " + replace1.join(" : "));
  }
  excludedirs = null;

  var result = new Array();
  while (args.length - consumedargs > 0) {
    var filespec = args.item(consumedargs);
    consumedargs++;
    var infiles = glob(srcdir + filespec);
    //echo ("GLOB " + filespec + " -> " + infiles.join(" "));

    for (var i = 0; i < infiles.length; i++) {
      processfiles(infiles[i], result);
      //echo("PROCESS " + infiles[i] + " -> (" + result.length + ") " + result.join("\n"));
    }
  }

  if (verbose > 1)
    echo("DEPLINES " + result.length);

  if (backslash)                // fix output for MSDOS tools if necessary
    for (i = 0; i < result.length; i++)
      result[i] = result[i].replace(/\//gm, "\\");

  //  result.sort();                // make it more stable

  if (outputfile == null) {
    for (i = 0; i < result.length; i++)
      echo(result[i]);
  } else {
    // Read outputfile and compare
    if (ofs.FileExists(outputfile)) {
      var f = ofs.GetFile(outputfile);
      var content = "";
      if (f == null)
        alert("could not open " + outputfile);
      if (f.Size != 0) {
        //echo("File " + outputfile + " is " + f.Type + " Size=" + f.Size);
        var ff = f.OpenAsTextStream(1, 0);
        content = ff.ReadAll();
        ff.Close();
        ff = null;
      }
      f = null;

      if (content == result.join("\n")) {
        if (verbose > 0)
          echo ("File " + outputfile + " unchanged");
        return;
      }
    }

    var exc;
    try {
      var ff = ofs.CreateTextFile(outputfile);
    } catch (exc) {
      alert("Could not create " + outputfile + ": " + exc.description + " (" + (exc.number & 0xffff) + ")");
    }
    ff.write(result.join("\n"));
    if (verbose > 0)
      echo("Wrote deps into " + outputfile);
  }
}


//----------- Utility functions -------------------------------------//
function expandsubdirs(path) {
  var arr = new Array();
  var ix = 0;

  path = path.replace(/\\/gm, "/");

  var f = ofs.GetFolder(path);
  if (f == null)
    alert("can't open dir " + path);

  if (path == ".")
    path = "";
  else if (path != "")
    path += "/";

  var fc = new Enumerator(f.SubFolders);
 outer:
  for (fc.moveFirst() ; !fc.atEnd(); fc.moveNext()) {
    var item = "" + fc.item();
    if (debug)
      echo ("dir=" + item + " = " + path + basename(item));
    item = path + basename(item);

    for (var x = 0; x < excludedirs.length; x++) {
      if (item.match(excludedirs[x]) != null) {
        if (verbose > 0)
          echo ("canal expandsubdir skipped '" + item + "' due to exclusion ");
        continue outer;
      }
    }
    arr[ix++] = item;
    arr = arr.concat(expandsubdirs(item));
  }

  if (debug) 
    echo("expand " + path + " -> (" + arr.length + ") " + arr.join(" "));

  return arr.sort();
}

function glob(path) {
  //echo ("glob: " + path+" How come this is not provided by the runtime?\n");
  var arr = new Array();
  var name = basename(path);
  var ix = 0;

  path = pathname(path);
  path = path.replace(/\\/gm, "/");

  name = name.replace(/\./gm, "[.]");
  name = name.replace(/\*/gm, ".*");
  name = name.replace(/\?/gm, ".");
  name = "([/\\\\]|^)" + name;

  if (debug)
    echo ("Globbing for " + name + " in " + path);

  if (path != "" && !ofs.FolderExists(path)) {
    if (verbose > 1)
      echo("glob: " + path + " does not exist, skipped");
    return arr;
  }

  var f = ofs.GetFolder(path == "" ? "." : path);
  if (f == null)
    alert("can't open dir");

  if (path != "")
    path += "/";

  var fc = new Enumerator(f.Files);
 outer:
  for (fc.moveFirst() ; !fc.atEnd(); fc.moveNext()) {
    var item = "" + fc.item();
    if (item.match(new RegExp(name, "")) != null) {
      for (var x = 0; x < excludeglob.length; x++) {
        if (item.match(excludeglob[x]) != null) {
          if (verbose > 0)
            echo ("canal glob skipped '" + item + "' due to exclusion ");
          continue outer;
        }
      }
      if (debug && false)
        echo ("item=" + item + " = " + path + basename(item));
      item = path + basename(item);
      arr[ix++] = item;
    }
  }
  fc = item = null;

  return arr.sort();
}

function runtimeError(exception)  {
  alert("XSL Runtime Error " + exception.description
        + " line " + exception.line);
}

function loadError(oSRC, str) {
  var oErr = oSRC.parseError;

  var s = "";
  for (var i=1; i < oErr.linepos; i++) {
    s += " ";
  }
  alert("XML parse error " + oErr.url + "(" + oErr.line + "): pos " + oErr.linepos + "\n" + oErr.reason + "\n"
        + oErr.srcText + "\n" + s + "^");
}

function load_xml(file, validate, resolve) {
  var oXML = new ActiveXObject("MSXML.DOMDocument");
  oXML.validateOnParse = validate;
  oXML.resolveExternals = resolve;
  oXML.async = false;
  if (!oXML.load(file))
    loadError(oXML, "Load of " + file + " failed");

  return oXML;
}

function basename(path) {
  var result = path.match(/[^\/\\]*$/);
  //echo("basename(" + path + ") -> " + result);
  return "" + result;
}

function pathname(path) {
  if (path.match(/[\/\\][^\/\\]*$/) == null)
    return "";

  return "" + path.replace(/[\/\\][^\/\\]*$/, "");
}

function nonsuffix(path) {
  var result = path.replace(/[.][^.]*$/, "");
  //echo("nonsuffix(" + path + ") -> " + result);
  return "" + result;
}

function getsuffix(path) {
  var result = basename(path).match(/[.][^.]*$/);
  var suf;

  if (result == null)
      suf = "";
  else
      suf = ("" + result).substr(1);
  if (debug)
    echo("getsuffix(" + path + ") -> " + result + " -> '" + suf + "'");

  result = path = null;
  return suf;
}

function makedir(path) {
  if (path == "")
    return;

  var bn = new RegExp("[/\\\\][^/\\\\]*$", "");
  if (path.match(bn) != null) {
    makedir(path.replace(bn, ""));
  }
  bn = null;

  if (!ofs.FolderExists(path)) {
    if (verbose > 0)
      echo("mkdir " + path);
    ofs.CreateFolder(path);
  }
}

function alert(str) {
  if (WScript != null) {
    WScript.Echo(str);
    WScript.Quit(1);
  } else {
    echo("ALERT: " + s);
  }
}

function echo(s) {
  if (WScript != null) {
    WScript.Echo(s);
  } else {
    oLog.WriteLine(s);
  }
}

//------------ Real work ----------------------------------------//

function scandep(path) {

  if (!ofs.FileExists(path))
    alert("File does not exist: " + path);

  // Make sure we don't end up recursing forever when files include each other
  for (var i = 0; i < incstack.length; i++) {
    if (incstack[i] == path) {
      echo("Recursive inclusion detected " + path);
      return new Array();       // return an empty array
    }
  }

  var content = "";
  var f = ofs.GetFile(path);
  if (f == null)
    alert("could not open " + path);
  if (f.Size != 0) {
    //echo("File " + path + " is " + f.Type + " Size=" + f.Size);
    var ff = f.OpenAsTextStream(1, 0);
    content = ff.ReadAll();
    ff.Close();
    ff = null;
  }
  f = null;

  // scan includes but first adjust 'parentfile' for diagnostic prints
  incstack.push(path);
  var inc = includes(content);
  incstack.pop();
  return inc;
}

function includes(text) {
  var a, b, ix;
  var tmp = text;
  var file;
  var files = new Array();

  while (tmp.match(/^(#include\s+)<([^>]+)>/m) != null) {
    a = RegExp.$1; b = RegExp.$2; ix = RegExp.index;
    file = b.replace(/\\/g, "/");
    //echo( "<file='" + incstack[incstack.length - 1] + "' name='" + file + "' q='angle'/>");
    var got = getinclude(file, true);
    if (got != null)
      files = files.concat(got);
    tmp = tmp.substr(ix + a.length + b.length + 2); // 2 for <>
  }

  var tmp = text;
  // create tags for quote includes. No quoted quotes here
  while (tmp.match(/^(#include\s+)\"([^\"]+)\"/m) != null) {
    a = RegExp.$1; b = RegExp.$2; ix = RegExp.index;
    file = b.replace(/\\/g, "/");
    //echo("<file='" + parentfile + "' name='" + file + "' q='doublequote'/>");
    var got = getinclude(file, false);
    if (got != null)
      files = files.concat(got);
    tmp = tmp.substr(ix + a.length + b.length + 2); // 2 for quotes
  }

  tmp = a = b = ix = null;
  return files;
}

function getinclude(name, angle) {
  var files;
  for (var i = 0; i < incdirs.length; i++) {
      if (incdirs[i] == null)
        continue;
    var path = incdirs[i] + "/" + name;

    if (depcache.Exists(path)) {
      var xx = depcache.Keys();
      if (verbose > 1) {
        echo("FOUND " + path + " in DEPCACHE (" + depcache.Count + ") ");
        echo("" + depcache.Item(path).join(" : "));
      }
      return depcache.Item(path);
    }

    if (ofs.FileExists(path)) {
      files = scandep(path);
      files.push(path);

      // remove duplicates, some windows.h string get otherwise way long...
      // ... but this slows the script down so rather just do the try except
      // below to recover from jscript limitations
//      files = files.sort();
//      for (var j = 0; j < files.length - 1; j++) {
//        if (files[j] == files[j+1]) {
//          files.splice(j+1, 1);
//          j--;
//        }
//      }

      if (verbose > 1)
        echo("ADD " + path + " -> " + files.join());

      var exc;
      try {
        depcache.Add(path, files);
      } catch (exc) {
        echo ("Dependency cache ran out of memory " + name + ", may take longer but is ok " + exc.number & 0xffff + " " + exc.description);
      }
      return files;
    }

    if (verbose > 1)
      echo("TRIED " + path);
  }

  if (verbose > 0)
    echo("skipped " + name + " (file not found from " + basename(incstack[0])
         + " " + incstack[incstack.length - 1] + ")");
  return files;
}

function gendeps(target, deps, result) {
  target += ":";
  var tgtlen = target.length;
  var line = result.length - 1; // line
  d = 0;

 nextline:
  while (true) {
    // always put in first dep on line regardless of length
    result[++line] = target + " \"" + deps[d++] + "\"";
    // then put as many more as fit within 79 columns
    while (d < deps.length) {
      if (result[line].length + deps[d].length + 3 > 79)
        continue nextline;
      result[line] += " \"" + deps[d++] + "\"";
    }

    break;
  }
}

function processfiles(inputfile, result) {
  if (verbose > 1)
    echo("INPUTFILE " + inputfile);
  var deps = scandep(inputfile);
  if (deps.length < 1)
    return;

  // Replace absolute path names with relative ones.
  for (var j = 0; j < deps.length; j++) {
    for (var k = 0; k < replace0.length; k++) {
      if (deps[j].match(replace0[k])) {
        //echo ("REPLACE " + deps[j] + " -> " + replace1[k] + RegExp.rightContext);
        deps[j] = replace1[k] + RegExp.rightContext;
      }
    }
  }

  // remove duplicates
  deps = deps.sort();
  for (var j = 0; j < deps.length - 1; j++) {
    if (deps[j] == deps[j+1]) {
      deps.splice(j+1, 1);
      j--;
    }
  }

  //echo ("deps= (" + deps.length + ") " + deps.join(" : "));

  // output deps into array
  if (deps.length < 1)
    return;

  for (var j = 0; j < extensions.length; j++) {
    var target = nonsuffix(basename(inputfile)) + extensions[j];
    gendeps(target, deps, result);
  }
}
