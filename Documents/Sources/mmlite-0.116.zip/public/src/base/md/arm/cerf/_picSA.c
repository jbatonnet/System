/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * StrongArm SA-1100 Interrupt Controller support.
 */

#include <mmlite.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <drivers/drivers.h>
#include <fred.h>
#include <mmhal.h>
#include "_picSA.h"

#define _STATISTICS 0

#define IRQ_ID_COUNT (32+17)

extern PCXTINFO _Reschedule(PCXTINFO pContext);

typedef struct _ITABLE {
    INTERRUPT_SERVICE_ROUTINE Isr;  /* isr for IRQn*/
    void *pDevice;                  /* Argument to pass to it*/
#if _STATISTICS
    UINT32 Count;
    UINT32 pad;
#endif
} ITABLE;

/* The interrupt dispatcher uses a simple table of handlers. */
typedef struct _PIC {
    const struct IPicVtbl *v;
    UINT32 IRQMask;
    UINT32 GpioMask;
    ITABLE InterruptTable[IRQ_ID_COUNT];
} PIC;

/*
 * Only handles IRQ.
 *
 * ToDo:  Is it edge triggered or level triggered?
 *        Is it active high or active low?
 * Meaning, look at Flags.
 */

void MCT EnableInterrupt( IPic *pThis, DEVICE_FLAGS Flags, UINT Irq,
                          INTERRUPT_SERVICE_ROUTINE Isr, void *pDevice)
{
    PIC *pic = (PIC *) pThis;
    UINT b;

    /* We might want to protect the innocents and prevent them from
     * getting screwed trying to use the wrong IRQ.
     * Given the way we dispatch interrupts, that would never work.
     */
    if (Irq == 11)
        return;

    /* The order of the following operations is NOT irrelevant
     *
     * First, the argument. Failure case is if interrupt was
     * active and we are called with interrupts on and we get
     * an interrupt right after this statement. Wont happen.
     */
    pic->InterruptTable[ Irq ].pDevice = pDevice;

    /* Second, the ISR. If the interrupt was active we are done already.
     * If not, must activate it.
     */
    pic->InterruptTable[ Irq ].Isr = Isr;

    /* Third, the hardware.
     * Is it one of the GPIO ones ?
     */
    if ((Irq > 31) || (Irq < 11)) {

        /* Is it one of the muxed GPIO[11..27]
         */
        if (Irq > 31)
            b = 1 << (Irq - 32 + 11);
        else
            b = 1 << Irq;

        /* Set it as unmasked
         */
        pic->GpioMask |= b;

        /* Now must deal with trigger issues
         */
        GPIO->DetectFalling &= ~b;
        GPIO->DetectRaising |=  b;
        GPIO->DetectStatus  = b;

        /* If this isnt the first muxed interrupt line we are done
         */
        if (Irq > 31) {
            if (pic->GpioMask != b)
                return;

            /* Must enable the common IRQ
             */
            Irq = 11;
        }
    } 

    /* Finally, tell the IMR about it
     */
    pic->IRQMask |= 1 << Irq;
    TheHWPic->Mask |= 1 << Irq;
}

/*
 * Undo the above EnableInterrupt
 */
void MCT DisableInterrupt( IPic *pThis, UINT Irq, void **pOldDevice)
{
    PIC *pic = (PIC *) pThis;
    UINT b, r;

    /* Remove the ISR and its argument from our tables after setting
     * the hardware.
     * GPIO ?
     */
    r = Irq;
    if ((Irq > 31) || (Irq < 11)) {

        /* One of the muxed ones ?
         */
        r = (Irq > 31) ? (Irq - 32 + 11) : Irq;
        b = 1 << r;

        /* Set it as masked
         */
        pic->GpioMask &= ~b;

        /* Now must deal with trigger issues
         */
        GPIO->DetectRaising &= ~b;
        GPIO->DetectStatus   = b; /* ack it one last time */

        /* Iff its the last one we should turn off the IRQ
         */
        if (Irq > 31)
            r = (pic->GpioMask == 0) ? 11 : 32;
    }

    if (r < 32) {
        b = 1 << r;
        pic->IRQMask &= ~b;
        TheHWPic->Mask &= ~b;
    }

    pic->InterruptTable[ Irq ].Isr = NULL;
    *pOldDevice = pic->InterruptTable[ Irq ].pDevice; /* Return the old one */
    pic->InterruptTable[ Irq ].pDevice = NULL;

    return;
}

/*
 * Mask *all* interrupts.
 */
void MCT MaskAll( IPic *pThis )
{
    PIC *pic = (PIC *) pThis;
    UINT i, m;

    i = IntOff();

    m = TheHWPic->Mask;
    m &= ~pic->IRQMask;
    TheHWPic->Mask = m;

    SetPsr(i);
}

/*
 * Unmask all interrupts that should be unmasked.
 */
void MCT UnmaskAll( IPic *pThis )
{
    PIC *pic = (PIC *) pThis;
    UINT i, m;

    i = IntOff();

    m = TheHWPic->Mask;
    m |= pic->IRQMask;
    TheHWPic->Mask = m;

    SetPsr(i);
}

static const struct IPicVtbl picVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    EnableInterrupt,
    DisableInterrupt,
    MaskAll,
    UnmaskAll
};

PIC ThePIC = {
    &picVtbl,
    0,               /* IRQMask */
};

/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
    /* Disable all channels*/
    MaskAll(pThis);
}


IPic *PicCreate(void)
{
    IPic *pThis;

    TheHWPic->Mask = 0;
    TheHWPic->Level = 0; /* All IRQs */
    /* Make IDLE mode work */
    TheHWPic->Control = 1;
    pThis = (IPic *)&ThePIC;

    return pThis;
}

/******************************************************************************/
/* Normal Interrupt Traps*/
/******************************************************************************/

/* Returns the index of the first interrupt pending,
 * starting from the top.
 */
int PICGetInterrupt(void)
{
    UINT32 Status;
    int b, i;

    Status = TheHWPic->IrqPending;

    /* Ignore masked interrupts.
     */
    Status &= ThePIC.IRQMask;

    if (Status == 0) {
        return -1; /* masked, spurious */
    }

#if 0
    /* Start from the top
     */
    i = 31;
    b = 1 << i;
    for (;b != 0;) {

        /* This one ?
         */
        if (b & Status) {

            /* Yes, but is it the mux-ed one ?
             */
            if (i == 11) {
                /* Its a GPIO edge-detect interrupt, see which one.
                 * NB: same thing all over again
                 */
                Status = GPIO->DetectStatus;

                /* Mask
                 */
                Status &= ThePIC.GpioMask;

                i = 26;
                b = 1 << i;
                for (;i > 10;) {
                    if (b & Status)
                        break;
                    i--;
                    b = b >> 1;
                }
                /* Spurious ?!?
                 */
                if (i == 10)
                    return -1;

                GPIO->DetectStatus = b;
                return (32+i-11);

            } else if (i < 11) {
                /* Its a GPIO[0..10] edge-detect, ack it.
                 */
                GPIO->DetectStatus = b;
            }
            return i;
        }
        i--;
        b = b >> 1;
    }
#else
    /* Find the LSB bit set
     */
    b = Status & -Status;

    /* Compute its index.
     * This ought to be efficient on ARM cuz conditional instructions.
     * Xcept the compiler wanna play smart with constants, and the code
     * becomes 3 times longer than it needs to.
     */
#if 0
    i = ((b & 0xFFFF0000)!=0) << 4
        | ((b & 0xFF00FF00)!=0) << 3
        | ((b & 0xF0F0F0F0)!=0) << 2
        | ((b & 0xCCCCCCCC)!=0) << 1
        | ((b & 0xAAAAAAAA)!=0);

    /* Is it the mux-ed GPIO one ?
     */
    if (i == 11) {

        /* Its a GPIO edge-detect interrupt, see which one.
         * NB: same thing all over again
         */
        Status = GPIO->DetectStatus;

        /* Mask&check
         */
        Status &= ThePIC.GpioMask;
        if (Status != 0) {

            b = Status & -Status;
            i = ((b & 0xFFFF0000)!=0) << 4
                | ((b & 0xFF00FF00)!=0) << 3
                | ((b & 0xF0F0F0F0)!=0) << 2
                | ((b & 0xCCCCCCCC)!=0) << 1
                | ((b & 0xAAAAAAAA)!=0);

            GPIO->DetectStatus = b;
            return (32+i-11);
        }
        return -1;
    }

    if (i < 11) {
        /* Its a GPIO[0..10] edge-detect, ack it.
         */
        GPIO->DetectStatus = b;
    }
    return i;

#else
    /* This way it sortof does what I want.
     */
   {static UINT32 ffff0000 = 0xffff0000,
        ff00ff00 = 0xff00ff00,
        f0f0f0f0 = 0xf0f0f0f0,
        cccccccc = 0xcccccccc,
        aaaaaaaa = 0xaaaaaaaa;

    i = ((b & ffff0000)!=0) << 4
        | ((b & ff00ff00)!=0) << 3
        | ((b & f0f0f0f0)!=0) << 2
        | ((b & cccccccc)!=0) << 1
        | ((b & aaaaaaaa)!=0);

    /* Is it the mux-ed GPIO one ?
     */
    if (i == 11) {

        /* Its a GPIO edge-detect interrupt, see which one.
         * NB: same thing all over again
         */
        Status = GPIO->DetectStatus;

        /* Mask&check
         */
        Status &= ThePIC.GpioMask;
        if (Status != 0) {

            b = Status & -Status;
            i = ((b & ffff0000)!=0) << 4
                | ((b & ff00ff00)!=0) << 3
                | ((b & f0f0f0f0)!=0) << 2
                | ((b & cccccccc)!=0) << 1
                | ((b & aaaaaaaa)!=0);

            GPIO->DetectStatus = b;
            return (32+i-11);
        }
        return -1;
    }
    }
    if (i < 11) {
        /* Its a GPIO[0..10] edge-detect, ack it.
         */
        GPIO->DetectStatus = b;
    }
    return i;

#endif
#endif

    return -1;
}


CXTINFO *TrapIRQ(CXTINFO *pContext)
{
    UINT32 DoReschedule;
    BOOL NotMyInterrupt;
    int Index;
    ITABLE *IntSource;

    pContext->PC -= 4;

    /* Try to handle all pending interrupts at once */
    DoReschedule = 0;
    while ( (Index=PICGetInterrupt())>0 ) {
        IntSource=&ThePIC.InterruptTable[Index];

#if _STATISTICS
        IntSource->Count++;
#endif
        if (IntSource->Isr)
            DoReschedule |= (IntSource->Isr)(IntSource->pDevice, &NotMyInterrupt);
    }

    /* If any handlers requested a reschedule, it will get done */
    if (DoReschedule) {
#if _STATISTICS
        ThePIC.InterruptTable[0].Count++;
#endif
        pContext = _Reschedule(pContext);
    }

    return pContext;
}

#if _STATISTICS
void PrintIrqCounts(void)
{
    int i;
    for (i = 0; i < IRQ_ID_COUNT; i++)
        if (ThePIC.InterruptTable[i].Count != 0)
            printf("int[%d] = %d\n", i, ThePIC.InterruptTable[i].Count);
}
#endif
