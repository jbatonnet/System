/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _IMPORT_WINDOWS_H_
#define _IMPORT_WINDOWS_H_

/* Get INT16 type */
#include <mmlite_md.h>

/* Turn off warnings generated with -W4 on windows includes.
 * One warning (4142) is needed later because of int/long conflicts,
 * but the rest are temporary.
 */
#pragma warning(disable:4142)   /* benign redefinition of type */
#pragma warning(disable:4201)   /* nameless struct union */

#pragma warning(push)
#pragma warning(disable:4214)   /* bitfield other than int */
//#pragma warning(disable:4245)   /* nameless struct/union */
#pragma warning(disable:4514)
#pragma warning(disable:4115)   /* named type definition in parentheses */

typedef INT16 WCHAR, *PWCHAR, wchar_t;

#define WIN32_LEAN_AND_MEAN
#define NOMCX
#define NOIME

/* winbase.h depends on UNICODE without an underscore. Define that too. */
#ifdef _UNICODE
#define UNICODE 1
#endif

#if 0 // These are needed to compile with VC9 crt includes.
#ifndef _CRTIMP
/* Disable _CRTIMP to avoid DLL confusion with standard CRT functions.*/
#define _CRTIMP
#endif

/* Unless we support SAL all the way these just causes problems .*/
//#define USE_DECLSPECS_FOR_SAL 1
#define MIDL_PASS 1
#include <sal.h>
#undef MIDL_PASS
/* The following disables warnings from sscanf etc. XXX should eliminate */
#define _CRT_SECURE_NO_WARNINGS

/* XXX In case we ended up including VC9 assert.h, disable assertions */
//#define NDEBUG
#endif /* 0 */

/* wchar.h must be included first with VC8 */
#include <wchar.h>

/*  Avoid an unnecessary incompatibility with struct IID in guiddef.h
 */
#define IID ___bogus_IID

#undef DebugBreak
#include <windows.h>

#undef IID
#undef REFIID

#pragma warning(pop)

/* These OLE macros have the same value but are defined differently.
 * Simply undef them to quiet compiler.
 */
#undef S_OK
#undef S_FALSE
#undef E_FAIL
#undef E_OUTOFMEMORY

#pragma warning(disable:4057)   /* differs in indirection to slightly different base types */

#endif  /* _IMPORT_WINDOWS_H_ */
