/* Header file for standard linked list and node functions.
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __LIST_H__
#define __LIST_H__

#include <mmlite.h>

typedef void (* TransformArgFunc)(PTR, PTR);
typedef void (* TransformFunc   )(PTR);
typedef BOOL (* CompareFunc     )(PTR, PTR);

#endif /* __LIST_H__ */
