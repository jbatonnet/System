/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>

#ifdef _OLDSCHED
#include "../base/process.h"
#include <base/thread.h>
#else
#include <base/process2.h>
#include <base/thread2.h>
#endif

#include <base/schedul.h>


/*  In non-DEBUG builds, Base.h defines macro versions of these functions.
 *  We will undefine them here regardless, to insulate ourselves from any new flavors
 *  of builds.  The base image must always have *real* versions of these functions.
 */

#undef CurrentThread
#undef ThreadSetCurrent
#undef CurrentHeap
#undef CurrentNameSpace

#undef AtomicInc
#undef AtomicDec
#undef AtomicCmpAndSwap

extern PIHEAP pTheHeap;
extern PINAMESPACE pTheNameSpace;
extern PTHDINFO TheCurrentThread;
extern PIVMVIEW TheCurrentVmView;


/*  Current Thread object
 */
void ThreadSetCurrent( PITHREAD pThread)
{
    TheCurrentThread = (PTHDINFO)pThread;
}

PITHREAD RTLCALLTYPE CurrentThread(void)
{
    /* does not take a ref */
    return (PITHREAD)TheCurrentThread;
}

PIPROCESS RTLCALLTYPE CurrentProcess(void)
{
    /* does not take a ref */
    return TheCurrentThread->StartedIn;
}

PIVMVIEW RTLCALLTYPE CurrentVmView(void)
{
    /* does not take a ref */
    return TheCurrentVmView;
}

/*
PIUNKNOWN RTLCALLTYPE ActivityGetCurrent(void)
{
    if (TheCurrentThread)
        return TheCurrentThread->pIActivity;
    else
        return NULL;
}

void RTLCALLTYPE ActivitySetCurrent( PIUNKNOWN pIActivity)
{
    if (TheCurrentThread)
        TheCurrentThread->pIActivity = pIActivity;
}
*/

PIHEAP RTLCALLTYPE CurrentHeap(void)
{
    /* does not take a ref */
    return TheCurrentThread
        ? pPR(TheCurrentThread->StartedIn)->pHeap
        : pTheHeap;
}

#if 0
PIHEAP RTLCALLTYPE KernelHeap(void)
{
    /* does not take a ref */
    return pTheHeap;
}
#endif

PINAMESPACE RTLCALLTYPE CurrentNameSpace(void)
{
#if 1
    PTHDINFO th = TheCurrentThread;
    if (th)
        return pPR(th->StartedIn)->pNameSpace;
    else
        return pTheNameSpace;
#else
    return pTheNameSpace;
#endif
}
