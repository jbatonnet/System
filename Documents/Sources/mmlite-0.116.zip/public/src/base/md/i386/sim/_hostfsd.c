/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* NT server for remote IFile using sockets. */

#include <import_windows.h>
#include <mmlite.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "_netfile.h"
#include <winsock.h>
#include <machdep.h>            /* for TURN_INTERRUPT_OFF */
#include "_ntmmglu.h"

#define printf NT_printf
EXTERN_C INT __cdecl NT_printf(const char *format, ...);

//#include <machdep.h>


#define free(_p_) CurrentHeap()->v->Free(CurrentHeap(), 0, (_p_))
#define malloc(_s_) CurrentHeap()->v->Alloc(CurrentHeap(), HEAP_DEBUG_NAME("sim/_hostfsd"), (_s_), 0)

typedef struct {
    OVERLAPPED ol;
    CONDITION cnd;
} MYOVERLAPPED;

#define DPRINT(x)

static UINT CacheTimestamp = 0;

typedef void *PCONNECTION;

typedef struct _NTFILE {
    const struct IFileVtbl *v;
    UINT RefCnt;
    HANDLE Handle;
    BOOL IsSocket;
} *PNTFILE;
#define pNF(_ifile_) ((PNTFILE)(_ifile_))
#define iNF(_file_) ((PIFILE)(_file_))

typedef struct _NTNS {
    const struct INameSpaceVtbl *v;
    UINT RefCnt;
    HANDLE Handle;
} *PNTNS;
#define pNS(_ins_) ((PNTNS)(_ins_))
#define iNS(_ns_) ((PINAMESPACE)(_ns_))


INLINE PIFILE get_FILE(UINT32 client_says, PCONNECTION Conn)
{
    UnusedParameter(Conn);
    return (PIFILE) client_says;
}

INLINE UINT32 put_FILE(PIFILE file, PCONNECTION Conn, /* tmp in */ HOSTFS_TCHAR *name )
{
    UnusedParameter(Conn);
    UnusedParameter(name);

    return (UINT32) file;
}

INLINE PINAMESPACE get_NS(UINT32 client_says, PCONNECTION Conn)
{
    UnusedParameter(Conn);
    return (PINAMESPACE) client_says;
}

INLINE UINT32 put_NS(PINAMESPACE ns, PCONNECTION Conn, /* tmp in */ HOSTFS_TCHAR *name )
{
    UnusedParameter(Conn);
    UnusedParameter(name);

    return (UINT32) ns;
}

SCODE error_code_NT2MMLite(SCODE sc, char *where)
{
    UnusedParameter(where);

    /* NT doesn't seem to be very consistent in what error codes it returns */
    if (sc > 0) {
        /* Assume this is a Win32 error. */
        sc = STATUS_WIN32_ERROR(sc);
    }
    return sc;
}


extern const struct IFileVtbl NtFileVtbl; /* forward */
extern const struct INameSpaceVtbl NtNsVtbl; /* ditto */
static void FileRequestCompletions(PIFILE This);

static PIFILE AllocNtFile(HANDLE handle, BOOL IsSocket)
{
    PNTFILE File;

    File = (PNTFILE) malloc(sizeof(*File));
    if (!File)
        return NULL;

    File->v = &NtFileVtbl;
    File->RefCnt = 1;
    File->Handle = handle;
    File->IsSocket = IsSocket;

    /* Do asynch stuff for sockets only */
    if (IsSocket)
        FileRequestCompletions(iNF(File));

    return iNF(File);
}

static PINAMESPACE AllocNtNs()
{
    PNTNS Ns;

    Ns = (PNTNS) malloc(sizeof(*Ns));
    if (!Ns)
        return NULL;

    Ns->v = &NtNsVtbl;
    Ns->RefCnt = 1;
    Ns->Handle = INVALID_HANDLE_VALUE; /* no such thing for dirs */

    return iNS(Ns);
}

PRIVATE UINT MCT NtFileAddRef(PIFILE This)
{
    DPRINT(("NtFileADDREF"));
    return AtomicInc(&pNF(This)->RefCnt);
}

PRIVATE UINT MCT NtNsAddRef(PINAMESPACE This)
{
    DPRINT(("NSaddref"));
    return AtomicInc(&pNS(This)->RefCnt);
}

PRIVATE SCODE MCT NtFileQueryInterface(PIFILE This, REFIID pIid, void* *ppNew)
{
#if 1
    if (UuidCmp(&IID_IFile, pIid) || UuidCmp(&IID_IUnknown, pIid)) {
        DPRINT(("NtFileQIok"));
        NtFileAddRef(This);
        *ppNew = This;
        return NO_ERROR;
    }
#endif
    DPRINT(("NtFileQIfail"));
    *ppNew = NULL;
    return E_NO_INTERFACE;
}

PRIVATE SCODE MCT NtNsQueryInterface(PINAMESPACE This, REFIID pIid, void* *ppNew)
{
#if 1
    if (UuidCmp(&IID_INameSpace, pIid) || UuidCmp(&IID_IUnknown, pIid)) {
        DPRINT(("NSqiok"));
        NtNsAddRef((PINAMESPACE) This);
        *ppNew = This;
        return NO_ERROR;
    }
#endif
    DPRINT(("NSqifail"));
    *ppNew = NULL;
    return E_NO_INTERFACE;
}

PRIVATE UINT MCT NtFileRelease(PIFILE pThis)
{
    PNTFILE File = pNF(pThis);
    INT Refs;
    UINT32 State;
    BOOL ok;

    Refs = AtomicDec(&File->RefCnt);
    DPRINT(("NtFileRELE%d", Refs));
    if (Refs == 0) {
        TURN_INTERRUPTS_OFF(State);
        ok = CloseHandle(File->Handle);
        RESTORE_INTERRUPTS(State);
        if (!ok)
            printf("NtFileRelease(%x) failed sc=%x Handle=%x\n",
                   File, NT_GetLastError(), File->Handle);
        free(File);
    }

    return Refs;
}

PRIVATE UINT MCT NtNsRelease(PINAMESPACE pThis)
{
    PNTNS Ns = pNS(pThis);
    INT Refs;

    Refs = AtomicDec(&Ns->RefCnt);
    DPRINT(("NtNsRELE%d", Refs));
    if (Refs == 0) {
        free(Ns);
    }

    return Refs;
}

static HANDLE TheCompletionPort = INVALID_HANDLE_VALUE;
HANDLE TheCompletionEvent = INVALID_HANDLE_VALUE;
void InitNtFileStuff()
{
    TheCompletionPort = CreateIoCompletionPort(INVALID_HANDLE_VALUE,NULL,0,0);
    assert(TheCompletionPort != INVALID_HANDLE_VALUE);

    TheCompletionEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
    assert(TheCompletionEvent != INVALID_HANDLE_VALUE);
}

/* All we do here is signal the condition that is waiting for
 * a particular i/o to complete.  The OVERLAPPED is followed by the condition.
 */
void ActualIoCompletionInterrupt()
{
    BOOL ok;
    DWORD Transferred, Key;
    OVERLAPPED *pol;
    MYOVERLAPPED *mo;

    ok = GetQueuedCompletionStatus(TheCompletionPort, &Transferred,
                                   &Key, &pol, 0);
    DPRINT(("ActualIoCompletionInterrupt ok=%x transferred=%x\n",
           ok, Transferred));
    if (!ok)
        return;

    mo = (MYOVERLAPPED *) pol;
    Condition_InterruptSignal(&mo->cnd);
}


static void FileRequestCompletions(PIFILE This)
{
    HANDLE h;
    PNTFILE File = pNF(This);

    h = CreateIoCompletionPort(File->Handle, TheCompletionPort, (DWORD)File,0);
    assert(h == TheCompletionPort);
    assert(h != INVALID_HANDLE_VALUE);
}

PRIVATE SCODE MCT NtFileGetSize(PIFILE This, PUINT64 pSize);

PRIVATE SCODE MCT
NtFileReadAt(PIFILE This, UINT64 Position, 
             BYTE *Buffer, UINT ByteCount, UINT * pSizeRead)
{
    UINT32 State;
    PNTFILE File = pNF(This);
    SCODE sc = SUCCESS;
    BOOL r;
    MYOVERLAPPED mo;            /* NT type */

    *(UINT64*)&mo.ol.Offset = Position;
    if (File->IsSocket)
        mo.ol.hEvent = TheCompletionEvent;
    else
        mo.ol.hEvent = NULL;
    Condition_Init(&mo.cnd);

    DPRINT(("read %s pos %lx (x%x.%x) count x%x file %x\n",
            File->IsSocket ? "socket" : "file",
            Position, mo.ol.OffsetHigh, mo.ol.Offset, ByteCount,(UINT32)File));

    TURN_INTERRUPTS_OFF(State);
    r = ReadFile(File->Handle, Buffer, ByteCount, pSizeRead, &mo.ol);
    RESTORE_INTERRUPTS(State);
    if (r==FALSE) {
        sc = NT_GetLastError();
        if (sc == ERROR_HANDLE_EOF) {
            /* at or past EOF ? we need to know */
            UINT64 Size64;
            SCODE sc1 = NtFileGetSize(This, &Size64);
            sc = S_FALSE;
            if (!FAILED(sc1) && (Position > Size64))
                sc = E_INVALID_PARAMETER;
            assert(*pSizeRead == 0);
            DPRINT(("read(x%x) => x%x  sc=x%x\n",
                    (UINT32) File, *pSizeRead, sc/*, Buffer*/));

            return sc;
        }
    }

    if (File->IsSocket) {
        sc = SUCCESS;
        DPRINT(("IoWait...\n"));
        Condition_Wait(&mo.cnd, NULL, NULL);
        TURN_INTERRUPTS_OFF(State);
        assert(State == 0);
        if (GetOverlappedResult(File->Handle, &mo.ol, pSizeRead,TRUE)==FALSE) {
            sc = NT_GetLastError();
            assert(sc == ERROR_IO_INCOMPLETE);
            assert(FALSE);
        }
        RESTORE_INTERRUPTS(State);
    }

    if ((sc == ERROR_HANDLE_EOF) ||
        ((sc == SUCCESS) && (*pSizeRead < ByteCount)))
        sc = S_FALSE;
    else
        sc = error_code_NT2MMLite(sc, "NtFileReadAt");

#if 0
    if (*pSizeRead == 0) /* waziz?!?*/
        sc = S_FALSE;
#endif

    DPRINT(("read(x%x) => x%x  sc=x%x\n",
            (UINT32) File, *pSizeRead, sc/*, Buffer*/));

    return sc;
}

PRIVATE SCODE MCT
NtFileWriteAt(PIFILE This, UINT64 Position, 
               const BYTE *Buffer, UINT ByteCount, UINT * pSizeWritten)
{
    UINT32 State;
    SCODE sc = SUCCESS;
    PNTFILE File = pNF(This);
    OVERLAPPED ol;              /* NT type */

    *(UINT64*)&ol.Offset = Position;
    ol.hEvent = NULL;

    TURN_INTERRUPTS_OFF(State);
    if (WriteFile(File->Handle, Buffer, ByteCount, pSizeWritten,&ol) ==FALSE) {
        sc = NT_GetLastError();
        if ((sc == ERROR_IO_PENDING) &&
            (GetOverlappedResult(File->Handle,&ol,pSizeWritten,TRUE)==FALSE)){
            sc = NT_GetLastError();
            assert(sc == ERROR_IO_INCOMPLETE);
            assert(FALSE);
        }
    }
    RESTORE_INTERRUPTS(State);

    return error_code_NT2MMLite(sc, "NtFileWriteAt");
}

/* Get/Set a file's size
 */
PRIVATE SCODE MCT NtFileGetSize(PIFILE This, PUINT64 pSize)
{
    UINT32 State;
    SCODE sc = SUCCESS;
    PNTFILE File = pNF(This);
    DWORD sizeLow, sizeHigh;

    sizeHigh = (DWORD) -1;
    TURN_INTERRUPTS_OFF(State);
    sizeLow = GetFileSize(File->Handle, &sizeHigh);
    if (sizeLow == 0xffffffff)
        sc = NT_GetLastError();
    else
        *pSize = (UINT64)(sizeLow) | (((UINT64)sizeHigh) << 32);
    RESTORE_INTERRUPTS(State);
    return error_code_NT2MMLite(sc, "NtFileGetSize");
}

PRIVATE SCODE MCT NtFileSetSize(PIFILE This, UINT64 Size)
{
    UINT32 State;
    SCODE sc = SUCCESS;
    PNTFILE File = pNF(This);

    /* We do not truncate files (should ?)
     */
    sc = STATUS_WIN32_ERROR(  87);

    /* Cache probe ?
     */
    if (Size == (UINT64)(~0)) {
        //printf("simfiled: Cache probe unimplemented\n");
#if 0
        if (Conn->CacheTimestamp != CacheTimestamp) {
            sc = /*E_MEDIA_CHANGED*/ STATUS_WIN32_ERROR(1110);
            Conn->CacheTimestamp = CacheTimestamp;
        }
#endif
    } else {
        TURN_INTERRUPTS_OFF(State);
        /* First seek to the right position and then set the size */
        if(SetFilePointer(File->Handle, (UINT32) Size, NULL, FILE_BEGIN)
           == 0xffffffff)
            sc = NT_GetLastError();
        else if (!SetEndOfFile(File->Handle))
            sc = NT_GetLastError();
        else
            sc = S_OK;
        RESTORE_INTERRUPTS(State);
        sc = error_code_NT2MMLite(sc, "NtFileSetSize");
    }
    
    return sc;
}

PRIVATE SCODE MCT Unimp()
{
    return E_NOT_IMPLEMENTED;
}

#pragma warning(disable:4152)   /* data conversion in expression */

const struct INameSpaceVtbl NtNsVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    NtNsQueryInterface,
    NtNsAddRef,
    NtNsRelease,
    (void *) Unimp,
    (void *) Unimp,
#if 0
    NtNsBind,
    NtNsFindFirst,
    NtNsFindNext,
#endif
    (void *) Unimp
};

const struct IFileVtbl NtFileVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    NtFileQueryInterface, 
    NtFileAddRef, 
    NtFileRelease, 
    NtFileReadAt, 
    NtFileWriteAt, 
    NtFileSetSize, 
    NtFileGetSize
};

#if 1
/*------------------ "methods" ------------------------------*/
#if 1
#define ByteSwapUnicodeString(_ws_)
#define ByteSwap16(_val_) (_val_)
#define ByteSwap32(_val_) (_val_)
#define ByteSwap64(_val_,_p_) (*(_p_)) = (_val_)
#else
void ByteSwapUnicodeString(wchar_t *s)
{
    wchar_t *p;

    for (p = s; *p != 0; p++)
        *p = ByteSwap16(*p);
}
#endif

static HANDLE MakePipe(
    const _TCHAR *name)
{
    HANDLE Pipe;

#define DEFAULT_SIZE (4*1024)
    Pipe = CreateNamedPipe(name,
                           PIPE_ACCESS_DUPLEX,
                           PIPE_TYPE_BYTE |
                           PIPE_READMODE_BYTE |
                           PIPE_WAIT,
                           PIPE_UNLIMITED_INSTANCES,
                           DEFAULT_SIZE,     // output buffer size
                           DEFAULT_SIZE,     // input buffer size
                           INFINITE,   // default timeout
                           NULL       // security attrib
                           );
    if (Pipe == INVALID_HANDLE_VALUE)
        return NULL;

    _tprintf(_T("Waiting for connection on pipe %s\n"), name);

    if (ConnectNamedPipe(Pipe,NULL))
        return Pipe;

    CloseHandle(Pipe);
    return NULL;
}

BOOL may_write = TRUE;

void do_open(struct packet *p, PCONNECTION Conn)
{
    struct open_req *req = &p->u.open_req;
    struct open_rep *rep = &p->u.open_rep;
    SCODE sc = SUCCESS;
    UINT flags = ByteSwap32(req->flags);
    UINT openflags = 0, createflags = 0, Handle = 0;
    HOSTFS_TCHAR *filename;
    BOOL isdir = FALSE, ok;
    HANDLE file = NULL;
    UINT32 State;

    ByteSwapUnicodeString(req->path);

    if (flags & 0x20)                   /* NAME_SPACE_FAILIFEXISTS */
        createflags = CREATE_NEW;
    else if (flags & 0x10)              /* NAME_SPACE_CREATE */
        createflags = OPEN_ALWAYS;
    else
        createflags = OPEN_EXISTING;

    if (flags & 1)                      /* NAME_SPACE_READ */
        openflags |= GENERIC_READ;
    if (flags & 2)                      /* NAME_SPACE_WRITE */
        openflags |= GENERIC_WRITE;

    /* Interpret zero as read */
    if ((flags & 3) == 0)
        openflags |= GENERIC_READ;

    if (flags & 0x800) {                /* XXX   F_DIRECTORY: mkdir */
        isdir = TRUE;
        if (!(openflags & GENERIC_WRITE)) {
            DPRINT(("Can't create directory without NAME_SPACE_WRITE\n"));
            sc = STATUS_WIN32_ERROR(5);
            goto replystuff;
        }
    }

    if (!may_write
        && (openflags != GENERIC_READ || createflags != OPEN_EXISTING))
    {
        DPRINT(("Rejected \"%s\" flags=x%x because server is Read Only\n",
                   req->path, flags));
        sc = STATUS_WIN32_ERROR(5);     /* E_ACCESS_DENIED */
        goto replystuff;
    }

    filename = req->path;
    /* Check for \\.\ escape */
    if (_tcsncmp(filename, _T("...."), 4) == 0) {
        filename[0] = filename[1] = filename[3] = '\\';
        filename[2] = '.';
    }

    if (isdir) {
        /* In the end it might be better to have a separate RPC for mkdir */
        TURN_INTERRUPTS_OFF(State);
        ok = CreateDirectory(filename, NULL);
        if (ok == FALSE) {
            sc = NT_GetLastError();
            RESTORE_INTERRUPTS(State);
            DPRINT(("NOT! "));
        } else {
            RESTORE_INTERRUPTS(State);
            Handle = put_NS(AllocNtNs(), Conn, req->path);
        }
    } else if (filename[0] == _T('@')) { /* socket */
        PIFILE nf;
        SOCKET Sock;
        char server[20];
        _TCHAR *n = filename + 1;
        struct sockaddr_in sin;
        UINT i, i_port = 0;

        for (i = 0; *n != _EOS; i++, n++) {
            assert(i < 20);
            if (*n == _T(':')) {
                i_port = _ttoi(++n);
                server[i] = _EOS;
                break;
            }
            server[i] = (char) *n;
        }
        TURN_INTERRUPTS_OFF(State);
        Sock = socket(AF_INET, SOCK_STREAM, 0);
        assert(Sock != INVALID_SOCKET);
        sin.sin_family = AF_INET;
        sin.sin_port = htons((UINT16) i_port);
        sin.sin_addr.s_addr = inet_addr(server);
        i = connect(Sock, (struct sockaddr *) &sin, sizeof sin);
        RESTORE_INTERRUPTS(State);
        assert(i == 0);
        nf = AllocNtFile((HANDLE) Sock, TRUE);
        Handle = put_FILE(nf, Conn, req->path);
    } else {
        TURN_INTERRUPTS_OFF(State);

        if ((flags & NAME_SPACE_CREATE)
            && filename[0] == L'\\' && filename[1] == L'\\'
            && !_tcsncmp(filename+2+_tcscspn(filename+2, _T("\\")),
                         _T("\\pipe\\"), 6)) {
            /* Named pipe \\host\pipe\foo */
            file = MakePipe(filename);
        } else {
            file = CreateFile(filename,
                              openflags,
                              FILE_SHARE_READ|FILE_SHARE_WRITE,
                              NULL,
                              createflags,
                              FILE_ATTRIBUTE_NORMAL /* | FILE_FLAG_OVERLAPPED */,
                              NULL);
        }
        if (file == INVALID_HANDLE_VALUE) {
            sc = NT_GetLastError();
            RESTORE_INTERRUPTS(State);
            DPRINT(("NOT! "));
        } else {
            PIFILE nf;
            RESTORE_INTERRUPTS(State);
            nf = AllocNtFile(file, FALSE);
            Handle = put_FILE(nf, Conn, req->path);
        }
    }
    DPRINT(("Opened \"%s\" (%s) %s as file x%x handle x%x sc=x%x sizeof(*p)=%x\n",
               filename, (HOSTFS_TCHAR *) req->path,
               (openflags & GENERIC_WRITE)
               ? (isdir ? "New directory" : "WRITABLE")
               : "read only",
               (UINT) Handle, file, sc, sizeof(*p)));
 replystuff:
    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_OPEN_REP);
    p->sc = error_code_NT2MMLite(sc, "do_open");
    rep->handle = Handle;
    packet_prepare(p, sizeof(*rep));
}

void do_delete(struct packet *p, PCONNECTION Conn)
{
    struct delete_req *req = &p->u.open_req;/*overlap, same reqs */
    BOOL r;
    SCODE sc = SUCCESS;
    HOSTFS_TCHAR *objectname;
    UINT32 State;

    ByteSwapUnicodeString(req->path);
    objectname = req->path;

    /* try first to delete as file, then as dir.
     * yes, this mangles error reporting a bit.
     */
    TURN_INTERRUPTS_OFF(State);
    r = DeleteFile(objectname);
    RESTORE_INTERRUPTS(State);

    if (!r) {
        sc = GetLastError();
        if (sc == ERROR_ACCESS_DENIED) {
            TURN_INTERRUPTS_OFF(State);
            r = RemoveDirectory(objectname);
            RESTORE_INTERRUPTS(State);
            if (!r)
                sc = GetLastError();
            else
                sc = SUCCESS;
        }
    }
    DPRINT(("%sDeleted \"%ls\" sc=x%x\n",
            (r) ? "" : "NOT! ",
            objectname,
            sc));

    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_DELETE_REP);
    p->sc = error_code_NT2MMLite(sc, "do_delete");
    packet_prepare(p, 0);
}

void do_close(struct packet *p, PCONNECTION Conn)
{
    struct close_req *req = &p->u.close_req;
    PIFILE nf;
    SCODE sc = SUCCESS;

    DPRINT(("do_close handle x%x\n", req->handle));
    nf = get_FILE(req->handle, Conn);

    NtFileRelease(nf);

    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_CLOSE_REP);
    p->sc = error_code_NT2MMLite(sc, "do_close");
    packet_prepare(p, 0);
}

void do_getsize(struct packet *p, PCONNECTION Conn)
{
    struct getsize_req *req = &p->u.getsize_req;
    struct getsize_rep *rep = &p->u.getsize_rep;
    PIFILE File;
    UINT64 Size64;

    File = get_FILE(req->handle, Conn);
    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_GETSIZE_REP);

    p->sc = NtFileGetSize(File, &Size64);

    DPRINT(("getsize(x%x) => %lx (x%x.%x)  sc=x%x\n", (UINT32)File, Size64, Size64, p->sc));

    /* compilerbug->byref */
    ByteSwap64(Size64,&rep->size);

    packet_prepare(p, sizeof(*rep));
}

/* Partial implementation: if size is set to -1, check if floppy changed */
void do_setsize(struct packet *p, PCONNECTION Conn)
{
    struct setsize_req *req = &p->u.setsize_req;
    PIFILE File;
    SCODE sc = SUCCESS;

    File = get_FILE(req->handle, Conn);

    packet_init(p, PACKET_TYPE_SETSIZE_REP);
    p->sc = NtFileSetSize(File, req->size);
    packet_prepare(p, 0);
}

void do_read(struct packet *p, PCONNECTION Conn)
{
    struct read_req *req = &p->u.read_req;
    struct read_rep *rep = &p->u.read_rep;
    PIFILE File;
    UINT count, n;
    UINT64 Pos;

    File = get_FILE(req->handle, Conn);
    count = ByteSwap32(req->count);
    ByteSwap64(req->position, &Pos);

    if (count > MAX_READ_SIZE)
        count = MAX_READ_SIZE;

    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_READ_REP);

    p->sc = NtFileReadAt(File, Pos, rep->data, count, &n);

    rep->nread = ByteSwap32(n);
    packet_prepare(p, sizeof(*rep) - (MAX_READ_SIZE - n));
}

void do_write(struct packet *p, PCONNECTION Conn)
{
    struct write_req *req = &p->u.write_req;
    struct write_rep *rep = &p->u.write_rep;
    PIFILE File;
    SCODE sc = SUCCESS;
    UINT count, n;
    UINT64 Pos;

    File = get_FILE(req->handle, Conn);
    count = ByteSwap32(req->count);
    ByteSwap64(req->position, &Pos);

    sc = NtFileWriteAt(File, Pos, req->data, count, &n);

    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_WRITE_REP);
    p->sc = sc;
    rep->nwritten = ByteSwap32(n);
    packet_prepare(p, sizeof(*rep));
}

/* 
 */
SCODE findnext_helper(const HOSTFS_TCHAR *prefix, const HOSTFS_TCHAR *previous,
                                                      WIN32_FIND_DATA *search)
{
    HOSTFS_TCHAR path[MAX_PATH * 2];
    HANDLE dir;
    SCODE sc = SUCCESS;
    UINT32 State;

    if (_tcslen(prefix) == 0) {
        _tcscpy(path, _T("*"));
    } else {
        _tcscpy(path,prefix);
        _tcscat(path,_T("\\*"));
    }

    /* Assume error */
    sc = error_code_NT2MMLite(ERROR_FILE_NOT_FOUND,"do_findnext");

    TURN_INTERRUPTS_OFF(State);
    dir = FindFirstFile(path,search);

    /*printf("findnext_helper FFW %s->%x %x\n", prefix, dir, GetLastError());*/
    if (dir == INVALID_HANDLE_VALUE) {
        RESTORE_INTERRUPTS(State);
        return sc;
    }

    if (previous[0] == L'\0')  /* This is a FindFirst */
        sc = S_OK;
    else {
        do {
            if (_tcscmp(previous,search->cFileName) == 0) { /* Found previous */

                if (FindNextFile(dir,search)) {
                    /* Found next */
                    WIN32_FIND_DATA util;
                    memcpy((void*) &util, (const void*) search, sizeof(WIN32_FIND_DATA));
                    if (FindNextFile(dir, &util))
                        sc = S_OK;
                    else
                        sc = S_NO_MORE_ENTRIES;
                }
                else {                         /* Previous was last */
                    search->cFileName[0] = _T('\0');
                    sc = S_FALSE;
                }
                break;
            }
        } while (FindNextFile(dir,search));
    }

    FindClose(dir);
    RESTORE_INTERRUPTS(State);
    return sc;
}

void do_findnext(struct packet *p, PCONNECTION Conn)
{
    struct findnext_req *req = &p->u.findnext_req;
    struct findnext_rep *rep = &p->u.findnext_rep;
    SCODE sc = SUCCESS;
    WIN32_FIND_DATA SearchData;

    UnusedParameter(Conn);

    sc = findnext_helper(req->prefix,req->previous,&SearchData);
    /*printf("do_findnext(\"%ls\", \"%ls\") -> %x \"%ls\"\n",
      req->prefix, req->previous, sc, SearchData.cFileName);*/
    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_FINDNEXT_REP);
    /* Copy path to reply msg. */
    _tcsncpy(rep->name, SearchData.cFileName, sizeof(rep->name)/sizeof(rep->name[0]) - 1);
    /* make sure it is zero terminated */
    rep->name[sizeof(rep->name)/sizeof(rep->name[0]) - 1] = 0;
    p->sc = sc;
    packet_prepare(p, sizeof(*rep));
}

/* 
 * Use one thread per socket.  One socket has only one transaction
 * going on at a time.
 * Windowing etc. is achieved by using multiple sockets.
 */
#endif

SCODE SimFile_Server(struct packet *p)
{
    PCONNECTION Conn = NULL;

    p->sc = ByteSwap32(p->sc);

    switch (p->packet_type) {
    case PACKET_TYPE_OPEN_REQ:
        do_open(p, Conn);
        break;
    case PACKET_TYPE_CLOSE_REQ:
        do_close(p, Conn);
        break;
    case PACKET_TYPE_GETSIZE_REQ:
        do_getsize(p, Conn);
        break;
    case PACKET_TYPE_SETSIZE_REQ:
        do_setsize(p, Conn);
        break;
    case PACKET_TYPE_READ_REQ:
        do_read(p, Conn);
        break;
    case PACKET_TYPE_WRITE_REQ:
        do_write(p, Conn);
        break;
    case PACKET_TYPE_FINDNEXT_REQ:
        do_findnext(p, Conn);
        break;
    case PACKET_TYPE_DELETE_REQ:
        do_delete(p, Conn);
        break;
    default:
        printf("Unknown packet type x%x\n", p->packet_type);
        p->sc = 0x88888888; 
    }

    p->packet_length = ByteSwap16(p->packet_length);
    p->sc = ByteSwap32(p->sc);
    return S_OK;                /* blah */
}

SCODE SimFile_Init()
{
    return S_OK;
}
