/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Copyright (c) 1982, 1986, 1989, 1993
 *    The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the University of
 *    California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *    @(#)if.h    8.1 (Berkeley) 6/10/93
 */

/*
 * Structures defining a network interface, providing a packet
 * transport mechanism (ala level 0 of the PUP protocols).
 *
 * Each interface accepts output datagrams of a specified maximum
 * length, and provides higher level routines with input datagrams
 * received from its medium.
 *
 * Output occurs when the routine if_output is called, with three parameters:
 *    (*ifp->if_output)(ifp, m, dst, rt)
 * Here m is the mbuf chain to be sent and dst is the destination address.
 * The output routine encapsulates the supplied datagram if necessary,
 * and then transmits it on its medium.
 *
 * On input, each interface unwraps the data received by it, and either
 * places it on the input queue of a internetwork datagram routine
 * and posts the associated software interrupt, or passes the datagram to a raw
 * packet input routine.
 *
 * Routines exist for locating interfaces by their addresses
 * or for locating a interface on a certain network, as well as more general
 * routing and gateway routines maintaining information used to locate
 * interfaces.  These routines live in the files if.c and route.c
 */

#ifndef __IF_H
#define __IF_H 1

/*
 * Forward structure declarations for function prototypes [sic].
 */
#ifndef __SOCK__
struct socket; /* quiet some compiler's noise */
#endif
struct ether_header;

/*
 * Interface methods, see mmhal.h::INetDriver
 */

/*
 * Structure defining a queue for a network interface.
 *
 * (Would like to call this struct ``if'', but C isn't PL/1.)
 */
struct if_data;
struct ifqueue;

struct ifnet {
    /* inherit: CNetDriver */
    const struct INetDriverVtbl* v;    /* network driver vtable */
    INT RefCnt;                  /* reference count */
    CONDITION IntrPoint;         /* synch with Isr thread */
    PIENDPOINTFACTORY MBufFact;

    const char *if_name;               /* name, e.g. ``en'' or ``lo'' */
    struct ifnet *if_next;       /* all struct ifnets are chained */
    struct ifaddr *if_addrlist;  /* linked list of addresses per if */
    INT if_pcount;               /* number of promiscuous listeners */
    PTR if_bpf;                  /* packet filter structure */
    UINT16 if_index;             /* numeric abbreviation for this if  */
    INT16 if_unit;               /* sub-unit for lower level driver */
    INT16 if_timer;              /* time 'til if_watchdog called */
    UINT16 if_flags;             /* up/down, broadcast, etc. */

    struct DhcpInfo *pDhcpInfo;
/*
 * Structure describing information about an interface
 * which may be of interest to management entities.
 */
    struct if_data {
/* generic interface information */
        UINT8 ifi_type;       /* ethernet, tokenring, etc */
        UINT8 ifi_addrlen;    /* media address length */
        UINT8 ifi_hdrlen;     /* media header length */
        UINT8 xxx_pad;        /* lets keep alignment, shall we ? */
        UINT ifi_mtu;         /* maximum transmission unit */
        UINT ifi_metric;      /* routing metric (external only) */
        UINT ifi_baudrate;    /* linespeed */
/* volatile statistics */
        UINT ifi_ipackets;    /* packets received on interface */
        UINT ifi_ierrors;     /* input errors on interface */
        UINT ifi_opackets;    /* packets sent on interface */
        UINT ifi_oerrors;     /* output errors on interface */
        UINT ifi_collisions;  /* collisions on csma interfaces */
        UINT ifi_ibytes;      /* total number of octets received */
        UINT ifi_obytes;      /* total number of octets sent */
        UINT ifi_imcasts;     /* packets received via multicast */
        UINT ifi_omcasts;     /* packets sent via multicast */
        UINT ifi_iqdrops;     /* dropped on input, this interface */
        UINT ifi_noproto;     /* destined for unsupported protocol */
        UINT ifi_errors[8];   /* errors counters, among them: */
#define IFI_ERR_MISS  0       /* missed recv packets */
#define IFI_ERR_RESET 1       /* had to be reset */
#define IFI_ERR_XTIM  2       /* failed to xmita pkt */
#define IFI_ERR_MEM   3       /* memory errors (DMA, ..) */
#define IFI_ERR_XSUM  4       /* bad checksum in rcv pkt */
        TIME ifi_lastchange;  /* last updated */
    } if_data;
    struct ifqueue {
        struct mbuf *ifq_head;
        struct mbuf *ifq_tail;
        INT ifq_len;
        INT ifq_maxlen;
        INT ifq_drops;
    } if_snd;  /* output queue */
};
/* Conversion between interface and concrete class */
#define pIF(i) ((struct ifnet *) i)
#define iIF(p) ((PINETDRIVER) p)

#define if_mtu        if_data.ifi_mtu
#define if_type       if_data.ifi_type
#define if_addrlen    if_data.ifi_addrlen
#define if_hdrlen     if_data.ifi_hdrlen
#define if_metric     if_data.ifi_metric
#define if_baudrate   if_data.ifi_baudrate
#define if_ipackets   if_data.ifi_ipackets
#define if_ierrors    if_data.ifi_ierrors
#define if_opackets   if_data.ifi_opackets
#define if_oerrors    if_data.ifi_oerrors
#define if_collisions if_data.ifi_collisions
#define if_ibytes     if_data.ifi_ibytes
#define if_obytes     if_data.ifi_obytes
#define if_imcasts    if_data.ifi_imcasts
#define if_omcasts    if_data.ifi_omcasts
#define if_iqdrops    if_data.ifi_iqdrops
#define if_noproto    if_data.ifi_noproto
#define if_errors     if_data.ifi_errors
#define if_lastchange if_data.ifi_lastchange

#define IFF_UP          0x1     /* interface is up */
#define IFF_BROADCAST   0x2     /* broadcast address valid */
#define IFF_DEBUG       0x4     /* turn on debugging */
#define IFF_LOOPBACK    0x8     /* is a loopback net */
#define IFF_POINTOPOINT 0x10    /* interface is point-to-point link */
#define IFF_ADHOC       0x20    /* used for ad hoc routing (was NOTRAILERS) */
#define IFF_RUNNING     0x40    /* resources allocated */
#define IFF_NOARP       0x80    /* no address resolution protocol */
#define IFF_PROMISC     0x100   /* receive all packets */
#define IFF_ALLMULTI    0x200   /* receive all multicast packets */
#define IFF_OACTIVE     0x400   /* transmission in progress */
#define IFF_SIMPLEX     0x800   /* can't hear own transmissions */
#define IFF_ZEROCOPY    0x1000  /* will not copy outgoing packets */
#define IFF_xxx         0x2000  /* reserved */
#define IFF_NOADDR      0x4000  /* interface is receiving w/o link address */
#define IFF_MULTICAST   0x8000  /* supports multicast */


/* flags set internally only: */
#define IFF_CANTCHANGE \
    (IFF_BROADCAST|IFF_POINTOPOINT|IFF_RUNNING|IFF_OACTIVE|\
        IFF_SIMPLEX|IFF_MULTICAST|IFF_ALLMULTI)

/*
 * Output queues (ifp->if_snd) and internetwork datagram level (pup level 1)
 * input routines have queues of messages stored on ifqueue structures
 * (defined above).  Entries are added to and deleted from these structures
 * by these macros, which should be called with ipl raised to splimp().
 */
#define IF_QFULL(ifq) ((ifq)->ifq_len >= (ifq)->ifq_maxlen)
#define IF_DROP(ifq) ((ifq)->ifq_drops++)
#define IF_ENQUEUE(ifq, m) { \
    (m)->m_nextpkt = 0; \
    if ((ifq)->ifq_tail == 0) \
        (ifq)->ifq_head = m; \
    else \
        (ifq)->ifq_tail->m_nextpkt = m; \
    (ifq)->ifq_tail = m; \
    (ifq)->ifq_len++; \
}
#define IF_PREPEND(ifq, m) { \
    (m)->m_nextpkt = (ifq)->ifq_head; \
    if ((ifq)->ifq_tail == 0) \
        (ifq)->ifq_tail = (m); \
    (ifq)->ifq_head = (m); \
    (ifq)->ifq_len++; \
}
#define IF_DEQUEUE(ifq, m) { \
    (m) = (ifq)->ifq_head; \
    if (m) { \
        if (((ifq)->ifq_head = (m)->m_nextpkt) == 0) \
            (ifq)->ifq_tail = 0; \
        (m)->m_nextpkt = 0; \
        (ifq)->ifq_len--; \
    } \
}

#define IFQ_MAXLEN   50
#define IFNET_SLOWHZ 1   /* granularity is 1 second */

/*
 * The ifaddr structure contains information about one address
 * of an interface.  They are maintained by the different address families,
 * are allocated and attached when an address is set, and are linked
 * together so all addresses for an interface can be located.
 */
struct ifaddr {
    struct sockaddr *ifa_addr;     /* address of interface */
    struct sockaddr *ifa_dstaddr;  /* other end of p-to-p link */
#define ifa_broadaddr ifa_dstaddr  /* broadcast address interface */
    struct sockaddr *ifa_netmask;  /* used to determine subnet */
    struct ifnet *ifa_ifp;         /* back-pointer to interface */
    struct ifaddr *ifa_next;       /* next address for interface */
    UINT16 ifa_flags;              /* mostly rt_flags for cloning */
    INT16 ifa_refcnt;              /* extra to malloc for link info */
    INT ifa_metric;                /* cost of going out this interface */
};
#define IFA_ROUTE RTF_UP  /* route installed */

/*
 * Message format for use in obtaining information about interfaces
 * from getkerninfo and the routing socket
 */
struct if_msghdr {
    UINT16 ifm_msglen;        /* to skip over non-understood messages */
    UINT8 ifm_version;        /* future binary compatability */
    UINT8 ifm_type;           /* message type */
    INT ifm_addrs;            /* like rtm_addrs */
    INT ifm_flags;            /* value of if_flags */
    UINT16 ifm_index;         /* index for associated ifp */
    struct if_data ifm_data;  /* statistics and other data about if */
};

/*
 * Message format for use in obtaining information about interface addresses
 * from getkerninfo and the routing socket
 */
struct ifa_msghdr {
    UINT16 ifam_msglen;  /* to skip over non-understood messages */
    UINT8 ifam_version;  /* future binary compatability */
    UINT8 ifam_type;     /* message type */
    INT ifam_addrs;      /* like rtm_addrs */
    INT ifam_flags;      /* value of ifa_flags */
    UINT16 ifam_index;   /* index for associated ifp */
    INT ifam_metric;     /* value of ifa_metric */
};

/*
 * Interface request structure used for socket
 * ioctl's.  All interface ioctl's must have parameter
 * definitions which begin with ifr_name.  The
 * remainder may be interface specific.
 */
struct ifreq {
#define IFNAMSIZ 16
    char ifr_name[IFNAMSIZ];  /* if name, e.g. "en0" */
    union {
        struct sockaddr ifru_addr;
        struct sockaddr ifru_dstaddr;
        struct sockaddr ifru_broadaddr;
        UINT16 ifru_flags;
        INT ifru_metric;
        PBYTE ifru_data;
        UINT8 ifru_dhcpflags;
        struct {
            UINT16 opcode;
            UINT16 param;
        } ifru_debug;
    } ifr_ifru;
#define ifr_addr ifr_ifru.ifru_addr            /* address */
#define ifr_dstaddr ifr_ifru.ifru_dstaddr      /* other end of p-to-p link */
#define ifr_broadaddr ifr_ifru.ifru_broadaddr  /* broadcast address */
#define ifr_flags ifr_ifru.ifru_flags          /* flags */
#define ifr_metric ifr_ifru.ifru_metric        /* metric */
#define ifr_data ifr_ifru.ifru_data            /* for use by interface */
#define ifr_dhcpflags ifr_ifru.ifru_dhcpflags  /* DHCP flags */
#define ifr_debug ifr_ifru.ifru_debug          /* dynamic debug aid */
};

struct ifaliasreq {
    _TCHAR ifra_name[IFNAMSIZ];  /* if name, e.g. "en0" */
    struct sockaddr ifra_addr;
    struct sockaddr ifra_broadaddr;
    struct sockaddr ifra_mask;
};

/*
 * Structure used in SIOCGIFCONF request.
 * Used to retrieve interface configuration
 * for machine (useful for programs which
 * must know all networks accessible).
 */
#define IFCONF_MAX_AT_ONCE 8
struct ifconf {
    INT ifc_len;  /* size of associated buffer */
    union {
        UINT ifcu_token;
        struct ifreq ifcu_req[IFCONF_MAX_AT_ONCE];
    } ifc_ifcu;
#define ifc_tok ifc_ifcu.ifcu_token  /* iface to start from, in list */
#define ifc_reql ifc_ifcu.ifcu_req   /* array of structures returned */
};

#include <net/if_arp.h>

#define IFAFREE(ifa) \
    if ((ifa)->ifa_refcnt <= 0) \
        ifafree(ifa); \
    else \
        (ifa)->ifa_refcnt--;

extern struct ifnet *ifnet;

void ether_ifattach(struct ifnet *);
void RTLCALLTYPE ether_input(struct ifnet *, struct ether_header *,
                             struct mbuf *);
struct route_in;
INT RTLCALLTYPE ether_output(struct ifnet *, struct mbuf *, struct sockaddr *,
                             struct route_in *);
char *ether_sprintf(UINT8 *);

void RTLCALLTYPE if_attach(struct ifnet *);
void if_down(struct ifnet *);
void if_qflush(struct ifqueue *);
void if_slowtimo( void );
void if_up(struct ifnet *);
INT ifconf(INT, UINT8 *);
INT ifioctl(struct socket *, INT, UINT8 *);
INT ifpromisc(struct ifnet *, INT);
struct ifnet *ifunit(char *);

struct ifaddr *ifa_ifwithaddr(struct sockaddr *);
struct ifaddr *ifa_ifwithaf(INT);
struct ifaddr *ifa_ifwithdstaddr(struct sockaddr *);
struct ifaddr *ifa_ifwithnet(struct sockaddr *);
struct ifaddr *ifa_ifwithroute(INT, struct sockaddr *,
                    struct sockaddr *);
struct ifaddr *ifaof_ifpforaddr(struct sockaddr *, struct ifnet *);
void ifafree(_Inout_ struct ifaddr *);

void link_rtrequest(INT, struct rtentry *, struct sockaddr *);

INT MCT loioctl(PINETDRIVER, UINT32, PTR);
void loopattach(void);
INT MCT looutput(PINETDRIVER, struct mbuf *, struct sockaddr *,
                 struct route_in *);

#endif /* __IF_H */
