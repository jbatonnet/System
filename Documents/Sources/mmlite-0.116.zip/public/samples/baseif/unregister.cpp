/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Pointer and reference to the system namespace. */
INameSpace *pNS;
SCODE StatusCode;
IUnknown *pObject;
_TCHAR *pName = _TEXT("MyObject");

/* "MyObject" must already be registered in the namespace. */
_tprintf(_T("Attempting to unregister object name \"%s\".\n"),
              pName);
pNS = CurrentNameSpace();
StatusCode = pNS->Unregister(pName);
if(StatusCode != S_OK) {
    _tprintf(_T("Failed to unregister object name!\n"));
    exit(0);
}

/* Verify that object name is no longer registered. */
StatusCode = pNS->Bind(pName, 0, &pObject);
if (StatusCode == S_OK) {
    _tprintf(_T("Error in unregistering object name!\n"));
    pObject->Release();
    exit(0);
}
_tprintf(_T("Succeeded in unregistering object name.\n"));
/* END_SAMPLE */
return 0;
}
