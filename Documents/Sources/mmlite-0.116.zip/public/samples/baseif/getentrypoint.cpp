/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

/* BEGIN_SAMPLE */
/* Prints this module's entry point. */
int _tmain()
{
    IModule *pModule;    /* Pointer to module object. */
    ADDRESS Entry;    /* The module's entry point. */
    SCODE sc;

    /* Get the current module. */
    sc = GetCurrentModule( &pModule );
    if (FAILED(sc)) {
        _tprintf(_T("GetCurrentModule failed with sc = x%x\n"), sc);
        exit(0);
    }

    /* Find entry point value. */
    sc = pModule->GetEntryPoint(&Entry);
    if (FAILED(sc)) {
        _tprintf(_T("GetEntryPoint failed with sc = x%x\n"), sc);
    } else {
        _tprintf(_T("This module's entry point is x%x\n"), Entry);
    }

    /* Release the IModule. */
    pModule->Release();
    return 0;
}
/* END_SAMPLE */
