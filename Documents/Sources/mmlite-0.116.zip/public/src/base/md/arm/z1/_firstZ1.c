/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains FirstThread
 */

#include <mmlite.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <fred.h>
#include <diagnostics.h>

extern PIBASERTL pTheBaseRtl;

#define _SECURE_FS 0

#if _SECURE_FS
static PINAMESPACE ImageNameSpace = NULL;
#endif

PINAMESPACE GetImageNameSpace(void)
{
#if _SECURE_FS
    /* This forbids changing the filesystem where code comes from */
    return ImageNameSpace;
#else
    SCODE r;
    PIUNKNOWN pUnk;
    PINAMESPACE pNs = CurrentNameSpace();

    r = pNs->v->Bind(pNs,
                     _T("fs"),
                     0,
                     &pUnk);
    if (FAILED(r))
        return NULL;

    /* Ok, but is it a namespace
     */
    r = pUnk->v->QueryInterface(pUnk,
                                &IID_INameSpace,
                                (void **) &pNs);

    (void) pUnk->v->Release(pUnk);

    if (FAILED(r))
        return NULL;

    /* This one is not supposed to take a ref so lets do this horrible one */
    (void) pNs->v->Release(pNs);
    
    return pNs;

#endif
}
void SetImageNameSpace(PINAMESPACE pINS)
{
    CurrentNameSpace()->v->Register(CurrentNameSpace(), _T("fs"),
                    (PIUNKNOWN) pINS, 0, NULL);
#if _SECURE_FS
    ImageNameSpace = pINS;
#endif
}


PINAMESPACE InitHostFileSystem(_TCHAR *LinkName);
PINAMESPACE RomFsNew( PTR StartAddress, UINT MaxSize);

/* Leftover linking issues */
INT MODENTRY CrtInit(INT Op)
{
    return 1;/* TRUE */
}

typedef _TCHAR *TSTR;
const TSTR FIRST_IMAGE_NAME = _TEXT("tzk.cob");

/* To help diagnose product boot problems.
 * Should be an LED or something else externally accessible.
 */
int BootStep = 0;

void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    SCODE sc;
    const _TCHAR * Args = _TEXT("");
    PIMODULE pMod;
    PIPROGRAM prog;
    PINAMESPACE pRoot;
    MODULEENTRY EntryPoint;
    PIUNKNOWN pUnk;

    UnusedParameter(arg);

    /* Start the linked-in drivers
     */
    pRoot = CurrentNameSpace();

#define USE_LCD 0
#if USE_LCD
    LcdInit();
    sc = InitDebugConsole();
#endif

    sc = pRoot->v->Bind(pRoot,"COB/drivers.cob", 0, &pUnk);
    if (FAILED(sc)) {
        DBGME(3,printf("drivers.cob failed\n"));
        goto Out;
    }
    BootStep++; 
    /* leak the Unk */

    sc = pRoot->v->Bind(pRoot,"COB/drivercfg.cob", 0, &pUnk);
    if (FAILED(sc)) {
        DBGME(3,printf("drivercfg.cob failed\n"));
        goto Out;
    }
    BootStep++; 
    /* leak the Unk */

#if USE_LCD
#else
    /* Start the console, using the serial line driver
     */
    sc = InitConsole("com1");
#endif
    if (FAILED(sc)) {
        DBGME(3,printf("Failed to create debug console (sc = x%x)\n", sc));
        goto Out;
    }
    BootStep++; 

#if 1
    /* Start HostFs using the serial line driver
     */
    pRoot = InitHostFileSystem("com2");
#else
    /* Start RomFs using the FS image in FLASH
     */
    pRoot = RomFsNew( (PTR) 0x1010000, 0x100000 );
#endif

    if (pRoot == NULL) {
        DBGME(3,printf("FirstThread: InitXXFileSystem failed\n"));
        goto Out;
    }
    BootStep++; 

    SetImageNameSpace(pRoot);
    BootStep++; 

#if 1
    /* Get the Cob's Main method */
    sc = BindToObject(CurrentNameSpace(), _T("COB/tzk.cob"),
                      NAME_SPACE_READ, &IID_IProgram,
                      (void **) &prog);
    if (FAILED(sc)) {
        DBGME(3,printf("FirstThread: Could not load tzk.cob\n"));
        goto Out;
    }

    BootStep++; 
    sc = prog->v->Main(prog, Args ? Args : _T(""));
    prog->v->Release(prog);
#else
    sc = LdrLoadImage(GetImageNameSpace(), FIRST_IMAGE_NAME, Args, 0, &pMod);
    if (FAILED(sc)) {
        DBGME(3,printf("Failed to load %s (sc = x%x)\n", FIRST_IMAGE_NAME,sc));
        goto Out;
    }
    BootStep++; 

    pMod->v->GetEntryPoint(pMod, (ADDRESS *) &EntryPoint);
    EntryPoint(pTheBaseRtl);
    pMod->v->Release(pMod);
#endif

  Out:
    BaseDelete();
}


/* Should be somewhere else but fornow 
*/
SCODE InitConsole(const char *DriverName)
{
    PIUNKNOWN pUnk;
    PINAMESPACE Ns = CurrentNameSpace();
    SCODE sc;

    sc = Ns->v->Bind(Ns,DriverName, 0, &pUnk);
    if (FAILED(sc))
        return sc;

    sc = Ns->v->Register(Ns, _TEXT("stdin"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = Ns->v->Register(Ns, _TEXT("stdout"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = Ns->v->Register(Ns, _TEXT("stderr"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

 Error:
    /* Let our own reference go
     */
    (void) pUnk->v->Release(pUnk);

    return sc;
}

