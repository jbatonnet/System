/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <stdio.h>

/* BEGIN_SAMPLE */
/* MyClass implements only IUnknown. */
struct MyClass : IUnknown {
    SCODE MCT QueryInterface(REFIID riid, void **ppvObject);
    UINT MCT AddRef(void);
    UINT MCT Release(void);
private:
    UINT RefCount;
};

UINT MCT MyClass::Release(void)
{
    UINT Refs = AtomicDec(&RefCount);
    /* Last reference? */
    if(Refs == 0) {
        _tprintf(_T("Object %x is released.\n"), (ADDRESS) this);
        delete this;
    }
    return Refs;
}
/* END_SAMPLE */

void __cdecl operator delete(void *p)
{
    free(p);
}

SCODE MCT MyClass::QueryInterface (REFIID Iid, void* *ppNew)
{
    return GenericQueryInterface(this, Iid, ppNew, IID_IUnknown);
}

UINT MCT MyClass::AddRef (void)
{
    return AtomicInc(&RefCount);
}

int _tmain()
{
    MyClass mc;

    mc.Release();

    return 0;
}
