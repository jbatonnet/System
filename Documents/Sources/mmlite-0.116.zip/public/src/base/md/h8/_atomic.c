/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* *** AtomicCmpAndSwap
 *
 * Compare *pTarget with OldVal.  If equal, set *pTarget to NewVal,
 * return TRUE; else return FALSE.
 */
BOOL AtomicCmpAndSwap(PUINT pTarget, UINT OldVal, UINT NewVal)
{
    UINT OldCount;
    UINT8 istate;
    BOOL ret;

    TURN_INTERRUPTS_OFF(istate);
    OldCount = *pTarget;
    if (OldCount == OldVal) {
        *pTarget = NewVal;
        ret = TRUE;
    } else {
        ret = FALSE;
    }
    RESTORE_INTERRUPTS(istate);
    return ret;
}

/* *** AtomicSwap
 *
 * Atomically swaps NewCount with *pCount and returns the old value.
 */
UINT AtomicSwap(PUINT pCount, UINT NewCount)
{
    UINT8 istate;
    UINT OldCount;

    TURN_INTERRUPTS_OFF(istate);
    OldCount = *pCount;
    *pCount = NewCount;
    RESTORE_INTERRUPTS(istate);

    return OldCount;
}
