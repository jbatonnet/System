/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include "linkage.h"
#include <mmlite.h>
#include <fred.h>
#include <base/cons.h>
#include <schedulif.h>
#include "optims.h"

#if defined(_DEBUG)
#define DBG(_x_) printf _x_
#else
#define DBG(_x_)
#endif

/* xxx globals xxx */
IPic *pThePic = NULL;
PIHEAP pTheHeap = NULL;
PINAMESPACE pTheNameSpace = NULL;
IScheduler *pTheScheduler = NULL;

/*
 * Base initialization.  This is the first MI function ever invoked.
 */
void BaseInit(void)
{
    PITHREAD TheThread;
    SCODE sc;
#if defined(_DEBUG)
    ADDRESS MemBase;
    static int BootCount = 0;

    BootCount++;
    DBG(("BaseInit: %sEntered, stack= ~0x%x\n",(BootCount>1) ? "Re" : "",&MemBase));
#endif

    /* Deal with interrupts first.
     */
    DBG(("BaseInit: Calling PicCreate()\n"));
    pThePic = PicCreate();

    /* Initialize the memory allocator.
     */
    DBG(("BaseInit: Initializing heap\n"));
    pTheHeap = MachineHeapCreate();

    /* Initialize scheduler
     */
    pTheScheduler = SchedulerCreate();

    /* Turn on system timer
     */
    DBG(("BaseInit: Calling EnableTimers()\n"));
    EnableTimers();

    /* Initialize the name space.
     */
    DBG(("BaseInit: Initializing Namespace\n"));
    NameSpaceCreate(&pTheNameSpace);

#if 0
    /* Initialize the loader.
     * Also makes CurrentHeap() work for the thread.
     */
    DBG(("BaseInit: Initializing Loader\n"));
    TheProcess = InitializeIModule(pTheHeap, pTheNameSpace);

    /* Create the first thread. Must succeed.
     */
    DBG(("BaseInit: Creating First Thread\n"));
    (void) TheProcess->v->CreateThread(
                         TheProcess,
                         0,
                         FirstThread,
                         NULL,
                         0,/*default stacksize*/
                         NULL,
                         &TheThread);
#else
    sc = ThreadCreate(NULL,
                      FirstThread,
                      NULL,
                      DEFAULT_STACK_SIZE,
                      0,
                      NULL, NULL,
                      &TheThread);
#endif

    /* This is now the current thread
     */
    ThreadSetCurrent(TheThread);
    (void) TheThread->v->Release(TheThread);

    /* Let scheduler go.
     */
    DBG(("BaseInit: Starting Scheduler\n"));
    {
    TIME Delta;
    BOOL bIgnore;
    Int32ToInt64(Delta,10);
    SetNextInterrupt(Delta,&bIgnore);
    /* on x86 interrupts were actually on when calling SetNextInterrupt
     * so we won't return here unless the interrupt took a while.
     */
    }

    ENABLE_INTERRUPTS();

    Delay(50000);

    /* Should never get here
     */
    DBG(("Failed to start first thread ??..\n"));

}

/*
 * Base finalization
 */
void BaseDelete(void)
{
    DBG(("I have nothing left to do.  Thanks for the ride.\n"));
    PicDelete(pThePic);
    TheEnd();
}
