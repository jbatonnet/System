/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define MMLITE_MP 1
#define SIM 1

#include <string.h>
#include <mmlite.h>
#include <base/schedul.h>
#include <schedulif.h>
#include "fred.h"
#include <_dosx.h>
#include "_ntmmglu.h"


/********************** main.c ******************************************/

extern UINT DelayMultiplier;
extern char *FIRST_IMAGE_NAME;
static char *_cmdline = "";

extern char * NT_GetCommandLineA(void);

/* The big bang.
 */

int main(int argc, char *argv[])
{
    UnusedParameter(argc);
    UnusedParameter(argv);

    DelayMultiplier *= 10000;

    if (argc > 1)
        FIRST_IMAGE_NAME = argv[1];

    if (argc > 2)
        _cmdline = argv[2];

    if (!argv) {
        char *z;
        BOOL quoted;

        z = NT_GetCommandLineA();

        quoted = (*z  == '\"');
        if (quoted)
            z++; /* skip quote IF THERE IS ONE */

        z = _strsplit(z, (quoted) ? "\"" : " ");
        if (z != NULL && *z) {
            if (quoted) z++;         /* skip space IF THERE IS ONE */
            if (*z) {    /* guard against trailing space from VS7 */
                FIRST_IMAGE_NAME = z;
                _cmdline = _strsplit(z, " ");
            }
        }
    }

    NT_Init();

    /* Make it that we can callback to DOS/BIOS
     */
    InitializeDosx(NULL);

#if 0
    /* For more complicated stuff we need a bigger stack.
     */
    __asm {
        mov     bstack,esp;
        mov     esp, offset stack + 1024*4 - 4;
    }
#endif

    /* Initialize interrupt dispatching first.
     */
//    IdtCreate();

    /* Machine-independent initialization and go.
     */
    BaseInit();

    /* Wont return, but just in case...
     */
    __asm {
        jmp     TheEnd;
    }

    return 1;
}

/***************** _timer.c ************************************/
/* Interrupt from PIT chip.
 * Call scheduler.
 */
#pragma warning(disable:4100)
#pragma warning(disable:4101)
__declspec(naked) void __cdecl SchedulingInterrupt(PTR CSeg, UINT32 EFlags)
{
    UINT32 a,b,c,d,e,f,g,h,i,j,k,l;

    /* On stack we have:
     * (high)
     *              saved SS     only if from user level  ;; 32bits
     *              saved ESP    only if from user level  ;; 32bits
     *              saved EFLAGS     ;; 32bits
     *              saved CS         ;; 32bits
     * esp->        saved eip        ;; 32bits
     */
    __asm {
        /* Interrupt frame setup
         */
        push ds;
        push es;
        push gs;
        push fs;
        pushad;
        push 0;                 /* pFpa */

#if 0
        /* Set segment registers to ring0 conventions */
        mov  dx,ss;
        mov  ds,dx;   /* Reference kernel data */
        mov  es,dx;   /* Reference kernel data */
        xor  dx,dx;
        mov  fs,dx;   /* Zapped */
        mov  gs,dx;   /* Zapped */
#endif

#if 0
        /* Quiet PIC (PIT always hangs off master PIC)
         */
        mov al,PIC_NS_EOI;
        out PIC0_PORT,al;
#endif
        /* Do not return here, go directly
         * where we came from (via an iretd)
         */
        call _Reschedule;
        /* no return */
        int 3;
    }
}
#pragma warning(default:4100)
#pragma warning(default:4101)

/*************************** dosx.c ******************************/

DOSX_INTERFACE _Dosx = {0,};
DOSX_COMMAND_LINE _Bull;
extern int *bstack;     /* in main.c */

void InitializeDosx( PDOSX_INTERFACE pIface)
{
    if (pIface)
        _Dosx = *pIface;
    else
    {
        /* BUGBUG get real command line */
        _Dosx.pCommandLine = &_Bull;
    }
}

/* Return a pointer to the info DOSX passed to us.
 */
PTR /*PDOSX_INTERFACE*/ DosxPointer(void)
{
    return (PTR) &_Dosx;
}

const char *BootCmdLine(void)
{
    return _cmdline;
}

/********************************* pic.c ***************************/

#pragma warning(disable:4100)
#pragma message("DUMMY pic")

/* The interrupt dispatcher uses a table of handlers,
 * and a few masks. Things would be much simpler without
 * the BIOS/DOS in the way.. 
 */
typedef struct SimPic {
    const struct IPicVtbl *v;
} SimPic;

/* Forward decl */
extern struct SimPic TheSimPic;

#pragma warning(disable:4701)   /* vc60 doesnt realize pState is initialized */
void ActualIoCompletionInterrupt(void);

__declspec(naked) void _IoCompletionInterrupt(void)
{
    PCXTINFO pState;

    __asm {
        /* Setup pointer to our saved state
         * We dont have to worry about registers, they are saved already.
         */
        mov     eax,esp;
        /* xxx adapt isr entry code to fit into CXTINFO struct
         */
        mov     ebp, esp;
        sub     esp,__LOCAL_SIZE;

        mov     pState,eax;
    }

    ActualIoCompletionInterrupt();
    HWLoadThreadContext(pState);
}

/* Interrupt from PIT chip.
 * Call scheduler.
 */
__declspec(naked) void __cdecl IoCompletionInterrupt()
{
    /* On stack we have:
     * (high)
     *              saved SS     only if from user level  ;; 32bits
     *              saved ESP    only if from user level  ;; 32bits
     *              saved EFLAGS     ;; 32bits
     *              saved CS         ;; 32bits
     * esp->        saved eip        ;; 32bits
     */
    __asm {
        /* Interrupt frame setup
         */
        push ds;
        push es;
        push gs;
        push fs;
        pushad;
        push 0;                 /* pFpa */

#if 0
        /* Set segment registers to ring0 conventions */
        mov  dx,ss;
        mov  ds,dx;   /* Reference kernel data */
        mov  es,dx;   /* Reference kernel data */
        xor  dx,dx;
        mov  fs,dx;   /* Zapped */
        mov  gs,dx;   /* Zapped */
#endif

        /* Do not return here, go directly
         * where we came from (via an iretd)
         */
        jmp _IoCompletionInterrupt;
    }
}

/* Change masks so that we handle an interrupt, and not the BIOS.
 * Install the Isr in the dispatch table, with its argument.
 * Tell the IDT to turn the interrupt to us.
 */
void MCT SimPicEnableInterrupt( IPic *pThis, DEVICE_FLAGS Flags, UINT Irq,
                                INTERRUPT_SERVICE_ROUTINE Isr,
                                void *pDevice)
{
}

/* Undo the above EnableInterrupt
 */
void MCT SimPicDisableInterrupt( IPic *pThis, UINT Irq, void **pOldDevice)
{
    *pOldDevice = NULL;
}

/*
 * Mask *all* interrupts.  Except NMI, but thats another story.
 */
void MCT SimPicMaskAll( IPic *pThis )
{
}

/*
 * Unmask all interrupts that should be unmasked.
 */
void MCT SimPicUnmaskAll( IPic *pThis )
{
}

static const struct IPicVtbl SimPicVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    SimPicEnableInterrupt,
    SimPicDisableInterrupt,
    SimPicMaskAll,
    SimPicUnmaskAll
};

struct SimPic TheSimPic = {
    &SimPicVtbl,
};


/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
    SimPic *pic = (SimPic*)pThis;
        UnusedParameter(pic);
}

IPic *PicCreate(void)
{
    SimPic *pic = &TheSimPic;

    return (IPic *) pic;
}

/*************************** idt.c ***************************/

#pragma warning(disable:4100)
#pragma message("DUMMY idt")

/*
 * Initialization
 */
void IdtCreate(void)
{
}

/* Install/Remove an interrupt handler entry
 */
extern 
void 
InstallIsr( 
        UINT InterruptNumber, 
        ADDRESS Isr,
        UINT RawTrapNumber, 
        UINT UserAccessible
        )
{
}

/************************ Multiprocessor locking ****************/
void MpSpinLockInit(PUINT pLock)
{
    *pLock = 0;
}

void MpSpinLock(PUINT pLock)
{
    while (AtomicSwap(pLock, 1) != 0)
        ;
}

void MpSpinUnlock(PUINT pLock)
{
    assert(*pLock == 1);
    *pLock = 0;
}

void MpSendInterrupt(void)
{
    NT_SetNextInterrupt(0);
}

/* Protect NT system calls from "interrupts" */
#include <machdep.h>            /* for TURN_INTERRUPT_OFF */

UINT HostFsd_NTBegin(void)
{
    UINT State;
    TURN_INTERRUPTS_OFF(State);
    return State;
}

void HostFsd_NTEnd(UINT State)
{
    RESTORE_INTERRUPTS(State);
}


void StartCpu(UINT CpuNo)
{
}
