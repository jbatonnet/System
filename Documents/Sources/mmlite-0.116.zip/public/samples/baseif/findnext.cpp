/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Find all entries in system namespace. */
#define BUFLEN    20

INameSpace *pNS;
SCODE StatusCode;
_TCHAR Buf[BUFLEN];
UINT Len;

_tprintf(_T("Search for all names in system namespace.\n"));
pNS = CurrentNameSpace();
StatusCode = pNS->FindNext(NULL, NULL, Buf, BUFLEN, &Len);
do {
    switch (StatusCode) {
        case S_OK:
            _tprintf(_T("The next name in the namespace is \"%s\".\n"),Buf);
            _tprintf(_T("The string length of \"%s\" is %d.\n"), Buf, Len);
            break;
        case S_NO_MORE_ENTRIES:    
            _tprintf(_T("The last name in the namespace is \"%s\".\n"),Buf);
            _tprintf(_T("The string length of \"%s\" is %d.\n"), Buf, Len);
            break;
        case S_BUFFER_TOO_SMALL:    
            _tprintf(_T("The name is %d characters long, which is\n"), Len);
            _tprintf(_T("too long to fit in the buffer supplied.\n"));
            break;
        default:   
            _tprintf(_T("An error has occurred!\n"));
            break;
    }
    StatusCode = pNS->FindNext(_T(""), Buf, Buf, BUFLEN, &Len);
} while (StatusCode == S_OK);
/* END_SAMPLE */
return 0;
}
