/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <diagnostics.h>
#include "at91m63200.h"

#define POLL_FOR_DISABLE_ON_SW1 1

extern PINAMESPACE RomFsNew( PTR StartAddress, UINT MaxSize);

/* RomFs initialization specific to board */
PINAMESPACE BoardInitRomFs(void)
{
    PINAMESPACE ns;
#if POLL_FOR_DISABLE_ON_SW1
    UINT Pins, i;

    PioB->Disable = PIOB_PB3;
    PioB->FilterEnable = PIOB_PB3;
    for (i = 0; i < 1000; i++) {
        Delay(1000);
        Pins = PioB->PinDataStatus;
        if ((Pins & PIOB_PB3) == 0)
            break;
    }
    if ((Pins & PIOB_PB3) == 0)
        return NULL;
#endif

    ns = RomFsNew( (PTR) 0x1080000, 0x800000 );
    if (!ns) DBGME(3,printf("BoardInitRomFs failed\n"));
    return ns;
}

