/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>
#include <drivers/serp.h>

#define UseSerplex 0

#ifdef NTUBIG2
PRIVATE _TCHAR con[] = _T("fs/COM3");
PRIVATE _TCHAR net[] = _T("fs/COM5");
#else
PRIVATE _TCHAR con[] = _T("fs/COM4");
PRIVATE _TCHAR net[] = _T("fs/COM6");
#endif

DRIVER_CONFIG DriverConfigs[] = {
#if 0 /* not used */
  {_T("null"), _T("COB/null.cob"), 0, },
#endif

#if UseSerplex
  {_T("serplex6a"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              con, NULL, 38400, FSSerplexAddr, },
  {_T("srfs"), _T("COB/hostfs.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("serplex6a"), },
  
#ifndef NTUBIG2
  /* seal */
  /* sr0 is the secure channel */
  {_T("serplex6d"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              net, NULL, 38400, NICSerplexAddr, },
  {_T("sr0"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6d"), _T("192.168.0.1"), },
  {_T("serplex6b"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              con, NULL, 38400, NICSerplexAddr, },
  {_T("sr1"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6b"), _T("169.254.0.1"), },//NULL,},
#else
  /* fridge */
  /* sr0 is the secure channel */
  {_T("serplex6e"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              net, NULL, 38400, NICSerplexAddr, },
  {_T("sr0"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6e"), _T("192.168.0.2"), },
  {_T("serplex6b"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              con, NULL, 38400, NICSerplexAddr, },
  {_T("sr1"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6b"), _T("169.254.10.2"), },//NULL,},
#endif
  
  {_T("serplex6c"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              con, NULL, 38400, CONSerplexAddr, },
#else
  {_T("sv0"), _T("COB/simnic.cob"), DEVICE_FLAGS_NET_DRIVER|DEVICE_FLAGS_INTERRUPTS, 0, 1},
#endif
  {NULL,}    
};

