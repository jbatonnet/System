/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Copyright (c) 1982, 1986, 1993
 *    The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the University of
 *    California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *    @(#)ip_var.h    8.1 (Berkeley) 6/10/93
 */

/*
 * Overlay for ip header used by other protocols (tcp, udp).
 */
struct ipovly {
    PTR ih_next, ih_prev;   /* for protocol sequence q's */
    UINT8 ih_x1;            /* (unused) */
    UINT8 ih_pr;            /* protocol */
    UINT16 ih_len;          /* protocol length */
    struct in_addr ih_src;  /* source internet address */
    struct in_addr ih_dst;  /* destination internet address */
};

/*
 * Ip reassembly queue structure.  Each fragment
 * being reassembled is attached to one of these structures.
 * They are timed out after ipq_ttl drops to 0, and may also
 * be reclaimed if memory becomes tight.
 */
struct ipq {
    struct ipq *next,*prev;               /* to other reass headers */
    UINT8 ipq_ttl;                        /* time for reass q to live */
    UINT8 ipq_p;                          /* protocol of this fragment */
    UINT16 ipq_id;                        /* sequence id for reassembly */
    struct mbuf *ipq_first,*ipq_last;     /* to mbuf headers of fragments */
    struct in_addr ipq_src,ipq_dst;
};

/*
 * Structure stored in mbuf in inpcb.ip_options
 * and passed to ip_output when ip options are in use.
 * The actual length of the options (including ipopt_dst)
 * is in m_len.
 */
#define MAX_IPOPTLEN 40

struct ipoption {
    struct in_addr ipopt_dst;       /* first-hop dst if source routed */
    BYTE ipopt_list[MAX_IPOPTLEN];  /* options proper */
};

/*
 * Structure attached to inpcb.ip_moptions and
 * passed to ip_output when IP multicast options are in use.
 */
struct ip_moptions {
    struct ifnet *imo_multicast_ifp;  /* ifp for outgoing multicasts */
    UINT8 imo_multicast_ttl;          /* TTL for outgoing multicasts */
    UINT8 imo_multicast_loop;         /* 1 => hear sends if a member */
    UINT16 imo_num_memberships;       /* no. memberships this socket */
    struct in_multi *imo_membership[IP_MAX_MEMBERSHIPS];
};

#ifdef __WANTS_STATS
struct ipstat {
    UINT ips_total;         /* total packets received */
    UINT ips_badsum;        /* checksum bad */
    UINT ips_tooshort;      /* packet too short */
    UINT ips_toosmall;      /* not enough data */
    UINT ips_badhlen;       /* ip header length < data size */
    UINT ips_badlen;        /* ip length < ip header length */
    UINT ips_fragments;     /* fragments received */
    UINT ips_fragdropped;   /* frags dropped (dups, out of space) */
    UINT ips_fragtimeout;   /* fragments timed out */
    UINT ips_forward;       /* packets forwarded */
    UINT ips_cantforward;   /* packets rcvd for unreachable dest */
    UINT ips_redirectsent;  /* packets forwarded on same net */
    UINT ips_noproto;       /* unknown or unsupported protocol */
    UINT ips_delivered;     /* datagrams delivered to upper level*/
    UINT ips_localout;      /* total ip packets generated here */
    UINT ips_odropped;      /* lost packets due to nobufs, etc. */
    UINT ips_reassembled;   /* total packets reassembled ok */
    UINT ips_fragmented;    /* datagrams sucessfully fragmented */
    UINT ips_ofragments;    /* output fragments created */
    UINT ips_cantfrag;      /* don't fragment flag was set, etc. */
    UINT ips_badoptions;    /* error in option processing */
    UINT ips_noroute;       /* packets discarded due to no route */
    UINT ips_badvers;       /* ip version != 4 */
    UINT ips_rawout;        /* total raw ip packets generated */
};
#endif

#ifdef KERNEL
/* flags passed to ip_output as last parameter */
#define IP_FORWARDING      0x1           /* most of ip header exists */
#define IP_RAWOUTPUT       0x2           /* raw ip header exists */
#define IP_ROUTETOIF       SO_DONTROUTE  /* bypass routing tables */
#define IP_ALLOWBROADCAST  SO_BROADCAST  /* can send broadcast packets */

extern struct ipstat ipstat;
extern struct ipq ipq;        /* ip reass. queue */
extern UINT16 ip_id;          /* ip packet ctr, for ids */
extern const INT ip_defttl;         /* default IP ttl */
extern const int ipforwarding;            /* ip forwarding */
extern u_char   ip_protox[];

INT ip_ctloutput(INT, struct socket *, INT, INT, struct mbuf **);
INT ip_dooptions(struct mbuf *);
void ip_drain(void);
void ip_forward(struct mbuf *, INT);
void ip_freef(struct ipq *);
void ip_freemoptions(struct ip_moptions *);
INT ip_getmoptions(INT, struct ip_moptions *, struct mbuf **);
void ip_init(void);
INT ip_mforward(struct mbuf *, struct ifnet *);
INT ip_optcopy(struct ip *, struct ip *);
INT ip_output(struct mbuf *, struct mbuf *, struct route_in *, INT,
              struct ip_moptions *);
INT ip_pcbopts(struct mbuf **, struct mbuf *);
struct mbuf * ip_reass(struct mbuf *, struct ipq *);
struct in_ifaddr * ip_rtaddr(struct in_addr);
INT ip_setmoptions(INT, struct ip_moptions **, struct mbuf *);
void ip_slowtimo(void);
struct mbuf * ip_srcroute(void);
void ip_stripoptions(struct mbuf *, struct mbuf *);
void ip_input (struct mbuf *);
INT  rip_ctloutput (INT, struct socket *, INT, INT, struct mbuf **);
void rip_init (void);
void rip_input (struct mbuf *);
INT rip_output (struct mbuf *, struct socket *, u_long);
INT rip_usrreq (struct socket *, INT, struct mbuf *, struct mbuf *,
                struct mbuf *);
#endif
