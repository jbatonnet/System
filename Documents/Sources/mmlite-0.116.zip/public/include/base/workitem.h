/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef __workitem_h__
#define __workitem_h__

#include <util/list-single.h>
#include <base/mutex2.h>
#include <base/condition2.h>
#include <base/activity.h>
#include <base/thread2.h>

#define MIN_AVAIL_POOL_COUNT 5
#define MAX_AVAIL_POOL_COUNT 10

/* This is the value of the activity thread whenever the work item is not
 * being processed (before it starts, or in between dispatches
 * Not word-aligned, so we aren't trampling on some real thread's address */
#define WORKITEM_PSEUDO_THREAD 0x12345672

typedef struct _WORKINFO {
  ACTINFO Activity;
  WORK_SWITCH_FUNCTION SwitchFunction;
  WORK_FUNCTION Func;
  WORK_ARGUMENT Arg;
} WORKINFO, *PWORKINFO, **PPWORKINFO;

#define pW(_pWork_)  ((PWORKINFO) (_pWork_))

#ifdef _DEBUG
/* This debug mechanism allows us to force the debugger into explicitly using
 * the private WORKINFO kernel struct so we can see its members.
 * WorkItem_Prologue must be after all variable declarations but before any
 * statements.
 */
#define WorkItem_Prologue() PWORKINFO pWorkProxy = pW(pWork)
#define pWorkArg pWorkProxy
#else
#define WorkItem_Prologue()
#define pWorkArg pWork
#endif /* _DEBUG */

#define /* BOOL */                                                            \
WorkItem_HasPseudoThread(/* PWORKINFO */ _pWork_)                             \
   (Activity_GetThread(_pWork_) == (PACTINFO)WORKITEM_PSEUDO_THREAD)

#define /* void */                                                            \
WorkItem_SetPseudoThread(/* PWORKINFO */ _pWork_)                             \
   Activity_SetThread(_pWork_, WORKITEM_PSEUDO_THREAD)

#define /* WORK_SWITCH_FUNCTION */                                            \
WorkItem_GetSwitchFunction(/* PWORKINFO */ _pWork_)                           \
   (pW(_pWork_)->SwitchFunction)

#define /* void */                                                            \
WorkItem_SetSwitchFunction(/* PWORKINFO */ _pWork_,                           \
                           /* WORK_SWITCH_FUNCTION */ _sf_)                   \
  (WorkItem_GetSwitchFunction(_pWork_) = (_sf_))

#define /* WORK_FUNCTION */                                                   \
WorkItem_GetFunc(/* PWORKINFO */ _pWork_)                                     \
     (pW(_pWork_)->Func)

#define /* void */                                                            \
WorkItem_SetFunc(/* PWORKINFO */ _pWork_,                                     \
                 /* WORK_FUNCTION */ _pFunc_)                               \
     (WorkItem_GetFunc(_pWork_) = (_pFunc_))

#define /* WORK_ARGUMENT */                                                   \
WorkItem_GetArg(/* PWORKINFO */ _pWork_)                                      \
     (pW(_pWork_)->Arg)

#define /* void */                                                            \
WorkItem_SetArg(/* PWORKINFO */ _pWork_,                                      \
                /* WORK_ARGUMENT */ _pArg_)                                 \
     (WorkItem_GetArg(_pWork_) = (_pArg_))

/* Handle the case if the current activity is a work item by derefencing it
 * to get its surrogate thread.*/
/* #define /\* void *\/                                                            \ */
/* WorkItem_Dereference(/\* PIACTIVITY *\/ pActivity)                              \ */
/* {                                                                             \ */
/*   PACTINFO pThdSurrogate = Activity_GetThread(pActivity);                     \ */
/*   if (pThdSurrogate != NULL) {                                                \ */
/*     assert(pThdSurrogate != (PACTINFO)WORKITEM_PSEUDO_THREAD);                \ */
/*     pActivity = pThdSurrogate;                                                \ */
/*   }                                                                           \ */
/* } */

PACTINFO THREAD_LINKAGE
ThreadPool_Switch(
    PWORKINFO pNewWork,
    PPWORKINFO pOldWork
    );

UINT
ThreadPool_GetAvailableCount();

void
ThreadPool_Create();

void
ThreadPool_Destroy();

#endif /* __workitem_h__ */
