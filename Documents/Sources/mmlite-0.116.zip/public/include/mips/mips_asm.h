/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Symbolic names for regs */

#define $zero $0
#define $at $1
#define $v0 $2
#define $v1 $3
#define $a0 $4
#define $a1 $5
#define $a2 $6
#define $a3 $7
#define $t0 $8
#define $t1 $9
#define $t2 $10
#define $t3 $11
#define $t4 $12
#define $t5 $13
#define $t6 $14
#define $t7 $15
#define $s0 $16
#define $s1 $17
#define $s2 $18
#define $s3 $19
#define $s4 $20
#define $s5 $21
#define $s6 $22
#define $s7 $23
#define $t8 $24
#define $t9 $25
#define $k0 $26
#define $k1 $27
#define $gp $28
#define $sp $29
#define $s8 $30
#define $ra $31

#define $cp0_index   $0
#define $cp0_random  $1
#define $cp0_tlblo   $2
#define $cp0_context $4
#define $cp0_badv    $8
#define $cp0_tlbhi   $10

#define $cp0_status  $12
# define CP0_SR_CU3 0x80000000
# define CP0_SR_CU2 0x40000000
# define CP0_SR_CU1 0x20000000
# define CP0_SR_CU0 0x10000000
# define CP0_SR_RE  0x02000000
# define CP0_SR_BEV 0x00400000
# define CP0_SR_TS  0x00200000 /* eMIPS extension: writeable */
# define CP0_SR_PE  0x00100000
# define CP0_SR_CM  0x00080000
# define CP0_SR_PZ  0x00040000
# define CP0_SR_SwC 0x00020000
# define CP0_SR_IsC 0x00010000
# define CP0_SR_INT 0x0000ff00
# define CP0_SR_RST 0x00000080  /* eMIPS extension: RESET */
# define CP0_SR_KUo 0x00000020
# define CP0_SR_IEo 0x00000010
# define CP0_SR_KUp 0x00000008
# define CP0_SR_IEp 0x00000004
# define CP0_SR_KUc 0x00000002
# define CP0_SR_IEc 0x00000001

#define $cp0_cause   $13
#define $cp0_epc     $14

#define $cp0_ectl    $16    /* eMIPS: Extension Control register */
# define CP0_EC_SSH      8   /* one byte per slot */
# define CP0_EC_EN    0x01   /* Enabled */
# define CP0_EC_LD    0x02   /* Loaded */
# define CP0_EC_TR    0x04   /* Trap on illegal instruction */
# define CP0_EC_PR    0x18   /* Priority over TISA */
# define CP0_EC_PER   0x20   /* Peripheral */
# define CP0_EC_PRIV  0x40   /* Privileged signals */
# define CP0_EC_CLK   0x80   /* Clock enable */

/* Offsets in the CXTINFO structure
 */
#define TS_AT (1 * 4)
#define TS_V0 (2 * 4)
#define TS_V1 (3 * 4)
#define TS_A0 (4 * 4)
#define TS_A1 (5 * 4)
#define TS_A2 (6 * 4)
#define TS_A3 (7 * 4)
#define TS_T0 (8 * 4)
#define TS_T1 (9 * 4)
#define TS_T2 (10 * 4)
#define TS_T3 (11 * 4)
#define TS_T4 (12 * 4)
#define TS_T5 (13 * 4)
#define TS_T6 (14 * 4)
#define TS_T7 (15 * 4)
#define TS_S0 (16 * 4)
#define TS_S1 (17 * 4)
#define TS_S2 (18 * 4)
#define TS_S3 (19 * 4)
#define TS_S4 (20 * 4)
#define TS_S5 (21 * 4)
#define TS_S6 (22 * 4)
#define TS_S7 (23 * 4)
#define TS_T8 (24 * 4)
#define TS_T9 (25 * 4)
#define TS_K0 (26 * 4)
#define TS_K1 (27 * 4)
#define TS_GP (28 * 4)
#define TS_SP (29 * 4)
#define TS_FP (30 * 4)
#define TS_RA (31 * 4)

#define TS_PC (32 * 4)

#ifdef TIGON
#define TS_INTS (33 * 4)
#define SIZEOF_CXTINFO (34*4)
#else
#define TS_SR (33 * 4)
#define TS_HI (34 * 4)
#define TS_LO (35 * 4)
#define TS_EC (36 * 4)
#define SIZEOF_CXTINFO (37*4)
#endif


/* Macros to declare functions etc.
 */
#define ENTRY(_name_) \
        .text; \
        .align 2; \
        .global _name_; \
        .type _name_,function; \
        .ent _name_; \
_name_:

#define FRAMESIZE(_size_) \
        .frame $sp,_size_,$31

#define END(_name_) \
        .end _name_; \
        .size _name_, .-_name_

#define _ENTRY
#define _IMPORT(n)       .global n .text
#define _CODE(n)         .text
#define _BSS(n)          .bss
#define _DATA(n)         .data
#define _DCD             .int
#define _EQU             =
#define _SKIP            .skip
/* .align would work also methinks */
#define _ALIGN(n)        .balign n
#define _EXPORT(n)       .global n
#define _FUNCTION(n)     n:  .type n,function
#define _F(n)            n
#define _L(n)            n
#define _LABEL(n)        n:
#define _END

