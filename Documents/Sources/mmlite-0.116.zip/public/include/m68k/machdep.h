/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Machine-dependent functions and definitions 
 * which are not otherwise defined in fred.h
 *
 */
/* XXX This implementation is lifted from mips and needs to be ported */
extern BOOL IntsDisabled;

#define __NEED_M_THDINFO 0

#define MachineSpecificInfo(a,b) (E_NOT_IMPLEMENTED)
#define CurrentProcessorKind() (PROCESSOR_KIND_M68K)
#define CurrentProcessorOEM() (0)
extern UINT64 CurrentProcessorSpeed(void);

#define DEFAULT_STACK_SIZE (2*1024)

#define FLUSH_WRITE_BUFFER() \
{ \
        /* Read unused SRAM memory location */ \
        /*asm volatile ("lw $0, 0x1ffc($0)");*/ \
}

#define TURN_INTERRUPTS_OFF(_s_) \
{ \
    /* It is ok to do this non-atomically because if we get interrupted */ \
    /* the value will be the same when we get back (that is FALSE or we */ \
    /* won't get interrupted in the first place) */ \
    _s_ = IntsDisabled; \
    IntsDisabled = TRUE; \
}

#define RESTORE_INTERRUPTS(_s_) \
{ \
    IntsDisabled = _s_; \
}

#define ENABLE_INTERRUPTS() \
{ \
    IntsDisabled = FALSE; \
}

#define DISABLE_INTERRUPTS() \
{ \
    IntsDisabled = TRUE; \
}

#define INTERRUPTS_ARE_DISABLED() (IntsDisabled)

/* interrupt path: isr->scheduler */
extern PCXTINFO _Reschedule(PCXTINFO);

/* OPTIMIZATION SECTION
 */
