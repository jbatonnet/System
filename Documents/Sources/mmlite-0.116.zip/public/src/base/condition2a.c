/* Implementation of non-interface condition variable functions.
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#define OPTIMIZE
/* enable Base.h optimizations, since we're the "base" */

#include <mmlite.h>
#include <fred.h>
#include <base/thread2.h>
#include <base/mutex2.h>
#include <base/condition2.h>
#include <base/schedul.h>
#include <schedulif.h>

/* Deferred points to list of conditions that have been signalled from an
 * interrupt. PTR and not PCOND because of circular include errors in schedul.h
 */
volatile PTR /*PCOND*/ DeferredConditionSignals = NULL;

/* This is called from context switch code.
 * Assumes preemption disabled, interrupts enabled.
 * Preemption disabled & uniprocessor implies noone
 * else can modify pCond->Waiters.
 */
void Condition_DrainDeferred(void)
{
    PCOND pCondCurrent;

    assert(!pTheScheduler->v->PreemptionIsEnabled(pTheScheduler));

    /* There are no races in this test, noone but us removes
     * entries from the list.  We only worry about additions
     * that happen while we work on it.
     */
    while (DeferredConditionSignals != NULL) {

	/* Instead of atomically dequeueing (which is ok) we can
	 * just take the whole list away in one shot, then process
	 * individual elements without much concerns.  If there is
	 * only one entry its the same thing.
	 */
	do {
	    pCondCurrent = DeferredConditionSignals;
	} while (!AtomicCmpAndSwap((PUINT) &DeferredConditionSignals,
				   (UINT)  pCondCurrent,
				   (UINT)  NULL));

	/* Now we have the whole list in hand.  No one will try
	 * to put back a condition we hold on to, because it has been
	 * signalled already.  Therefore no one messes with us.
	 */
	do {
	    /* Don't think this should ever fail.. but.
	     */
          assert(!Condition_WaiterQueueIsEmpty(pCondCurrent));

          pTheScheduler->v->WakeUpOnCondition(pTheScheduler,
                                              (PCONDITION)pCondCurrent,
                                              FALSE);
	    /* Move on to the next condition. Notice we kept this one busy
	     * all the way to the end.  Let it go now.
	     */
	    pCondCurrent = Condition_Pop(pCondCurrent);

	} while (pCondCurrent != NULL);

	/* Now go back and check the list again, for any latecomers
	 */
    }
}


