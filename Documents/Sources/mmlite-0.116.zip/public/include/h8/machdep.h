/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define __HAS_UNCHECKED_FUNCTION_CALLING 1
#define __SUPPORTS_COB_NAMESPACE 1
#define __NO_EXECUTABLES 1

#define MachineSpecificInfo(a,b) (E_NOT_IMPLEMENTED)
#define CurrentProcessorKind() (PROCESSOR_KIND_H8)
#define CurrentProcessorOEM() (0)
extern UINT64 CurrentProcessorSpeed(void);

#ifdef __GNUC__

void H8RestoreInterrupt(UINT8 ccr);

#define DISABLE_INTERRUPTS() \
{ \
    __asm__ ("orc #0x80,ccr"); \
}

#define TURN_INTERRUPTS_OFF(_s_) \
{ \
    UINT8 s; \
	__asm__ ("stc ccr,%0l" : "=r" (s) ); \
    __asm__ ("orc #0x80,ccr"); \
	_s_ = s; \
}

#if 0
#define RESTORE_INTERRUPTS(_s_) \
{ \
    UINT8 s = _s_; \
	__asm__ ("ldc %0l,ccr" : : "r" (s) ); \
}
#else
#define RESTORE_INTERRUPTS(_s_) \
{ \
	H8RestoreInterrupt((UINT8)_s_); \
}
#endif

#define ENABLE_INTERRUPTS() \
{ \
    asm volatile ("andc #0x7f,ccr"); \
}

#else

//
// Renesas HEW Compiler
//
#include <machine.h>

#define ENABLE_INTERRUPTS()		and_ccr(0x7F)
#define DISABLE_INTERRUPTS()	or_ccr(0x80)

#define TURN_INTERRUPTS_OFF(s) \
{ \
	s = get_ccr(); \
	or_ccr(0x80); \
}

#define RESTORE_INTERRUPTS(s)	set_ccr(s)

#endif

#define DEFAULT_STACK_SIZE 8192

/* embedded monitor call
 */
#define MONCALL_APPLICATION_EXIT 1
#define MONCALL_CONSOLE_OUT 2
#define MONCALL_CONSOLE_IN 3
#define MONCALL_SET_VECTOR_TABLE 4

extern UINT Moncall( UINT8 Code, UINT16 Parm2, UINT8 Parm1);
