/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Tigon-specific.
 * Machine-dependent functions and definitions 
 * which are not otherwise defined in fred.h
 *
 */

#define CurrentProcessorKind() (PROCESSOR_KIND_MIPS_TIGON)
#define CurrentProcessorOEM() (0)

#define FLUSH_WRITE_BUFFER() \
{ \
        /* Read unused SRAM memory location */ \
        asm volatile ("lw $0, 0x1ffc($0)"); \
}

#define TURN_INTERRUPTS_OFF(_s_) \
{ \
    /* It is ok to do this non-atomically because if we get interrupted */ \
    /* the value will be the same when we get back (that is FALSE or we */ \
    /* won't get interrupted in the first place) */ \
    _s_ = IntsDisabled; \
    IntsDisabled = TRUE; \
}

#define RESTORE_INTERRUPTS(_s_) \
{ \
    IntsDisabled = _s_; \
}

#define ENABLE_INTERRUPTS() \
{ \
    IntsDisabled = FALSE; \
}

#define DISABLE_INTERRUPTS() \
{ \
    IntsDisabled = TRUE; \
}

#define INTERRUPTS_ARE_DISABLED() (IntsDisabled)

UINT CurrentCpuNumber(void);

extern volatile UINT32 ExceptionPC;
extern volatile UINT32 IntsDisabled;
extern volatile UINT32 EventMask;

void StartHelperCpu(void);      /* Assembler code */

void TheBeginning(void);        /* Called from assembler */
void HelperBeginning(void);     /* ditto */
void SchedInt(PCXTINFO pCxt);   /* ditto */

#define DMA_CHANNEL_READ_HIGH  0
#define DMA_CHANNEL_READ       1
#define DMA_CHANNEL_WRITE_HIGH 2
#define DMA_CHANNEL_WRITE      3
UINT DmaInit(UINT MemSize);
void DmaTest(void);
BOOL DmaStart(UINT Channel,
              ADDRESS Physical, void *LocalPtr, UINT Length, void *Info);
BOOL DmaComplete(UINT Channel, void **pInfo);

void EtherInit(BOOL LoopBack);
void EtherTest(void);
BOOL EtherTransmitStart(void *LocalPtr, UINT Length);
void *EtherTransmitComplete(void);
PTR EtherReceive(UINT *pLength);
void EtherReceiveDone(PTR Addr, BOOL Dropped);

void RaiseInterrupt(ADDRESS Routine, PCONDITION pCond);

/* OPTIMIZATION SECTION
 */
/*register volatile struct _TG_REGS *TgRegs __asm__("$28");*/
#define TgRegs TG_REGS_INTERNAL
