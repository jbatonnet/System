/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Microsoft MMLITE June 1995 --jvh
 * NT server for remote IFile using sockets.
 */

#include <windows.h>

#ifndef __mmmach_h__
typedef unsigned __int64 UINT64;
typedef unsigned int UINT32;
typedef int INT32;
typedef unsigned short UINT16;
typedef unsigned char UINT8;
//typedef int SCODE;
typedef UINT32 UINT;            /* XXX */
#endif

#define UnusedParameter(x) x = x
#define STATUS_WIN32_ERROR(u) ((SCODE)((u)|0x80070000))
#define INLINE __inline

#include <stdio.h>
#include <wchar.h>
#include <stdlib.h>
#define printf NT_printf
EXTERN_C INT __cdecl NT_printf(const char *format, ...);

#include "../_netfile.h"

static UINT CacheTimestamp = 0;
UINT debug_level = 0;

typedef void *PCONNECTION;

INLINE HANDLE get_HANDLE(UINT32 client_says, PCONNECTION Conn)
{
    UnusedParameter(Conn);
    return (HANDLE) client_says;
}

INLINE UINT32 put_HANDLE(HANDLE file, PCONNECTION Conn, /* tmp in */ wchar_t *name )
{
    return (UINT32) file;
}

SCODE error_code_NT2MMLITE(SCODE sc, char *where)
{
    /* NT doesn't seem to be very consistent in what error codes it returns */
    if (sc > 0) {
        /* Assume this is a Win32 error. */
        sc = STATUS_WIN32_ERROR(sc);
    }
    return sc;
}

/*------------------ "methods" ------------------------------*/
BOOL may_write = FALSE;

void do_open(struct packet *p, PCONNECTION Conn)
{
    struct open_req *req = &p->u.open_req;
    struct open_rep *rep = &p->u.open_rep;
    HANDLE file;
    SCODE sc = SUCCESS;
    UINT flags = req->flags;
    UINT openflags = 0, createflags = 0;
    wchar_t *filename;
    BOOL isdir = FALSE;

    if (flags & 0x20)                   /* NAME_SPACE_FAILIFEXISTS */
        createflags = CREATE_NEW;
    else if (flags & 0x10)              /* NAME_SPACE_CREATE */
        createflags = OPEN_ALWAYS;
    else
        createflags = OPEN_EXISTING;

    if (flags & 1)                      /* NAME_SPACE_READ */
        openflags |= GENERIC_READ;
    if (flags & 2)                      /* NAME_SPACE_WRITE */
        openflags |= GENERIC_WRITE;

    if (flags & 0x800) {                /* XXX   F_DIRECTORY: mkdir */
        isdir = TRUE;
        if (!(openflags & GENERIC_WRITE)) {
            if (debug_level)
                printf("Can't create directory without NAME_SPACE_WRITE\n");
            sc = STATUS_WIN32_ERROR(5);
            goto replystuff;
        }
    }

    if (!may_write
        && (openflags != GENERIC_READ || createflags != OPEN_EXISTING))
    {
        if (debug_level)
            printf("Rejected \"%ls\" flags=x%x because server is Read Only\n",
                   req->path, flags);
        sc = STATUS_WIN32_ERROR(5);     /* E_ACCESS_DENIED */
        goto replystuff;
    }

    filename = req->path;
    /* Check for \\.\ escape */
    if (wcsncmp(filename, L"....", 4) == 0) {
        filename[0] = filename[1] = filename[3] = '\\';
        filename[2] = '.';
    }

    if (isdir) {
        /* In the end it might be better to have a separate RPC for mkdir */
        if (CreateDirectoryW(filename, NULL) == FALSE)
            sc = GetLastError();
        file = 0;
    } else {
        file = CreateFileW(filename,
                           openflags,
                           FILE_SHARE_READ|FILE_SHARE_WRITE,
                           NULL,
                           createflags,
                           FILE_ATTRIBUTE_NORMAL,
                           NULL);
        if (file == INVALID_HANDLE_VALUE)
            sc = GetLastError();
    }
    if (debug_level)
        printf("Opened \"%ls\" %s as handle x%x sc=x%x\n", filename,
               (openflags & GENERIC_WRITE)
               ? (isdir ? "New directory" : "WRITABLE")
               : "read only",
               (UINT) file, sc);
 replystuff:
    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_OPEN_REP);
    p->sc = error_code_NT2MMLITE(sc, "do_open");
    rep->handle = put_HANDLE(file, Conn, req->path);
    packet_prepare(p, sizeof(*rep));
}

void do_close(struct packet *p, PCONNECTION Conn)
{
    struct close_req *req = &p->u.close_req;
    HANDLE file;
    SCODE sc = SUCCESS;

    if (debug_level)
        printf("do_close handle x%x\n", req->handle);
    file = get_HANDLE(req->handle, Conn);

    if (CloseHandle(file) == FALSE)
        sc = GetLastError();

    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_CLOSE_REP);
    p->sc = error_code_NT2MMLITE(sc, "do_close");
    packet_prepare(p, 0);
}

void do_getsize(struct packet *p, PCONNECTION Conn)
{
    struct getsize_req *req = &p->u.getsize_req;
    struct getsize_rep *rep = &p->u.getsize_rep;
    HANDLE file;
    SCODE sc = SUCCESS;
    DWORD size;                 /* NT type */

    file = get_HANDLE(req->handle, Conn);

    size = GetFileSize(file, 0); /* BUGBUG: at most 4GB */
    if (size == 0xffffffff)
        sc = GetLastError();

    /*printf("getsize(x%x) => x%x  sc=x%x\n", (UINT32) file, size, sc);*/
    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_GETSIZE_REP);
    p->sc = error_code_NT2MMLITE(sc, "do_getsize");
    rep->size = size;
    packet_prepare(p, sizeof(*rep));
}

/* Partial implementation: if size is set to -1, check if floppy changed */
void do_setsize(struct packet *p, PCONNECTION Conn)
{
    struct setsize_req *req = &p->u.setsize_req;
    HANDLE file;
    SCODE sc = SUCCESS;

    file = get_HANDLE(req->handle, Conn);

    /* We do not truncate files (should ?)
     */
    sc = STATUS_WIN32_ERROR(  87);

    /* Cache probe ?
     */
    if (req->size == (UINT64)(~0)) {
        printf("simfiled: Cache probe unimplemented\n");
#if 0
        if (Conn->CacheTimestamp != CacheTimestamp) {
            sc = /*E_MEDIA_CHANGED*/ STATUS_WIN32_ERROR(1110);
            Conn->CacheTimestamp = CacheTimestamp;
        }
#endif
    }
    
    /*printf("setsize(x%x) => x%x  sc=x%x\n", (UINT32) file, req->size, sc);*/
    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_SETSIZE_REP);
    p->sc = error_code_NT2MMLITE(sc, "do_setsize");
    packet_prepare(p, 0);
}

void do_read(struct packet *p, PCONNECTION Conn)
{
    struct read_req *req = &p->u.read_req;
    struct read_rep *rep = &p->u.read_rep;
    HANDLE file;
    SCODE sc = SUCCESS;
    OVERLAPPED ol;              /* NT type */
    UINT count, nread;

    file = get_HANDLE(req->handle, Conn);
    count = req->count;

    if (count > MAX_READ_SIZE)
        count = MAX_READ_SIZE;
/*    printf("read pos x%x count x%x file %x\n", (UINT) req->position, count, req->handle); */
    ol.Offset = (UINT) req->position;
    ol.OffsetHigh = 0;          /* BUGBUG at most 4GB */
    ol.hEvent = NULL;           /* ? */

    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_READ_REP);

    if (ReadFile(file, rep->data, count, &nread, &ol) == FALSE)
        sc = GetLastError();
        
    /* printf("read(x%x) => x%x  sc=x%x \"%s\"\n", (UINT32) file, nread, sc,
           rep->data); */

    if ((sc == ERROR_HANDLE_EOF) ||
        ((sc == SUCCESS) && (nread < count)))
        p->sc = S_FALSE;
    else
        p->sc = error_code_NT2MMLITE(sc, "do_read");
    rep->nread = nread;
    packet_prepare(p, sizeof(*rep) - (MAX_READ_SIZE - nread));
}

void do_write(struct packet *p, PCONNECTION Conn)
{
    struct write_req *req = &p->u.write_req;
    struct write_rep *rep = &p->u.write_rep;
    HANDLE file;
    SCODE sc = SUCCESS;
    OVERLAPPED ol;              /* NT type */
    UINT nwritten;

    file = get_HANDLE(req->handle, Conn);

    ol.Offset = (UINT) req->position;
    ol.OffsetHigh = 0;          /* BUGBUG at most 4GB */
    ol.hEvent = NULL;           /* ? */

/*printf("do_write(file x%x  count %x pos %x data[0..9] \"%.10s\"\n",
       req->handle, req->count, (UINT32) req->position, req->data);
*/
    if (WriteFile(file, req->data, req->count, &nwritten, &ol) == FALSE)
        sc = GetLastError();
        
    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_WRITE_REP);
    p->sc = error_code_NT2MMLITE(sc, "do_write");
    rep->nwritten = nwritten;
/*printf("do_writeEND(sc=%x n=%x pos=%x)\n", sc, nwritten, ol.Offset);*/
    packet_prepare(p, sizeof(*rep));
}

/* 
 */
SCODE findnext_helper(const wchar_t *prefix, const wchar_t *previous,
                                                      WIN32_FIND_DATAW *search)
{
    wchar_t path[MAX_PATH * 2];
    HANDLE dir;
    SCODE sc;

    wcscpy(path,prefix);
    wcscat(path,L"\\*");

    /* Assume error */
    sc = error_code_NT2MMLITE(ERROR_FILE_NOT_FOUND,"do_findnext");

    dir = FindFirstFileW(path,search);
    /*printf("findnext_helper FFW %s->%x %x\n", prefix, dir, GetLastError());*/
    if (dir == INVALID_HANDLE_VALUE)
        return sc;

    if (previous[0] == L'\0')  /* This is a FindFirst */
        sc = S_OK;
    else {
        do {
            if (wcscmp(previous,search->cFileName) == 0) { /* Found previous */

                if (FindNextFileW(dir,search)) /* Found next        */
                    sc = S_OK;
                else {                         /* Previous was last */
                    search->cFileName[0] = L'\0';
                    sc = S_FALSE;
                }
                break;
            }
        } while (FindNextFileW(dir,search));
    }

    FindClose(dir);
    return sc;
}

void do_findnext(struct packet *p, PCONNECTION Conn)
{
    struct findnext_req *req = &p->u.findnext_req;
    struct findnext_rep *rep = &p->u.findnext_rep;
    SCODE sc;
    WIN32_FIND_DATAW SearchData;

    sc = findnext_helper(req->prefix,req->previous,&SearchData);
    /*printf("do_findnext(\"%ls\", \"%ls\") -> %x \"%ls\"\n",
      req->prefix, req->previous, sc, SearchData.cFileName);*/
    /* Reuse packet for reply */
    packet_init(p, PACKET_TYPE_FINDNEXT_REP);
    /* Copy path to reply msg. */
    wcsncpy(rep->name, SearchData.cFileName, sizeof(rep->name)/sizeof(rep->name[0]) - 1);
    /* make sure it is zero terminated */
    rep->name[sizeof(rep->name)/sizeof(rep->name[0]) - 1] = 0;
    p->sc = sc;
    packet_prepare(p, sizeof(*rep));
}

/* 
 * Use one thread per socket.  One socket has only one transaction
 * going on at a time.
 * Windowing etc. is achieved by using multiple sockets.
 */

SCODE SimFile_Server(struct packet *p)
{
    PCONNECTION Conn = NULL;

    switch (p->packet_type) {
    case PACKET_TYPE_OPEN_REQ:
        do_open(p, Conn);
        break;
    case PACKET_TYPE_CLOSE_REQ:
        do_close(p, Conn);
        break;
    case PACKET_TYPE_GETSIZE_REQ:
        do_getsize(p, Conn);
        break;
    case PACKET_TYPE_SETSIZE_REQ:
        do_setsize(p, Conn);
        break;
    case PACKET_TYPE_READ_REQ:
        do_read(p, Conn);
        break;
    case PACKET_TYPE_WRITE_REQ:
        do_write(p, Conn);
        break;
    case PACKET_TYPE_FINDNEXT_REQ:
        do_findnext(p, Conn);
        break;
    default:
        printf("Unknown packet type x%x\n", p->packet_type);
        return 0x88888888;
    }

    return p->sc;
}

SCODE SimFile_Init()
{
#if 0
//    SCODE sc;
    char *rootpath;

//    int argc, char *argv[];

    rootpath = getenv("SIMFILE_ROOT");
    if (!rootpath)
        rootpath = ".";

    printf("SIMFILE_ROOT=\"%s\"\n", rootpath);
#endif
    return S_OK;
#if 0
    if (!rootpath)
        return E_INVALID_HANDLE; /* whatever */

    while (argc >= 2 && argv[1][0] == TEXT('-')) {
        switch (argv[1][1]) {
        case TEXT('w'):
            may_write = TRUE;
            break;
        case TEXT('v'):
            debug_level++;
            break;
        case TEXT('?'):
        case TEXT('h'):
        default:
            printf("netfiled: NT server for NetFile protocol (remote IFile)"
                   "\n\t-? -h\thelp"
                   "\n\t-v\tverbose"
                   "\n\t-w\tenable writing"
                   "\n");
            exit(0);
            break;
        }
        argc--;
        argv++;
    }
    
        /* Check for input, anything typed means invalidate cache
         * (trivial, stupid, works).
         */
        do {
            (void) getchar();
            CacheTimestamp += 1;
            if (debug_level)
                printf("Timestamp now %d  ", CacheTimestamp);
        } while (ShouldRun);
    }

    if (debug_level)
        printf("exiting....\n");
    exit(0);
    return 0;
#endif
}
