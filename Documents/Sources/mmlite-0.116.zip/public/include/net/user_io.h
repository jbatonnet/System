/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*++

Module Name:

    via.h

Abstract:

    Definitions according to the specs

Author:

    Alessandro Forin (sandrof)  04-Dec-1997

Revision History:

--*/

#ifndef _VIA_
#define _VIA_ 1

#if !defined(_MMLITE_H_)
//old header files
typedef unsigned __int64 UINT64;
typedef unsigned __int32 UINT32;
typedef unsigned __int16 UINT16;
typedef unsigned __int8 UINT8;
#endif /* _MMLITE_H_ */


/* Return codes defined for VIA User Agent functions
 */
typedef enum _VIP_RETURN {

    /* The function completed successfully
     */
    VIP_SUCCESS,

    /* No Descriptors are completed on the specified queue
     */
    VIP_NOT_DONE,

    /* One or more input parameters were invalid
     */
    VIP_INVALID_PARAMETER,

    /* An error occurred due to insufficient resources
     */
    VIP_ERROR_RESOURCE,

    /* The request timed out before it could successfully complete
     */
    VIP_TIMEOUT,

    /* A connection request was rejected by the remote end
     */
    VIP_REJECT,

    /* The reliability level attribute for a VI was invalid or not supported
     */
    VIP_INVALID_RELIABILITY_LEVEL,

    /* The maximum transfer size attribute for a VI was invalid or not supported
     */
    VIP_INVALID_MTU,

    /* The quality of service attribute for a VI was invalid or not supported.
     */
    VIP_INVALID_QOS,

    /* The protection tag attribute for a VI or a memory region was invalid
     */
    VIP_INVALID_PTAG,

    /* The VI Provider does not support RDMA Read
     */
    VIP_INVALID_RDMAREAD
  
} VIP_RETURN;

/* Mapping for size-specific types
 */

typedef UINT8   VIP_UINT8;
typedef UINT16  VIP_UINT16;
typedef UINT32  VIP_UINT32;
typedef UINT64  VIP_UINT64;

/* Other types
 */
typedef UINT8  VIP_CHAR;
typedef UINT   VIP_BOOLEAN;
typedef UINT32 VIP_ULONG;
typedef void * VIP_PVOID;
typedef UINT32 VIP_MEM_HANDLE,
               VIP_VI_HANDLE,
               VIP_CQ_HANDLE,
               VIP_NIC_HANDLE,
               VIP_CONNECTION_HANDLE;
#define VIP_INVALID_HANDLE ((UINT32)NULL)
#define VIP_INFINITE INFINITE

/* Addresses are 64bits for the hardware
 */
typedef union _VIP_PVOID64 {
    VIP_UINT64 AddressBits;
    VIP_PVOID  Address;
    /* The following is ok for 32 bit little-endian machines. */
    struct {
        VIP_UINT32  Address;
        VIP_UINT32  AddressHigh;
    } AddressHalves;
} VIP_PVOID64;

/* Descriptors are made up of 3 types of segments,
 * starting with a control segment.
 */
typedef struct _VIP_CONTROL_SEGMENT {
    VIP_PVOID64    Next;
    VIP_UINT16     Status;
    VIP_UINT8      Control;
    VIP_UINT8      SegCount;
    VIP_UINT32     Length;
} VIP_CONTROL_SEGMENT, *PVIP_CONTROL_SEGMENT;

typedef struct _VIP_ADDRESS_SEGMENT {
    VIP_PVOID64    Data;
    VIP_PVOID64    Cookie;
} VIP_ADDRESS_SEGMENT, *PVIP_ADDRESS_SEGMENT;

typedef struct _VIP_DATA_SEGMENT {
    VIP_PVOID64    Data;
    VIP_UINT32     Length;
    VIP_UINT32     PadForAlign;
} VIP_DATA_SEGMENT, *PVIP_DATA_SEGMENT;

/* For send/receive operations, the control segment is followed
 * directly by zero or more data segments
 */
typedef struct _VIP_SR_DESCRIPTOR {
    VIP_CONTROL_SEGMENT ControlSegment;
    VIP_DATA_SEGMENT    DataSegment[1]; /* could be missing */
} VIP_SR_DESCRIPTOR, *PVIP_SR_DESCRIPTOR;

/* For RDMA operations, the control segment is followed 
 * by one address segment, followed by zero or more data segments
 */
typedef struct _VIP_RDMA_DESCRIPTOR {
    VIP_CONTROL_SEGMENT ControlSegment;
    VIP_ADDRESS_SEGMENT AddressSegment;
    VIP_DATA_SEGMENT    DataSegment[1]; /* could be missing */
} VIP_RDMA_DESCRIPTOR, *PVIP_RDMA_DESCRIPTOR;

typedef union _VIP_DESCRIPTOR {
    VIP_SR_DESCRIPTOR   SendReceiveDescriptor;
    VIP_RDMA_DESCRIPTOR RDMADescriptor;
} VIP_DESCRIPTOR, *PVIP_DESCRIPTOR;

/*
 * Possible values for the Control field of the Control Segment
*/
#define VIP_CONTROL_OP_SENDRECV  0x00
#define VIP_CONTROL_OP_RDMAWRITE 0x01
#define VIP_CONTROL_OP_RDMAREAD  0x02
#define VIP_CONTROL_IMMEDIATE    0x04
#define VIP_CONTROL_QFENCE       0x08

/* Possible values for the Status field of the Control Segment
 */
#define VIP_STATUS_DONE                 0x0001
#define VIP_STATUS_FORMAT_ERROR         0x0002
#define VIP_STATUS_PROTECTION_ERROR     0x0004
#define VIP_STATUS_LENGTH_ERROR         0x0008
#define VIP_STATUS_PARTIAL_ERROR        0x0010
#define VIP_STATUS_DESC_FLUSHED_ERROR   0x0020
#define VIP_STATUS_TRANSPORT_ERROR      0x0040
#define VIP_STATUS_RDMA_PROT_ERROR      0x0080
#define VIP_STATUS_REMOTE_DESC_ERROR    0x0100
#define VIP_STATUS_ERROR_MASK           0x01FE
#define VIP_STATUS_OP_SEND              0x0000
#define VIP_STATUS_OP_RECEIVE           0x1000
#define VIP_STATUS_OP_RDMA_WRITE        0x2000
#define VIP_STATUS_OP_REMOTE_RDMA_WRITE 0x3000
#define VIP_STATUS_OP_RDMA_READ         0x4000
#define VIP_STATUS_OP_MASK              0x7000

/* Possible values for the ResourceCode field in an error descriptor
 */
typedef enum _VIP_RESOURCE_CODE {
    VIP_RESOURCE_NIC,
    VIP_RESOURCE_VI,
    VIP_RESOURCE_CQ,
    VIP_RESOURCE_DESCRIPTOR
}  VIP_RESOURCE_CODE;

/* Possible values for the ErrorCode field in an error descriptor
 */
typedef enum _VIP_ERROR_CODE {
    VIP_ERROR_POST_DESC,
    VIP_ERROR_CONN_LOST,
    VIP_ERROR_RECVQ_EMPTY,
    VIP_ERROR_VI_OVERRUN,
    VIP_ERROR_RDMAW_PROT,
    VIP_ERROR_RDMAW_DATA,
    VIP_ERROR_RDMAW_ABORT,
    VIP_ERROR_RDMAR_PROT,
    VIP_ERROR_COMP_PROT
}  VIP_ERROR_CODE;

/* The error Descriptor
 */
typedef struct _VIP_ERROR_DESCRIPTOR {
    VIP_NIC_HANDLE    NicHandle;
    VIP_VI_HANDLE     ViHandle;
    VIP_CQ_HANDLE     CqHandle;
    VIP_DESCRIPTOR   *DescriptorPtr;
    VIP_ULONG         OpCode;
    VIP_RESOURCE_CODE ResourceCode;
    VIP_ERROR_CODE    ErrorCode;
} VIP_ERROR_DESCRIPTOR;

#if 0
/* The possible values for VIP_RELIABILITY_LEVEL are:
 */
typedef enum _VIP_RELIABILITY_LEVEL {
    VIP_SERVICE_UNRELIABLE,
    VIP_SERVICE_RELIABLE_DELIVERY,
    VIP_SERVICE_RELIABLE_RECEPTION
} VIP_RELIABILITY_LEVEL;
#else
/* Definition defies math */
typedef VIP_UINT16 VIP_RELIABILITY_LEVEL;
#define VIP_SERVICE_UNRELIABLE 1
#define VIP_SERVICE_RELIABLE_DELIVERY 2
#define VIP_SERVICE_RELIABLE_RECEPTION 4
#endif

/* The NIC attributes structure
 */
typedef struct _VIP_NIC_ATTRIBUTES {
    VIP_CHAR        Name [64];
    VIP_ULONG       HardwareVersion;
    VIP_ULONG       ProviderVersion;
    VIP_UINT16      NicAddressLen;
    const VIP_UINT8 *LocalNicAddress;
    VIP_BOOLEAN     ThreadSafe;
    VIP_UINT16      MaxDiscriminatorLen;
    VIP_ULONG       MaxRegisterBytes;
    VIP_ULONG       MaxRegisterRegions;
    VIP_ULONG       MaxRegisterBlockBytes;
    VIP_ULONG       MaxVI;
    VIP_ULONG       MaxDescriptorsPerQueue;
    VIP_ULONG       MaxSegmentsPerDesc;
    VIP_ULONG       MaxCQ;
    VIP_ULONG       MaxCQEntries;
    VIP_ULONG       MaxTransferSize;
    VIP_ULONG       NativeMTU;
    VIP_ULONG       MaxPtags;
    VIP_RELIABILITY_LEVEL ReliabilityLevelSupport;
    VIP_BOOLEAN     RDMAReadSupport;
} VIP_NIC_ATTRIBUTES;


/* The VIP_VI_ATTRIBUTES structure
 */
typedef struct _VIP_VI_ATTRIBUTES {
    VIP_RELIABILITY_LEVEL  ReliabilityLevel;
    VIP_ULONG              MaxTransferSize;
    VIP_BOOLEAN            EnableRdmaWrite;
    VIP_BOOLEAN            EnableRdmaRead;
    VIP_PVOID              QoS;
    VIP_CQ_HANDLE          SendCQHandle;
    VIP_CQ_HANDLE          RecvCQHandle;
} VIP_VI_ATTRIBUTES;


/* This structure defines the attributes of registered memory regions
 */
typedef struct _VIP_MEM_ATTRIBUTES {
    VIP_BOOLEAN           EnableRdmaWrite;
    VIP_BOOLEAN           EnableRdmaRead;
} VIP_MEM_ATTRIBUTES;

/* Possible states for a VI
 */
typedef enum _VIP_VI_STATE {
    VIP_STATE_IDLE,
    VIP_STATE_CONNECTED,
    VIP_STATE_CONNECT_PENDING,
    VIP_STATE_ERROR
} VIP_VI_STATE;

/* Generic address
 */
typedef struct _VIP_NET_ADDRESS {
    VIP_UINT16  HostAddressLen;
    VIP_UINT16  DiscriminatorLen;
    VIP_UINT8   HostAddress[1]; /* variable length */
} VIP_NET_ADDRESS;


/*
 * User Agent APIs 
 */

/* XXX declspec(dllimport) XXX */

#ifdef _MSC_VER
#define VIP_LINKAGE __cdecl
#else
#define VIP_LINKAGE
#endif

/* Section 9.2 */
VIP_RETURN 
VIP_LINKAGE
VipOpenNic(
    IN  const UINT32 DeviceId,
    OUT VIP_NIC_HANDLE *NicHandle
    );

VIP_RETURN 
VIP_LINKAGE
VipCloseNic(
    IN  VIP_NIC_HANDLE  NicHandle
    );

/* Section 9.3 */
VIP_RETURN 
VIP_LINKAGE
VipCreateVi(
    IN  VIP_NIC_HANDLE     NicHandle,
    IN  VIP_VI_ATTRIBUTES *ViAttribs,
    OUT VIP_VI_HANDLE     *ViHandle
    );

VIP_RETURN 
VIP_LINKAGE
VipDestroyVi(
    IN  VIP_VI_HANDLE ViHandle
    );


/* Section 9.4 */

VIP_RETURN 
VIP_LINKAGE
VipConnectWait(
    IN  VIP_NIC_HANDLE         NicHandle,
    IN  VIP_NET_ADDRESS       *LocalAddr,
    IN  VIP_ULONG              TimeOut,
    OUT VIP_NET_ADDRESS       *RemoteAddr,
    OUT VIP_VI_ATTRIBUTES     *RemoteViAttribs,
    OUT VIP_CONNECTION_HANDLE *ConnHandle
    );

VIP_RETURN
VIP_LINKAGE
VipConnectWaitAsynch(
    IN  VIP_NIC_HANDLE         NicHandle,
    IN  VIP_NET_ADDRESS       *LocalAddr,
    IN  void *                 Event  /* ComplPorts? OVERLAPPED maybe ? */
    );

VIP_RETURN 
VIP_LINKAGE
VipConnectAccept(
    IN  VIP_CONNECTION_HANDLE ConnHandle,
    IN  VIP_VI_HANDLE         ViHandle
    );

VIP_RETURN 
VIP_LINKAGE
VipConnectReject(
    IN  VIP_NIC_HANDLE         NicHandle,
    IN  VIP_CONNECTION_HANDLE ConnHandle
    );

VIP_RETURN 
VIP_LINKAGE
VipConnectRequest(
    IN  VIP_VI_HANDLE      ViHandle,
    IN OUT  VIP_NET_ADDRESS   *LocalAddr,
    IN  VIP_NET_ADDRESS   *RemoteAddr,
    IN  VIP_ULONG          TimeOut,
    OUT VIP_VI_ATTRIBUTES *RemoteViAttribs
    );

VIP_RETURN 
VIP_LINKAGE
VipConnectRequestAsynch(
    IN VIP_VI_HANDLE            ViHandle,
    IN VIP_NET_ADDRESS   *      RemoteAddr,
    IN void *                   Event
    );

VIP_RETURN 
VIP_LINKAGE
VipDisconnect(
    IN  VIP_VI_HANDLE ViHandle
    );


/* Section 9.5 */
VIP_RETURN 
VIP_LINKAGE
VipRegisterMem(
    IN  VIP_NIC_HANDLE      NicHandle,
    IN  VIP_PVOID           VirtualAddress,
    IN  VIP_ULONG           Length,
    IN  VIP_MEM_ATTRIBUTES *MemAttribs,
    OUT VIP_MEM_HANDLE     *MemoryHandle
    );

VIP_RETURN 
VIP_LINKAGE
VipDeregisterMem(
    IN  VIP_NIC_HANDLE NicHandle,
    IN  VIP_PVOID      VirtualAddress,
    IN  VIP_ULONG      Length,
    IN  VIP_MEM_HANDLE MemoryHandle
    );


/* Section 9.6 */
VIP_RETURN 
VIP_LINKAGE
VipPostSend(
    IN  VIP_VI_HANDLE   ViHandle,
    IN  VIP_DESCRIPTOR *DescriptorPtr
    );

VIP_RETURN 
VIP_LINKAGE
VipSendDone(
    IN  VIP_VI_HANDLE    ViHandle,
    OUT VIP_DESCRIPTOR **DescriptorPtr
    );

VIP_RETURN
VIP_LINKAGE
VipSendWait(
    IN  VIP_VI_HANDLE    ViHandle,
    IN  VIP_ULONG        TimeOut,
    OUT VIP_DESCRIPTOR **DescriptorPtr
    );

VIP_RETURN 
VIP_LINKAGE
VipPostRecv(
    IN  VIP_VI_HANDLE   ViHandle,
    IN  VIP_DESCRIPTOR *DescriptorPtr
    );

VIP_RETURN 
VIP_LINKAGE
VipRecvDone(
    IN  VIP_VI_HANDLE    ViHandle,
    OUT VIP_DESCRIPTOR **DescriptorPtr
    );

VIP_RETURN
VIP_LINKAGE
VipRecvWait(
    IN  VIP_VI_HANDLE    ViHandle,
    IN  VIP_ULONG        TimeOut,
    OUT VIP_DESCRIPTOR **DescriptorPtr
    );

VIP_RETURN 
VIP_LINKAGE
VipCQDone(
    IN  VIP_CQ_HANDLE  CQHandle,
    OUT VIP_VI_HANDLE *ViHandle,
    OUT VIP_BOOLEAN   *RecvQueue
    );

VIP_RETURN
VIP_LINKAGE
VipCQWait(
    IN  VIP_CQ_HANDLE  CQHandle,
    IN  VIP_ULONG      TimeOut,
    OUT VIP_VI_HANDLE *ViHandle,
    OUT VIP_BOOLEAN   *RecvQueue
    );

/* Section 9.7 */
VIP_RETURN 
VIP_LINKAGE
VipCreateCQ(
    IN  VIP_NIC_HANDLE NicHandle,
    IN  VIP_ULONG      EntryCount,
    OUT VIP_CQ_HANDLE *CQHandle
    );

VIP_RETURN 
VIP_LINKAGE
VipDestroyCQ(
    IN  VIP_CQ_HANDLE CQHandle
    );

VIP_RETURN 
VIP_LINKAGE
VipResizeCQ(
    IN  VIP_CQ_HANDLE CQHandle,
    IN  VIP_ULONG     EntryCount
    );


/* Section 9.8 */
VIP_RETURN 
VIP_LINKAGE
VipQueryNic(
    IN  VIP_NIC_HANDLE      NicHandle,
    OUT VIP_NIC_ATTRIBUTES *Attributes
    );

VIP_RETURN 
VIP_LINKAGE
VipSetViAttributes(
    IN  VIP_VI_HANDLE      ViHandle,
    IN  VIP_VI_ATTRIBUTES *Attributes
    );

VIP_RETURN
VIP_LINKAGE
VipQueryVi(
    IN  VIP_VI_HANDLE      ViHandle,
    OUT VIP_VI_STATE      *State,
    OUT VIP_VI_ATTRIBUTES *Attributes,
    OUT VIP_BOOLEAN       *SendQueueEmpty,
    OUT VIP_BOOLEAN       *RecvQueueEmpty
    );

VIP_RETURN 
VIP_LINKAGE
VipSetMemAttributes(
    IN  VIP_NIC_HANDLE      NicHandle,
    IN  VIP_PVOID           Address,
    IN  VIP_MEM_HANDLE      MemHandle,
    IN  VIP_MEM_ATTRIBUTES *MemAttribs
    );

VIP_RETURN
VIP_LINKAGE
VipQueryMem(
    IN  VIP_NIC_HANDLE      NicHandle,
    IN  VIP_PVOID           Address,
    IN  VIP_MEM_HANDLE      MemHandle,
    OUT VIP_MEM_ATTRIBUTES *MemAttribs
    );

VIP_RETURN 
VIP_LINKAGE
VipQuerySystemManagementInfo(
    IN  VIP_NIC_HANDLE  NicHandle,
    IN  VIP_ULONG       InfoType,
    OUT VIP_PVOID      *SysManInfo
    );


/* Section 9.9 */
VIP_RETURN 
VIP_LINKAGE
VipErrorCallback(
    IN  VIP_NIC_HANDLE NicHandle,
    IN  VIP_PVOID      Context,
    IN  void(VIP_LINKAGE *Handler)(
        IN  VIP_PVOID             Context,
        IN  VIP_ERROR_DESCRIPTOR *ErrorDesc
        )
    );

/****************************
 * Additional APIs and stuff
 */
VIP_RETURN
VIP_LINKAGE
VipSockaddrToVipAddress(
    IN  const struct sockaddr *Sockaddr,
    IN  VIP_ULONG SockaddrLength,
    OUT VIP_NET_ADDRESS *VipAddress
    );

VIP_RETURN
VIP_LINKAGE
VipAddressToSockaddr(
    IN  const VIP_NET_ADDRESS *VipAddress,
    OUT struct sockaddr *Sockaddr,
    OUT VIP_ULONG *SockaddrLength
    );

#define VIP_PORT_ANY ((UINT16)0)

VIP_RETURN
VIP_LINKAGE
VipBindToPort(
    IN  VIP_VI_HANDLE ViHandle,
    IN  UINT16 Port,
    IN OUT  VIP_NET_ADDRESS   *VipAddress
    );

VIP_BOOLEAN
VIP_LINKAGE
VipIsBound(
    IN  VIP_VI_HANDLE ViHandle,
    IN  VIP_NET_ADDRESS   *VipAddress
    );

#define AF_ALVIA 28

#endif /* _VIA_ */
