/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>

PIUNKNOWN PnpCobMain(void);

PIUNKNOWN CobMain(void)
{
    return PnpCobMain();
}
