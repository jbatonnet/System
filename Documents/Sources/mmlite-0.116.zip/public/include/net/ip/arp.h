/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Copyright (c) 1982, 1986, 1993
 *    The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the University of
 *    California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *    @(#)if_ether.h    8.1 (Berkeley) 6/10/93
 */

#ifndef __IP_ARP_H
#define __IP_ARP_H

#include <if_dl.h>

#include <util/list-double2.h>

/*
 * Structure of a 10Mb/s Ethernet header.
 */
#ifdef __GNUC__
#define __GCCPACK __attribute__ ((packed))
#else
#define __GCCPACK
#endif

/*
 * The number of bytes in an ethernet (MAC) address.
 */
#define ETHER_ADDR_LEN      6

struct ether_header {
    UINT8 ether_dhost[ETHER_ADDR_LEN];
    UINT8 ether_shost[ETHER_ADDR_LEN];
    UINT16 ether_type;
} __GCCPACK;

#define ETHERTYPE_PUP    0x0200  /* PUP protocol */
#define ETHERTYPE_IP     0x0800  /* IP protocol */
#define ETHERTYPE_ARP    0x0806  /* Addr. resolution protocol */
#define ETHERTYPE_REVARP 0x8035  /* reverse Addr. resolution protocol */

/*
 * The ETHERTYPE_NTRAILER packet types starting at ETHERTYPE_TRAIL have
 * (type-ETHERTYPE_TRAIL)*512 bytes of data followed
 * by an ETHER type (as given above) and then the (variable-length) header.
 */
#define ETHERTYPE_TRAIL 0x1000  /* Trailer packet */
#define ETHERTYPE_NTRAILER 16

#define ETHERMTU 1500
#define ETHERMIN (60-14)

/*
 * Macro to map an IP multicast address to an Ethernet multicast address.
 * The high-order 25 bits of the Ethernet address are statically assigned,
 * and the low-order 23 bits are taken from the low end of the IP address.
 */
#define ETHER_MAP_IP_MULTICAST(ipaddr, enaddr) \
    /* struct in_addr *ipaddr; */ \
    /* UINT8 enaddr[6];       */ \
{ \
    (enaddr)[0] = 0x01; \
    (enaddr)[1] = 0x00; \
    (enaddr)[2] = 0x5e; \
    (enaddr)[3] = (UINT8)(((UINT8 *)ipaddr)[1] & 0x7f); \
    (enaddr)[4] = ((UINT8 *)ipaddr)[2]; \
    (enaddr)[5] = ((UINT8 *)ipaddr)[3]; \
}

/*
 * Ethernet Address Resolution Protocol.
 *
 * See RFC 826 for protocol description.  Structure below is adapted
 * to resolving internet addresses.  Field names used correspond to 
 * RFC 826.
 */
struct ether_arp {
    struct arphdr ea_hdr;  /* fixed-size header */
    UINT8 arp_sha[6];      /* sender hardware address */
    UINT8 arp_spa[4];      /* sender protocol address */
    UINT8 arp_tha[6];      /* target hardware address */
    UINT8 arp_tpa[4];      /* target protocol address */
};
#define arp_hrd ea_hdr.ar_hrd
#define arp_pro ea_hdr.ar_pro
#define arp_hln ea_hdr.ar_hln
#define arp_pln ea_hdr.ar_pln
#define arp_op  ea_hdr.ar_op


/*
 * Structure shared between the ethernet driver modules and
 * the address resolution code.  For example, each ec_softc or il_softc
 * begins with this structure.
 */
struct arpcom {
    struct ifnet ac_if;                 /* network-visible interface */
    UINT8 ac_enaddr[6];                 /* ethernet hardware address */
    struct in_addr ac_ipaddr;           /* copy of ip address- XXX */
    struct ether_multi *ac_multiaddrs;  /* list of ether multicast addrs */
    INT ac_multicnt;                    /* length of ac_multiaddrs list */    
};

struct llinfo_arp {                
    struct sockaddr_in la_inaddr;
    struct sockaddr_dl la_dladdr;
    struct mbuf *la_hold;        /* last packet until resolved/timeout  */
    INT la_asked;                /* # of times we QUERIED for this addr */
    UINT la_expire;              /* deletion time in seconds */
    UINT la_flags;

    ListNodeDeclare(llinfo_arp, ListNode);
#define llarpoff offsetof(struct llinfo_arp, ListNode)
};
#define LAF_EMBRYO 0x01
#define LAF_DOWN   0x02


#if 0
struct sockaddr_inarp {
    UINT8 sin_len;
    UINT8 sin_family;
    UINT16 sin_port;
    struct in_addr sin_addr;
    struct in_addr sin_srcaddr;
    UINT16 sin_tos;
    UINT16 sin_other;
#define SIN_PROXY 1
};
#endif

/*
 * IP and ethernet specific routing flags
 */
#define RTF_USETRAILERS RTF_PROTO1  /* use trailers */
#define RTF_ANNOUNCE RTF_PROTO2     /* announce new arp entry */

#ifdef KERNEL
extern const UINT8 etherbroadcastaddr[6];
extern const UINT8 ether_ipmulticast_min[6];
extern const UINT8 ether_ipmulticast_max[6];

struct llinfo_arp *arptnew (struct in_addr *);
extern struct llinfo_arp llinfo_arp;  /* head of the llinfo queue */

void arpwhohas(struct arpcom *, struct in_addr *);
void arp_input(struct mbuf *);
INT arpresolve(struct arpcom *, struct route_in *, struct mbuf *, UINT8 *);
void arp_rtrequest(INT, struct rtentry *, struct sockaddr *);
void arptimer( void );

void arp_addentry(struct ifnet *, INT, struct sockaddr_in *,
                  struct sockaddr_dl *);
void arp_delentry(struct ifnet *, struct sockaddr_in *);

INT ether_addmulti(struct ifreq *, struct arpcom *);
INT ether_delmulti(struct ifreq *, struct arpcom *);

#define DEBUG
#ifdef DEBUG
void arpdump(void);
#endif

/*
 * Ethernet multicast address structure.  There is one of these for each
 * multicast address or range of multicast addresses that we are supposed
 * to listen to on a particular interface.  They are kept in a linked list,
 * rooted in the interface's arpcom structure.  (This really has nothing to
 * do with ARP, or with the Internet address family, but this appears to be
 * the minimally-disrupting place to put it.)
 */
struct ether_multi {
    UINT8 enm_addrlo[6];           /* low  or only address of range */
    UINT8 enm_addrhi[6];           /* high or only address of range */
    struct arpcom *enm_ac;         /* back pointer to arpcom */
    UINT enm_refcount;             /* no. claims to this addr/range */
    struct ether_multi *enm_next;  /* ptr to next ether_multi */
};

/*
 * Structure used by macros below to remember position when stepping through
 * all of the ether_multi records.
 */
struct ether_multistep {
    struct ether_multi *e_enm;
};

/*
 * Macro for looking up the ether_multi record for a given range of Ethernet
 * multicast addresses connected to a given arpcom structure.  If no matching
 * record is found, "enm" returns NULL.
 */
#define ETHER_LOOKUP_MULTI(addrlo, addrhi, ac, enm) \
    /* UINT8 addrlo[6]; */ \
    /* UINT8 addrhi[6]; */ \
    /* struct arpcom *ac; */ \
    /* struct ether_multi *enm; */ \
{ \
    for ((enm) = (ac)->ac_multiaddrs; \
        (enm) != NULL && \
        (bcmp((enm)->enm_addrlo, (addrlo), 6) != 0 || \
         bcmp((enm)->enm_addrhi, (addrhi), 6) != 0); \
        (enm) = (enm)->enm_next); \
}

/*
 * Macro to step through all of the ether_multi records, one at a time.
 * The current position is remembered in "step", which the caller must
 * provide.  ETHER_FIRST_MULTI(), below, must be called to initialize "step"
 * and get the first record.  Both macros return a NULL "enm" when there
 * are no remaining records.
 */
#define ETHER_NEXT_MULTI(step, enm) \
    /* struct ether_multistep step; */  \
    /* struct ether_multi *enm; */  \
{ \
    if (((enm) = (step).e_enm) != NULL) \
        (step).e_enm = (enm)->enm_next; \
}

#define ETHER_FIRST_MULTI(step, ac, enm) \
    /* struct ether_multistep step; */ \
    /* struct arpcom *ac; */ \
    /* struct ether_multi *enm; */ \
{ \
    (step).e_enm = (ac)->ac_multiaddrs; \
    ETHER_NEXT_MULTI((step), (enm)); \
}

#endif

#endif // __IP_ARP_H
