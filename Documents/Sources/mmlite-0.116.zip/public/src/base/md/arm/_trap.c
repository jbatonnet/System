/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>
#include <mmhal.h>
#include <base/debugger.h>

#if defined(_DEBUG)
#define DBG(_x_) printf _x_
char *trapStr = "Caught a %s exception, skipping over\n\n";
#else
#define DBG(_x_)
#endif

extern UINT32 MMUFaultAddress(void);
extern UINT32 MMUFaultStatus(void);

/* Installable trap handler returns TRUE if debugger action is required */
BOOL (*TrapDAHandler)(PCXTINFO *) = NULL;
/* Install/Remove an interrupt handler entry */
void InstallIsr( UINT InterruptNumber, ADDRESS Isr,
                UINT RawTrapNumber, UINT UserAccessible)
{
    /* XXX Only used for TrapDA for now */
    TrapDAHandler = (BOOL (*)(PCXTINFO *)) (PTR) Isr;
}

/* Data Access Traps */
PCXTINFO TrapDA(PCXTINFO pContext)
{
    BOOL DebuggerNeeded = TRUE;
    (void) CheckStackOverflow(CurrentThread());
    pContext->PC -= 4;
    /* XXX This code could certainly be optimized... */
    if (TrapDAHandler != NULL)
        DebuggerNeeded = (*TrapDAHandler)(&pContext);
    if (DebuggerNeeded) {
        if (!DebuggerAttached) {
            DBG((trapStr, "data abort"));
            DBG(("pc %08x %08x %08x lr=%08x\n",
                 pContext->PC-4, MMUFaultAddress(), MMUFaultStatus(), pContext->R14));
            DBG(("stack usage: %d\n", CheckStackUsage(CurrentThread())));
        }
        Debugger(pContext,4);
    }
    return pContext;
}

/* Prefetch Access Traps*/
PCXTINFO TrapPA(CXTINFO *pContext)
{
    /* Skip over faulting instruction. Don't need to do anything, since PC is 4 bytes beyond.*/
    (void) CheckStackOverflow(CurrentThread());
    if (!DebuggerAttached) {
        DBG((trapStr, "prefetch abort"));
        DBG(("pc %08x\n", pContext->PC-4));
        DBG(("stack usage: %d\n", CheckStackUsage(CurrentThread())));
    }
    Debugger(pContext,3);
    return pContext;
}

PCXTINFO TrapUI(CXTINFO *pContext)
{
    (void) CheckStackOverflow(CurrentThread());
    if (!DebuggerAttached) {
        if (*(UINT32*)(pContext->PC-4) == 0xfedefede) /* 0xe7ffdefe */
            DBG((trapStr, "breakpoint"));
        else
            DBG((trapStr, "undefined instruction"));
        DBG(("pc %08x *pc=%08x lr=%08x\n", pContext->PC-4, *(UINT32*)(pContext->PC-4), pContext->R14));
        DBG(("stack usage: %d\n", CheckStackUsage(CurrentThread())));
    }
    Debugger(pContext,1);
    return pContext;
}

/* Fast Interrupt Traps*/
PCXTINFO TrapFIQ(CXTINFO *pContext)
{
    pContext->PC -= 4;  
    DBG((trapStr, "FIQ"));
    return pContext;
}
