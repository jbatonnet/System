/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* --------------------------------------------------------------------------
 *
 * Module:
 *
 *    keybd_hw.h
 *
 * Purpose:
 *
 *    MMLite header file for keyboard devices.
 *
 * Author:
 *    A. Forin (sandrof)
 *
 * --------------------------------------------------------------------------
 */

#ifndef __KEYBOARD_HW_
#define __KEYBOARD_HW_ 1


/* A keyboard report is a state-change event.
 * It indicates what key was pressed/released
 * by the user, at the indicated time.
 */
typedef struct {

    /* Time at which sample was received,
     * or artificially generated.
     */
    TIME        ReportTime;

    /* Keyboard scan code.
     * Uniquely identifies the key, real
     * or presumed (overruns).
     */
    UINT16      MakeCode;

    /* Event type, one of up/down/special
     */
    UINT16      Flags;

} KEYBOARD_INPUT_DATA, *PKEYBOARD_INPUT_DATA;

/* Scan codes are device-specific
 */

/* Flags field encodings.
 */
#define KEYBOARD_FLAGS_DOWN_STROKE   0x000
#define KEYBOARD_FLAGS_UP_STROKE     0x001
#define KEYBOARD_FLAGS_SPECIAL_0     0x002
#define KEYBOARD_FLAGS_SPECIAL_1     0x004
#define KEYBOARD_FLAGS_OVERRUN       0x100


/* Nt-compat defines
 */
#define KEYBOARD_OVERRUN_MAKE_CODE    0xFF

#define KEY_MAKE        KEYBOARD_FLAGS_DOWN_STROKE
#define KEY_BREAK       KEYBOARD_FLAGS_UP_STROKE
#define KEY_E0          KEYBOARD_FLAGS_SPECIAL_0
#define KEY_E1          KEYBOARD_FLAGS_SPECIAL_1


#endif /* __KEYBOARD_HW__ */
