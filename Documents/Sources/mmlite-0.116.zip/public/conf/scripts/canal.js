// Copyright (c) Microsoft Corporation. All rights reserved.
//

// Code analyzer that makes html pages and some cross reffing.  --jvh 2000

//----------- Globals --------------------------------------------//
var htmldir = null;
var xmldir = null;
var incdir = null;
var verbose = 0;
var debug = false;
var maketoc = false;
var ofs = null;
var scriptpath = null;
var xmldata = "";
var inputfile;
var suffix;
var recursive = false;
var excludeglob;
var excludedirs;
var collectionwritemode = "new";
var docindex = null;
var rootpath = "";
var domdocument_name = "Msxml2.DOMDocument.5.0";
var schema_cache;

try {
    schema_cache = new ActiveXObject("Msxml2.XMLSchemaCache.5.0");
} catch (exception) {
try {
    schema_cache = new ActiveXObject("Msxml2.XMLSchemaCache.4.0");
    domdocument_name = "Msxml2.DOMDocument.4.0";
} catch (exception) {
    alert("*** Runtime Error: " + exception.description + "\n*** Looks like msxml4 is missing.\n*** Try downloading from http://msdn.microsoft.com/XML/XMLDownloads/default.aspx");
    exit;
}}

var bracecount = 0;
var bracketcount = 0;
var parencount = 0;
var isnested = false;

function resetnesting() {
  bracecount = 0;
  bracketcount = 0;
  parencount = 0;
  isnested = false;
}

var apos = 0;

//----------- Main --------------------------------------------//
function usage() {
  alert("USAGE: canal [-v]* (verbose) [-V] (debug) [-t] (make TOC, no files) [-r path] (recurse dir) [-d path] (dir) [-e except-dir] (skip these dirs) [-w web-output-dir] (generate web pages) [-x exclude pattern] (anti-wildcard) [-a] (append) [-u] (update) [-c collection-file] (collect interesting info) [-i docindex-file] (hrefs to doc) source-file\n");
}

// main()
if (WScript != null) {
  var xmlcollectionfile = "";

  ofs = WScript.CreateObject("Scripting.FileSystemObject");
  var scriptpath = ofs.getParentFolderName(WScript.scriptFullName);

  var dirs = new Array();
  excludeglob = new Array();
  excludedirs = new Array();

  schema_cache.add("x-schema:spec-schema.xml", "conf/spec-schema.xml");
  schema_cache.add("x-schema:expanded-schema.xml", "conf/expanded-schema.xml");

  var args = WScript.arguments;
  var consumedargs = 0;
  for (var i = 0; i < args.length; i++) {
    if (args.item(i).substring(0,1) == "-") {
      consumedargs++;
      var opt = args.item(i).substr(1);
      switch(opt) {
      case "w":                 // html dir
        if (args.length - i < 2)
          usage();
        htmldir = args.item(++i).replace(/\\/g, "/");
        consumedargs++;
        break;
      case "x": {               // eXclude leaf pattern
        if (args.length - i < 2)
          usage();
        var xname = args.item(++i);
        xname = xname.replace(/\./gm, "[.]");
        xname = xname.replace(/\*/gm, ".*");
        xname = xname.replace(/\?/gm, ".");
        xname = "([/\\\\]|^)" + xname;

        excludeglob = excludeglob.concat(new RegExp(xname, ""));
        consumedargs++;
        xname = null;
        break;
      }
      case "e": {               // Exclude dir
        if (args.length - i < 2)
          usage();
        var xname = args.item(++i);
        xname = xname.replace(/\\/gm, "/");
        xname = xname.replace(/\./gm, "[.]");
        xname = xname.replace(/\*/gm, ".*");
        xname = xname.replace(/\?/gm, ".");
        xname = "^" + xname;

        excludedirs = excludedirs.concat(new RegExp(xname, ""));
        consumedargs++;
        xname = null;
        break;
      }
      case "d":                 // add dir to input list
        if (args.length - i < 2)
          usage();
        i++;
        dirs = dirs.concat(args.item(i).replace(/\\/g, "/"));
        consumedargs++;
        break;
      case "r":                 // add dir and all its subdirs to inputs
        if (args.length - i < 2)
          usage();
        i++;
        dirs = dirs.concat(args.item(i), expandsubdirs(args.item(i).replace(/\\/g, "/")));
        consumedargs++;
        break;
      case "i": {                // documentation index file
        if (args.length - i < 2)
          usage();
        docindex = load_xml(args.item(++i), true, true, false);
        consumedargs++;
        break;
      }
      case "c":                 // data Collection file
        if (args.length - i < 2)
          usage();
        xmlcollectionfile = args.item(++i).replace(/\\/g, "/");
        consumedargs++;
        break;
      case 'a':
        collectionwritemode = "append";
        break;
      case 'u':
        collectionwritemode = "update";
        break;
      case "t":                 // table of contents
        maketoc = true;
        break;
      case "v":                 // Verbose
        verbose++;
        break;
      case "V":                 // debug VVERRY Verbose
        debug = true;
        break;
      default:
        alert("unknown option '" + opt + "'");
      }
    }
  }

  if (args.length - consumedargs < 1)
    usage();

  var xmlfile;
  if (xmlcollectionfile != "") {
    if (collectionwritemode == "append")
      xmlfile = ofs.OpenTextFile(xmlcollectionfile, 8); // append mode
    else if (collectionwritemode == "update")
      xmlfile = ofs.OpenTextFile(xmlcollectionfile, 8, true); // append XXX should be write mode once rest of update is done
    else
      xmlfile = ofs.CreateTextFile(xmlcollectionfile, true);
    //xmlfile.Write("<?xml version='1.0'?>\n\n");
    //xmlfile.Write("<extracted-code-data>\n");
    xmlcollectionfile = null;
  }

  if (debug) {
    echo ("dirs= (" + dirs.length + ") " + dirs.join(" : "));
    echo ("excludedirs= (" + excludedirs.length + ") "
          + excludedirs.join(" : "));
    echo ("excludeglob= (" + excludeglob.length + ") "
          + excludeglob.join(" : "));
  }

  // allocate one array for collecting results so as to help the GC.
  var newline = new Array();

  var tocdic = new ActiveXObject("Scripting.Dictionary");
  var tocprefix = "toc-4";

  while (args.length - consumedargs > 0) {
    var filespec = args.item(consumedargs);
    consumedargs++;

    // Keep an array of TOC indices at different depths.
    // The file names are toc-1-0-2.xml (depth 2, 1 & first & third entry)
    var depth = 0, index = 0;

    if (dirs.length > 0) {
      var files, tocfile, mapfile;
      // Keep track of sub-entries for file index generation.
      var childdirlist = new Array();
      var childdirtoc = new Array();
      var childfilelist = new Array();
      var childfiletoc = new Array();

      for (var d = 0; d < dirs.length; d++) {
        if (maketoc) {
          var tmp = dirs[d].replace(/[^\/\\]+/g, "");
          depth = tmp.length + 1;   // count slashes
          var mytocpath = "";
          if (tocdic.Exists(dirs[d])) {
            //echo("SAVED " + tocdic.item(dirs[d]));
            mytocpath = tocdic.item(dirs[d]);
          } else {            
            mytocpath = tocprefix;
            for (tmp = 0; tmp < depth-1; tmp++)
              mytocpath += "-" + "0";
          }
          // Create Table of Contents in MSDN style in the directory.
          var tocfilename_rel = "/" + dirs[d] + "/" + mytocpath + ".xml";
          var tocfilename = htmldir + tocfilename_rel;
          var mapfilename = htmldir + "/" + dirs[d] + "/map.xml";
          var incmapfilename = htmldir + "/" + dirs[d] + "/map2.inc.xml";
            
          if (verbose)
            echo("Generating TOCFILE " + tocfilename);
          makedir(pathname(tocfilename));
          tocfile = ofs.CreateTextFile(tocfilename);
          // Add included map entries if any.
          mapfile = ofs.CreateTextFile(mapfilename);

          var mytitle = dirs[d];
          if (mytitle == ".")
              mytitle = "Source"; // top level
          // forward map TOC
          tocfile.write("<MTN title=\"" + mytitle
                        + "\" nodeType=\"node\" type=\"none\" tocPath=\""
                        + mytocpath + "\" prePartum=\""+tocfilename_rel+"\"");
          // Refer to source explanation/index file
          tocfile.write(" ref=\"" + dirs[d] + "/files.htm\"");
          tocfile.write(" >\n");

          // and reverse map
          mapfile.write("<?xml version=\"1.0\"?>\n<!DOCTYPE MsdnTocMap [\n<!ELEMENT MsdnTocMap (L+)>\n<!ATTLIST MsdnTocMap \n            rootToc CDATA #IMPLIED\n>\n\n<!ELEMENT L EMPTY>\n<!ATTLIST L\n            url         ID #REQUIRED\n            pth        CDATA #REQUIRED\n>\n]>\n\n<MsdnTocMap>\n");
          mapfile.write("  <L url=\"files.htm\" pth=\""+mytocpath+"\" />\n");

          // For top-level map.xml we need to add static and generated
          // additional mapping info.
          try {
              // toc.inc has all the genspec generated entries
              var incmapfile = ofs.OpenTextFile(incmapfilename);
              var stuff = incmapfile.ReadAll();
              mapfile.write(stuff);
              incmapfile.Close();
              if (verbose > 0)
                echo("Included " + incmapfilename);

      if (false) // interfaces.htm cannot be there twice or nothing works
              try {
                // toc.xml has static entries. Reverse map and output.
                var toc = load_xml(htmldir + "/toc.xml", true, true, false);
                var nodelist = toc.selectNodes("//MTN[@ref]");
                if (verbose > 0)
                  echo("Found " + nodelist.length + " //MTN[@ref] in toc.xml");
                for (var i = 0; i < nodelist.length; i++) {
                  var ref = nodelist.item(i).getAttribute("ref");
                  var tocPath = nodelist.item(i).getAttribute("tocPath");
                  // if there is a slash in the path we need to output
                  // into subdir. map.inc there will do the trick.
                  if (ref.match(/[/]/)) {
// NOT NEEDED because the files will be listed anyway by virtue of existing
// + does not work anyways (would need CreateTextFile)
//                    var where = RegExp.leftContext;
//                    var what = RegExp.rightContext;
//                    var filename = htmldir + "/" + where + "/map.inc";
//                    echo("OUTPUT '" + what + "' to '" + where
//                         + "' -> " + filename); 
//                    var file = ofs.OpenTextFile(filename);
//                    file.write("  <L url='"+what+"' pth='"+tocPath+"' />\n");
//                    file.Close();
                  } else {
                    mapfile.write("  <L url='"+ref+"' pth='"+tocPath+"' />\n");
                  }
                }
              } catch(e) {
              }
          } catch(e) {
          }

          // Add TOC entries for subdirs.
          index = 0;
          for (var d2 = d + 1; d2 < dirs.length; d2++) {
            // eliminate dirs that are not subdirs */
            if (dirs[d] == ".") {
              if (dirs[d2].indexOf("/") != -1) // immediate sub of dot
                continue;
            } else {
              if (dirs[d2].indexOf(dirs[d]+"/") != 0) // proper prefix
                continue;

              // eliminate recursive subdirs
              if (dirs[d2].indexOf("/", dirs[d].length + 1) != -1) {
                if (verbose > 1)
                  echo("NOT IMMEDIATE subdir " + dirs[d2] + " of " + dirs[d]);
                continue;
              }
            }

            var tocpath = mytocpath + "-" + index++;
            if (verbose > 1)
              echo("SUBDIR " + dirs[d2] + " of " + dirs[d] + " tocP="+tocpath);

            if (tocdic.Exists(dirs[d2]))
              alert("DOUBLE entry " + dirs[d2] + " " + mytocpath);
            else
              tocdic.Add(dirs[d2], tocpath);

            tocfile.Write("  <MTN title=\"" + basename(dirs[d2])
                          + "\" nodeType=\"collection\" type=\"none\" tocPath=\""
                          + tocpath + "\" prePartum=\"/"
                          + dirs[d2] + "/" + tocpath + ".xml"
                          + "\" ref=\"" + dirs[d2] + "/files.htm\" />\n");
            childdirlist[childdirlist.length] = basename(dirs[d2]);
            childdirtoc[childdirtoc.length] = tocpath;
          }
        }
        files = glob(dirs[d] + "/" + filespec);
        for (var i = 0; i < files.length; i++) {
          xmldata = "";
          inputfile = files[i];
          if (docindex) {
            rootpath = pathname(inputfile).replace(/[^\/\\]+/g, "..");
            // Fix if already in root...
            if (inputfile[0] == '.' && inputfile[1] == '/')
                rootpath = ".";
            if (debug)
              echo ("rootpath is " + rootpath);
          }

          // Create HTML (or other) file.
          // Returns name of the generated file.
          var htmlfilename = canal(newline);

          // Add TOC entries for files
          if (tocfile && (htmlfilename != null)) {
              var tocpath = files[i]; // XXX
              tocfile.Write("  <MTN title=\"" + basename(inputfile)
                            + "\" nodeType=\"leaf\" type=\"file\" tocPath=\""
                            + mytocpath + "-" + index + "\" ref=\""
                            + pathname(inputfile) + "/"
                            + basename(htmlfilename) + "\" />\n");
              mapfile.write("  <L url=\"" + basename(htmlfilename) +
                            "\" pth=\"" + mytocpath + "-" + index + "\" />\n");
              index++;
              childfilelist[childfilelist.length] = basename(inputfile);
              childfiletoc[childfiletoc.length] = mytocpath + "-" + index;
          }

          if (xmlfile) {
            if (collectionwritemode == "update") {
              echo ("XXX should delete old content");
              xmlfile.Write(xmldata);
            } else {
              xmlfile.Write(xmldata);
            }
          }
        }
        if (maketoc) {
          tocfile.write("</MTN>\n");
          mapfile.write("</MsdnTocMap>");
          tocfile.Close();
          mapfile.Close();

          rootpath = dirs[d].replace(/[^\/\\]+/g, "..");
          // Fix if already in root...
          if (dirs[d] == ".")
            rootpath = ".";

          make_file_index(dirs[d], htmldir + "/" + dirs[d],
                          rootpath,
                          childdirlist, childdirtoc,
                          childfilelist, childfiletoc);
          childdirlist.length = 0;
          childdirtoc.length = 0;
          childfilelist.length = 0;
          childfiletoc.length = 0;
        }
      }
    } else {
      var files = glob(filespec);
      for (var i = 0; i < files.length; i++) {
        xmldata = "";
        inputfile = files[i];
        if (maketoc)
          alert("TOC generation supported with -r option only");
        else
          canal(newline);
        if (xmlfile) {
          mlfile.Write(xmldata);
        }
      }
    }
  }

  if (xmlfile) {
    //xmlfile.Write("</extracted-code-data>\n");
    xmlfile.Close();
  }
}

//----------- Utility functions -------------------------------------//
function expandsubdirs(path) {
  var arr = new Array();

  path = path.replace(/\\/gm, "/");

  var f = ofs.GetFolder(path);
  if (f == null)
    alert("can't open dir " + path);

  if (path == ".")
    path = "";
  else if (path != "")
    path += "/";

  var fc = new Enumerator(f.SubFolders);
 outer:
  for (fc.moveFirst() ; !fc.atEnd(); fc.moveNext()) {
    var item = "" + fc.item();
    if (debug)
      echo ("dir=" + item + " = " + path + basename(item));
    item = path + basename(item);

    for (var x = 0; x < excludedirs.length; x++) {
      if (item.match(excludedirs[x]) != null) {
        if (verbose > 0)
          echo ("canal expandsubdir skipped '" + item + "' due to exclusion ");
        continue outer;
      }
    }
    arr = arr.concat(item, expandsubdirs(item));
  }

  if (debug) 
    echo("expand " + path + " -> (" + arr.length + ") " + arr.join(" "));

  return arr.sort();
}

function glob(path) {
  //echo ("glob: " + path+" How come this is not provided by the runtime?\n");
  var arr = new Array();
  var name = basename(path);
  var ix = 0;

  path = pathname(path);
  path = path.replace(/\\/gm, "/");

  name = name.replace(/\./gm, "[.]");
  name = name.replace(/\*/gm, ".*");
  name = name.replace(/\?/gm, ".");
  name = "([/\\\\]|^)" + name;

  if (debug)
    echo ("Globbing for " + name + " in " + path);

  var f = ofs.GetFolder(path == "" ? "." : path);
  if (f == null)
    alert("can't open dir");

  if (path != "")
    path += "/";

  var fc = new Enumerator(f.Files);
 outer:
  for (fc.moveFirst() ; !fc.atEnd(); fc.moveNext()) {
    var item = "" + fc.item();
    if (item.match(new RegExp(name, "")) != null) {
      for (var x = 0; x < excludeglob.length; x++) {
        if (item.match(excludeglob[x]) != null) {
          if (verbose > 0)
            echo ("canal glob skipped '" + item + "' due to exclusion ");
          continue outer;
        }
      }
      if (debug)
        echo ("item=" + item + " = " + path + basename(item));
      item = path + basename(item);

      // Update mode, skip unchanged files.
      // Caveat: Some links from source to doc could have changed but
      // update mode does not check for that

      if (collectionwritemode == "update") {
        //echo("LOOKING for " + htmldir + "/" + item + ".htm");
        if (ofs.FileExists(htmldir + "/" + item + ".htm")) {
          var sfile = ofs.GetFile(item);
          // sfile must exist because we found it already...
          var ofile = ofs.GetFile(htmldir + "/" + item + ".htm");
          //echo("Dates: " + ofile.DateLastModified + " and " + sfile.DateLastModified);
          if (ofile.DateLastModified > sfile.DateLastModified) {
            if (verbose > 1)
              echo (item + " up to date, skipped");
            continue outer;
          }
        }
      }

      arr[ix++] = item;
    }
  }
  fc = item = null;

  return arr.sort();
}

function runtimeError(exception)  {
  alert("XSL Runtime Error " + exception.description
        + " line " + exception.line);
}

function loadError(oSRC, str) {
  var oErr = oSRC.parseError;

  var s = "";
  for (var i=1; i < oErr.linepos; i++) {
    s += " ";
  }
  alert("XML parse error " + oErr.url + "(" + oErr.line + "): pos " + oErr.linepos + "\n" + oErr.reason + "\n"
        + oErr.srcText + "\n" + s + "^");
}

function setprops(tree) {
  var namespaces=null;

  tree.setProperty("SelectionLanguage", "XPath");
  if (namespaces != null)
    tree.setProperty("SelectionNamespaces", namespaces);
}

function load_xml(file, validate, resolve, quiet) {
  if (!ofs.FileExists(file)) {
    if (!quiet)
      echo ("File " + file + " does not exist");
    return null;
  }
  if (verbose > 1)
    echo("Loading " + file);

  var oXML = new ActiveXObject(domdocument_name);
  oXML.validateOnParse = validate;
  oXML.resolveExternals = resolve;
  oXML.async = false;
  oXML.schemas = schema_cache;
  if (!oXML.load(file))
    loadError(oXML, "Load of " + file + " failed");

  setprops(oXML);
  return oXML;
}

function apply_script(oSRC, result_name, script, dowrite) {
  var sXML2 = null;
  var oXSL = new ActiveXObject(domdocument_name);
  oXSL.validateOnParse = true;
  oXSL.async = false;
  oXSL.schemas = schema_cache;

  if (!oXSL.load(script)) {
    loadError(oXSL, "Load of " + script + " failed");
    return null;
  }

  if (verbose > 1)
    echo("Transforming with " + script);

  try {
    sXML2 = oSRC.transformNode(oXSL);
  } catch (exception) {
    alert("XSL Runtime Error: " + exception.description);
    return null;
  }

  if (verbose > 1 && debug)
    echo("Done with " + script);

  /* Fix output for C compiler */
  var re = /&gt;/g;
  sXML2 = sXML2.replace(re, ">");

  if (dowrite) {
    // Make sure the name isn't empty
    if (result_name.match(/[\/\\]$/) != null)
      result_name += "tmp";
    if (verbose > 1)
      echo("Creating " + result_name);
    var oFile = ofs.CreateTextFile(result_name);
    oFile.Write(sXML2);
    oFile.Close();
  }

  return sXML2;
}

function basename(path) {
  var result = path.match(/[^\/\\]*$/);
  //echo("basename(" + path + ") -> " + result);
  return "" + result;
}

function pathname(path) {
  if (path.match(/[\/\\][^\/\\]*$/) == null)
    return "";

  return "" + path.replace(/[\/\\][^\/\\]*$/, "");
}

function nonsuffix(path) {
  var result = path.replace(/[.][^.]*$/, "");
  echo("nonsuffix(" + path + ") -> " + result);
  return "" + result;
}

function getsuffix(path) {
  var result = basename(path).match(/[.][^.]*$/);
  var suf;

  if (result == null)
      suf = "";
  else
      suf = ("" + result).substr(1);
  if (debug)
    echo("getsuffix(" + path + ") -> " + result + " -> '" + suf + "'");

  result = path = null;
  return suf;
}

function makedir(path) {
  if (path == "")
    return;

  var bn = new RegExp("[/\\\\][^/\\\\]*$", "");
  if (path.match(bn) != null) {
    makedir(path.replace(bn, ""));
  }
  bn = null;

  if (!ofs.FolderExists(path)) {
    if (verbose > 0)
      echo("mkdir " + path);
    ofs.CreateFolder(path);
  }
}

function alert(str) {
  if (WScript != null) {
    WScript.Echo(str);
    WScript.Quit(1);
  } else {
    echo("ALERT: " + s);
  }
}

function echo(s) {
  if (WScript != null) {
    WScript.Echo(s);
  } else {
    oLog.WriteLine(s);
  }
}

// --- Index file generation
function make_file_index(srcdir, htmldir, rootpath,
                         dirlist, dirtoc,
                         filelist, filetoc)
{
    //echo("MAKE_FILE_INDEX: DIR=" + srcdir + " HTMLDIR=" + htmldir + " DIRLIST=" + dirlist + " DIRTOC=" + dirtoc + " FILELIST=" + filelist + " FILETOC=" + filetoc);

    var tree = load_xml(srcdir + "/files.xml", true, true, true);
    if (tree)
      echo("Loaded " + srcdir + "/files.xml");
    else
      tree = load_xml("conf/nofiles.xml", true, true, false);
    //echo("ROOTPATH=" + rootpath);
    var rootnode = tree.selectSingleNode("/source-files");
    rootnode.setAttribute("rootpath", rootpath);
    var i;
    for (i = 0; i < dirlist.length; i++) {
      var node = tree.selectSingleNode("//dir[@name = '"+dirlist[i]+"']");
      if (node) {
        //echo("FOUND " + dirlist[i]);
      } else {
        //echo("NOPE " + dirlist[i]);
        node = tree.createElement("dir");
        node.setAttribute("name", dirlist[i]);
        rootnode.appendChild(node);
      }
      node.setAttribute("tocPath", dirtoc[i]);
    }

    for (i = 0; i < filelist.length; i++) {
      var node = tree.selectSingleNode("//file[@name = '"+filelist[i]+"']");
      if (node) {
        //echo("FOUND " + filelist[i]);
      } else {
        //echo("NOPE " + filelist[i]);
        node = tree.createElement("file");
        node.setAttribute("name", filelist[i]);
        rootnode.appendChild(node);
      }
      var suffix = getsuffix(filelist[i]);
      if (suffix.match(/^(htm|html|xsl|xslt|xml|jpg|gif|pdf|ps|xls|doc|ppt)$/) != null)
        node.setAttribute("htmlname", filelist[i]);
      else
        node.setAttribute("htmlname", filelist[i] + ".htm");
      node.setAttribute("tocPath", filetoc[i]);
    }

    //echo("srcdir.XML=" + tree.xml);

    apply_script(tree, htmldir + "/files.htm",
                 "conf/scripts/genfileindex.xsl", true);
}


//------------ Real work ----------------------------------------//

function lookuplink(key) {
  if (docindex == null)
    return null;

  var node = docindex.selectSingleNode("//A[@NAME = '" + key + "']");
  if (node == null) {
    return null;
  }
  var link = node.getAttribute("HREF");
  if (link == null) {
    echo("\"" + key + "\" has no HREF");
    return null;
  }

  if (rootpath != "")
    link = rootpath + "/" + link;

  if (debug)
    echo("lookuplink " + key + " -> " + link);

  return link;
}

var seenrefs;

function maketag(tag, kind) {
  var newline = "";
  var ref, ix;
  var refid = 2;

  // Avoid duplicates 
  ref = tag;
 Outer:
  while (true) {
    for (ix = 0; ix < seenrefs.length; ix++) {
      if (seenrefs[ix] == ref) {
        if (debug)
          echo ("renamed matching ref " + ref + " -> " + tag + "#" + refid);
        ref = tag + "#" + refid++;
        continue Outer;
      }
    }
    break;
  }
  seenrefs = seenrefs.concat(ref);

  var link = lookuplink(tag);
  if (link == null)
    newline += "<FONT color='blue'>";
  newline += "<A name='" + ref + "' ";
  if (link != null)
    newline += "HREF='" + link + "' ";
  newline += ">" + tag + "</A>";
  if (link == null)
    newline += "</FONT>";

  xmldata += "<tag name='" + tag + "' ref='" + ref + "' kind='" + kind + "' file='" + basename(inputfile) + "' path='" + pathname(inputfile) + "'/>\n";
  return newline;
}

function assykeywords (line) {
  // cpp
  line = line.replace(/(^|[^a-zA-Z_]|\s)(defined)([^a-zA-Z_0-9]|\s|$)/gm,
                      "$1<FONT COLOR='purple'>$2<\/FONT>$3");
  line = line.replace(/(^|[^a-zA-Z_]|\s)(\#include|\#ifdef|\#ifndef|\#if|\#endif|\#else|\#elif|\#pragma|\#define|\#undef)([^a-zA-Z_0-9]|\s|$)/gm,
                      "$1<FONT COLOR='purple'>$2<\/FONT>$3");

  // standard macros
  line = line.replace(/(^|[^a-zA-Z_]|\s)(_FUNCTION|_CODE|_LABEL|_ENTRY|_END|_IMPORT|_EXPORT|_DCD|ENTRY|END)([^a-zA-Z_0-9]|\s|$)/gm,
                       "$1<FONT COLOR='amber'>$2<\/FONT>$3");
  return line;
}

function makefilekeywords (line) {
  // cpp
  line = line.replace(/(^|[^a-zA-Z_]|\s)(defined|DEFINED)([^a-zA-Z_0-9]|\s|$)/gm,
                      "$1<FONT COLOR='purple'>$2<\/FONT>$3");
  line = line.replace(/(^|[^a-zA-Z_]|\s)(\!include|\!ifdef|\!ifndef|\!if|\!endif|\!else|\!elif|\!pragma|\!define|\!undef)([^a-zA-Z_0-9]|\s|$)/gm,
                      "$1<FONT COLOR='purple'>$2<\/FONT>$3");

  // standard macros
  line = line.replace(/(\$\(MMLITE_SDK\)|SUBDIRS|SUBDIR|TARGETS|\$\(LIBRARY_DIR\)|\$\(SRC_DIR\)|\$\(BIN_DIR\)|\$\(SYSTEM_DIR\)|\$\(_SILENT\))/gm,
                       "<FONT COLOR='amber'>$1<\/FONT>");
  return line;
}


function prettyk4 (line, newline) {
  if (line == "")
    return newline;

  // special jscript keywords
  if (suffix == "js") {
    line = line.replace(/(^|[^a-zA-Z_]|\s)(function|var|null|true|false)([^a-zA-Z_0-9]|\s|$)/gm,
    "$1<FONT COLOR='purple'>$2<\/FONT>$3");
  }

  newline[apos++] = line;
  line = null;
  return newline;
}

function prettyk3 (line, newline) {
  // make standard library calls orange
  var a, b, m;

  m = line.match(/(^|[^a-zA-Z_]|\s)(printf|puts|gets|sscanf|fgets|fputs|fread|fwrite|fopen|fclose|fflush|fscanf|putchar|memcpy|strcpy|memcmp|strcmp|strncmp|strncpy|memset|memmove)([^a-zA-Z_0-9.]|\s|$)/gm);
  if (m != null) {
    var a = RegExp.$1, b = RegExp.$2;
    newline = prettyk4(line.substring(0, m.index + a.length), newline);
    newline[apos++] = "<FONT COLOR='orange'>";
    newline[apos++] = line.substr(m.index + a.length, b.length);
    newline[apos++] = "</FONT>";
    newline = prettyk4(line.substr(m.index + a.length + b.length), newline);
  } else {
    newline = prettyk4(line, newline);
  }
  line = a = b = m = null;
  return newline;
}

/* Special case URLs for certain symbols */
var sym2urlmap = null;

function initmap() {
    sym2urlmap = new ActiveXObject("Scripting.Dictionary");

    sym2urlmap.Add("PIUNKNOWN", "IUnknown.htm");
    sym2urlmap.Add("PIHEAP", "IHeap.htm");
    sym2urlmap.Add("PINAMESPACE", "INameSpace.htm");
    sym2urlmap.Add("PIFILE", "IFile.htm");
    sym2urlmap.Add("PIPROCESS", "IProcess.htm");
    sym2urlmap.Add("PITHREAD", "IThread.htm");
    sym2urlmap.Add("PIENDPOINT", "IEndpoint.htm");
    sym2urlmap.Add("PIVMSPACE", "IVmSpace.htm");
    sym2urlmap.Add("PIVMVIEW", "IVmView.htm");
    sym2urlmap.Add("PIVMMAPPING", "IVmMapping.htm");
    sym2urlmap.Add("PIMODULE", "IModule.htm");
    sym2urlmap.Add("PCONDITION", "IBaseRtl.htm#CONDITION");
    sym2urlmap.Add("PMUTEX", "IBaseRtl.htm#MUTEX");
    sym2urlmap.Add("PTIME_CONSTRAINT", "IBaseRtl.htm#TIME_CONSTRAINT");
    sym2urlmap.Add("CONDITION", "IBaseRtl.htm#CONDITION");
    sym2urlmap.Add("MUTEX", "IBaseRtl.htm#MUTEX");
    sym2urlmap.Add("TIME_CONSTRAINT", "IBaseRtl.htm#TIME_CONSTRAINT");
    sym2urlmap.Add("VM_FLAGS", "IVmSpace.htm#VM_FLAGS");
}

function prettytoURL(symbol) {
    if (sym2urlmap == null)
        initmap();
    var url = "";
    if (rootpath)
        url += rootpath + "/";

    if (sym2urlmap.Exists(symbol)) {
        url += sym2urlmap.Item(symbol);
    } else {
        url += "doc/BaseTypes.htm#";
        url += symbol;
    }
    return url;
}

function prettyk2 (line, newline) {
  // make MMLite keywords amber
  var a, b, m;

  m = line.match(/(^|[^a-zA-Z_]|\s)(SCODE|S_OK|S_FALSE|TIME|PTR|_TCHAR|ADDRESS|INT16|UINT16|INT32|UINT32|INT64|UINT64|UINT8|INT8|PIUNKNOWN|PIHEAP|PINAMESPACE|PIFILE|PIPROCESS|PITHREAD|PIENDPOINT|PIVMSPACE|PIVMVIEW|PIVMMAPPING|PIMODULE|PCONDITION|PMUTEX|PINT8|PINT16|PINT32|PINT64|PUINT8|PUINT16|PUINT32|PUINT64|PUINT|PINT|REFIID|NULL|TRUE|FALSE|MUTEX|CONDITION|TIME|CONSTRAINT|PTIME_CONSTRAINT|_TEXT|_T|INT|UINT|PBOOL|VM_OFFSET|VM_SIZE|VM_FLAGS|ADDR_SIZE|assert|BOOL|EXTERN_C)([^a-zA-Z_0-9.]|\s|$)/gm);
  if (m != null) {
    var a = RegExp.$1, b = RegExp.$2;
    newline = prettyk3(line.substring(0, m.index + a.length), newline);
    newline[apos++] = "<A COLOR='amber' HREF='";
    newline[apos++] = prettytoURL(line.substr(m.index + a.length, b.length));
    newline[apos++] = "' STYLE='text-decoration:none' >";
    newline[apos++] = line.substr(m.index + a.length, b.length);
    newline[apos++] = "</A>";
    newline = prettyk3(line.substr(m.index + a.length + b.length), newline);
  } else {
    newline = prettyk3(line, newline);
  }
  line = a = b = m = null;
  return newline;
}

function prettykeyword (line, newline) {
  // make keywords purple
  var a, b, m;

  if (line == "")
    return newline;

  m = line.match(/(^|[^a-zA-Z_]|\s)(const|typedef|extern|static|defined|long|volatile|inline|__attribute|class|unsigned|signed|\#include|\#ifdef|\#ifndef|\#if|\#else|\#endif|\#elif|\#pragma|\#define|\#undef|if|else|while|do|for|return|goto|continue|break|switch|case|default|int|float|double|short|char|wchar_t|size_t|void|struct|union|enum|sizeof|__asm|public|private|friend|new|delete)([^a-zA-Z_0-9.]|\s|$)/gm);
  if (m != null) {
    var a = RegExp.$1, b = RegExp.$2;
    newline = prettyk2(line.substring(0, m.index + a.length), newline);
    newline[apos++] = "<FONT COLOR='purple'>";
    newline[apos++] = line.substr(m.index + a.length, b.length);
    newline[apos++] = "</FONT>";
    newline = prettyk2(line.substr(m.index + a.length + b.length), newline);
  } else {
    newline = prettyk2(line, newline);
  }
  line = a = b = m = null;
  return newline;
}

function prettynormal(line, newline) {
  // On top level we attempt to identify relevant tags.
  // Assume the last chunk is relevant for non-preprocessor lines.
  // There is a lot of heuristic here, hopefully it gets it right mostly.
  while (line != "") {
    var m;
    m = line.match(/(#[a-z]+\s+|struct\s+|=\s+|typedef\s+[A-Za-z_][A-Za-z0-9]*\s+|[A-Za-z_][A-Za-z0-9]*\s+|[^#A-Za-z0-9_]+|\s|^)([A-Za-z_][A-Za-z_0-9:]*)(\s*)(=|$|;|\s+\:\s+.+)/);

    if (m == null) {
      newline = prettykeyword(line, newline); 
      line = null;
      return newline;
    }

    var a = RegExp.$1, b = RegExp.$2, c = RegExp.$3, d = RegExp.$4;

    if (verbose > 2)
      echo("KEYWORD 1=" + a + " 2=" + b + " 3=" + c + " 4=" + d);

    var reserved = (null != b.match(/^(static|extern|class|struct|void|int|enum|double|defined|amp|lt|gt|__cdecl|for|__attribute__|new|delete)$/));

    newline = prettykeyword(line.substring(0, m.index), newline);
    newline = prettykeyword(a, newline);
    // avoid preprocessor and reserved words (and = initializations)
    if (reserved || a.match(/^[#=]/) != null) {
      newline = prettykeyword(b, newline);
    } else {
      if (d == "=") {
        newline[apos++] = maketag(b, "variable");
        d = "";                 // leave = for later
      } else if (d == ";") {
        if (a.match(/typedef/) != null)
          newline[apos++] = maketag(b, "type");
        else if (a.match(/[A-Za-z_]/) != null)
          newline[apos++] = maketag(b, "variable");
        else
          newline[apos++] = maketag(b, "type");
      } else if (a.match(/struct/) != null)
        newline[apos++] = maketag(b, "struct");
      else
        newline[apos++] = maketag(b, "function");
    }
    newline[apos++] = c;
    newline[apos++] = d;
    line = line.substr(m.index + a.length + b.length + c.length + d.length);
  }

  line = m = a = b = c = d = null;
  return newline;
}

function prettyflattened(line, newline) {
  if (line == "")
    return newline;

  if (isnested) {
    newline = prettykeyword(line, newline);
    line = null;
    return newline;
  }

  while (true) {
    // Create tag for #define
    var m = line.match(/^(#define\s+)([A-Za-z_][A-Za-z_0-9]*)(.*)$/m);
  
    if (m == null) {
      newline = prettynormal(line, newline);
      break;
    }
    if (verbose > 2)
      echo("DEFINE m=" + m);
    var a = RegExp.$1; var b = RegExp.$2; var c = RegExp.$3;
    var ix = RegExp.index;

    newline = prettynormal(line.substring(0, ix + a.length), newline);
    newline[apos++] = maketag(b, "define");
    // avoid thinking there is a type at the end of the define
    newline = prettykeyword(c, newline);
    line = line.substr(ix + a.length + b.length + c.length);
  }

  line = m = a = b = c = m = null;
  return newline;
}

function prettyassy(line, newline) {
  // On top level we attempt to identify relevant tags.
  // Assume the last chunk is relevant for non-preprocessor lines.
  // There is a lot of heuristic here, hopefully it gets it right mostly.
  while (line != "") {
    var m;
    m = line.match(/(_FUNCTION\(|_LABEL\(|_IMPORT\(|ENTRY\()([^\)]+)(\))/);

    if (m == null) {
      newline[apos++] = assykeywords(line);
      line = null;
      return newline;
    }

    var a = RegExp.$1, b = RegExp.$2, c = RegExp.$3;

    if (verbose > 2)
      echo("ASSYWORD 1=" + a + " 2=" + b + " 3=" + c);

    newline[apos++] = assykeywords(line.substring(0, m.index));
    newline[apos++] = assykeywords(a);

    if (a.match(/_FUNCTION/) != null)
      newline[apos++] = maketag(b, "function");
    else if (a.match(/_LABEL/) != null)
      newline[apos++] = maketag(b, "variable");
    else
      newline[apos++] = maketag(b, "reference");

    newline[apos++] = assykeywords(c);
    line = line.substr(m.index + a.length + b.length + c.length);
  }

  line = m = null;
  return newline;
}

function prettynoquotes(line, newline) {
  // All quoted text has been removed.
  // We are called with the rest (repeatedly)
  var ix;

  if (line == "")
    return newline;

  if (suffix == "s")
    return prettyassy(line, newline);

  while (line != "") {
    // Search for the first nesting
    var m = line.match(/([][(){}])/m);
    if (m == null) {
      newline = prettyflattened(line, newline);
      line = "";
      break;
    }

    newline = prettyflattened(line.substring(0, m.index), newline);
    line = line.substr(m.index + m[0].length);

    switch (m[0]) {
    case "{":
      //echo ("Lbrace");
      bracecount++;
      break;
    case "}":
      //echo ("Rbrace");
      bracecount--;
      break;
    case "[":
      //echo ("Lbracket");
      bracketcount++;
      break;
    case "]":
      //echo ("Rbracket");
      bracketcount--;
      break;
    case "(":
      //echo ("Lparen");
      parencount++;
      break;
    case ")":
      //echo ("Rparen");
      parencount--;
      break;
    default:
      alert("canal flooding");
    }

    if (isnested) {
      if (bracecount == 0 && bracketcount == 0 && parencount == 0) {
        isnested = false;
        newline[apos++] = "</FONT>";
        newline[apos++] = m[0];
      } else
        newline[apos++] = m[0];
    } else {
      if (bracecount > 0 || bracketcount > 0 || parencount > 0) {
        isnested = true;
        newline[apos++] = m[0];
        newline[apos++] = "<FONT face='tahoma' size='1'>";
      } else
        newline[apos++] = m[0];
    }
  }

  line = null;
  return newline;
}

function prettyline (line, newline) {
  var ix;

  while (line != "") {
    // Search for the first quotation (comment, string, char, xml tag
    var m = line.match(/(\/\*|<|\'|\"|\/\/)/m);
    if (m == null) {
      newline = prettynoquotes(line, newline);
      line = "";
      continue;
    }

    newline = prettynoquotes(line.substring(0, m.index), newline);
    line = line.substr(m.index + m[0].length);
    if (m[0] == "/*") {        // comments
      //echo ("comment");
      newline[apos++] = "<FONT COLOR='green'>";
      newline[apos++] = m[0];
      ix = line.indexOf("*/");
      if (ix == -1) {
        echo("canal: runaway comment");
        newline[apos++] = line;
        line = "";
      } else {
        ix += 2;
        newline[apos++] = line.substring(0, ix);
        line = line.substr(ix);
      }
      newline[apos++] = "</FONT>";
    } else if (m[0] == "//") { // c++ comments
      //echo ("c++ comment");
      newline[apos++] = "<FONT COLOR='green'>";
      newline[apos++] = m[0];
      m = line.match(/(.*$)/m);
      if (m == null) {
        echo("canal: unterminated c++ comment");
        newline[apos++] = line;
        line = "";
      } else {
        ix = m[0].length;
        newline[apos++] = line.substring(0, ix);
        line = line.substr(ix);
      }
      newline[apos++] = "</FONT>";
    } else if (m[0] == "\"") {  // strings
      //echo ("double quote");
      newline[apos++] = "<FONT COLOR='brown'>";
      newline[apos++] = m[0];
      while (true) {
        // search for end of string but beware of backslashed and doubles
        m = line.match(/(\\\\|\\\"|\")/m);
        if (m == null)  {
          echo("canal: runaway string");
          newline[apos++] = line;
          line = "";
          break;
        } else {
          ix = m.index + m[0].length;
          newline[apos++] = line.substring(0, ix);
          line = line.substr(ix);
          if (m[0] == "\"")
            break;
          // if not real end of string, continue searching
        }
      }
      newline[apos++] = "</FONT>";
    } else if (m[0] == "\'") {  // same for single quotes
      //echo ("single quote");
      newline[apos++] = "<FONT COLOR='brown'>\'";
      while (true) {
        // search for end of string but beware of backslashed and doubles
        // terminate at end of line anyways...  failure mode is better for .js
        m = line.match(/(\\\\|\\\'|\'|$)/m);
        if (m == null)  { // EOF
          echo("canal: runaway char constant");
          newline[apos++] = line;
          line = "";
          break;
        } else {
          ix = m.index + m[0].length;
          newline[apos++] = line.substring(0, ix);
          line = line.substr(ix);
          if (m[0] == "\'")
            break;
          if (RegExp.lastMatch == "") { // EOL
              echo("canal: runaway char constant, terminated at line end");
              break;
          }
          // if not real end of char, continue searching
        }
      }
      newline[apos++] = "</FONT>";
    } else if (m[0] == "<") {        // xml tag
      if (verbose > 2)
        echo ("xml tag (nesting NYI)");
      newline[apos++] = m[0];
      ix = line.indexOf(">");
      if (ix == -1) {
        echo("canal: runaway xml tag");
        newline[apos++] = line;
        line = "";
      } else {
        ix += 1;
        newline[apos++] = line.substring(0, ix);
        line = line.substr(ix);
      }
    } else {
      echo ("UNHANDLED " + m[0]);
      newline[apos++] = m[0];
    }
  }

  line = m = null;
  return newline;
}

function includes(line) {
  var a, b, ix;
  // decorate angle includes like strings. No ampersands there...
  while (line.match(/^(#include\s+)&lt;([^&]+)&gt;/m) != null) {
    a = RegExp.$1; b = RegExp.$2; ix = RegExp.index;
    xmldata += "<inclusion file='" + inputfile + "' name='" + b + "' quotes='angle'/>\n";
    line = line.substring(0, ix) + a + "<FONT COLOR='brown'>&lt;" + b + "&gt;<\/FONT>" + line.substr(ix + a.length + b.length + 8); // 8 for &lt;&gt;
  }

  var tmp = line;
  // create tags for quote includes. No quoted quotes here
  while (tmp.match(/^(#include\s+)\"([^\"]+)\"/m) != null) {
    a = RegExp.$1; b = RegExp.$2; ix = RegExp.index;
    xmldata += "<inclusion file='" + inputfile + "' name='" + b + "' quotes='doublequote'/>\n";
    tmp = tmp.substr(ix + a.length + b.length + 2); // 8 for quotes
  }

  tmp = a = b = ix = null;
  return line;
}

function stdquote(text) {
    text = text.replace(/\&/g, "&amp;" );
    text = text.replace(/\</g, "&lt;");
    text = text.replace(/\>/g, "&gt;");

    return text;
}

function ccode(content, htmlfile, datafile, newline) {
  if (verbose > 0) {
    if (suffix == "s")
      echo("Assembly code " + basename(inputfile));
    else if (suffix == "js")
      echo("JScript code " + basename(inputfile));
    else
      echo("C code " + basename(inputfile));
  }

  // Clear previous array contents and hope they get GC'd
  for ( ; apos > 0; apos--)
    newline[apos-1] = null;

  // Clear reference duplicate avoidance mem
  seenrefs = null;
  seenrefs = new Array();

  resetnesting();
  content = stdquote(content);
  content = includes(content);
  newline = prettyline(content, newline);
  content = newline.join("");
  newline = null;

  return content;
}

function makefile(content, htmlfile, datafile) {
  if (verbose > 0)
    echo("makefile " + basename(inputfile));

  content = stdquote(content);
  // comments, quick and dirty
  content = content.replace(/(\#.*)$/gm, "<FONT color='green'>$1</FONT>");
  content = makefilekeywords(content);

  return content;
}

function canal(newline) {
  var htmlfilename = "";
  var htmlfilename = "";
  var htmlfile = null;
  var datafilename = "";
  var datafile = null;
  var verbatim = false;

  suffix = getsuffix(inputfile);
  if (suffix.match(/^(htm|html|xsl|xslt|xml|jpg|gif|pdf|ps|xls|doc|ppt)$/) != null) {
    verbatim = true;
    if (false) {
      if (verbose > 0)
        echo ("verbatim skipped for now (make binary copy later) " + suffix);
      return null;
    }
  }

  if (suffix.match(/^(exe|dll|sys|pdb|wad|ncb)$/) != null) {
    xmldata += "<file name='" + inputfile + "' file='" + basename(inputfile) + "' path='" + pathname(inputfile) + "' skipped='yes' />\n";
    if (verbose > 0)
      echo ("skipped binary file " + inputfile);
    return null;
  }

  xmldata += "<file name='" + inputfile + "' file='" + basename(inputfile) + "' path='" + pathname(inputfile) + "' />\n";
  // Open all the files
  if (htmldir) {
    makedir(pathname(htmldir + "/" + inputfile));
    htmlfilename = htmldir + "/" + inputfile;
    if (!verbatim) {
      htmlfilename += ".htm";
      if (!maketoc) {
        htmlfile = ofs.CreateTextFile(htmlfilename);
        if (htmlfile == null)
          alert("Can't open " + htmlfilename);
      }
    }
  }

  if (maketoc)                  // just return the name
    return htmlfilename;

  if (xmldir) {
    datafilename = xmldir + "/" + basename(inputfile) + ".xml";
    var datafile = ofs.CreateTextFile(datafilename);

    if (datafile == null)
      alert("Can't open " + datafilename);
  }

  if (!ofs.FileExists(inputfile))
    alert("File does not exist: " + inputfile);

  var content = "";
  var f = ofs.GetFile(inputfile);
  if (f == null)
    alert("could not open " + inputfile);
  if (verbatim) {
    if (ofs.FileExists(htmlfilename)) {
      if (verbose > 1)
        echo("Deleting copy target " + htmlfilename);
      ofs.DeleteFile(htmlfilename, true);
    }
    f.Copy(htmlfilename, true);
  } else if (f.Size != 0) {
    //echo("File " + inputfile + " is " + f.Type + " Size=" + f.Size);
    var ff = f.OpenAsTextStream(1, 0);
    content = ff.ReadAll();
    ff.Close();
    ff = null;
  }
  f = null;

  var myroot = pathname(inputfile);
  if (myroot != ".")
    myroot = myroot.replace(new RegExp("([^/]+)", "g"), "..");

  if (verbose > 1)
    echo ("canal " + inputfile + "(" + basename(inputfile) + ") -> " + htmlfilename + " " + datafilename + " myroot=" + myroot);

  datafilename = null;

  // Preludes
  if (htmlfile && !verbatim) {
    htmlfile.Write("<HEAD>\n<TITLE>" + basename(inputfile) + " Source</TITLE>\n");
    htmlfile.Write("<SCRIPT SRC='" + myroot + "/sourcecss.js'></SCRIPT>\n");
    htmlfile.Write("</HEAD><BODY>\n");
    htmlfile.Write("<SCRIPT>PrintHeader(\""+inputfile+"\");</SCRIPT>\n");
    htmlfile.Write("<DIV CLASS='BodyDiv'>\n");
    //htmlfile.Write("<H1>" + inputfile + "</H1>\n");
    htmlfile.Write("<PRE>\n");
  }
  if (datafile) {
    datafile.Write("<?xml version='1.0'?>\n\n");
    datafile.Write("<extracted-code-data>\n");
  }

  if (verbatim) {
    if (htmlfile) {
      if (verbose > 0)
        echo("xml file " + basename(inputfile) + " (just copy it)");
      //      htmlfile.Write(content);
    }
  } else {
    switch (suffix) {
    case "c":
    case "C":
    case "s":
    case "h":
    case "H":
    case "hh":
    case "c++":
    case "cpp":
    case "cxx":
    case "idl":
    case "js":
      content = ccode(content, htmlfile, datafile, newline);
    break;
    case "mk":
    case "":
      if (suffix != "" || basename(inputfile) == "makefile") {
        content = makefile(content, htmlfile, datafile);
        break;
      }
      /* fall through */
    default:
      content = stdquote(content);
      echo("canal warning: unknown suffix '" + suffix + "' for " + inputfile + " -> simple output");
    }
  }

  // Postludes
  if (htmlfile && !verbatim) {
    htmlfile.Write(content);
    htmlfile.Write("</PRE>\n");
    htmlfile.Write("</DIV>\n");
    htmlfile.Write("<SCRIPT>PrintFooter(\"" + myroot + "\");</SCRIPT>\n");
    // Add some blanks to make the window scroll.
    htmlfile.Write("<P>&nbsp;</P><P>&nbsp;</P><P>&nbsp;</P><P>&nbsp;</P>");
    htmlfile.Write("<P>&nbsp;</P><P>&nbsp;</P><P>&nbsp;</P><P>&nbsp;</P>");
    htmlfile.Write("<P>&nbsp;</P><P>&nbsp;</P><P>&nbsp;</P><P>&nbsp;</P>");
    htmlfile.Write("</BODY>\n");
    htmlfile.Close();
  }
  if (datafile) {
    datafile.Write(xmldata + "</extracted-code-data>\n");
    datafile.Close();
  }

  content = datafile = htmlfile = null; // futile attempt on avoiding mem leak

  return htmlfilename;          // needed for toc generation
}
