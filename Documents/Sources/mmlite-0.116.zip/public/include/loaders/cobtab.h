/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file is used for a preinitialized cob table.
 * The configuration creates the contents and the Cob Manager (cobmgr.c)
 * reads it.
 */

/* Include auto-generated part */
#include <s_cobtab.h>

/* These are not yet auto-generated */
extern PIUNKNOWN CobSampCobMain(void);
extern PIUNKNOWN SerialCobMain(void);
extern PIUNKNOWN DriverCfgCobMain(void);
extern PIUNKNOWN WsDiscovCobMain(void);



struct PRECOB {
    const _TCHAR *name;
    PIUNKNOWN (*CobMainRoutine)(void);
};

extern const struct PRECOB ThePreCobTable[];

#ifndef PRIVATE_SOAP_COBS
#define PRIVATE_SOAP_COBS
#endif

#if 0
#ifdef _WITH_PRIVATE_COBS
#define PRIVATE_SOAP_COBS \
    {_T("aes.cob"), AesCypherCobMain }, \
    {_T("aes_fpga.cob"), AesFpgaCypherCobMain }, \
    {_T("rsa.cob"), RsaCypherCobMain }, \
    {_T("hmac_sha1.cob"), HmacSha1CobMain }, \

#endif

#define BASIC_NET_COBS \
    {_T("drivercfg.cob"), DriverCfgCobMain }, \
    {_T("drivers.cob"), DriversCobMain }, \
    {_T("protocol.cob"), ProtocolCobMain }, \

#define BASIC_SOAP_UDP_COBS \
    {_T("tokenizer.cob"), TokenizerCobMain }, \
    {_T("sax.cob"), SaxCobMain }, \
    {_T("soap.cob"), SoapCobMain }, \
    {_T("wsaddr.cob"), WsAddrCobMain }, \
    {_T("wsres.cob"), WsResCobMain }, \
    {_T("calc.cob"), CalcCobMain }, \
    {_T("sensor.cob"), SensorCobMain }, \
    {_T("http.cob"), HttpCobMain }, \
    {_T("planner.cob"), PlannerCobMain }, \
    {_T("statistics.cob"), StatisticsCobMain }, \
    {_T("sampling.cob"), SamplingCobMain }, \
    {_T("wsman.cob"), WsManCobMain }, \
    {_T("wsdiscov.cob"), WsDiscovCobMain }, \
    {_T("base64.cob"), base64CobMain },

#define BASIC_SOAP_COBS \
    BASIC_SOAP_UDP_COBS \
    {_T("sntp.cob"), SntpCobMain }, \
    {_T("marionette.cob"), marionetteCobMain }, \
    {_T("tabletService.cob"), tabletServiceCobMain }, \

//  {_T(".cob"), CobMain },
#endif
