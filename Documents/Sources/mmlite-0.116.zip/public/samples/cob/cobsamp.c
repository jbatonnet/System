/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file implements a generic sample COB that exports a single
 * namespace as a constructor. New objects are created through Bind.
 * The code also implements ISampleFactory, which has more constructors.
 *
 * This code also demonstrates how to do multiple inheritance from two
 * different interfaces (ISampleFactory and INameSpace). one instance
 * implements both interfaces. There are two v-tables. An object pointer
 * always points to the pointer to the corresponding v-table pointer.
 * The macros pSN, iSN, pSF, and iSF are used to convert between an
 * implementation instance pointer (PFACTORY) and the interface instance
 * pointers visible to the outside (PINAMESPACE, PISAMPLEFACTORY).
 * It is generally a good idea to define the macros even if there is just
 * one interface as you might want to add another one later and it increases
 * readability by decreasing random casting.
 *
 * Ok, so when do you use a name space and when a special constructor?
 * It pretty much boils down to arguments. If none of your constructors
 * take and arguments, a namespace is fine. A name space is nice because
 * it minimizes the code the client needs to do. Just bind to the right
 * thing and let the intermediate name spaces delegate down to your bind.
 * Also the name space can be accessed directly from a web browser as the
 * path is an URI. You could do some arguments by encoding them into the URI
 * like "COB/SampleFactory.cob/ZeroFile?Size=0x100000".  But this kind of a 
 * thing adds a lot of unnecessary string processing and bloat: an explicit
 * constructor is simpler. And more importantly, we currently have no way of
 * representing an object reference in an URI and do the marshalling.
 * So anything that takes an object as an argument (like CreateFilterFile)
 * has no other choice but to define a special interface for the constructor.
 * Do you then want to do both like in this sample? You decide...
 *
 * OLE had a notion of creating an object without arguments (i.e. in limbo)
 * and then bringing it up by calling a specific Initializer method. Guess
 * what? That doesn't solve anything as compared to a factory interface
 * like in this file. You still need to declare a new interface, come up with
 * a name, an include file, an IID. That is because something like IFile
 * doesn't have any initializers and IFile is strictly more general than say
 * the FilterFile so it makes no sense to add it either.  The only difference
 * the OLE way would make is that 1) you need to add a state machine to your
 * implementation to handle the Limbo->Live transition and guard against
 * any method call in the wrong state, and 2) you end up exposing the
 * constructor to an application, with security and loss of transparency
 * issues. So just forget about it.
 *
 * Another way would be to have some polymorphism and have some generic thing
 * that could be used for every factory. This might or might not be a good
 * idea, but in either case we don't have that now.
 */
#include <mmlite.h>
#include <stdio.h>
#include <assert.h>
#include <tchar.h>

#include <sampfac.h>
#include "cobsamp.h"

#include "isampfac.c"           /* Normally comes from iidlib */

typedef struct _FACTORY {
    struct INameSpaceVtbl *v;
    struct ISampleFactoryVtbl *fv;
    UINT RefCnt;
} *PFACTORY;

PRIVATE struct INameSpaceVtbl TheNameVtbl;
PRIVATE struct ISampleFactoryVtbl TheFactVtbl;

PRIVATE struct _FACTORY _TheFactory = {
    &TheNameVtbl,
    &TheFactVtbl,
    0
};

/* INameSpace::<this> points to first v-table
 * pSN (pointer of Sample NameSpace) converts interface ptr to implementation.
 * iSN (interface of SN)  converts implementation ptr to interface ptr.
 */
#define pSN(_i_) ((PFACTORY)(_i_))
#define iSN(_p_) ((PINAMESPACE)(_p_))

/* ISampleFactory::<this> points to the second method table.
 * pSF (pointer of Sample Factory): interface to implementation.
 * iSF implementation to interface.
 * Note that NULL should always translate to NULL.
 */
#define pSF(_i_) ((_i_) ? \
                  (PFACTORY)((ADDRESS)(_i_) - offsetof(struct _FACTORY, fv)) \
                  : NULL)
#define iSF(_p_) ((_p_) ? (PISAMPLEFACTORY)&(_p_)->fv : NULL)

/* Make our single instance visible to code in zerofile.c etc. */
const PINAMESPACE pTheFactory = iSN(&_TheFactory);

/* NameSpace::QI.  Return a pointer of the right kind. */
PRIVATE SCODE MCT SNQueryInterface(PINAMESPACE pThis, REFIID Iid, void **ppObj)
{
    SCODE sc;
    DPRINT(("SNQueryInterface\n"));
    sc = GenericQueryInterface((PIUNKNOWN) pThis, Iid, ppObj, &IID_INameSpace);

    if (SUCCEEDED(sc)) {
        DPRINT(("SNQueryInterface ==> NameSpace\n"));
        return S_OK;
    }

    /* Special handling for IP interface if not recognized already
     */
    if ((sc == E_NO_INTERFACE) && UuidCmp(&IID_ISampleFactory, Iid)) {
        DPRINT(("SNQueryInterface ==> SampleFactory\n"));
        pThis->v->AddRef(pThis);
        /* Return value is pointer to second v-table pointer */
        *ppObj = (void*) iSF(pSN(pThis));
        return S_OK;
    }

    if (FAILED(sc))
      DPRINT(("SNQueryInterface ==> Fail\n"));

    return sc;
}

/* NameSpace::AddRef */
PRIVATE UINT MCT SNAddRef(PINAMESPACE pThis)
{
    UINT RefCnt = AtomicInc(&pSN(pThis)->RefCnt);
    DPRINT(("SNAddRef x%x ==> %d\n", pThis, RefCnt));
    return RefCnt;
}

/* Refs went to zero, finalizer (internal use only) */
PRIVATE void SNDestroy(PFACTORY x)
{
    UnusedParameter(x);
    DPRINT(("SNDestroy\n"));

    /* Nothing to finalize or deallocate in this implementation */
}

/* NameSpace::Release */
PRIVATE UINT MCT SNRelease(PINAMESPACE pThis)
{
    PFACTORY sn = pSN(pThis);
    UINT RefCnt = AtomicDec(&sn->RefCnt);

    DPRINT(("SNRelease x%x ==> %d\n", pThis, RefCnt));
    if (RefCnt == 0) {
        SNDestroy(sn);
    }
    return RefCnt;
}

/* NameSpace::Bind. Construct various objects, dispatch on URI. */
PRIVATE SCODE SNBind(PINAMESPACE pThis, const _TCHAR * pName,
                     NAME_SPACE_FLAGS Flags, PIUNKNOWN *ppObject)
{
    UnusedParameter(pThis);
    DPRINT(("SNBind(%s)\n", pName));
#if 0 /* Don't be too picky about arguments... */
    /* Only implement object creation -- could be expanded for other uses */
    if (Flags != (NAME_SPACE_READ | NAME_SPACE_WRITE | NAME_SPACE_CREATE))
        return E_INVALID_PARAMETER;
#endif

    if (!_tcscmp(pName, _T("zero"))) {
        /* Implemented in zerofile.c */
        return CreateZeroFile((PIFILE *) ppObject);
    } else if (!_tcscmp(pName, _T("null"))) {
        /* Implemented in zerofile.c */
        return CreateNullFile((PIFILE *) ppObject);
    } else if (!_tcscmp(pName, _T("mem"))) {
        /* Implemented in memfile.c */
        return CreateMemFile((PIFILE *) ppObject);
#if 0
    } else if (!_tcscmp(pName, _T("ns"))) {
        /* Implemented by mmbase */
        return NameSpaceCreate((PINAMESPACE *) ppObject);
#endif
    } else {
        return E_NAME_NOT_FOUND;
    }
}

/* Delegate simple methods on the seocondary interface to the primary
 * one after adjusting the this pointer.
 */
/* ISampleFactory::QI - delegate to NameSpace implementation */
PRIVATE SCODE MCT SFQueryInterface(PISAMPLEFACTORY pThis, REFIID Iid,
                                   void **ppObj)
{
    return SNQueryInterface(iSN(pSF(pThis)), Iid, ppObj);
}

/* ISampleFactory::AddRef - delegate to NameSpace implementation */
PRIVATE UINT MCT SFAddRef(PISAMPLEFACTORY pThis)
{
    return SNAddRef(iSN(pSF(pThis)));
}

/* ISampleFactory::Release - delegate to NameSpace implementation */
PRIVATE UINT MCT SFRelease(PISAMPLEFACTORY pThis)
{
    return SNRelease(iSN(pSF(pThis)));
}

/* ISampleFactory::CreateNullFile.  This is here just to show that you
 * can have constructors with no args in a factory interface too.
 * This one is in fact a duplication from that in the name space.
 * One way, the other way, or both? You choose.
 */
PRIVATE SCODE MCT SFCreateNullFile(PISAMPLEFACTORY pThis, PIUNKNOWN *ppFile)
{
    UnusedParameter(pThis);
    DPRINT(("SFCreateNullFile\n"));
    return CreateNullFile((PIFILE *) ppFile);
}

/* ISimpleFactory::CreateFilterFile. Takes an IFile argument, thuis cannot
 * be implemented in NameSpace::Bind. No choice here.
 */
PRIVATE SCODE MCT SFCreateFilterFile(PISAMPLEFACTORY pThis, PIFILE pParent,
                                    UINT64 Offset, UINT64 Size,
                                    PIUNKNOWN *ppRestrictedFile)
{
    UnusedParameter(pThis);
    DPRINT(("SFCreateFilterFile(off=%lx, size=%lx\n", Offset, Size));
    return CreateFilterFile(pParent, Offset, Size, (PIFILE *)ppRestrictedFile);
}

/* Default method */
PRIVATE SCODE Unimp(void)
{
    return E_NOT_IMPLEMENTED;
}

/* The NameSpace method table.
 * Some methods don't do anything and use Unimp()
 */
PRIVATE struct INameSpaceVtbl TheNameVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    SNQueryInterface,
    SNAddRef,
    SNRelease,
    (_INameSpace_Register_METHOD_TYPE) Unimp,
    (_INameSpace_Unregister_METHOD_TYPE) Unimp,
    SNBind,
    (_INameSpace_FindNext_METHOD_TYPE) Unimp,
    (_INameSpace_GetCapabilities_METHOD_TYPE) Unimp
};

/* SampleFactory method table */
PRIVATE struct ISampleFactoryVtbl TheFactVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    SFQueryInterface,
    SFAddRef,
    SFRelease,
    SFCreateNullFile,
    SFCreateFilterFile
};

/* ENTRY POINT.
 * This is what gets called first thing (almost, CrtInit got there first,
 * and perhaps CobMain if this component was run stand-alone. See main.c).
 * The COB manager calls the entry point and expect to get back an object.
 * The CobManager then caches the object pointer and doesn't call the entry
 * point again. The program doesn't exit when CobMain returns, instead it is
 * terminated once the refs of the object go to zero. (see SNDestroy).
 */
PIUNKNOWN CobSampCobMain(void)
{
    PINAMESPACE sf;

    DPRINT(("InitSampleFactory\n"));
    sf = iSN(&_TheFactory);
    assert(sf);

    pSN(&_TheFactory)->RefCnt = 1;      /* first ref */
    return (PIUNKNOWN) sf;
}
