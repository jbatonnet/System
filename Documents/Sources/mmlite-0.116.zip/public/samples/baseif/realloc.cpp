/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Get a pointer to the current process heap. */
IHeap *pHeap = CurrentHeap();
void *ptr = NULL;    /* Pointer to void and initially equal to NULL. */
void *pAlloc = NULL;    /* Pointer to void and equal to NULL. */
UINT NewSize = 0;
UINT AllocSize = 50;
UINT RealAllocSize;
UINT RealReallocSize;

pAlloc = pHeap->Alloc(HEAP_ZERO_MEMORY, AllocSize, 0);
if(pAlloc == NULL)    {
    _tprintf(_TEXT("Memory allocation failed.\n"));
    return 0;
}
/* Determine the actual size of the allocated memory block. */
RealAllocSize = pHeap->Size(0, pAlloc);

ptr = pHeap->Realloc(HEAP_ZERO_MEMORY, pAlloc, NewSize, 0);
if(ptr == NULL) {
    _tprintf(_TEXT("Memory reallocation failed.\n"));
    return 0;
}
/* Determine the actual size of the reallocated memory block. */
RealReallocSize = pHeap->Size(0, ptr);
if(NewSize <= RealReallocSize)
    _tprintf(_T("There were %d more bytes allocated than specified in ")
             _T("the Realloc method.\nThere were %d original (Alloc) ")
             _T("bytes freed.\n"),
             RealReallocSize - NewSize, 
             RealAllocSize - RealReallocSize);
/* END_SAMPLE */
return 0;
}
