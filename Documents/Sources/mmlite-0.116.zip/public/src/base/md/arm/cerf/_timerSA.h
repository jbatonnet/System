/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _timer_h_
#define _timer_h_

struct  _ost {
    volatile UINT32    Match[4];
    volatile UINT32    Count;
    volatile UINT32    Status;
    volatile UINT32    Watchdog;
    volatile UINT32    IEnable;
};
#define TheTimer                ((struct _ost *)0x90000000)

struct _rtc {
    volatile UINT32    Alarm;
    volatile UINT32    Count;
    volatile UINT32    Trim;
    volatile UINT32    Reserved;
    volatile UINT32    Status;
};
#define TheRTC                  ((struct _rtc *)0x90010000)

#endif /* _timer_h_*/
