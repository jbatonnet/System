/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __MMLITE_MD_H__
#define __MMLITE_MD_H__

typedef signed char INT8;
typedef unsigned char UINT8;
typedef short INT16;
typedef unsigned short UINT16;
typedef signed int INT32;
typedef unsigned int UINT32;
typedef struct _INT64 INT64;
typedef struct _UINT64 UINT64;
#define __NO_BUILTIN_INT64

typedef INT32 INT;
typedef UINT32 UINT;

#define _UINTSIZE        ( 32 )
#ifdef _OLDSCHED
#define _MUTEX_STATE_SIZE       ( 1 )
#define _CONDITION_STATE_SIZE   ( 2 )
#else
#define _MUTEX_STATE_SIZE       ( 5 )
#define _CONDITION_STATE_SIZE   ( 3 )
#endif

struct  _CXTINFO {
    UINT32 PC;
    UINT32 PCSW;
    UINT32 R2; /* return address    */
    UINT32 R3; /* frame pointer     */
    UINT32 SP; /* stack pointer     */
    UINT32 R5; /* first arg, retval */
    UINT32 R6; /* second argument   */
    UINT32 R7; /* third argument    */
    UINT32 R8; /* fourth argument   */
    UINT32 CalleeSaved[23/*32-9*/];
    UINT32 CallerSaved[32];
};

/* Normally ADDRESS is defined in mmlite.h but we need it prematurely so
 * override and define it here.
 */
#define __MACHDEP_ADDRESS_DEFINITION 1
typedef UINT ADDRESS;
typedef UINT ADDR_SIZE;

typedef struct _TM_MACHINE_INFO {
    ADDRESS  MMIOBase;
    ADDRESS  TMMIOBase;
    ADDRESS  SRAMBase;
    UINT     SRAMSize;
    ADDRESS  RDRAMBase;
    UINT     RDRAMSize;
    UINT     ClockFreq;
} TM_MACHINE_INFO;

#define _DCACHELINESIZE (64) /* Size in bytes of data-cache line   */
#define _PAGE_SIZE (4096)       /* XXX no pages on this platform */

/* No inlines because compiler chokes */
#define INLINE

/* XXX The rest should go somewhere else */

/* Inline functions and other optimizations. */

#if !defined(_DEBUG) && defined(OPTIMIZE) && 0 

extern struct _THDINFO *TheCurrentThread;
#define CurrentThread() ((PITHREAD)TheCurrentThread)
#define ThreadSetCurrent(_th_) TheCurrentThread = (struct _THDINFO *)(_th_)

extern PIHEAP pTheHeap;
#define CurrentHeap() ((PIHEAP)pTheHeap)

extern PINAMESPACE pTheNameSpace;
#define CurrentNameSpace() ((PINAMESPACE)pTheNameSpace)
#endif  /* !defined(_DEBUG) && defined(OPTIMIZE) */

#if defined(__TCS__)
#define AtomicInc(_puint_) ++(*(_puint_))
#define AtomicDec(_puint_) --(*(_puint_))
#define AtomicCmpAndSwap(_p_,_o_,_n_) \
    ((*(_p_) == (_o_)) ? ((*(_p_) = (_n_)),TRUE) : (FALSE))

custom_op INT  carry(UINT a, UINT b);
custom_op INT  borrow(UINT a, UINT b);

#define INT64ADD(_r_,_p1_,_p2_) \
    (_r_).HighPart = (_p1_).HighPart + (_p2_).HighPart + carry((_p1_).LowPart,(_p2_).LowPart); \
    (_r_).LowPart  = (_p1_).LowPart  + (_p2_).LowPart

#define INT64SUB(_r_,_p1_,_p2_) \
    (_r_).HighPart = (_p1_).HighPart - (_p2_).HighPart - borrow((_p1_).LowPart,(_p2_).LowPart); \
    (_r_).LowPart  = (_p1_).LowPart  - (_p2_).LowPart

#endif

#endif /* MMLITE_MD_H */
