/* Header file for automated unit testing.
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __TEST_H__
#define __TEST_H__

#include <string.h>
#include "mmlite.h"
#define MAX_STRING_LENGTH 4096

typedef BOOL (*TestFunction)(void);

typedef struct _TestFunctionPair {
  TestFunction test_function;
  char* test_name;
} TestFunctionPair;

#define GetTestFunctionArraySize(_array_)                                     \
     (sizeof(_array_)/sizeof(TestFunctionPair))

void RunTestSuite(char* name, TestFunctionPair array[], int size)
{
    int i;
    int failcount = 0;
    TestFunction initializer = array[0].test_function;

     _tprintf(_TEXT("\n%s, %d tests\n"), name, size - 1);
     for (i = 1; i < size; i++) {
       initializer();
       _tprintf(_TEXT("\n%s\n"), array[i].test_name);
       if (array[i].test_function() == FALSE) {
	 failcount++;
       }
     }
     _tprintf(_TEXT("\n%d tests failed.\n"), failcount);
}

#define /* void */                                                            \
compare_integer(/* UINT */ _correct_,                                         \
                /* UINT */ _test_,                                            \
                /* char* */ _name_)                                           \
     compare_integer2((UINT)(_correct_), (UINT)(_test_), (_name_));

#define /* void */                                                            \
compare_integer_not(/* UINT */ _incorrect_,                                   \
                    /* UINT */ _test_,                                        \
                    /* char* */ _name_)                                       \
     compare_integer2_not((UINT)(_incorrect_), (UINT)(_test_), (_name_));

BOOL compare_string(char* correct_string,
		    char* test_string,
		    char* test_name)
{
    _tprintf(_TEXT("%s..."), test_name);
    if (strncmp(correct_string, test_string, MAX_STRING_LENGTH) == 0) {
      _tprintf(_TEXT("PASSED\n"));
      return TRUE;
    }
    else {
      _tprintf(_TEXT("FAILED\nExpected:%s\nInstead:%s\n"),
	       correct_string, test_string);
      return FALSE;
    }
}

BOOL compare_integer2(UINT correct_integer,
		     UINT test_integer, 
		     char* test_name)
{
    if (correct_integer == test_integer) {
      _tprintf(_TEXT("PASSED %s\n"), test_name);
      return TRUE;
    }
    else {
      _tprintf(_TEXT("FAILED %s\nExpected:%d\nInstead:%d\n"),
      	       test_name, correct_integer, test_integer);
      return FALSE;
    }
}

BOOL compare_integer2_not(UINT incorrect_integer,
			  UINT test_integer, 
			  char* test_name)
{
    if (incorrect_integer != test_integer) {
      _tprintf(_TEXT("PASSED %s\n"), test_name);
      return TRUE;
    }
    else {
      _tprintf(_TEXT("FAILED %s\nIncorrect:%d (should be %d)\n"),
      	       test_name, incorrect_integer, test_integer);
      return FALSE;
    }
}

SCODE CreateAThread( 
     THREAD_FUNCTION pStart,
     THREAD_ARGUMENT Arg
     )
{
    PIPROCESS pPrc = CurrentProcess();
    SCODE sc;

    sc = pPrc->v->CreateThread(pPrc,
			       pStart,
			       Arg,
			       0,
			       NULL,
			       NULL,
			       NULL);
    return sc;
}


#endif /* __TEST_H__ */

