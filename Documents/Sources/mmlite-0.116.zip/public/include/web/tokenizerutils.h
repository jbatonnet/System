/* Copyright (c) Microsoft Corporation. All rights reserved. */


#ifndef __TOKENIZER_INTERFACE__ 
#define __TOKENIZER_INTERFACE__ 1

#include <mmlite.h>
#include <tokenizerif.h>
#include <stdarg.h>

typedef enum _TOKENIZER_COPYMODE
{
    TOKENIZER_COPYMODE_UTF8 = 0,
    TOKENIZER_COPYMODE_ASCII = 1,
    TOKENIZER_COPYMODE_BINARY = 2
} TOKENIZER_COPYMODE;

#define iTokenizer(x)  ((PITOKENIZER)(x))
#define pTokenMarker(x)  ((PTokenMarker)(x))

/* Parsing utilities */


#define CR                      13
#define LF                      10
#define SP                      32
#define HT                      9
#define COLON                   58
                      
/* The parameters are of type PBYTE (c) and char (n) */

#define IsASCIIChar(c, n)           (((*(c))) == (n))
#define IsCRChar(c)                 (IsASCIIChar(c, CR))        /* carriage return, '\r' */
#define IsLFChar(c)                 (IsASCIIChar(c, LF))        /* linefeed, '\n' */
#define IsSPChar(c)                 (IsASCIIChar(c, SP))        /* whitespace, ' ' */
#define IsHTChar(c)                 (IsASCIIChar(c, HT))        /* horizontal tab, '\t' */
#define IsCOLONChar(c)              (IsASCIIChar(c, COLON))     /* colon, ':' */
#define IsWhitespaceChar(c)         ( IsCRChar((c)) || IsLFChar((c)) || IsSPChar((c)) || IsHTChar((c)))


/* Same macros taking a PTokenMarker as c */

#define IsASCII(c, n)           IsASCIIChar((pTokenMarker(c))->Content, n)
#define IsCR(c)                 IsCRChar((pTokenMarker(c))->Content)        /* carriage return, '\r' */
#define IsLF(c)                 IsLFChar((pTokenMarker(c))->Content)        /* linefeed, '\n' */
#define IsSP(c)                 IsSPChar((pTokenMarker(c))->Content)        /* whitespace, ' ' */
#define IsHT(c)                 IsHTChar((pTokenMarker(c))->Content)        /* horizontal tab, '\t' */
#define IsCOLON(c)              IsCOLONChar((pTokenMarker(c))->Content)     /* colon, ':' */
#define IsWhitespace(c)         IsWhitespaceChar((pTokenMarker(c))->Content)


/* The parameters are of type PBYTE* (c) and char (n) */
                            
#define EatASCII(c, n) \
{ \
    while (IsASCII((c), (n))) { \
        sc = (c)->v->AdvanceSymbol((c), 1, NULL); \
        CHECKSC("advance symbol"); \
    } \
}

#define EatWHITESPACE(c) \
{ \
    while ( IsWhitespace((c)) ) { \
        sc = (c)->v->AdvanceSymbol((c), 1, NULL); \
        CHECKSC("advance symbol"); \
    } \
}

/* same as EatWHITESPACE, but continues on error */
#define EatWHITESPACE_IGNORE(c) \
{ \
    while ( IsWhitespace((c)) ) { \
        sc = (c)->v->AdvanceSymbol((c), 1, NULL); \
        if(FAILED(sc) || sc == S_FALSE) \
            break; \
    } \
}

#define EatSP(c)                { EatASCII((c), SP); }


#define EatCR(c)                { EatASCII((c), CR); }

#define EatLF(c)                { EatASCII((c), LF); }

#define EatHT(c)                { EatASCII((c), HT); }

#define EatOneCRLF(c) \
{ \
    INT Match = 1; \
    sc = (c)->v->CmpToken(c, _T("\r"), 1, &Match);      \
    CHECKSC("compare token"); \
    if (sc == S_OK) { \
        sc = (c)->v->AdvanceSymbol((c), 1, NULL); \
        CHECKSC("advance symbol"); \
    } \
    sc = (c)->v->CmpToken(c, _T("\n"), 1, &Match);      \
    CHECKSC("compare token"); \
    if (sc == S_OK) { \
        sc = (c)->v->AdvanceSymbol((c), 1, NULL); \
        CHECKSC("advance symbol"); \
    } \
}

#define EatLWS(c) \
{ \
    EatOneCRLF(c); \
    while (IsSP((c)) || IsHT((c))) { \
        sc = (c)->v->AdvanceSymbol((c), 1, NULL); \
        CHECKSC("advance symbol"); \
    } \
}

#define THISBYTE(aTokenizer) (*((pTokenMarker(aTokenizer))->Content))

#define PUTBYTE(aTokenizer, aValue) \
{ \
    sc = (aTokenizer)->v->SetNextByte((aTokenizer), (aValue)); \
    CHECKSC("set byte"); \
}

#define GETBYTE(aTokenizer, aValue) \
{ \
    sc = (aTokenizer)->v->GetNextByte((aTokenizer), &(aValue)); \
    CHECKSC("get byte"); \
}

#define GETCHAR(aTokenizer, aValue) \
{ \
    sc = (aTokenizer)->v->GetNextChar((aTokenizer), &(aValue)); \
    CHECKSC("get char"); \
}

#define CHECKBYTE(aTokenizer, aValue) \
{ \
    BYTE b; \
    sc = (aTokenizer)->v->GetNextByte((aTokenizer), &(b)); \
    CHECKSC("get byte"); \
    CHECKSETSC(b == (aValue), E_PARSING_ERROR, "unexpected byte value"); \
}

#define CHECKBYTEMSG(aTokenizer, aValue, message) \
{ \
    BYTE b; \
    sc = (aTokenizer)->v->GetNextByte((aTokenizer), &(b)); \
    CHECKSC(message); \
    CHECKSETSC(b == (aValue), E_PARSING_ERROR, message); \
}

#define ADVANCE(aTokenizer, steps) CHECKOP((aTokenizer)->v->AdvanceSymbol((aTokenizer), (steps), NULL), "advance symbol");

#define TOKENIZERISVALID(tokenMarker) ((pTokenMarker(tokenMarker)->Refs & REFCNT_FLAG1) > 0)
#define TOKENIZERREVALIDATE(tokenMarker) (pTokenMarker(tokenMarker)->Refs |= REFCNT_FLAG1)
#define TOKENIZERINVALIDATE(tokenMarker) (pTokenMarker(tokenMarker)->Refs &= ~REFCNT_FLAG1)
#define TOKENIZERREFCOUNT(tokenMarker)(pTokenMarker(tokenMarker)->Refs & ~(REFCNT_FLAGS_MASK))

#endif /* __TOKENIZER_INTERFACE__ */
