/* Copyright (c) Microsoft Corporation. All rights reserved. */

#include <mmlite.h>
#include <x86_cpu.h>
#include <fred.h>
#include <_dosx.h>
#include <base/debugger.h>

extern void __stdcall DebugSynNotifyLoad(char *pbData, const char *pszDllPath);
extern void __stdcall DebugSynNotifyUnload(char *pbData);

/* Notify debugger of load so that it can find the symbols
 */
UINT DebuggerNotifyLoad(const _TCHAR *ModuleName,
                        ADDRESS LoadStart,
                        ADDRESS LoadEnd,
                        PTR Unused)
{
    UINT State;
#ifdef _UNICODE
    char *_name = _wcstos(ModuleName);
#else
#define _name ModuleName
#endif

    TURN_INTERRUPTS_OFF(State);
    DebugSynNotifyLoad((PTR) LoadStart, _name);
    RESTORE_INTERRUPTS(State);

#ifdef _UNICODE
    free(_name);
#else
#undef _name
#endif

    return 0;
}

void DebuggerNotifyUnload(const _TCHAR *ModuleName, ADDRESS LoadStart,
                          UINT Token)
{
    UINT32 State;

    UnusedParameter(Token);
    UnusedParameter(ModuleName);

    TURN_INTERRUPTS_OFF(State);
    DebugSynNotifyUnload((PTR) LoadStart);
    RESTORE_INTERRUPTS(State);
}

void DCPutChar( UINT8 c);

int DCGetChar( BOOL DoEcho );

int NT_puts(const char *s);

int puts(const char *s)
{
    UINT32 State;
    INT r;
    
    TURN_INTERRUPTS_OFF(State);
    r = NT_puts(s);
    RESTORE_INTERRUPTS(State);
    return r;
}

