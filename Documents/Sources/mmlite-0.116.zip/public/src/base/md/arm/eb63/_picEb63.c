/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Atmel AT91M63200 Advance Interrupt Controller (AIC) support.
 */
#include <mmlite.h>
#include <diagnostics.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <drivers/drivers.h>
#include <fred.h>
#include <mmhal.h>
#include "at91m63200.h"

#define _STATISTICS 0

#define IRQ_ID_COUNT (32)

extern PCXTINFO _Reschedule(PCXTINFO pContext);

typedef struct _ITABLE {
#if 0
    /* This is kept in the AIC */
    INTERRUPT_SERVICE_ROUTINE Isr;  /* isr for IRQn*/
#endif
    void *pDevice;                  /* Argument to pass to ISR */
#if _STATISTICS
    UINT32 Count;
#endif
} ITABLE;

/* The interrupt dispatcher uses a simple table of handlers. */
typedef struct _PIC {
    const struct IPicVtbl *v;
    UINT32 Enabled;
    ITABLE InterruptTable[IRQ_ID_COUNT];
} PIC;

/*
 * ToDo:  Is it edge triggered or level triggered?
 *        Is it active high or active low?
 *
 * Currently we assume IRQ, and the device gets to set edge/level, high/low.
 */

void MCT EnableInterrupt( IPic *pThis, DEVICE_FLAGS Flags, UINT Irq, INTERRUPT_SERVICE_ROUTINE Isr, void *pDevice)
{
    PIC *pic = (PIC *) pThis;
    UINT32 Mode = AICSM_PRIO(1);

#if 0
    /* We might want to protect the innocents and prevent them from
     * getting screwed trying to use the wrong IRQ.
     */
    if ((Irq > 14) && (Irq < 28)) {
        DBGME(3,printf("Useless IRQ %d, will never trigger.\n",Irq));
        return;
    }
#endif

    if (Irq == 30) {
        PioA->Disable = PIOA_IRQ1;
        PioA->FilterDisable = PIOA_IRQ1;
    }

    /* Map interrupt mode flags
     */
    if ((Flags & DEVICE_FLAGS_LEVEL_TRIGGER) == 0)
        Mode |= AICSM_EDGE;
    if (Flags & DEVICE_FLAGS_POSITIVE_LEVEL)
        Mode |= AICSM_POSITIVE;

    /* The order of the following operations is NOT irrelevant
     *
     * First, the argument. Failure case is if interrupt was
     * active and we are called with interrupts on and we get
     * an interrupt right after this statement. Wont happen.
     * [e.g. old ISR called with new argument]
     */
    pic->InterruptTable[ Irq ].pDevice = pDevice;

    /* Second, the ISR. If the interrupt was active we are done already.
     */
    TheAic->SourceVector[ Irq ] = (UINT32) Isr;

    /* Third, the mode.
     */
    TheAic->SourceMode[ Irq ] = Mode;

    /* Finally, the mask
     */
    pic->Enabled |= (1 << Irq);
    TheAic->Enable = pic->Enabled;
}

/*
 * Undo the above EnableInterrupt
 */
void MCT DisableInterrupt( IPic *pThis, UINT Irq, void **pOldDevice)
{
    PIC *pic = (PIC *) pThis;

    /* Remove the ISR and its argument from our tables after setting
     * the hardware mask.
     */
    pic->Enabled &= ~(1 << Irq);
    TheAic->Disable = ~pic->Enabled;

    TheAic->SourceVector[ Irq ] = 0;
    *pOldDevice = pic->InterruptTable[ Irq ].pDevice; /* Return the old one */
    pic->InterruptTable[ Irq ].pDevice = NULL;
}

/*
 * Mask *all* interrupts.
 */
void MCT MaskAll( IPic *pThis )
{
    UnusedParameter(pThis);
    TheAic->Disable = ~0;
}

/*
 * Unmask all interrupts that should be unmasked.
 */
void MCT UnmaskAll( IPic *pThis )
{
    PIC *pic = (PIC *) pThis;
    TheAic->Enable = pic->Enabled;
}

static const struct IPicVtbl picVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    EnableInterrupt,
    DisableInterrupt,
    MaskAll,
    UnmaskAll
};

PIC ThePIC = {
    &picVtbl,
    0,
};

/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
    /* Disable all channels*/
    MaskAll(pThis);
}


IPic *PicCreate(void)
{
    IPic *pThis;
    int Irq;

    ThePIC.Enabled = 0;
    pThis = (IPic *)&ThePIC;

    /* Reset chip, disable all ints
     */
    TheAic->Disable = ~0;
    TheAic->Clear = ~0;
    for (Irq = 0; Irq < 8; Irq++)
        TheAic->EndOfInterrupt = ~0;

    /* Clear all vectors.
     * NB: There are many unimplemented ones, they read as zeroes
     */
    for (Irq = 0; Irq < 32; Irq++) 
        TheAic->SourceVector[ Irq ] = 0;
    TheAic->SpuriousVector = 0;

    return pThis;
}

/* Dispatch an interrupt
 * NB: Doesnt seem to be possible to handle more than one at a time.
 * If we try the AIC locks up.
 */
CXTINFO *TrapIRQ(CXTINFO *pContext)
{
    UINT32 DoReschedule;
    BOOL NotMyInterrupt;
    int Index;
    ITABLE *IntSource;
    INTERRUPT_SERVICE_ROUTINE Isr;

    pContext->PC -= 4;

    DoReschedule = 0;

    Isr = (INTERRUPT_SERVICE_ROUTINE) TheAic->IrqVector;
    Index = TheAic->Status & AICST_MASK;
    IntSource=&ThePIC.InterruptTable[Index];

    if (Isr && Index) {
#if _STATISTICS
        IntSource->Count++;
#endif
        DoReschedule |= (Isr)(IntSource->pDevice, &NotMyInterrupt);
        TheAic->EndOfInterrupt = 1;
    }
#if _STATISTICS
    else {
        ThePIC.InterruptTable[0].Count++;
    }
#endif

    /* If the handler requested a reschedule, it will get done */
    if (DoReschedule)
        pContext = _Reschedule(pContext);

    return pContext;
}

#if _STATISTICS
void PrintIrqCounts(void)
{
    int i;
    for (i = 0; i < IRQ_ID_COUNT; i++)
        if (ThePIC.InterruptTable[i].Count != 0)
            printf("int[%d] = %d\n", i, ThePIC.InterruptTable[i].Count);
}
#endif
