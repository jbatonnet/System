/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>

PIUNKNOWN JoyCobMain(void);
EXTERN_C PIDEVICE RTLCALLTYPE JoyNew( PUINT pPortBase, PUINT pChan);
EXTERN_C PIDEVICE RTLCALLTYPE MouseNew (_TCHAR **InputDeviceName, UINT * pMType, UINT * yyy);
EXTERN_C PIDEVICE RTLCALLTYPE KeyboardNew (PUINT basePort);

PIUNKNOWN CobMain(void)
{
    MouseNew(0, 0, 0);
    KeyboardNew(0);
    return (PIUNKNOWN) JoyNew(0, 0);
}
