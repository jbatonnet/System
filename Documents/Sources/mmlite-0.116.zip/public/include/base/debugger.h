/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*********************
 *
 * Interface routines that must be implemented by a debugger stub
 */

#if defined(__NO_DEBUGGER)
#define Debugger(a,b)
#define DebuggerNotifyLoad(a,b,c,d) 0
#define DebuggerNotifyUnload(a,b,c)
#define DebuggerAttached FALSE
#define DebuggerOutputString(a,b)
#else
/* A trap handler calls this when all else fails
 */
extern void Debugger(PCXTINFO pContext, UINT32 TrapNumber);

/* A loader calls this when a module is loaded
 * Returns a Token to pass back on unload.
 */
extern UINT DebuggerNotifyLoad(const _TCHAR *ModuleName,
                               ADDRESS LoadStart,
                               ADDRESS LoadEnd,
                               PTR DebuggerSpecific);

/* A loader calls this when a module is unloaded
 */
extern void DebuggerNotifyUnload(const _TCHAR *ModuleName,
                                 ADDRESS LoadStart,
                                 UINT Token);

/* The debugger routes these (ASCII) messages to the remote user,
 * wrapped as appropriate inside the debugger/debuggee comm protocol.
 */
extern void DebuggerOutputString( const unsigned char *String, int nBytes );

/* Some critical pieces of code (trap handlers ad es.) might need to know
 * if/when we are running under control of a debugger.
 */
extern BOOL DebuggerAttached;
#endif

/* If this range is non-zero, the debugger will watch for memory read/write
 * requests at addresses within the given range of addresses.
 * It will perform 16/32 bit accesses as requested, rather than the
 * usual byte-at-a-time accesses it normally performs on regular memory.
 * A user might modify this range via the debugger stub itself.
 */
extern ADDRESS StartOfIoSpace;
extern ADDRESS EndOfIoSpace;


/*********************
 *
 * Routines provided to the debugger by other, machine-independent modules
 */

/* The debugger stub calls this when a remote debugger is attached,
 * who wants to be provided with the list of loaded modules.
 * This should turn around and call DebuggerNotifyLoad() for each.
 */
extern void DebuggerNotifyModuleList(void);

/* Terminate the system, whatever that means (reboot,shutdown,...)
 */
extern void BaseDelete(void);


/*********************
 *
 * Routines provided to the debugger by other, machine-dependent modules
 */

/* Break into the debugger, usually via a strange machine instruction.
 * Could be a macro.
 */
#if !defined(DebugBreak)
extern void DebugBreak(void);
#endif

/* The means to communicate to the remote debugger, one byte at a time
 * in order to implement the debugger/debuggee comm protocol.
 */
extern void putDebugChar(unsigned char c);/* write a single character      */

extern int getDebugChar(void);            /* read and return a single char */

