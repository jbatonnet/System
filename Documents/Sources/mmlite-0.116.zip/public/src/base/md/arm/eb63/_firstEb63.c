/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains FirstThread
 */

#include <mmlite.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <fred.h>
#define _DEBUG 1
#include <diagnostics.h>
#include <drivers/serp.h>

extern PIBASERTL pTheBaseRtl;

#define BREAK_BUTTON 1
#if BREAK_BUTTON
#include "at91m63200.h"

/* Push SW4 (PA9/IRQ0) to drop in the debugger 
 */
BOOL MCT Sw4Isr(void *This, PBOOL pNotMyInterrupt)
{
    DebugBreak();
    return FALSE;
}
#endif

extern PINAMESPACE BoardInitFileSystem(void);

/* Leftover linking issues */
INT MODENTRY CrtInit(INT Op)
{
    return 1;/* TRUE */
}

typedef _TCHAR *TSTR;
const TSTR FIRST_IMAGE_NAME = _TEXT("tzk.cob");

/* To help diagnose product boot problems.
 * Should be an LED or something else externally accessible.
 */
int BootStep = 0;

void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    SCODE sc;
    const _TCHAR * Args = _TEXT("");
    PINAMESPACE pRoot;
    PIUNKNOWN pUnk;

#if BREAK_BUTTON
    PioA->Disable = PIOA_IRQ0;
    PioA->FilterEnable = PIOA_IRQ0;
    sc = AddDevice (NULL, (PTR) Sw4Isr, (ADDRESS)0, 31, 0);
#endif

    UnusedParameter(arg);

    /* Start the linked-in drivers
     */
    pRoot = CurrentNameSpace();

    BootStep++; 

    sc = pRoot->v->Bind(pRoot,"COB/drivers.cob", 0, &pUnk);
    if (FAILED(sc)) {
        DBGME(3,printf("drivers.cob failed\n"));
        goto Out;
    }
    BootStep++; 
    /* leak the Unk */

    /* Start the console, using the serial line driver
     */
    StartDriver("com1");
    BootStep++;
    
    StartDriver("com2");
    BootStep++;
    
    /* Hostfs must use serplex */
    StartDriver("serplex6a");
    BootStep++;

#if USE_SERPLEX
    StartDriver("serplex6c");
    BootStep++;
 
    sc = InitConsole("serplex6c");
#else
    sc = InitConsole("com2");
#endif
    if (FAILED(sc)) {
        DBGME(3,printf("Failed to create debug console (sc = x%x)\n", sc));
        goto Out;
    }
    BootStep++; 

    pRoot = BoardInitFileSystem();
    BootStep++; 

    if (pRoot)
        SetImageNameSpace(pRoot);
    BootStep++; 

//    StartDriver("Wave0");

    FirstApp(Args);
    BootStep++; 

  Out:
    BaseDelete();
}
