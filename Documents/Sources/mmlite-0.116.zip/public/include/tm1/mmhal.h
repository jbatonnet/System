/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* --------------------------------------------------------------------------
 *
 * Module:
 *
 *    mmhal.h
 *
 * Purpose:
 *
 *    FRED header file (TriMedia version)
 *
 * Author:
 *    A. Forin (sandrof)
 *
 * --------------------------------------------------------------------------
 */

#ifndef __MMHAL_
#define __MMHAL_ 1

/*
 * Bit/Byte-order defines
 */
#ifndef BYTE_ORDER

#define LITTLE_ENDIAN 1
#define BIG_ENDIAN 0

#define BYTE_ORDER LITTLE_ENDIAN

#endif /* BYTE_ORDER */

#include <endian.h>

/*
 * I/O accesses
 */
typedef ADDRESS IO_PORT;

#define IOSpaceReadInt8(_This_) (*((volatile UINT8*)_This_))
#define IOSpaceWriteInt8(_This_,_Value_) ((*((volatile UINT8*)_This_)) = (UINT8)(_Value_))

#define IOSpaceReadInt16(_This_) (*((volatile UINT16*)_This_))
#define IOSpaceWriteInt16(_This_,_Value_) ((*((volatile UINT16*)_This_)) = (UINT16)(_Value_))

#define IOSpaceReadInt32(_This_) (*((volatile UINT32*)_This_))
#define IOSpaceWriteInt32(_This_,_Value_) ((*((volatile UINT32*)_This_)) = (UINT32)(_Value_))

#define IOSpaceReadFIFO16(_This_,_Str_,_Cnt_) \
{ \
    UINT16 *_ptr_ = _Str_; \
    UINT _Count_; \
    for (_Count_ = _Cnt_; _Count_ > 0; _Count_--, _ptr_++) { \
        *_ptr_ = *(volatile UINT16*)(_This_); \
        IOMemoryBarrier(); \
    } \
}

#define IOSpaceWriteFIFO16(_This_,_Str_,_Cnt_) \
{ \
    UINT16 *_ptr_ = _Str_; \
    UINT _Count_; \
    for (_Count_ = _Cnt_; _Count_ > 0; _Count_--, _ptr_++) { \
        *(volatile UINT16*)(_This_) = *_ptr_; \
        IOWriteBufferFlush(); \
    } \
}


/*
 * There are no I/O WriteBuffer-ing issues
 */
#define IOWriteBufferFlush()

/*
 * There are no out-of-order I/O read issues
 */
#define IOMemoryBarrier()


/*
 *  NT compatibility defines
 */
#define READ_PORT_UCHAR(_a_)       IOSpaceReadInt8((IO_PORT)_a_)
#define WRITE_PORT_UCHAR(_a_,_v_)  IOSpaceWriteInt8((IO_PORT)_a_,_v_)
#define READ_PORT_USHORT(_a_)      IOSpaceReadInt16((IO_PORT)_a_)
#define WRITE_PORT_USHORT(_a_,_v_) IOSpaceWriteInt16((IO_PORT)_a_,_v_)
#define READ_PORT_ULONG(_a_)       IOSpaceReadInt32((IO_PORT)_a_)
#define WRITE_PORT_ULONG(_a_,_v_)  IOSpaceWriteInt32((IO_PORT)_a_,_v_)
#define READ_PORT_BUFFER_USHORT(_a_,_b_,_c_) \
                                   IOSpaceReadFIFO16((IO_PORT)(_a_),_b_,_c_)
#define WRITE_PORT_BUFFER_USHORT(_a_,_b_,_c_) \
                                   IOSpaceWriteFIFO16((IO_PORT)(_a_),_b_,_c_)

#define KeStallExecutionProcessor(_u_) Delay(_u_)

#endif  /*__MMHAL_*/
