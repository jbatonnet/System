/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <driverif.h>

EXTERN_C INT MODENTRY CrtInit(INT Op);

SCODE MCT DriverCobQueryInterface(PIDEVICECONSTRUCTOR pThis, REFIID Iid,
                                       void **ppObj);
UINT MCT DriverCobAddRef(PIDEVICECONSTRUCTOR pThis);
UINT MCT DriverCobRelease(PIDEVICECONSTRUCTOR pThis);

/* Driver COB Object */
typedef struct _DRIVERCOB {
    struct IDeviceConstructorVtbl *v;
    UINT RefCnt;
} *PDRIVERCOB;

/* IUnknown::<this> points to v-table
 * pDC (pointer of Driver Cob) converts interface ptr to implementation.
 * iDC (interface of DC)  converts implementation ptr to interface ptr.
 */
#define pDriverCob(_i_) ((PDRIVERCOB)(_i_))
#define iDriverCob(_p_) ((PIDEVICECONSTRUCTOR)(_p_))

/* IUnknown::QI.  Return a pointer of the right kind. */
SCODE MCT DriverCobQueryInterface(PIDEVICECONSTRUCTOR pThis, REFIID Iid,
                                       void **ppObj)
{
    return GenericQueryInterface((PIUNKNOWN) pThis, Iid, ppObj,
                                 &IID_IDeviceConstructor);
}

/* IUnknown::AddRef */
UINT MCT DriverCobAddRef(PIDEVICECONSTRUCTOR pThis)
{
    PDRIVERCOB x = pDriverCob(pThis);

    return AtomicInc(&x->RefCnt);
}

/* IUnknown::Release */
UINT MCT DriverCobRelease(PIDEVICECONSTRUCTOR pThis)
{
    PDRIVERCOB x = pDriverCob(pThis);
    UINT RefCnt = AtomicDec(&x->RefCnt);

    if (RefCnt == 0) {
        /* Nothing special to finalize or deallocate in this implementation
         * but give C runtime a chance to run global destructors etc.
         */
        CrtInit(DLL_PROCESS_DETACH);
    }
    return RefCnt;
}

SCODE MCT UnimplementedMethod()
{
    return E_NOT_IMPLEMENTED;
}

static struct IDeviceConstructorVtbl vtab = {
    DriverCobQueryInterface,
    DriverCobAddRef,
    DriverCobRelease,
    (_IDeviceConstructor_Constructor_METHOD_TYPE) UnimplementedMethod
};

static struct _DRIVERCOB _DriverCobObject = { &vtab, 1 };

PIUNKNOWN BubbaCobMain(void)
{
    return (PIUNKNOWN) iDriverCob(&_DriverCobObject);
}
