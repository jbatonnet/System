/* Copyright (c) Microsoft Corporation. All rights reserved. */

#include <stdio.h>
#include <mmlite.h>
#include <arm/at91m63200.h>

void setled(int ledno, BOOL on)
{
    if (on)
        PioB->ClearData = PIOB_PB8 << (ledno - 1);
    else
        PioB->SetData = PIOB_PB8 << (ledno - 1);
}

int _tmain()
{
    UINT32 Status, Last;
    UINT i;

    Status = PioB->PinDataStatus & PIOB_PB3;

    printf("Push button 1: %s\n", Status ? "off" : "ON");
    for (i = 0; i < 3000000; i++) {
        Last = Status;
        Status = PioB->PinDataStatus & PIOB_PB3;
        if (Status != Last) {
            setled(1, !Status);
            printf(" %s ", Status ? "off" : "ON");
        }
    }
    return 0;
}
