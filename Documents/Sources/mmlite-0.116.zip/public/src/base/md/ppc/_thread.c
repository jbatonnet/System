/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <string.h>             /* for memset prototype */

/* Initialize the machine-dependent part of a thread object.
 * The (new) thread should be set to execute the function START
 * with argument ARG.  No scheduling side-effects.
 */
void MachineThreadCreate(PITHREAD pThis, THREAD_FUNCTION pStart, 
                         THREAD_ARGUMENT Arg, PTR StackTop, UINT ArgCount,
                         UINT32 Flags)
{
    UINT64 *pStk = (UINT64 *)StackTop;
    CXTINFO *pCxt;

    assert(ArgCount == -1);

    /* NB: The compiler assumes that stacks are aligned.
     * We know for sure that they must be UINT64 aligned,
     * we dont know if they might have to be UINT128 aligned.
     * So make sure its properly aligned, just in case.
     */
#define ALGN 16
    pStk = (PTR)(((ADDRESS)pStk) & (~(ALGN-1)));

#if 0
    /* Make room for args.
     * NB: C Calling convention wants room for (TBD)
     */
    pStk -= 16;
#endif

    /* Make room for context on stack
     * Thread's initial state will point there.
     */
    pCxt = (CXTINFO *)pStk;
    pCxt--;
    pTH(pThis)->CxtInfo = pCxt;

    memset(pCxt, 0, sizeof(*pCxt));

    /* Setup non-zero registers
     */
    pCxt->gpr[3] = (UINT64) Arg;         /* a0 */
    pCxt->pc     = (UINT64) pStart;
    pCxt->gpr[1] = (UINT64) pStk;        /* sp */
    pCxt->lr     = (UINT64) ThreadExit;  /* lr */
    pCxt->msr    = PPC_MSR_HV | PPC_MSR_EE | PPC_MSR_IR | PPC_MSR_DR | PPC_MSR_RI;
}
