/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _KERNEL_SCHEDUL_H_
#define _KERNEL_SCHEDUL_H_

/* #define SCHEDULER_NAME _TEXT("cb_sched2") */

/*
 * The scheduler is packaged as an (non-COM) object.
 */

/* Condition pkg provides these to Scheduler
 */
typedef void (*WAITCOND_CALLBACK)(PCONDITION pCond,
                                  PMUTEX pMutex,
                                  PTIME pTimeOut);

#ifdef _OLDSCHED
/* Scheduler provides this callback to Condition pkg
 */
typedef PITHREAD (*TIMEOCOND_CALLBACK)(PITHREAD pThdFirst,
                                       PITHREAD pThdCancel);


extern void ConditionTimeoutThread(PCONDITION pCond,
                                   PITHREAD pThd,
                                   TIMEOCOND_CALLBACK CallBack);

extern volatile PTR DeferredConditionSignals;
extern void DrainDeferredConditions(void);
PITHREAD ThreadConditionCancel(PITHREAD pThd, PITHREAD pThdCancel);
#endif

#include <schedulif.h>

/* Assume there is only one scheduler */

extern IScheduler *pTheScheduler;

extern IScheduler *SchedulerCreate(void);

#endif /* _KERNEL_SCHEDUL_H_ */
