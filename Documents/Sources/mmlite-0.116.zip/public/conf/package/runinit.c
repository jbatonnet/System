/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <stdio.h>
#include <mmlite.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>

#ifdef _CLR
#include <clr/clr.h>
PICLR pTheCLR = NULL;
#endif

extern PIBASERTL pTheBaseRtl;

extern const _TCHAR *FIRST_IMAGE_NAME;

#ifdef LOAD_EXES
PRIVATE const _TCHAR *GetSuffix(const _TCHAR *arg)
{
    const _TCHAR *p;
    /* find end */
    for (p = arg; *p; p++)
        ;
    /* find dot going backwards */
    for ( ; *p != _T('.'); p--)
        if (p == arg)
            return NULL;
    return p+1; /* return next after dot */
}
#endif

SCODE FirstApp(const _TCHAR *Args)
{
#ifdef LOAD_EXES
    const _TCHAR *Suffix;
    PIMODULE pMod;
    MODULEENTRY EntryPoint;
#endif
    PINAMESPACE ns;
    PIPROGRAM prog;
    const _TCHAR *Image;
    SCODE sc;

    Image = FIRST_IMAGE_NAME;

#ifdef _CLR
    ns = CurrentNameSpace();
    pTheCLR = ClrCreate();

    if (ns->v->Register(ns, CLR_NAME,
				   (PIUNKNOWN)pTheCLR, 0,
				   NULL) != S_OK) {
      printf("failed to register the CLR\n");
      goto Out;
    }
#endif

#ifdef LOAD_EXES
    Suffix = GetSuffix(Image);
    if (Suffix && !_tcscmp(Suffix, _T("cob"))) {
#endif
        /* Load it COB style
         */
        /* Bind to "COB/" */
        sc = BindToObject(CurrentNameSpace(), _T("COB"), NAME_SPACE_READ,
                         &IID_INameSpace, (void **) &ns);
        if (FAILED(sc))
            goto Out;

        /* Get the Cob's Main method */
        sc = BindToObject(ns, Image, NAME_SPACE_READ, &IID_IProgram,
                         (void **) &prog);
        ns->v->Release(ns);
        if (FAILED(sc))
            goto Out;

        sc = prog->v->Main(prog, Args ? Args : _T(""));
        prog->v->Release(prog);
#ifdef LOAD_EXES
    } else {
        /* Load EXE style */
        sc = LdrLoadImage(GetImageNameSpace(), Image, Args, 0, &pMod);
        if (FAILED(sc)) {
            printf("Failed to load %s (sc = x%x)\n", FIRST_IMAGE_NAME, sc);
            goto Out;
        }

        pMod->v->GetEntryPoint(pMod, (ADDRESS *) &EntryPoint);
        EntryPoint(pTheBaseRtl);
        pMod->v->Release(pMod);
    }
#endif

  Out:
    return sc;
}
