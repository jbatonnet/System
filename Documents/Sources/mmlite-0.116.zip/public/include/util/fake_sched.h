/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __FAKE_SCHED_H__
#define __FAKE_SCHED_H__

PRIVATE PINAMESPACE pTheNameSpace;

void CurrentHeapDelayedFree(PITHREAD pThd)
{
}

/*  BOOL SetNextInterrupt(TIME t, BOOL* b) */
/*  { */
/*      return TRUE; */
/*  } */

/*  void ThreadSetCurrent(PITHREAD pThd) */
/*  { */
/*  } */

/*  void BaseDelete(void) */
/*  { */
/*  } */

#endif /* __FAKE_SCHED_H__ */

