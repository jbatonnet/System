/* Copyright (c) Microsoft Corporation. All rights reserved. */
/************************************************************************
**   File name :  3437f.h
**                H8/3437 Series header file
**
**                16 Bit Free Running Timer  
**                Interrupt controller
**                I/O ports
**
**                HITACHI Micro Systems, Inc 1997                             
**
**                This file is referenced from tchain\hitachi\ch38\sample
**
**   Aug. 26 1997 Version  1.0   TMN                                          
*************************************************************************/

struct st_frt {                                         /* struct FRT   */
              union {                                   /* TIER         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char ICIAE:1;       /*    ICIAE     */
                           unsigned char ICIBE:1;       /*    ICIBE     */
                           unsigned char ICICE:1;       /*    ICICE     */
                           unsigned char ICIDE:1;       /*    ICIDE     */
                           unsigned char OCIAE:1;       /*    OCIAE     */
                           unsigned char OCIBE:1;       /*    OCIBE     */
                           unsigned char OVIE :1;       /*    OVIE      */
                           }      BIT;                  /*              */
                    }           TIER;                   /*              */
              union {                                   /* TCSR         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char ICFA :1;       /*    ICFA      */
                           unsigned char ICFB :1;       /*    ICFB      */
                           unsigned char ICFC :1;       /*    ICFC      */
                           unsigned char ICFD :1;       /*    ICFD      */
                           unsigned char OCFA :1;       /*    OCFA      */
                           unsigned char OCFB :1;       /*    OCFB      */
                           unsigned char OVF  :1;       /*    OVF       */
                           unsigned char CCLRA :1;      /*    CCLRA     */
                           }      BIT;                  /*              */
                    }           TCSR;                   /*              */
              unsigned int      FRC;                    /* FRC          */
              unsigned int      OCR;                    /* OCRA or OCRB */
              union {                                   /* TCR          */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char IEDGA:1;       /*    IEDGA     */
                           unsigned char IEDGB:1;       /*    IEDGB     */
                           unsigned char IEDGC:1;       /*    IEDGC     */
                           unsigned char IEDGD:1;       /*    IEDGD     */
                           unsigned char BUFEA:1;       /*    BUFEA     */
                           unsigned char BUFEB:1;       /*    BUFEB     */
                           unsigned char CKS  :2;       /*    CKS       */
                           }      BIT;                  /*              */
                    }           TCR;                    /*              */
              union {                                   /* TOCR         */
                    unsigned char BYTE;                 /*  Byte Access */
                    struct {                            /*  Bit  Access */
                           unsigned char wk   :3;       /*              */
                           unsigned char OCRS :1;       /*    OCRS      */
                           unsigned char OEA  :1;       /*    OEA       */
                           unsigned char OEB  :1;       /*    OEB       */
                           unsigned char OLVLA:1;       /*    OLVLA     */
                           unsigned char OLVLB:1;       /*    OLVLB     */
                           }      BIT;                  /*              */
                    }           TOCR;                   /*              */
              unsigned int      ICRA;                   /* ICR          */
              unsigned int      ICRB;                   /* ICR          */
              unsigned int      ICRC;                   /* ICR          */
              unsigned int      ICRD;                   /* ICR          */
};                                                      /*              */
                                                                                                
struct st_p8 {                                          /* struct P8    */
             unsigned char      DDR;                    /* P8DDR        */
             char               wk;                     /*              */
             union {                                    /* P8DR         */
                   unsigned char BYTE;                  /*  Byte Access */
                   struct {                             /*  Bit  Access */
                          unsigned char wk:1;           /*    Bit 7     */
                          unsigned char B6:1;           /*    Bit 6     */
                          unsigned char B5:1;           /*    Bit 5     */
                          unsigned char B4:1;           /*    Bit 4     */
                          unsigned char B3:1;           /*    Bit 3     */
                          unsigned char B2:1;           /*    Bit 2     */
                          unsigned char B1:1;           /*    Bit 1     */
                          unsigned char B0:1;           /*    Bit 0     */
                          }      BIT;                   /*              */
                   }            DR;                     /*              */
};                                                      /*              */
                                               
#define FRT     (*(volatile struct st_frt   *)0xFF90)   /* FRT   Address*/
#define P8      (*(volatile struct st_p8    *)0xFFBD)   /* P8    Address*/
#define SYSCR   (*(volatile union  un_syscr *)0xFFC4)   /* SYSCR Address*/

