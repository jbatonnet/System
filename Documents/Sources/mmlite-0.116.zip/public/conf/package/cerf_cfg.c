/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>
#include <drivers/serp.h>

#define USE_SERPLEX 1
#define SERPLEX_ON_USB 0          /* Use "USB Sync" driver on windows */
#define SERPLEX_ON_SERIAL3 0      /* The one with the funny cable */
#define SERPLEX_ON_SERIAL1 1      /* On the aux motherboard */

#if SERPLEX_ON_USB
#define SERPLEXLINE _T("com4")
#endif
#if SERPLEX_ON_SERIAL3
#define SERPLEXLINE _T("com3")
#endif
#if SERPLEX_ON_SERIAL1
#define SERPLEXLINE _T("com1")
#endif



_TCHAR name[] = _T("CERF0");
_TCHAR ssid[] = _T("COMPAQ");
UINT8 wkey64[6] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x00/*MBZ*/};
UINT8 wkey128[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x01, 0x02, 0x03, 0x04, 0, 0, 0, 0};

DRIVER_CONFIG DriverConfigs[] = {
  {_T("null"), _T("COB/null.cob"), 0, },

  /* NB: Start this before com1, else trouble.  Wish I knew.
   */
  {_T("com3"), _T("COB/sa.cob"), DEVICE_FLAGS_INTERRUPTS, 0x80050000, 17, NULL, NULL, 38400, },
#if 0
  {_T("com2"), _T("COB/sa.cob"), DEVICE_FLAGS_INTERRUPTS, 0x80030000, 16, NULL, NULL, 38400, },
#endif
  {_T("com1"), _T("COB/sa.cob"), DEVICE_FLAGS_INTERRUPTS, 0x80010000, 15, NULL, NULL, 38400, },

  {_T("udc"), _T("COB/udc.cob"), DEVICE_FLAGS_INTERRUPTS, 0x80000000, 13, NULL, },
#if 0 /* alternate USB behaviours, demo only */
  {_T("com4"), _T("COB/usbdserial.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0, _T("udc"), NULL, },
  {_T("dkeybd"), _T("COB/usbdkeybd.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0, _T("udc"), NULL, },
#endif
  {_T("dmouse"), _T("COB/usbdmouse.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0, _T("udc"), NULL, },

  {_T("ucb"), _T("COB/ucb_cerf.cob"), DEVICE_FLAGS_INTERRUPTS, 0x80060000, 18, NULL, NULL, 0x90060000, },

#if USE_SERPLEX
  /* Console, hostfs and sernet share one serial port. Run serplexd.exe on NT side. */
  {_T("serplex6a"), _T("COB/serplex.cob"), DEVICE_FLAGS_MANUAL_START | DEVICE_FLAGS_NO_THREAD, 0, 0,
              SERPLEXLINE, NULL, 0, FSSerplexAddr, },
  {_T("srfs"), _T("COB/hostfs.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("serplex6a"), },

  {_T("serplex6c"), _T("COB/serplex.cob"), DEVICE_FLAGS_MANUAL_START | DEVICE_FLAGS_NO_THREAD, 0, 0,
              SERPLEXLINE, NULL, 0, CONSerplexAddr, },
#endif

  {_T("cs0"), _T("COB/cs8900.cob"), DEVICE_FLAGS_NET_DRIVER|DEVICE_FLAGS_INTERRUPTS, 0x08000300, 47, },
#if 1
  {_T("cw0"),  _T("COB/cw10.cob"),  DEVICE_FLAGS_NET_DRIVER|DEVICE_FLAGS_INTERRUPTS, 0x20000000, 43, 
    name /* name */, ssid /* ssid */, 0x28000000 /* AttributeBase */,
    4 /* portType = 802.11 IBSS*/, 0, }, 
#else
  /* WEP doesnt work yet */  
  {_T("cw0"),  _T("COB/cw10.cob"),  DEVICE_FLAGS_NET_DRIVER|DEVICE_FLAGS_INTERRUPTS, 0x20000000, 43, 
    name /* name */, ssid /* ssid */, 0x28000000 /* AttributeBase */,
      4 /* portType = 802.11 IBSS */, (PTR) wkey128, }, 
#endif
  {NULL,}    
};
