/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <mmmacros.h>
#include <fred.h>
#include <x86_cpu.h>
#include <_dosx.h>
#include <_cons.h>
#include <base/cons.h>

int stack[1024];
int *bstack;

/* This needs to be somewhere ... XXX */
const _TCHAR *FIRST_IMAGE_NAME = _T("tzk.cob");

extern void DisableTimers(), EnableTimers();

/* The end of the world as we know it.
 */
__declspec(naked) void TheEnd(void)
{
    /* No more interrupts for us.
     */
    __asm cli;

    DisableTimers();

    /* Switch to initial stack, turn interrupts off (sanity),
     * abide by linkage convention (in main), and return.
     */
    __asm {
        mov     esp,bstack;
        cli;
        pop     ebp;
        ret     0;
    }
}

/* The big bang.
 *
 * Startup(16bit) code enters here, in protected mode, 32bit flat segments.
 * We perform the machdep initialization needed before the MI code can take
 * over and get things rolling.
 */
__declspec(naked) void main(PDOSX_INTERFACE pIface)
{
    /* Make linkage explicit, see above
     */
    __asm {
        push    ebp;
        mov     ebp,esp;
    }

    /* Make it that we can callback to DOS/BIOS
     */
    InitializeDosx(pIface);

    /* For more complicated stuff we need a bigger stack.
     */
    __asm {
        mov     bstack,esp;
        mov     esp, offset stack + 1024*4 - 4;
    }

#if !defined(USE_OLD_PIC)
    DBG(("Fixing RelocationBase from %x to %x XXX\n",
         ((PDOSX_INTERFACE) DosxPointer())->RelocationBase, 0x20000));

    /* Turns out the RelocationBase is incorrect. Fix it manually XXX */
    ((PDOSX_INTERFACE) DosxPointer())->RelocationBase = 0x20000;
#endif

    /* Enable A20 address line to make memory map reasonable */
    //DBG(("Enable A20 line\n"));
    GateA20(TRUE);

    /* Initialize interrupt dispatching first.
     */
    IdtCreate();
    (void) PicCreate(); /* to call BIOS early on */

    /* Machine-independent initialization and go.
     */
    BaseInit();

    /* Wont return, but just in case...
     */
    __asm {
        jmp     TheEnd;
    }
}
