/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>

/* VM mappings are setup 1:1 with this protection
 */
#define IO_PT_FLAGS 0xc02       /* uncachable, write-through, RW all (I/O!) */

/* Anything else is described in the table below
 */
typedef struct _AddrMapEntry {
    ADDRESS     Physical;
    ADDRESS     Virtual;
    ADDR_SIZE   Size;
    UINT        Flags;
} AddrMapEntry;

AddrMapEntry AddrMap[] = {
/*  Physical    Virtual     Size        Flags */
    /* I/O etc. */
    {0x08000000, 0x08000000, 0x00100000, IO_PT_FLAGS}, /* cs8900 */
    {0x20000000, 0x20000000, 0x20000000, IO_PT_FLAGS}, /* PCMCIA */
    {0x40000000, 0x40000000, 0x10000000, IO_PT_FLAGS}, /* variable i/o */
    {0x80000000, 0x80000000, 0x40000000, IO_PT_FLAGS}, /* on chip regs */
    /* DRAM */
    {0xC0000000, 0x00000000, 0x01000000, 0x0C0E}, /* to RAM, hide all FLASH */
    /* Expose the FLASH (r/o) */
    {0x00000000, 0x50000000, 0x01000000, 0x000A}, /* 16M Flash */
    {0x00000000, 0x51000000, 0x01000000, IO_PT_FLAGS}, /* for programming */
    /* Expose RAM */
    {0xC0000000, 0xC0000000, 0x00800000, 0x0C0E}, /* 8M RAM */
    /* override */
    {0xE0000000, 0xE0000000, 0x08000000, 0x0C0E}  /* 128M Cache flush */
};
#define nAddrMap (sizeof AddrMap / sizeof AddrMap[0])

/* First level page table, physical address
 * Carved from the top of the SDRAM block
 */
#define PageTableStartAddress 0xC07FC000
#define PageTableBase  ((UINT32 *)(PageTableStartAddress))
void EnableMMU(UINT32 *);

/* Set up a minimal set of page tables according to the AddrMap table.
 * Use 1M sections for simplicity.
 * Assumes we are running with MMU off.
 */
void PageTableInit(void)
{
    int i, j;
    ADDRESS Physical;
    UINT32 *PTE, Flags;

    /* Default initialization for the PTEs.
     */
    PTE = PageTableBase;
    Physical = 0;
    for (i = 0; i < (16*1024/4); i++) {
#if 1
        *PTE++ = 0;             /* invalid */
#else
        *PTE++ = Physical | IO_PT_FLAGS;
        Physical += 0x00100000;
#endif
    }

    /*
     * Map 1M sections according to the AddrMap information.
     */
    for (i = 0; i < nAddrMap; i++) {

        Physical = AddrMap[i].Physical;

        /* Compute starting entry
         */
        PTE = PageTableBase + (AddrMap[i].Virtual >> 20);

        /* Fill them in, one 1MB section at a time
         */
        Flags = AddrMap[i].Flags;
        j = AddrMap[i].Size >> 20;
        for (; j > 0; --j) {
            *PTE++ = Physical | Flags;
            Physical += 0x00100000;
        }        
    }

    /* Ready to rock&roll
     */
    EnableMMU(PageTableBase);

}

/* Create the system heap.  Left to machdep code because messy otherwise.
 * The heap should account for all available memory, carved out of memory
 * that is already used or unavailable (like the 640K-1meg hole on PCs).
 * It does not have to account for all the memory in the system.
 * Returns a PIHEAP pointer.
 */

PIHEAP MachineHeapCreate( void )
{
    PIHEAP pIHeap;
    ADDRESS MemBase = (ADDRESS) _end;

#define MemTop  (PageTableStartAddress)
#define MemSize (MemTop - MemBase)

    pIHeap = CreateHeapFrom(MemBase, 0, MemSize, MemSize);

    /* BUGBUG We dont account for
     * 1- The base itself (0xc0000000.._end)
     * 2- The page tables (0xc07fc000..0xc0800000)
     */
    return pIHeap;
}

extern void DisableMMU(void);

void TheEnd(void)
{
    void (*Reset)(void) = (void (*)())0x0;

    /* Flush caches, turn off the MMU, jump at 0
     */
    FlushCache();
    DisableMMU();
    printf("MMU disabled, jumping to FLASH reset (seeya!)\n");
    for(;;)
        Reset();
}

#define verify 0
#if verify
#include "_timerSA.h"
extern void PrintIrqCounts(void);
#endif
/* .. */
extern void ArmIdle(ADDRESS xx, ADDRESS UncachedAddress);
static volatile int x;
void ArmMachineIdle(ADDRESS Arg)
{
#if verify
    UINT32 t0, t1;
    static INT32 maxsleep = -1;

    t0 = TheTimer->Count;
    ArmIdle((ADDRESS) 0,0x80000000);
    t1 = TheTimer->Count;
    if ((t1 - t0) > maxsleep) {
        maxsleep = t1 - t0;
        printf("{%d}",maxsleep);
        PrintIrqCounts();
    }
#else
    ArmIdle((ADDRESS) 0,0x80000000);
#endif
    /* Mistery why this is needed, 
     * much as I can tell its yet another Intel bug
     */
    x++;
}
