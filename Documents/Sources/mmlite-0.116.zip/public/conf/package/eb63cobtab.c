/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <loaders/cobtab.h>

extern PIUNKNOWN DriverCfgCobMain(void);
extern PIUNKNOWN SerialCobMain(void);
extern PIUNKNOWN NullCobMain(void);
extern PIUNKNOWN Db161CobMain(void);
extern PIUNKNOWN Bv16CobMain(void);
extern PIUNKNOWN SerplexCobMain(void);
extern PIUNKNOWN Sl811CobMain(void);
extern PIUNKNOWN UsbHubCobMain(void);
extern PIUNKNOWN PnpCobMain(void);
extern PIUNKNOWN UsbStorCobMain(void);
extern PIUNKNOWN gianofbCobMain(void);

const struct PRECOB ThePreCobTable[] = {
  {_T("drivercfg.cob"), DriverCfgCobMain },
  {_T("drivers.cob"), DriversCobMain },
  {_T("eb63usart.cob"), SerialCobMain },
  {_T("serplex.cob"), SerplexCobMain },
#if 0
  {_T("sl811.cob"), Sl811CobMain },
  {_T("usbhub.cob"), UsbHubCobMain },
  {_T("pnp.cob"), PnpCobMain },
  {_T("usbstor.cob"), UsbStorCobMain },
  {_T("null.cob"), NullCobMain },
  {_T("db161.cob"), Db161CobMain },
  {_T("bv16.cob"), Bv16CobMain },
#endif
#if defined(mips)
  {_T("gianofb.cob"), gianofbCobMain },
#endif
  {0,0}
};
