/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmhal.h>

extern unsigned char dgetc( BOOL DoEcho );

#ifdef TIGON
extern INT dputchar( INT c);
#define __HAS_MACHINE_PUTCHAR 1

#else
extern void DCPutChar( UINT8 c );
#define __HAS_MACHINE_PUTS 1

BOOL DebuggerAttached;

PRIVATE void OutputString(const BYTE *s, int len)
{
    char ch;

    /* Sanity
     */
    if (len == 0)
        return;

    /* If no debugger just print
     */
    if (!DebuggerAttached) {
        if (len < 0) len = ((UINT)~0 >> 1);
        while (s && ((ch = *s++) != 0)) {
            DCPutChar(ch);
            if (--len == 0) return;
        }
        return;
    }
    DebuggerOutputString(s, len);
}

int puts(const char *s)
{
    OutputString((const BYTE *)s, -1);
    return 0;
}


int DCGetchar( BOOL DoEcho )
{
    int c;

    do {
        c = dgetc(DoEcho);
    } while (c == '\r');    /* zap returns */
    return c;
}

#endif


/* Debug console IFile */

PRIVATE struct IFileVtbl DebugConsoleVtbl;

typedef struct {
    const struct IFileVtbl *v;
    UINT    RefCnt;
} *PDCONS;

#define pDC(_t_) ((PDCONS)(_t_))

PRIVATE PDCONS DCNew(void)
{
    PDCONS File;

    File = CurrentHeap()->v->Alloc(CurrentHeap(),
                                   HEAP_ZERO_MEMORY,
                                   sizeof(*File),
                                   0);
    if (!File)
      return NULL;

    File->v = &DebugConsoleVtbl;
    File->RefCnt = 1;

    return File;
}

PRIVATE void DCDestroy(PDCONS File)
{
    CurrentHeap()->v->Free(CurrentHeap(), 0, File);
}

PRIVATE SCODE MCT DCQueryInterface(PIFILE pThis, REFIID pIid, void* *ppNew)
{
    return GenericQueryInterface((PIUNKNOWN) pThis, pIid, ppNew, &IID_IFile);
}

PRIVATE UINT MCT DCAddRef(PIFILE pThis)
{
    PDCONS File = pDC(pThis);

    return AtomicInc(&File->RefCnt);
}

PRIVATE UINT MCT DCRelease(PIFILE pThis)
{
    PDCONS File = pDC(pThis);
    UINT Refs;

    Refs = AtomicDec(&File->RefCnt);
    if (Refs == 0)
      DCDestroy(File);

    return Refs;
}

/*
 * Read from a file
 */
PRIVATE SCODE MCT
DCReadAt(PIFILE pThis, UINT64 Position, 
                                 BYTE *Buffer, UINT ByteCount, PUINT pSizeRead)
{
#ifdef TIGON
    UnusedParameter(pThis);
    UnusedParameter(Position);
    UnusedParameter(Buffer);
    UnusedParameter(ByteCount);
    UnusedParameter(pSizeRead);

    return E_NOT_IMPLEMENTED;
#else
    int c;

    UnusedParameter(pThis);
    UnusedParameter(Position);

#ifdef _UNICODE
    if (ByteCount < 2)
        return E_INVALID_PARAMETER;
#else
    if (ByteCount < 1)
        return E_INVALID_PARAMETER;
#endif

    c = DCGetchar(FALSE);

    if (c == -1) { /* EOF */
        if (pSizeRead)
            *pSizeRead = 0;
        return S_FALSE;
    } else {
#ifdef _UNICODE
        if (pSizeRead)
            *pSizeRead = 2;
        *(wchar_t &)Buffer = c;
#else
        if (pSizeRead)
            *pSizeRead = 1;
        *Buffer = (char) c;
#endif
        return S_OK;
    }
#endif
}


/*
 * Write to a file
 */
PRIVATE SCODE MCT
DCWriteAt(PIFILE pThis, UINT64 Position, 
               const BYTE *Buffer, UINT ByteCount, PUINT pSizeWritten)
{
    UnusedParameter(pThis);
    UnusedParameter(Position);

#ifdef _UNICODE
    --- must convert to ascii ---;
#endif

    if (pSizeWritten)
      *pSizeWritten = ByteCount;

#ifdef TIGON
    for ( ; ByteCount > 0; Buffer++, ByteCount--)
      dputchar(*Buffer);
#else
    OutputString(Buffer, ByteCount);
#endif

    return S_OK;
}

/* Get/Set a file's size
 */
PRIVATE SCODE MCT DCGetSize(PIFILE pThis, PUINT64 pSize)
{
    UnusedParameter(pThis);
    UnusedParameter(pSize);

    return E_NOT_IMPLEMENTED;
}

PRIVATE SCODE MCT DCSetSize(PIFILE pThis, UINT64 Size)
{
    UnusedParameter(pThis);
    UnusedParameter(Size);

    return E_NOT_IMPLEMENTED;
}

PRIVATE struct IFileVtbl DebugConsoleVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    DCQueryInterface, 
    DCAddRef, 
    DCRelease, 
    DCReadAt, 
    DCWriteAt, 
    DCSetSize, 
    DCGetSize
};

SCODE InitDebugConsole(void)
{
    PIFILE File = (PIFILE) DCNew();
    PINAMESPACE ns = CurrentNameSpace();
    SCODE sc;

    if (!File)
      return E_NOT_ENOUGH_MEMORY;

    sc = ns->v->Register(ns, _TEXT("stdin"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = ns->v->Register(ns, _TEXT("stdout"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = ns->v->Register(ns, _TEXT("stderr"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    return S_OK;

  Error:
    return sc;
}
