/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _MMLITE_H_
#define _MMLITE_H_

/* Minimal support for -analyze */
#include <sal.h>

/* ISO C headers that are needed for the definitions below and baseif.h */
#include <stdarg.h>
#include <tchar.h>

#define __NEEDS_EXTERN_C 1
#define __NEEDS_OFFSETOF 1
#define __NEEDS_NULL 1
#define __NEEDS_ROUND 1
#include <__defs.h>

/* Machine dependent types */
#include <mmlite_md.h>

/* 64 bit arithmetic macros for the benefit of compilers that don't */
#include <base/int64.h>

#if !defined(_IMPORT_WINDOWS_H_) && !defined(DebugBreak)
#ifdef __DebugBreak
#define DebugBreak() __DebugBreak() /* Sometimes defined in mmlite_md.h */
#else
EXTERN_C void DebugBreak(void);
#endif
#endif

/* Scalar type that holds a pointer. The register size, same as UINT but
 * makes it explicit that something is an address.
 * TM1 needs the definition for TM_MACHINE_INFO so we allow overriding it.
 */
#if !defined(__MACHDEP_ADDRESS_DEFINITION)
typedef UINT ADDRESS;
typedef UINT ADDR_SIZE;
#endif

#ifndef INLINE
#define INLINE  __inline
#endif

#define UnusedParameter(x) x=x
#define PRIVATE static
#define PUBLIC

#ifndef _MSC_VER
#define __cdecl
#endif
#define RTLCALLTYPE __cdecl
#define METHODCALLTYPE __cdecl
#define MCT METHODCALLTYPE
#define THREAD_LINKAGE __cdecl
#define MODENTRY __cdecl

/* Optimization support */
#if defined(__TCS__) && !defined(__cplusplus)
#define RESTRICT __restrict__
#else
#define RESTRICT
#endif

/* Support for packing directives in different compilers */
#if defined(_MSC_VER) || defined(h8) || defined(__TCS__) || defined(ecog) || defined(__ADSPBLACKFIN__)
#define _PACKED  /* cant do, sigh */
#elif defined(__GNUC__)
#define _PACKED __attribute__ ((__packed__))
#else
#define _PACKED __packed
#endif

typedef INT8 *PINT8;
typedef UINT8 *PUINT8;

typedef INT16 *PINT16;
typedef UINT16 *PUINT16;

typedef INT32 *PINT32;
typedef UINT32 *PUINT32;

typedef INT64 *PINT64;
typedef UINT64 *PUINT64;

typedef void *PTR;
typedef INT32 SCODE;/* SCODEs must be signed values (macros depend on it) */

typedef UINT *PUINT;
typedef UINT BOOL, *PBOOL;
typedef UINT8 BYTE, *PBYTE;

#define CONST_VTBL const

#if defined(__cplusplus)
#define REFIID      const IID &
#else
#define REFIID      const struct IID * /*const */
#endif

#if defined(__GNUC__) || defined(ADS)
/* g++ expects two dummy words at the beginning of a v-table */
#define __VTABLE_COMPATIBILITY_FILLER_DECLARATION UINT __Filler0, __Filler1;
#define __VTABLE_COMPATIBILITY_FILLER_INITIALIZER 0,0,
#else
#define __VTABLE_COMPATIBILITY_FILLER_DECLARATION
#define __VTABLE_COMPATIBILITY_FILLER_INITIALIZER
#endif

/* Virtual memory basic types */
typedef UINT64 VM_OFFSET;
typedef UINT64 VM_SIZE;

/*** Error code macros. ***/
#ifndef SUCCEEDED
#define SUCCEEDED(u)    ((SCODE)(u) >= 0)
#endif

#ifndef FAILED
#define FAILED(u)       ((SCODE)(u) < 0)
#endif

#if _UINTSIZE == 16
#define STATUS_WIN32_ERROR(u) ((SCODE)((u)|0xF000))
//#define STATUS_OLE32_ERROR(u) ((SCODE)((u)|0xC000))
#define STATUS_MMLITE_ERROR(u) ((SCODE)((u)|0xE000))
//#define STATUS_MMLITE_WARN(u)  ((SCODE)((u)|0x6000))
#else
#define STATUS_WIN32_ERROR(u) ((SCODE)((u)|0x80070000))
//#define STATUS_OLE32_ERROR(u) ((SCODE)((u)|0x80040000))
#define STATUS_MMLITE_ERROR(u) ((SCODE)((u)|0x80060000))
//#define STATUS_MMLITE_WARN(u)  ((SCODE)((u)|0x00060000))
#endif

#ifndef NO_ERROR
#define NO_ERROR 0
#endif

/* Boolean types. */

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

typedef void (RTLCALLTYPE  * STRINGER)(void *Where, _TCHAR *String);

typedef struct _CXTINFO CXTINFO, *PCXTINFO;

#define DLL_PROCESS_ATTACH 1
#define DLL_PROCESS_DETACH 0

typedef INT (MODENTRY *MODULEENTRY)(void *);

/* Disable some Visual C -W4 warnings that are too annoying */
#if defined(_MSC_VER) && i386
#pragma warning(disable:4100)   /* unreferenced formal parameter */
#pragma warning(disable:4127)   /* conditional expression is constant */
/* Auto-generated operators on packed structs. This only applies to C++ */
#pragma warning(disable:4510)
#pragma warning(disable:4512)
#pragma warning(disable:4610)
#pragma warning(disable:4214)/* bitfield other than int */
#endif

/* Include some generated interfaces */
#include <mmhal.h>
#include "baseif.h"
#include "basertlif.h"
#include "utilif.h"

/*** TIME ***/
/*typedef INT64 TIME;*/
/*typedef TIME  *PTIME;*/

/* Time is a 64-bit value representing the number of 100-nanosecond intervals
 * since January 1, 1601 GMT.  Negative values are interpreted as being
 * relative to the current time by some interfaces -- positive as absolute.
 */
#define TIME_RELATIVE(time) (-(time))
#define TIME_SECONDS(secs)  (((secs) * (1000*1000*10)))
#define TIME_MILLIS(millis) (((millis) * (1000*10)))
#define TIME_MICROS(micros) (((micros) * (10)))

#if !defined(__NO_BUILTIN_INT64)
#define TIME_FOREVER       ((TIME)(((UINT64)1 << 63) - 1))
#else
EXTERN_C const TIME TIME_FOREVER;
#endif
#define TIME_ORIGIN INT64_ZERO

PIUNKNOWN MODENTRY CobMain(void);

/* XXX These will go away */
typedef struct IDma *PIDMA;

#define GetCurrentModule(_ppIModule_) \
    GetModuleContainsAddr(GetPC(), _ppIModule_)
#define RemoveDevice(_dev_,_irq_) (void) AddDevice(_dev_,NULL,0,_irq_,NULL)

#ifdef _DEBUG
#define HEAP_DEBUG_NAME(_s_) ((ADDRESS)(_s_) << HEAP_FLAGS_SHIFT)
#else
#define HEAP_DEBUG_NAME(_s_) 0
#endif

#ifdef _UNICODE
/* Convenience function for binding and then QueryInterface'ing */
/* Latin1 version with _UNICODE, conversion can be a hassle ... */
EXTERN_C SCODE BindToObjectA(PINAMESPACE pINameSpace, const char * FileName, 
                   UINT Flags, REFIID Iid, /*out*/ void **ppObject);
#else
#define BindToObjectA(_ns_,_n_,_f_,_i_,_p_) BindToObject(_ns_,_n_,_f_,_i_,_p_)
#endif

/*** Unicode printing ***/

#if defined(_UNICODE)
#define UNICODE_BYTE_ORDER_MARK 0xFEFF
#define UNICODE_NOT_A_CHARACTER 0xFFFF

/*
 * A StrFormat() format string is normally a string of TCHAR's (which are
 * actually wchar_t's in the UNICODE case).  Alternatively, a pointer to a
 * STRFORMAT_ESCAPE structure may be passed instead of a format string, which
 * allows ASCII format strings to be passed indirectly and used.  This
 * case is detected by passing UNICODE_NOT_A_CHARACTER as the flag value.
 */
typedef struct _STRFORMAT_ESCAPE 
{
    wchar_t flag; /* Pass UNICODE_NOT_A_CHARACTER for ASCII format string */
    const char *ptr;  /* Contains pointer to ASCII format string */

} STRFORMAT_ESCAPE;

#else /* !_UNICODE */

/* The opposite is true when _UNICODE is not defined
 */
#define ASCII_NOT_A_CHARACTER   0x7F

typedef struct _STRFORMAT_ESCAPE 
{
    char flag;  /* Pass ASCII_NOT_A_CHARACTER for a unicode format string */
    const char *ptr;  /* Contains pointer to ASCII format string */

} STRFORMAT_ESCAPE;
#endif /* _UNICODE */

/* PATH macros. */

#define PATH_SEPARATOR1 _TEXT('/')
#define PATH_SEPARATOR2 _TEXT('\\')
#define IS_PATH_SEPARATOR(x) ((x) == PATH_SEPARATOR1 || (x) == PATH_SEPARATOR2)
#define STR_PATH_SEPARATOR _TEXT("/")
#define STR_PATH_SEPARATOR_SET _TEXT("/\\")

#endif  /* _MMLITE_H_ */
