/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __list_h__
#define __list_h__

/* Generic doubly linked circular list node
 */
typedef struct _LISTNODE LISTNODE,*PLISTNODE;

struct _LISTNODE {
    PLISTNODE pPrev;  /* Before this node                         */
    PLISTNODE pNext;  /* After this node                          */
};

PLISTNODE ListInsert(PLISTNODE pNode, PLISTNODE pNew);
PLISTNODE ListRemove(PLISTNODE pNode);
#define ListInitialize(_l_) (void) ListInsert( NULL, &(_l_))
#endif
