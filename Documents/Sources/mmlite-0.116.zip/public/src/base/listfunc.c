/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define OPTIMIZE        /* enable Base.h optimizations, since we're the "base" */

#include <mmlite.h>
#include <base/list.h>

/* Optionally let an architecture provide specially optimized
 * versions of these functions.
 */
#if !defined(__MACHDEP_LISTFUNC)

/* Insert new node pNew after an existing node pNode.
 * Returns pointer to the new node.
 */
PLISTNODE ListInsert(PLISTNODE pNode, PLISTNODE pNew)
{
    if (pNode == NULL)
        pNew->pNext = pNew->pPrev = pNew;
    else {
        pNew->pNext = pNode->pNext;
        pNew->pNext->pPrev = pNew;
        pNode->pNext = pNew;
        pNew->pPrev = pNode;
    }
    return pNew;
}

/* Remove a node from a list.
 * Returns pointer to the next node; NULL if this was the only node.
 */
PLISTNODE ListRemove(PLISTNODE pNode)
{
    PLISTNODE pNext;

    if ((pNext = pNode->pNext) == pNode)
        return NULL;

    pNext->pPrev = pNode->pPrev;
    pNode->pPrev->pNext = pNext;
    pNode->pPrev = pNode->pNext = pNode;
    return pNext;
}

#if 0 /* Moved to atomic.c */
/* Atomically insert at the front of a singly-linked list.
 */
void AtomicLIFOInsert(PLISTNODE RESTRICT pList, PLISTNODE RESTRICT pNode)
{
 again:
    pNode->pPrev = pList->pPrev;
    if (!AtomicCmpAndSwap((PUINT)&pList->pPrev,
                          (UINT) pNode->pPrev,
                          (UINT) pNode))
        goto again;
}

/* Atomically remove from the front of a singly-linked list.
 * Returns the element removed, or NULL if empty.
 */
PLISTNODE AtomicLIFORemove(PLISTNODE pList)
{
    PLISTNODE pNode;

 again:
    pNode = pList->pPrev;
    if ((pNode != NULL) &&
        ! AtomicCmpAndSwap((PUINT)&pList->pPrev,
                           (UINT) pNode,
                           (UINT) pNode->pPrev))
        goto again;

    return pNode;
}
#endif
#endif
