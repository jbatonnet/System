/* Copyright (c) Microsoft Corporation. All rights reserved. */
//#include "file.h"

typedef struct  {
    PIFILE pFile;
    INT64 SeekPos;
} *FILE_HANDLE;

#define INVALID_FILE_HANDLE NULL

/* Get an IFile object from a string
 */
static PIFILE BindToSomeIFile( PINAMESPACE pIName, const _TCHAR * FileName, UINT Flags)
{
    SCODE Sc;
    PIUNKNOWN pUnk;
    PIFILE pFile;

    if (pIName == NULL)
        return NULL;

    pUnk = NULL;
    Sc = pIName->v->Bind(pIName, FileName, Flags, &pUnk);

    if (!FAILED(Sc)) {

        Sc = pUnk->v->QueryInterface(pUnk,&IID_IFile,(void**)&pFile);

        pUnk->v->Release(pUnk);

        if (!FAILED(Sc))
            return pFile;
    }

    return NULL;
}



static UINT _Seek( FILE_HANDLE File, UINT Position)
{
    /* Only does seek set */
    Int32ToInt64(File->SeekPos,Position);

    return (INT) Position;
}

static FILE_HANDLE _Open( const _TCHAR * FileName, UINT Mode)
{
    PIFILE pFile;
    FILE_HANDLE File;
    PIHEAP pIHeap = CurrentHeap();

    if (Mode != 0x1)
        return INVALID_FILE_HANDLE;

    pFile = BindToSomeIFile( GetImageNameSpace(), FileName, NAME_SPACE_READ);
    if (pFile == NULL)
        return INVALID_FILE_HANDLE;

    File = pIHeap->v->Alloc(pIHeap,0,sizeof *File, 0);
    File->pFile = pFile;
    Int64FromHighAndLow(File->SeekPos,0,0);

    return File;
}

static INT _Read( FILE_HANDLE File, BYTE *Buffer, UINT nBytes)
{
    PIFILE pFile = File->pFile;
    INT64 Pos, Btr64;
    SCODE Sc;
    UINT BytesThisRound;
    int BytesRead = 0;

    Pos = File->SeekPos;

    do {
        Sc = pFile->v->ReadAt( pFile, Int64ToUint64(Pos), Buffer, nBytes, &BytesThisRound);
        if (FAILED(Sc))
            goto Exit;

        if (BytesThisRound == 0 && Sc == S_FALSE)
            return BytesRead;           /* EOF */

        Int32ToInt64(Btr64,BytesThisRound);
        Pos = Int64Add(Pos,Btr64);
        File->SeekPos = Pos;
        BytesRead += BytesThisRound;
        Buffer += BytesThisRound;
        nBytes -= BytesThisRound;

    } while (nBytes > 0);

 Exit:
    return BytesRead ? BytesRead : -1;
}

static INT _Close( FILE_HANDLE File)
{
    PIFILE pFile = File->pFile;
    UINT Cnt = pFile->v->Release(pFile);

    if (Cnt == 0) {
        PIHEAP pIHeap = CurrentHeap();
        pIHeap->v->Free(pIHeap,0,File);
    }
    return 0;
}

static INT _Stat( FILE_HANDLE File)
{
    UINT64 Size;
    PIFILE pFile;

    pFile = File->pFile;
    if (FAILED(pFile->v->GetSize( pFile, &Size)))
        return -1;

    return Int64ToInt32(Size);
}
