/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* --------------------------------------------------------------------------
 *
 * Module:
 *
 *    mouse_hw.h
 *
 * Purpose:
 *
 *    MMLite header file for mouse devices.
 *
 * Author:
 *    A. Forin (sandrof)
 *
 * --------------------------------------------------------------------------
 */

#ifndef __MOUSE_HW_
#define __MOUSE_HW_ 1


/* A mouse report indicates the state of
 * the mouse at the time of the report.
 * Note these are *not* state-change-events.
 */
typedef struct {

    /* Coordinates are absolute.
     * For 2D mice, z==0
     */
    UINT16      LastX;
    UINT16      LastY;
    UINT16      LastZ;

    /* State of mouse buttons (1==Down)
     * See below for encodings.
     */
    UINT16      RawButtons;

    /* Time at which sample was received,
     * or artificially generated.
     */
    TIME        ReportTime;

} MOUSE_INPUT_DATA, *PMOUSE_INPUT_DATA;

/* Button state encodings.
 */
#define MOUSE_BUTTON_1_DOWN   0x1
#define MOUSE_BUTTON_2_DOWN   0x2
#define MOUSE_BUTTON_3_DOWN   0x4
#define MOUSE_BUTTON_4_DOWN   0x8

/* And so forth for all possible 16 buttons.
 * What is left-middle-right is questionable, but.
 */
#define MOUSE_RIGHT_BUTTON_DOWN  MOUSE_BUTTON_1_DOWN
#define MOUSE_LEFT_BUTTON_DOWN   MOUSE_BUTTON_2_DOWN
#define MOUSE_MIDDLE_BUTTON_DOWN MOUSE_BUTTON_3_DOWN

/* Mouse hardware types/connections
 */

#define MOUSE_UNKNOWN_INPUT             0
#define MOUSE_SERIAL_INPUT              1
#define MOUSE_BUSMOUSE_INPUT            2
#define MOUSE_I8042_INPUT               3

#define MOUSE_UNKNOWN_PROTOCOL          0       /* probe it */
#define MOUSE_PS2_PROTOCOL              1
#define MOUSE_MSPLUS_PROTOCOL           2
#define MOUSE_BALLPT_PROTOCOL           3
#define MOUSE_LOGITECH_S_PROTOCOL       4
#define MOUSE_MAX_PROTOCOL              5

#define MOUSE_TYPE_IS(_in_,_pr_)        ((UINT32)((_in_ << 16) | _pr_))
#define MOUSE_INPUT_IS(_m_)             (((_m_) >> 16) & 0xffff)
#define MOUSE_PROTOCOL_IS(_m_)          ((_m_) & 0xffff)

/* Nt-compat defines
 */
#define MOUSE_INPORT_HARDWARE    MOUSE_TYPE_IS(MOUSE_BUSMOUSE_INPUT,MOUSE_PS2_PROTOCOL)
#define MOUSE_I8042_HARDWARE     MOUSE_TYPE_IS(MOUSE_I8042_INPUT,MOUSE_PS2_PROTOCOL)
#define MOUSE_SERIAL_HARDWARE    MOUSE_TYPE_IS(MOUSE_SERIAL_INPUT,MOUSE_UNKNOWN_PROTOCOL)
#define BALLPOINT_I8042_HARDWARE  MOUSE_TYPE_IS(MOUSE_I8042_INPUT,MOUSE_BALLPT_PROTOCOL)
#define BALLPOINT_SERIAL_HARDWARE MOUSE_TYPE_IS(MOUSE_SERIAL_INPUT,MOUSE_BALLPT_PROTOCOL)

#endif /* __MOUSE_HW__ */
