/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <mmmacros.h>
#include <tchar.h>
#include <loaders/cobtab.h>
#include <base/cons.h>

extern PIUNKNOWN Db161CobMain(void);

extern PIUNKNOWN HostfsCobMain(void);
extern PIUNKNOWN SerplexCobMain(void);

const struct PRECOB ThePreCobTable[] = {
    EB63DS_COBS
    {_T("eb63usart.cob"), SerialCobMain },
    {_T("db161.cob"), Db161CobMain },
    PRIVATE_SOAP_COBS
    {0,0}
};

/* Select root "fs" file system */
PINAMESPACE BoardInitRomFs(void);
PINAMESPACE BoardInitHostFs(void);

PINAMESPACE BoardInitFileSystem(void)
{
#ifdef _MINIMIZE
    return NULL;
#else
    /* Use RomFs with eb63big: it's a flashed standalone image */
    PINAMESPACE ns = BoardInitRomFs();
    if (!ns)                    /* not there */
        ns = BoardInitHostFs(); /* use hostfs instead */
    return ns;
#endif
}

#if 1
SCODE FirstApp(const _TCHAR *Args)
{
    METHOD_DECLARE_NOTHIS(eb63ds, FirstThread);
    PINAMESPACE ns = CurrentNameSpace();
    PIPROGRAM prog = NULL;

    sc = BindToObject(ns, _T("COB/protocol.cob"), NAME_SPACE_READ,
                      &IID_IProgram, (void **) &prog);
    CHECKSC("load network stack");
    sc = prog->v->Main(prog, "start");
    CHECKSC("protocol start");
    sc = prog->v->Main(prog, "dhcp");
    CHECKSC("protocol dhcp");
    sc = prog->v->Main(prog, "lo0 127.0.0.1");
    CHECKSC("protocol lo0");
    RELEASE_NULL(prog);

    sc = BindToObject(ns, _T("COB/http.cob"), NAME_SPACE_READ,
                      &IID_IProgram, (void **) &prog);
    CHECKSC("load http.cob");

    sc = prog->v->Main(prog, "http");
    CHECKSC("start http server on port 80");
    RELEASE_NULL(prog);

    sc = BindToObject(ns,_T("COB/cimdb.cob"), NAME_SPACE_READ,
                  &IID_IProgram, (void **) &prog);
    CHECKSC("load cimdb");
    sc = prog->v->Main(prog,_T("-a 172.31.40.217"));
    CHECKSC("cimdb start");
    RELEASE_NULL(prog);

    sc = BindToObject(ns,_T("COB/dssp.cob"), NAME_SPACE_READ,
                  &IID_IProgram, (void **) &prog);
    CHECKSC("load dssp");
    sc = prog->v->Main(prog,_T(""));
    CHECKSC("dssp start");
    RELEASE_NULL(prog);

METHOD_CLEANUP;
    RELEASE(prog);
    SleepUntil(TIME_FOREVER);
    return sc;
}
#endif
