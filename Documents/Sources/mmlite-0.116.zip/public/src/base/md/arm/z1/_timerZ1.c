/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* PREFACE -- A word about crystals.
 *
 * In MMLite (and in Win32) TIME is a 63 bit value, indicating the
 * number of TIME units since the start of the Gregorian calendar,
 * in January 1600. The high bit is used to represent relative-time,
 * meaning a point in the future which is NN TIME units from 'now'.
 * The 'unit' of TIME is 100 nanoseconds, aka 10 MHz.
 *
 * In a digital computer the timing device (aka 'timer') is built
 * manipulating some base signal (CLOCK), usually by division by a constant
 * which is most likely a power of 2. Regardless of the specific
 * transformation (multiplication/division), the properties of the
 * derived signal are circa the same as the original signal.  The accuracy
 * is based on the physical properties (cut, impurities, etc etc)
 * of the device used to generate the CLOCK signal.  We shall call
 * this device a 'crystal', even though one might use a simple RC
 * circuit to create a rough oscillator.
 * The crystal shall be defined by (a) frequency and (b) accuracy.
 * The frequency is expressed in MHz, its inverse is the period of
 * time expressed by one CLOCK unit.  So if a timer device reads as 
 * a incrementing/decrementing counter, the value 1 on the counter
 * (one 'tick') counts as one CLOCK unit.
 * The accuracy is expressed in parts-per-million (ppm), it indicates
 * both the uncertainty in establishing the true measure of CLOCK,
 * and the range of dynamic variations thereof.  Many factors can
 * cause a drift in the CLOCK signal, like temperature, aging, etc etc.
 * For instance, a 10 MHz, 10 ppm CLOCK is a 10MHz+/-100Hz signal,
 * meaning anywhere between 9,999,900 Hz and 10,000,100 Hz.
 * [We are simplifying and ignoring many many issues here]
 *
 * The basic problem addressed in this software module is the
 * transformation between the CLOCK and the TIME domains.
 * More specifically, this module is asked to (a) tell the
 * CurrentTime(), by reading the timer device in CLOCK units
 * and returning the corresponding TIME units, and (b) set
 * the timer (in CLOCK units) to expire some TIME units in the future.
 * In other words, (a) transforms CLOCKs to TIMEs and (b) does
 * the opposite TIMEs to CLOCKs transformation.
 *
 * There are many issues affecting the precision of this transformation,
 * this simple discussion will only address some computational aspects.
 * For instance, consider the deceivingly simple act of reading the timer.
 * How many instructions does it take ? Are the instructions in cache ?
 * Is there possible contention on the bus during the READ transaction ?
 * So how many cycles does it take ? In which cycle exactly are we sampling
 * the timer ? Was the timer just about to change or ... ?
 * Consider then the act of WRITING the timer.
 * We need to know exactly when the new value takes hold; ideally
 * the timer itself would tell us "the new value N replaced a
 * previous value of P", so that we can keep track correctly of
 * the flow of passing CLOCK units. [see RTC-avoidance discussion below]
 * 
 * So what about those CLOCK<=>TIME conversions ?
 * Say we have (a) a number C of CLOCK units to convert into
 * the equivalent number T of TIME units.  Or (b) viceversa.
 * All we have to do is to find the ratio between the two base units,
 * where one is well known (10 MHz for TIME) and the other is
 * given by the timer's crystal.  
 * Let Tf be the 10 MHz reference frequency, T0 the 100ns reference period,
 * Cf the crystal's frequency and C0 the crystal's period.
 * Define the ratio between frequencies as R = Tf/Cf = C0/T0.
 * Transformation (a) above is then the multiplication
 *
 *              (a)      t = R * c
 *
 * and transformation (b) is the converse division
 *
 *              (b)      c = t / R
 *
 * There are two sets of numerical issues here, based on the errors
 * in (1) representing the ratio R (and/or the reciprocal 1/R) and
 * (2) roundoffs in the integer multiplication/division.
 * 
 * It should be noted that the first set of issues could be voided
 * by maintaining the original formulation R = C0/R0:
 *              (a)      t = (C0 * c) / T0
 *              (b)      c = (T0 * t) / C0
 * because T0 and Tf are precisely represented, and at least one of
 * Cf,C0 are also precise [but the hardware guys are so funny at times..].
 * This involves both a multiplication and a division, possibly in 64 bits,
 * in both conversions.  Performance-wise it is therefore less desireable.
 * 
 * To compound the numerical issues, we have here some strict performance
 * requirements.  This is a real time system after all, it is only
 * natural to make frequent accesses to the timing services,
 * both by the system scheduler and by various other components.
 * Our axioms for performance considerations are as follows.
 * - 64 bit math is more expensive than 32 bit math (32bit processor)
 * - Division is more expensive than multiplication.
 *   It is likely to be implemented in software rather than hardware.
 * - Multiplication is more expensive than addition/subtraction.
 *   This too might be missing from the hardware (it really happened).
 * - add/subtract is slightly more expensive than a shift operation.
 *   This is true of the ARM, due to the barrel shifter that can tack
 *   onto most instructions.
 * These considerations apply the the ARM processor, caveat emptor.
 * Beware of pipelined processors and claims that 'processor X
 * retires a 64x64->128bit multiply every cycle' which is not the
 * same as saying that the multiplication starts at cycle N and ends at N+1.
 *
 * The ideal case is clearly for R=1, meaning timer CLOCK == 10 MHz.
 * No conversion whatever is necessary here, no additional errors.
 * Near to ideal is the case R=2^n, simple shifts perform the conversion.
 * Accuracy is not affected if n<0, meaning if the CLOCK frequency
 * is higher than the TIME frequency of 10 MHz.  
 * Spelling this out: 20,40,80,160,... MHz and 5,2.5,1.25,0.625,... MHz
 *
 * Consider instead the case of a 30 MHz CLOCK.  It would appear to
 * be trivial because 1/R == 3.  Indeed, conversion (b) can be
 * performed simply by
 *                   c = t * 3 = add(t,Lshift(t,1))
 * And in a similar vein one can think of the cases 1/R = 5,6,7,9,..
 * But consider transformation (a) now.  R=1/3 has infinite digits
 * in any binary base [2 and 3 are primes, duh..], therefore the best
 * we can hope for is a 32bit division in hardware.  Or is it ?
 * And what if that division is in a general-purpose software routine ?
 * We have opened the door to an open-ended series of opportunistic
 * transformations and redefinitions of the problem.
 * For instance. 1/3=0.01010101010101010101010101010101...
 * This number can be changed (normalized, to gain precision) to
 * 1/3=2^-1*0.10101010101010101010101010101010.. and keeping the mantissa
 * to 32 bits [we could use more if 'c' has say 16 bits only..]
 *                   t = c / 3 = Rshift(mul64(c,0xAAAAAAAA),32+1)
 * which can be off by one, but we can quickly compensate for it:
 *                   if (t*3 != c) t++
 * Thats the basic idea behind multiply-by-the-reciprocal.
 * Another idea is to add or subtract a small constant.
 * Meaning, perhaps 1/N is bad but (1+1/N) is not so bad.
 * Another idea is to look at the number of bits that are set (ones)
 * in the constants we use, and to minimize them.
 * Meaning, perhaps 1/N has many ones but 1/(M*N) does not.
 * If M is a small constant the ratio M/(M*N) might be more efficient.
 * Take a look at the factoring of Cf into primes, that can get you
 * ideas for a good transformation.  For instance, consider 4.9152 MHz.
 * Turns out 49152 = 3 * 2^14, a very simple factoring.
 */

/*
 * Time might be kept using both an RTC and the PIT (timer 0).
 * The former gives an RTCDelta interrupt granularity, and
 * is the sole responsible for the drift [temperature & co.].
 * The latter gives fine grain resolution, and is used for
 * scheduling purposes.
 *
 * The basic idea is that the current time is given by
 *
 *      Now = TOY + ReloadDelta + (Ticks - PIT)
 *
 * where TOY is the accumulated count of the RTC interrupts,
 * ReloadDelta is the accumulated count of PIT reloads (one
 * reload per rescheduling), Ticks is the value the PIT was
 * last reloaded with, and PIT is the current reading of
 * the PIT.
 *
 * An important but subtle point is how the subexpression
 * in parens is evaluated.  PIT is a 16 bit counter, which
 * counts down from the (Ticks) value it is loaded with.
 * When it reaches zero it keeps decrementing from xFFFF.
 * (We use the Intel 8254 in Mode0).
 * By using signed 16 bits arithmetic we are guaranteed that
 * the (unsigned!) result of the subtraction is precisely
 * the number of ticks elapsed.  Assuming only that we did
 * not ignore the PIT interrupt for e.g. 54 milliseconds,
 * which is a safe assumption (else this whole OS is garbage..).
 *
 *
 * Formal analysis was based on the following pseudo code.
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (Ticks - PIT)
 *
 * PIT.Set(t) ::
 *      ReloadDelta += (Ticks - PIT)
 *      PIT = t
 *      Ticks = t
 *
 * PIT.Interrupt() :: <nothing needed>
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, 16msec
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * All functions are assumed atomic interrupt-wise.
 *
 * Notice that the above proof still holds if we remove
 * the RTC chip: just cancel RTC.Interrupt() and wire TOY==0.
 * Drift analysis (in PIT.Set()) becomes important, e.g. the
 * time between the first and second statement.
 *
 * UPDATE UPDATE UPDATE --for Atmel parts-- UPDATE UPDATE UPDATE
 *
 * Here the PIT counts up, not down. One way to work around this
 * is to set COUNTER at MAX-desired_delta and take the interrupt
 * at overflow. At interrupt time COUNTER measures our latency,
 * so we can account for it.
 * One useful idea here is to use ARM's "swap" instruction, which
 * atomically does a read+write operation, e.g. on the COUNTER.
 * Darn, the counter is infact read-only. So much for that one.
 * There is no way to load anything but zero in that COUNTER, sorry.
 *
 * Another way is to load register C with COUNTER+desired_delta,
 * and use the match as interrupt trigger. At interrupt time the
 * difference COUNTER-C is the latency. COUNTER would be free-running
 * in this solution. There is an issue here as to how many cycles
 * does it take to (a) read COUNTER (b) add DELTA (c) write C.
 * Unless this is (a) deterministic and (b) known with high accuracy
 * we'll get strong clock drift.
 *
 * Yet another way is to load C with desired-delta, and reset+start
 * the counter. Interrupt again is at match with C.  One advantage is
 * that C holds Ticks directly on-chip, reducing memory load/stores.
 * The same drift problem as above applies here, the sequence is
 * (a) read COUNTER (b) reset-restart it.
 *
 * In both these last two cases the counter could be match-reset.
 * The problem with that is that we sometimes load very small delta
 * values, and it might be a while after the interrupt triggers
 * before we reload the timer. [This is scheduler-dependent]
 * So the counter might reset multiple times...
 *
 * The first (non-)solution would be the one that works best without
 * the RTC, assuming the swap trick.  The third one is the one that
 * minimizes drift uncertainty, and therefore the chosen one.
 * The equations for this solution are
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (PIT - Ticks)
 *
 * PIT.Set(t) ::
 *      PIT.C = t
 *      PIT_WAS = PIT
 *      PIT.Restart()
 *      ReloadDelta += (PIT_WAS - Ticks) + <drift>
 *      Ticks = 0
 *
 * PIT.Interrupt() :: <nothing needed [except calling PIT.Set()]>
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, ~2 seconds
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 */

#include <mmlite.h>
#include <diagnostics.h>
#include <fred.h>
#include <mmhal.h>
#include "at91x40.h"
#include "zenith1.h"

/* The MSFT Zenith board can be fit with many crystals, the two of interest
 * are 22.1184 MHz and 4.9152 MHz.  A divisor (by 1/2/4/8/16) selects the
 * actual MCLK signal, via jumpers. It also has a 32768 Hz reference crystal,
 * which comes in on GPIO6/T2CLK (timer 2 clock input pin);
 * we use it for auto-detecting the MCLK frequency (system clock).
 * Counters are fed that clock, divided by one of 2,8,32,128,1024.
 * Counter registers are 16 bit (yuch).
 *
 * As for the RTC, since we have so many timers we can expend one.
 * It is desireable to maximize the distance between RTC interrupts,
 * to minimize overhead.  The RTC interval also must be chosen to
 * avoid roundoff errors, as this is the one that controls drift.
 * This value should be such that MAX*C0 is an integral number of TIME units
 * See ClockIsr() for how this is used.
 */

volatile struct {
    TIME Toy;                   /* Time-of-year (gross estimate/epoch)      */

                                /* NB: These two are PERIODs, not TIMEs     */
    UINT32 ReloadDelta;         /* Delta from TOY due to multiple PIT intrs */
    UINT16 Ticks;               /* Value of the Counter at RTC interrupt    */

} SystemTimer = {
    Int64Initializer(0, 0),
    };

extern UINT DelayMultiplier;
extern UINT DelayShifter;
extern UINT DelayOverhead;

/* Configuration data.
 * We can use one of two crystals, 5 divisors each.
 */
#define RtcTicker      Z1TimerConfig[0].RtcClockTick
#define RtcPeriod      Z1TimerConfig[0].RtcTicks
#define OstMaxInterval Z1TimerConfig[0].PitMaxInterval
#define OstShifter     Z1TimerConfig[0].PitShiftValue
#define OstScaler      Z1TimerConfig[0].PitClockScaler

/* AT 22+ MHz:
 * Keep a decent accuracy (about 1us say) and good range (>40ms).
 * The timer is a 16bit counter running at 22.xx/32=0.691200 MHz,
 * set a max interval that still leaves enough room before overflow.
 * Div    F(MHz)    T(ns)   MAX(ms)
 * /2     11.0      90.5    5.9
 * /8     2.7       362     23.7
 * /32    0.7       1447    94.8   best
 * /128   0.17      5787    380
 * /1024  0.0216    46296   3034.027777..per
 */
#define nPER_CONFIG 5
#define nCONFIGS (nPER_CONFIG*2)
TIMER_CONFIG Z1TimerConfig[nCONFIGS] = {
    /* First entry is the one in actual use, and the default one
     */
/*0*/
    {/* 22MHz, no divisor */
        Z1Crystal,

        TCHM_MCKI_32,
        5, /* 32 */

        /* Even if the true max is ?? use a nice RTC period */
        64800,
        Int64Initializer(0,TIME_SECONDS(3)),

        /* MAX for PIT */
        Int64Initializer(0, TIME_MICROS(93750)) /* max 64800 = 93.75ms*/
    },
/*1*/
    {/* 22MHz/2 */
        Z1Crystal/2,

        TCHM_MCKI_32,
        6, /* 64 */

        /* No change in RTC programming, hence 2x the default */
        64800,
        Int64Initializer(0,TIME_SECONDS(6)),

        /* No change in PIT programming, hence 2x the default */
        Int64Initializer(0, TIME_MICROS(93750)*2)
    },
/*2*/
    {/* 22MHz/4 */
        Z1Crystal/4,

        TCHM_MCKI_8,
        5, /* 32 */

        /* No change in RTC programming, hence 4x the default */
        64800,
        Int64Initializer(0,TIME_SECONDS(12)),

        /* Speedup the counter, back to #0 in granularity */
        Int64Initializer(0, TIME_MICROS(93750)) /* max 64800 = 93.75ms*/
    },
/*3*/
    {/* 22MHz/8 */
        Z1Crystal/8,

        TCHM_MCKI_8,
        6, /* 64 */

        /* No change in RTC programming, hence 8x the default */
        64800,
        Int64Initializer(0,TIME_SECONDS(24)),

        /* Speedup the counter, back to #1 in granularity */
        Int64Initializer(0, TIME_MICROS(93750)*2)
    },
/*4*/
    {/* 22MHz/16 */
        Z1Crystal/16,

        TCHM_MCKI_2,
        4, /* 16 */

        /* No change in RTC programming, hence 16x the default */
        64800,
        Int64Initializer(0,TIME_SECONDS(48)),

        /* Speedup the counter, back to #0 in granularity */
        Int64Initializer(0, TIME_MICROS(93750)) /* max 64800 = 93.75ms*/
    },
    /* AT 4.9152 MHz:
     * The timer is a 16bit counter running at 4.9xx/??=??? MHz,
     * max interval is therefore ??? ms.
     * Make sure it doesnt wrap around unnoticed.
     */
/*5*/
    {/* 9.8304MHz / 1024 = 9.6 KHz.  65535 / 9.6KHz = 6.8265625 sec */
        Z1Crystal/16,

        TCHM_MCKI_2,
        5, /* 32 */

        /* No change in RTC programming, hence 16x the default */
        64800,
        Int64Initializer(0,TIME_SECONDS(48)),

        /* Speedup the counter, back to #0 in granularity */
        Int64Initializer(0, TIME_MICROS(93750)) /* max 64800 = 93.75ms*/
    },
/*fixme */
};

/*
 * Interrupt handler for the programmable timer (scheduler)
 */
#define verify 0
#if verify
extern UINT32 TimeHalted[];
#endif

BOOL TimerIsr(TC_CHANNEL *Channel, BOOL *pNotMine)
{
    UINT32 x;

#if verify
    TimeHalted[1] = TheCNT->Counter;
#endif

    /* Acknowledge the interrupt
     */
    x = Channel->Status;

    /* No need for this, as this is the default */
    /* *pNotMine=FALSE; */

    /* Say its time to reschedule */
    return TRUE;
}


/*
 * Interrupt handler for RTC timer.
 */
BOOL ClockIsr(TC_CHANNEL *Channel, BOOL *pNotMine)
{
    UINT32 x;

    /* Acknowledge the interrupt */
    x = Channel->Status;

    /* Add one tick worth to the time of day */
    SystemTimer.Toy = TimeAdd(SystemTimer.Toy, RtcTicker);

    /* Zero the increment */
    SystemTimer.ReloadDelta = 0;

    /* Take the value of the PIT at this point */
    SystemTimer.Ticks = ThePIT->Counter;

    /* No need for this, as this is the default */
    /* *pNotMine=FALSE; */

    /* Leave the scheduler alone */
    return FALSE;
}

/*
 * The Atmel part has a 32x32->64 bit multiplier
 */
#if defined(__NO_BUILTIN_INT64)
extern INT64 Uint32TimesUint32ToInt64(UINT32 a, UINT32 b);
#else
#define Uint32TimesUint32ToInt64(_a_,_b_) (INT64)(((UINT64)_a_)*((UINT64)_b_))
#endif

/* Worker functions for the two crystals cases, 2 xforms each
 */
typedef UINT32 (* TO_TICKS)(TIME Delta);
typedef TIME (* TO_TIME)(UINT32 Ticks);

/* These are the routines for tranformation (b) TIME->CLOCK
 */
UINT32 TimeToTicks22MHz(TIME Delta)
{
    UINT32 Ticks, Temp;

    /* Is it within range ?
     * NB: This guarantees a max number of bits for Delta,
     *    since obviously Ticks must fit in 16 bits.
     */
    if (!TimeLess(Delta,OstMaxInterval))
        /* Nope, trim */
        return 64800; /* 64800/691,200=93.75ms with ~1ms before overflow */

    /*
     * Crystal is 22.1184 MHz, almost 20MHz but not exactly. Triple sigh..
     * NB: c = t / R = t * Cf / Tf = t * 22.x/10
     *  
     *  Ticks = Time * 2 * 1.10592
     *        = Time * 2 * (1 + 2^-4 * (1 + (0xB1D92B80 * 2^-32)))
     */
    Ticks = ((UINT32) Int64ToInt32(Delta)) << 1; /* 18 bits max */

    Delta = Uint32TimesUint32ToInt64(0xB1D92B80,Ticks);
    Temp  = Uint64High32Bits(Delta); /* 19 bits max */

    Ticks = Ticks + ((Ticks + Temp) >> 4); /* 19 bits max */

    /* Finally, account for the divisor in the timer chip, at least /2
     */
    Ticks = Ticks >> OstShifter;
    return Ticks;
}

UINT32 TimeToTicks5MHz(TIME Delta)
{
    UINT32 Ticks;

    /* Is it within range ?
     */
    if (!TimeLess(Delta,OstMaxInterval))
        /* Nope, trim */
        return 63897; /* roundup(MAX / 1.2288MHz) */

    /*
     * Crystal is 9.8304 MHz, almost 10MHz but not exactly. Sigh.
     *  
     *  Ticks  = Delta * 100000 / 98304 = ....
     *         = Delta + Delta * 2^-6 + Delta * 0xd5555555 * 2^-41
     */
    Ticks = (UINT32) Int64ToInt32(Delta);
    Delta = Uint32TimesUint32ToInt64(0xd5555555,Ticks);
    Delta = Int64RShift(Delta, 41);
    Ticks = Ticks + (Ticks >> 6) + (UINT32) Int64ToInt32(Delta);
    Ticks = Ticks >> OstShifter;
    return Ticks;
}

TO_TICKS TimeToTicks = TimeToTicks22MHz;

/* These are the routines for tranformation (a) CLOCK->TIME
 *
 * NOTE: The range for Ticks is defined by the RTC period.
 * This routine is asked to convert "ReloadDelta+e", which
 * is cleared by the RTC ISR.
 */
TIME TicksToTime22MHz(UINT32 Ticks)
{
    TIME Delta64;

    /* The RTC period is 3 seconds, which fits Ticks in 24 bits.
     */
    /*
     * Crystal is 22.1184 MHz, almost 20MHz but not exactly. Triple sigh..
     * NB: t = c * R = c * Tf / Cf = c * 10/22.x
     *
     *  Time = Ticks * 5 / 11.0592 = Ticks * 0.0.45211226851per(851)
     *       = 2^-1 * Ticks * (0xE77B425F * 2^-32)
     */

    /* Account for the divisor in the timer chip, at least /2
     * This shifter is at max 6, hence max 30 bits.
     */
    Ticks = Ticks << OstShifter;

    Delta64 = Uint32TimesUint32ToInt64(0xE77B425F,Ticks);
    Ticks = Uint64High32Bits(Delta64); /* 18 bits max */

    Ticks = Ticks >> 1;

    Int64FromHighAndLow(Delta64,0,Ticks);
    return Delta64;
}

TIME TicksToTime5MHz(UINT32 Ticks)
{
    TIME Delta64;

    /*
     * Crystal is 9.8304 MHz, almost 10MHz but not exactly. Sigh.
     *  
     *  Time  = Ticks * 98304 / 100000 = ....
     *        = Ticks - Ticks * 2^-6 - Ticks * 0xaefb2aae * 2^-41
     */
    Ticks = Ticks << OstShifter;
    Delta64 = Uint32TimesUint32ToInt64(0xaefb2aae, Ticks);
    Delta64 = Int64RShift(Delta64, 41);
    Ticks = Ticks - (Ticks >> 6) - (UINT32) Int64ToInt32(Delta64);
    Int64FromHighAndLow(Delta64,0,Ticks);
    return Delta64;
}

TO_TIME TicksToTime = TicksToTime22MHz;

/* Arm the timer to trigger in DELTA units of TIME (100ns) from now.
 */
extern UINT32 ReadWrite(PUINT32 ReadAddress,
                        PUINT32 WriteAddress, UINT32 WriteValue);

BOOL SetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    UINT32 PitWas, Ticks;
    UINT16 Delta16;
    UINT IntrState;
    BOOL StateWas;

    Ticks = TimeToTicks(Delta);

    if (Ticks < 2)
        Ticks = 2;              /* sanity minimum */

    assert(Ticks <= 0xffff);

    /*
     * Got the tick count, program the timer now
     */
    TURN_INTERRUPTS_OFF(IntrState);

    /* Set the new match value
     */
    ThePIT->C = Ticks;

    /* Get&Restart the COUNTER, in a well-known amount of time
     */
    PitWas = ReadWrite((PUINT)&ThePIT->Counter,
                       (PUINT)&ThePIT->Control, TCHC_ENABLE | TCHC_TRIGGER);

    /* Account for this reload
     */
    Delta16 = PitWas - SystemTimer.Ticks;
    SystemTimer.ReloadDelta += Delta16; /* BUGBUG add drift if no RTC */
    SystemTimer.Ticks = 0;

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);

    return StateWas;
}

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is max_toy_resolution
 */
TIME GetKernelTime ()
{
    UINT32 Delta;
    TIME Delta64;
    TIME TOY;
    UINT16 Ticks, PIT, Delta16;
    UINT IntrState;

    /* Cache a few values with interrupt protection
     *
     * NB: The value we return is bound to be 'obsolete',
     * not just by the time needed to compute it and return
     * to the point of call but also by unpredictable
     * delays due to device and timer interrupts.
     * Therefore it is not worth over-extending the protection
     * against interrupts inside this function, as it would
     * serve no benefit whatever.  The opposite need,
     * minimizing interrupt latency, is the one that dominates.
     */
    TURN_INTERRUPTS_OFF(IntrState);

    PIT   = ThePIT->Counter;
    Ticks = SystemTimer.Ticks;
    Delta = SystemTimer.ReloadDelta;
    TOY   = SystemTimer.Toy;

    RESTORE_INTERRUPTS(IntrState);

    /* Compute the number of elapsed ticks since the last RTC interrupt.
     */
    Delta16 = PIT - Ticks;
    Delta += Delta16;

    Delta64 = TicksToTime(Delta);

    /* Now put them all together.
     */
    TOY = Int64Add(Delta64, TOY);

    return TOY;
}

/* The board can be jumper-set to run at various clock speeds.
 * This function detects what frequency we are running at, and
 * sets up various pseudo-constants accordingly.
 * Besides the timer, at least one other module (serial line)
 * needs to know this information.
 */
extern void DbgPortInit(void);

void ClockDetect(void)
{
    /* The 5/22MHz XTAL signal from the crystal is fed to a divisor
     * and it is the output of this divisor that becomes MCLKI,
     * the CPU's and system's master clock.  A jumper selects
     * which bit of this counter becomes MCLKI.  There are 5
     * positions for this jumper, corresponding to:
     * XTAL (counter is bypassed), XTAL/2, XTAL/4, XTAL/8, XTAL/16.
     */
    /* On pin P6/T2_CLK we get the signal from a second crystal,
     * a 32KHz one used by the RTC chip. The idea is to start two counters
     * concurrently, one fed by the 32KHz reference and the other by MCLKI.
     * Comparing the two gives the true speed we are running at.
     */
    /* Once the ratio between clocks is found, we look it up in this table.
     * Allow for a small range around the given number.
     */
    static struct {
        UINT16 Start, End;
    } Ranges[nCONFIGS] = {
      /* 22 MHz and divisions thereof */
      {/*/1*/336,339}, {/*/2*/167,170}, {/*/4*/83,86},
      {/*/8*/41,44}, {/*/16*/20,22},
      /* 4.9 MHz and divisions thereof */
      {/*/1*/74,76}, {/*/2*/36,39}, {/*/4*/17,20},
      {/*/8*/9,10}, {/*/16*/4,5}
    };
    UINT32 c, s, i, tries = 0;
#define T0 (&Tc0->Channel0)
#define T2 (&Tc0->Channel2)

    /* At 22MHz.. */
    DelayMultiplier =  5662;
    DelayShifter    =    10;
    DelayOverhead   = 14131;

    T2->Control = TCHC_DISABLE;
    s = T2->Status;
    T0->Control = TCHC_DISABLE;
    s = T0->Status;

    /* Enable the 32KHz external signal on pin P6/PIO_TCLK2 */
    ThePio->Disable = PIO_TCLK2;
    ThePio->OutDisable = PIO_TCLK2;
    ThePio->FilterDisable = PIO_TCLK2;

    /* Setup the "internal" timer, top speed.
     */
    T0->Mode = TCHM_WAVE | TCHM_MCKI_2;
    T0->IntrDisable = ~0;
    T0->A =
    T0->B = 
    T0->C = 0;
    T0->Control = TCHC_ENABLE;
    s = T0->Status;

    /* Setup the "external" timer.
     */
    Tc0->BlockMode = TCBM_2_TCLK2; /* xc2 is T2_CLK */

    T2->Mode = TCHM_WAVE | TCHM_XC2;
    T2->IntrDisable = ~0;
    T2->A =
    T2->B =
    T2->C = 0;
    T2->Control = TCHC_ENABLE;
    s = T2->Status;

    tries = 0;
 Again:
    /* Start all counters */
    Tc0->BlockControl = TCBC_SYNCRHO;

    /* Wait a minimum */
    Delay(5);

    /* Dont loop forever
     * NB: min 2 instr/loop => max loop speed same as counter
     * NOTE: Yes we assume T0 is faster.
     */
    for (i = 0; i < 0x10000; i++) {
        s = T0->Status;/*  a destructive read */
        if (s & TCHI_OVERFLOW) break;
    }
    /* See where the external clock is, stop them both
     */
    c = T2->Counter;
    T0->Control = TCHC_DISABLE;
    T2->Control = TCHC_DISABLE;

    DBGME(1,printf("%s %d %d [%d %x]\n",
                   (s & TCHI_OVERFLOW) ? "YES!" : "nope",
                   T0->Counter, c, i, s));

    /* Check we gotsome, might not fly first shot
     */
    if ((i >= 0x10000) || (c == 0)) {
        if (++tries >= 3) {
            /* Ouch.
             */
//printf("tr %d %x ",i,c);
            return;
        }
        goto Again;
    }

    /* Compute the (integer) ratio
     */
    s = 0x10000 / c;

    for (i = 0; i < nCONFIGS; i++) {
        if ((s >= Ranges[i].Start) &&
            (s <= Ranges[i].End))
            break;/* got it */
    }

    DBGME(1,printf("%s %d [%d %d]\n",
                   (i < nCONFIGS) ? "YES!" : "nope",
                   i, s, c));

    /* If its weird dont try anything.
     */
    if (i == nCONFIGS) {
//printf("nC %d %x ",i,c);
        return;
    }

    /* OK, install the proper config
     */
    Z1TimerConfig[0] = Z1TimerConfig[i];

    /* Config Delay() also
     * NB: "i" is the log2 of the clock divisor.
     */
    DelayShifter   += i;
    DelayOverhead <<= i;

    /* If it is the 5 MHz crystal then switch converters
     * and redo the Delay thing (we are x4.5 slower)
     */
    if (i >= nPER_CONFIG) {
        TimeToTicks = TimeToTicks5MHz;
        TicksToTime = TicksToTime5MHz;
        i -= nPER_CONFIG;
        DelayMultiplier =       629;
        DelayShifter    =     9 + i;
        DelayOverhead   = 3140 << i;
    }

    /* And reset the debug serial line
     */
    DbgPortInit();
}

/* Initialization
 */
void EnableTimers( void )
{
    UINT32 x;

    /* Start by finding out what clock frequency we got
     */
    /* ClockDetect(); Done already */
    DBGME(1,printf("ClockSpeed: %d\n",Z1Clock));

    /*
     * First, do the RTC. Use channel 1 on TC0 for it.
     */
    x = TheRTC->Status;
    TheRTC->Control = TCHC_DISABLE; /* stop it if it was running */

    /* Install the ISR */
    AddDevice((PTR) TheRTC, (void *) ClockIsr, 0, IRQ_ID_TIMER1, 0);

    /* Enable the clock feed, in the power manager */
    ThePs->PerClockEnable = ThePs->PerClockStatus | PSPC_TC1;

    /* Program the counter, as slow as possible */
    TheRTC->Mode = TCHM_WAVE | TCHM_MCKI_1024 | TCHM_TRG_RC;

    /* See the discussion at the beginning of this file */
    TheRTC->C = RtcPeriod;

    /* Reset and start the counter */
    TheRTC->Control = TCHC_ENABLE | TCHC_TRIGGER;

    /* Enable interrupts */
    TheRTC->IntrEnable = TCHI_C_COMPARE;

    /*
     * Next the programmable timer. Use channel 0 on TC0 for it.
     */
    x = ThePIT->Status;
    ThePIT->Control = TCHC_DISABLE; /* stop it if it was running */

    /* Install the ISR */
    AddDevice((PTR) ThePIT, (void *) TimerIsr, 0, IRQ_ID_TIMER0, 0);

    /* Enable the clock feed, in the power manager */
    ThePs->PerClockEnable = ThePs->PerClockStatus | PSPC_TC0;

    /* Program the counter */
    ThePIT->Mode = TCHM_WAVE | OstScaler;
    ThePIT->A =
    ThePIT->B =
    ThePIT->C = 0;

    /* Reset and start the counter */
    ThePIT->Control = TCHC_ENABLE | TCHC_TRIGGER;

    /* Enable timer interrupt */
    ThePIT->IntrEnable = TCHI_C_COMPARE;

    /* Start of time is now
     * NB: Leave the TOY+ReloadDelta, in case a reset restarts the system.
     */
    SystemTimer.Ticks = ThePIT->Counter;

#if verify
    /* Use Channel2 as a high-frequency counter, for measuring purposes
     */
    x = TheCNT->Status;
    TheCNT->Control = TCHC_DISABLE; /* stop it if it was running */

    /* Enable the clock feed, in the power manager */
    ThePs->PerClockEnable = ThePs->PerClockStatus | PSPC_TC2;

    /* Program the counter, as fast as possible */
    TheCNT->Mode = TCHM_WAVE | TCHM_MCKI_2;

    TheCNT->C = 0; /* irrelevant but */

    /* Reset and start the counter */
    TheCNT->Control = TCHC_ENABLE | TCHC_TRIGGER;
    
#endif

}

/* Estimate the current processor speed
 */
UINT64 CurrentProcessorSpeed(void)
{
    UINT64 Speed;

    /* Dont think we'll overflow 32 bits :-))
     */
    Int64FromHighAndLow(Speed,0,Z1Clock);
    return Speed;
}

