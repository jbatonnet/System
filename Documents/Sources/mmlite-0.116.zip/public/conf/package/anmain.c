/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>

PINETDRIVER RTLCALLTYPE AnNew( PUINT pPortBase, PUINT pIrq, PUINT pMedia);

PIUNKNOWN CobMain(void)
{
    return (PIUNKNOWN) AnNew(NULL, NULL, NULL);
}
