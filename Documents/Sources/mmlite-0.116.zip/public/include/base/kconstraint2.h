/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Header file for kernel representations of time constraints. */

#ifndef _OLDSCHED

#ifndef __KCONSTRAINT2_H__
#define __KCONSTRAINT2_H__

#include <base/urgency2.h>
#include <base/tconstraint2.h>
#include <util/list-single.h>

typedef struct _KCONSTRAINT KCONSTRAINT, *PKCONSTRAINT;

struct _KCONSTRAINT {
  PTR pSchedObject;            /* Currently associated scheduler object      */
  TIME tInitialRestartBy;      /* [KernelTime] for calculating TimeTaken     */
  TIME tLastRefresh;           /* Last modification time of this constaint   */
  URGENCY uLocal;              /* Local urgency                              */
  URGENCY uInherited;          /* Urgency inherited from waiters             */
  PTIME_CONSTRAINT ptcPending; /* User-mode time constraint pending          */

  PKCONSTRAINT pkcStackNext;   /* Pointer to surrounding constraint in stack */
  NODE nSchedQueueNode;       /* Node for being placed on sched queues      */
  NODE nWaitQueueNode;        /* Node for being placed on wait queues       */
};

#define pKC(_pkc_) ((PKCONSTRAINT)(_pkc_))

#define /* PTR */                                                             \
KConstraint_GetSchedObject(/* PKCONSTRAINT */ _pkc_)                          \
     (pKC(_pkc_)->pSchedObject)

#define /* void */                                                            \
KConstraint_SetSchedObject(/* PKCONSTRAINT */ _pkc_,                          \
                          /* PTR */ _pSchedObject_)                           \
     (pKC(_pkc_)->pSchedObject = (_pSchedObject_))

#define /* TIME */                                                            \
KConstraint_GetInitialRestartBy(/* PKCONSTRAINT */ _pkc_)                     \
     (pKC(_pkc_)->tInitialRestartBy)

#define /* void */                                                            \
KConstraint_SetInitialRestartBy(/* PKCONSTRAINT */ _pkc_,                     \
                              /* TIME */ _tInitialRestartBy_)                 \
     (KConstraint_GetInitialRestartBy(_pkc_) = (_tInitialRestartBy_))

#define /* TIME */                                                            \
KConstraint_GetLastRefresh(/* PKCONSTRAINT */ _pkc_)                          \
     (pKC(_pkc_)->tLastRefresh)

#define /* void */                                                            \
KConstraint_SetLastRefresh(/* PKCONSTRAINT */ _pkc_,                          \
                      /* TIME */ _tLastRefresh_)                              \
     (KConstraint_GetLastRefresh(_pkc_) = (_tLastRefresh_))

#define /* PURGENCY */                                                        \
KConstraint_GetLocalUrgency(/* PKCONSTRAINT */ _pkc_)                         \
     (&(pKC(_pkc_)->uLocal))

#define /* BOOL */                                                            \
KConstraint_IsInheritedUrgencyValid(/* PKCONSTRAINT */ _pkc_)                 \
     (!KConstraintWaiterQueueIsEmpty(_pkc_))

#define /* PURGENCY */                                                        \
KConstraint_GetCurrentUrgency(/* PKCONSTRAINT */ _pkc_)                       \
     (&(pKC(_pkc_)->uInherited))

#define /* TIME */                                                            \
KConstraint_GetRestartBy(/* PKCONSTRAINT */ _pkc_)                            \
     (Urgency_GetRestartBy(KConstraint_GetCurrentUrgency(_pkc_)))

#define /* void */                                                            \
KConstraint_SetRestartBy(/* PKCONSTRAINT */ _pkc_,                            \
                        /* TIME */ _tRestartBy_)                              \
      Urgency_SetRestartBy(KConstraint_GetLocalUrgency(_pkc_), _tRestartBy_)

#define /* _CRITICALITY */                                                    \
KConstraint_GetCriticality(/* PKCONSTRAINT */ _pkc_)                          \
     (Urgency_GetCriticality(KConstraint_GetCurrentUrgency(_pkc_)))

#define /* void */                                                            \
KConstraint_SetCriticality(/* PKCONSTRAINT */ _pkc_,                          \
                          /* _CRITICALITY */ _c_)                             \
     Urgency_SetCriticality(KConstraint_GetLocalUrgency(_pkc_), _c_)

#define /* PTIME_CONSTRAINT */                                                \
KConstraint_GetPending(/* PKCONSTRAINT */ _pkc_)                              \
     (pKC(_pkc_)->ptcPending)

#define /* void */                                                            \
KConstraint_SetPending(/* PKCONSTRAINT */ _pkc_,                              \
                      /* PTIME_CONSTRAINT */ _ptcPending_)                    \
     (KConstraint_GetPending(_pkc_) = pTC(_ptcPending_))

#define /* BOOL */                                                            \
KConstraint_HasPending(/* PKCONSTRAINT */ _pkc_)                              \
     (KConstraint_GetPending(_pkc_) != NULL)

#define /* PNODE */                                                          \
KConstraint_GetStackNext(/* PKCONSTRAINT */ _pkc_)                            \
     (pKC(_pkc_)->pkcStackNext)

#define /* PNODE */                                                          \
KConstraint_SetStackNext(/* PKCONSTRAINT */ _pkc_,                            \
                        /* PKCONSTRAINT */ _pkcNext_)                         \
     (KConstraint_GetStackNext(_pkc_) = pKC(_pkcNext_))

#define /* BOOL */                                                            \
KConstraint_HasStackNext(/* PKCONSTRAINT */ _pkc_)                            \
     (KConstraint_GetStackNext(_pkc_) != NULL)

#define /* PNODE */                                                          \
KConstraint_GetWaitQueueNode(/* PKCONSTRAINT */ _pkc_)                        \
     &(pKC(_pkc_)->nWaitQueueNode)

#define /* PNODE */                                                          \
KConstraint_GetSchedQueueNode(/* PKCONSTRAINT */ _pkc_)                       \
     &(pKC(_pkc_)->nSchedQueueNode)

void KConstraint_Init(
     PKCONSTRAINT pkc,
     PTIME_CONSTRAINT pcval
     );

BOOL KConstraint_UrgencyGT(
     PTR pkc1,
     PTR pkc2
     );

BOOL KConstraint_UrgencyGTEQ(
     PTR pkc1,
     PTR pkc2
     );

PKCONSTRAINT KConstraint_Push(
     PKCONSTRAINT pkc,
     PKCONSTRAINT pkcNew
     );

PKCONSTRAINT KConstraint_Pop(
     PKCONSTRAINT pkc
     );

void KConstraint_StartInheritance(
     PKCONSTRAINT pkcOwner,
     PURGENCY puNew
     );

void KConstraint_RecalculateInheritance(
     PKCONSTRAINT pkcRecalc
     );

#endif /* __KCONSTRAINT2_H__ */

#endif /* _OLDSCHED */
