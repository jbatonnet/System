/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Sharp LH77790 Interrupt Controller support.
 */

#include <mmlite.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <drivers/drivers.h>
#include <fred.h>
#include <mmhal.h>
#include <_irq790.h>
#include "_pic790.h"

UINT16 ReadCounter(void);
PCXTINFO _Reschedule(PCXTINFO pContext);
void ChainException(PCXTINFO pContext, UINT ExceptionNum);

typedef struct _ITABLE {
    INTERRUPT_SERVICE_ROUTINE Isr;  /* isr for IRQn*/
    void *pDevice;                  /* Argument to pass to it*/
} ITABLE;

/* The interrupt dispatcher uses a simple table of handlers. */
typedef struct _pic790 {
    const struct IPicVtbl *v;
    UINT IRQMask;
    ITABLE InterruptTable[IRQ_ID_COUNT];
} pic790;

/* Forward decl */
extern pic790 ThePIC;

volatile
enum _IRQMaskState {                 /* initially, irq's disabled */
    Enabled,
    Disabled
} IRQMaskState = Enabled;

/*
 * We only handle IRQ.
 */
void MCT EnableInterrupt( IPic *pThis, DEVICE_FLAGS Flags, UINT Irq,
                          INTERRUPT_SERVICE_ROUTINE Isr, void *pDevice)
{
    pic790 *pic = (pic790 *) pThis;
    UINT Mode = 0;

    /* Map the interrupt mode, if possible
     */
    if (Irq < 6) {
        if (Flags & DEVICE_FLAGS_POSITIVE_LEVEL)
            Mode |= 1;
        if ((Flags & DEVICE_FLAGS_LEVEL_TRIGGER) == 0)
            Mode |= 2;
        TheHWPic->Config0 = (TheHWPic->Config0 & ~(0x3 << Irq)) |
                            (Mode << Irq);
    }

    /* The order of the following operations is NOT irrelevant
     *
     * First, the argument. Failure case is if interrupt was
     * active and we are called with interrupts on and we get
     * an interrupt right after this statement. Wont happen.
     */
    pic->InterruptTable[ Irq ].pDevice = pDevice;

    /* Second, the ISR. If the interrupt was active we are done already.
     * If not, must activate it.
     */
    pic->InterruptTable[ Irq ].Isr = Isr;

    /* Third, the hardware.
     */
    pic->IRQMask |= 1 << Irq;

    /* Make sure we don't unmask interrupts unless we're suppose to.
     */
    if (IRQMaskState == Enabled) {
        UINT i, r;
        i = IntOff();
        r = TheHWPic->IrqEnable;
        r |= 1 << Irq;
        TheHWPic->IrqEnable = r;
        SetPsr(i);
    }

    return;
}

/*
 * Undo the above EnableInterrupt
 */
void MCT DisableInterrupt( IPic *pThis, UINT Irq, void **pOldDevice)
{
    pic790 *pic = (pic790 *) pThis;

    /* Remove the ISR and its argument from our tables after setting
     * the hardware.
     */
    pic->IRQMask &= ~(1 << Irq);

    if (IRQMaskState == Enabled) {
        UINT i, r;
        i = IntOff();
        r = TheHWPic->IrqEnable;
        r &= ~(1 << Irq);
        TheHWPic->IrqEnable = r;
        SetPsr(i);
    }

    pic->InterruptTable[ Irq ].Isr = NULL;
    *pOldDevice = pic->InterruptTable[ Irq ].pDevice; /* Return the old one */
    pic->InterruptTable[ Irq ].pDevice = NULL;

    return;
}

/*
 * Mask *all* interrupts.
 */
void MCT MaskAll( IPic *pThis )
{
    pic790 *pic = (pic790 *) pThis;
    UINT i, r;

    i = IntOff();

    r = TheHWPic->IrqEnable;
    r &= ~pic->IRQMask;
    TheHWPic->IrqEnable = r;

    SetPsr(i);
}

/*
 * Unmask all interrupts that should be unmasked.
 */
void MCT UnmaskAll( IPic *pThis )
{
    pic790 *pic = (pic790 *) pThis;
    UINT i, r;

    i = IntOff();

    r = TheHWPic->IrqEnable;
    r |= pic->IRQMask;
    TheHWPic->IrqEnable = r;

    SetPsr(i);
}

static const struct IPicVtbl picVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    EnableInterrupt,
    DisableInterrupt,
    MaskAll,
    UnmaskAll
};

pic790 ThePIC = {
    &picVtbl,
    0               /* IRQMask */
};

/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
    UnusedParameter(pThis);

    /* Enable all channels*/
    MaskAll(pThis);
}


IPic *PicCreate(void)
{
    IPic *pThis;

    pThis = (IPic *)&ThePIC;
    TheHWPic->IrqEnable = 0;            /* disable all interrupts */
    TheHWPic->Config0 = 0xFFFFFFFF;     /* set everything edge triggered, active high */
    TheHWPic->Clear = 0xFFFFFFFF;       /* clear all pending interrupts */

    return pThis;
}

/******************************************************************************/
/* Normal Interrupt Traps*/
/******************************************************************************/

/* PICGetInterrupt: This function acknowledges the highest priority*/
/* interrupt and returns the level of that interrupt.*/
int PICGetInterrupt(void)
{
    int b, picIndex;
    UINT16 picStatus;

    picStatus = TheHWPic->IrqStatus;

    /* Ignore pending interrupts handled by Angel.
     */
    picStatus &= ThePIC.IRQMask;

    if (picStatus) {
        switch (picStatus) {
        case IRQ_MASK_TIMER0:
            return IRQ_ID_TIMER0;
        case IRQ_MASK_TIMER1:
            return IRQ_ID_TIMER1;
        default:
            b = 1;
            for (picIndex = 0; picIndex < 12; ++picIndex) {
                if (b & picStatus)
                    return picIndex;
                b = b << 1;
            }
        }
    }

    return -1;
}

INLINE
void PICEndInterrupt(UINT irq)
{
    /* Needed only for edge triggered interrupts.
     */
    TheHWPic->Clear = 1 << irq;

    return;
}

#if !defined(ANGELX)

CXTINFO *TrapIRQ(CXTINFO *pContext)
{
    UINT32 DoReschedule;
    BOOL NotMyInterrupt;
    int Index;
    ITABLE *IntSource;

    pContext->PC -= 4;

    /* Try to handle all pending interrupts at once */
    DoReschedule = 0;
    while ( (Index=PICGetInterrupt())>0 )
    {
        IntSource=&ThePIC.InterruptTable[Index];

        if (IntSource->Isr) {
            DoReschedule |= (IntSource->Isr)(IntSource->pDevice, &NotMyInterrupt);
            PICEndInterrupt(Index);
        }
    }

    /* If any handlers requested a reschedule, it will get done */
    if (DoReschedule) {
        pContext = _Reschedule(pContext);
    }

    return pContext;
}

#else

UINT32  maxIrqTime = 0;
UINT32  minIrqTime = 0xFFFF;
UINT32  hiTime;
TIME    IrqStartTime = Int64Initializer(0, 0);
BOOL    IRQTracking = FALSE;

INT     IrqReenterCount = -1;
INT     maxIrqReenterCount;
UINT    startAngelTime;
UINT    maxUserAngel;

UINT    IrqChain;
UINT    IrqSimIRQ;
UINT    maxAngel;

UINT    AngelActive;
UINT    maxAngelActive;

CXTINFO *FromAngelIrq(CXTINFO *pContext)
{
    UINT32 stopAngelTime, elapsedTime;

    if ((0x80 & IntOff()) == 0)
        DebugBreak();

    --AngelActive;

    stopAngelTime = ReadCounter();
    elapsedTime = (UINT16) (startAngelTime - stopAngelTime);
    if (elapsedTime > maxUserAngel)
        maxUserAngel = elapsedTime;

    if (IRQTracking && 0 == IrqReenterCount) {
        static first = FALSE;
        TIME endTime;
        UINT32 elapsedTime;

        if (first) {
            first = FALSE;
        } else {
            endTime = GetKernelTime();
            endTime = TimeSubtract(endTime, IrqStartTime);
            hiTime |= Int64ToInt32(Int64RShift(endTime, 32));
            elapsedTime = Int64ToInt32(endTime);

            if (elapsedTime < minIrqTime) minIrqTime = elapsedTime;
            if (elapsedTime > maxIrqTime) maxIrqTime = elapsedTime;
        }
    }


    if ((0x80 & IntOff()) == 0)
        DebugBreak();

    --IrqReenterCount;

    return pContext;
}

void PICHandleAlternateIrq(CXTINFO *pContext)
{
    UINT16 picStatus;
    extern void SimulateAngelIRQ(CXTINFO *);
    extern void ToAngelIrqHandler(CXTINFO *);

    if ((0x80 & IntOff()) == 0)
        DebugBreak();

    picStatus = TheHWPic->IrqStatus;

    /* Pass all unhandled IRQ's to Angel.
     * N.B.  ChainException does not return.
     */
    if (picStatus & ~ThePIC.IRQMask) {
#if 0
--IrqReenterCount;
ChainException(pContext,0);
#endif
        if ((pContext->CPSR & 0x1f) == 0x13) {
            UINT32 start, end, elapsed;

            ++IrqSimIRQ;
            start = ReadCounter();
            SimulateAngelIRQ(pContext);     // This returns
            end = ReadCounter();
            elapsed = start - end;
            if (elapsed > maxAngel)
                maxAngel = elapsed;

            if ((0x80 & IntOff()) == 0)
                DebugBreak();
        } else {
            ++IrqChain;
#if 0
--IrqReenterCount;
ChainException(pContext,0);
#endif
            startAngelTime = ReadCounter();
            ++AngelActive;
            if (AngelActive > maxAngelActive)
                maxAngelActive = AngelActive;

            // THIS DOES NOT RETURN.  Control returns
            // to FromAngelIrq().
            ToAngelIrqHandler(pContext);
            DebugBreak();
        }
    }
}

CXTINFO *TrapIRQ(CXTINFO *pContext)
{
    UINT32 DoReschedule;
    BOOL NotMyInterrupt;
    int Index;
    ITABLE *IntSource;

    pContext->PC -= 4;

    /* No interrupt chaining allowed */
    ++IrqReenterCount;
    if (IrqReenterCount > maxIrqReenterCount)
        maxIrqReenterCount = IrqReenterCount;

    /* Try to handle all pending interrupts at once */
    DoReschedule = 0;
    while ( (Index=PICGetInterrupt())>0 )
    {
        IntSource=&ThePIC.InterruptTable[Index];

        if (IntSource->Isr) {
            DoReschedule |= (IntSource->Isr)(IntSource->pDevice, &NotMyInterrupt);
            PICEndInterrupt(Index);
        }
    }

    if (IRQTracking && 0 == IrqReenterCount)
        IrqStartTime = GetKernelTime();

    /* If any handlers requested a reschedule, it will get done */
    if (DoReschedule) {
        if (0 == IrqReenterCount) {
            pContext = _Reschedule(pContext);
        } else {
            static TIME t = Int64Initializer(0,TIME_MICROS(500));

            SetNextInterrupt(t, NULL);
        }
    }

    /* Won't return if any alternate IRQ (e.g one of Angel's) needs servicing. */
    PICHandleAlternateIrq(pContext);

    if (IRQTracking && 0 == IrqReenterCount) {
        static first = FALSE;
        TIME endTime;
        UINT32 elapsedTime;

        if (first) {
            first = FALSE;
        } else {
            endTime = GetKernelTime();
            endTime = TimeSubtract(endTime, IrqStartTime);
            hiTime |= Int64ToInt32(Int64RShift(endTime, 32));
            elapsedTime = Int64ToInt32(endTime);

            if (elapsedTime < minIrqTime) minIrqTime = elapsedTime;
            if (elapsedTime > maxIrqTime) maxIrqTime = elapsedTime;
        }
    }

    --IrqReenterCount;

    return pContext;
}

UINT32 MaskAllIRQ(void)
{
    UINT32 s;

    if (IRQMaskState == Disabled)
        return Disabled;

    MaskAll((IPic *) &ThePIC);

    s = IRQMaskState;
    IRQMaskState = Disabled;

    return s;
}

void RestoreAllIRQMask(UINT32 s)
{
    assert(s == Disabled || s == Enabled);
    assert(IRQMaskState == Disabled);

    if (s == Enabled) {
        IRQMaskState = Enabled;
        UnmaskAll((IPic *) &ThePIC);
    }
}

void UnmaskAllIRQ(void)
{
    if (IRQMaskState == Disabled) {
        IRQMaskState = Enabled;
        UnmaskAll((IPic *) &ThePIC);
    }
}
#endif
