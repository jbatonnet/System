/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>
//#include <stdio.h>
//#include <assert.h>
#include "_cons.h"

extern void BaseDelete(void);

/* Hardware descriptors have alignment needs */
#pragma  pack(1)

#include "_dosx.h"

#define SHRINK 1

/* This is to help the linker.
 */
#pragma warning(disable:4214)
typedef struct {
        UINT32  offset;
        UINT16  word_count : 5,
                xxxx : 3,
                type : 4,
                mbz : 1,
                dpl : 2,
                present : 1;
        SELECTOR selector;
} LINKTIME_GATEDESCRIPTOR;

/*
 * Static interrupt handlers
 */
extern void __cdecl ReflectInterrupt(void);
extern void __cdecl RTCInterrupt(void);
#ifdef USE_OLD_PIC
extern void __cdecl SchedulingInterrupt(void);
#endif
extern void __cdecl BadInstructionInterrupt(void);
extern void __cdecl InterruptWithCode(void);

/* See ReflectInterrupt below
 */
#define OFFSETOF_INTR(_i_) (((_i_) * 4) + (8 * ((_i_) / 32)))
#define Reflect(_n_) (((ADDRESS) ReflectInterrupt) + OFFSETOF_INTR(_n_))

/*
 * Interrupt Descriptor Table
 */
#define SEG_IC      2  /* see dosxtndr.asm */
#define SEG_G_IC { X86_PRIV_KERNEL, X86_TI_GDT, SEG_IC }
#define I(_f_) { ((UINT32)(_f_)), 0, 0, I386_A_INT_GATE, \
                      0, X86_PRIV_USER, 1, SEG_G_IC }

/* NOTE: PIC vectors 8,70 --> int2..9,int28..35
 */
#define PIC0_FIRST 8
#define PIC1_FIRST 28

#if SHRINK
#define INITIAL_IDTS    36
#else
#define INITIAL_IDTS    120
#endif

LINKTIME_GATEDESCRIPTOR idt_data[INITIAL_IDTS + 1] = {
I(0),                      /* 0 zero divide */
I(0),                      /* 1 single step */
I(0),                      /* 2 nmi */
I(0 /*BadInstructionInterrupt*/ ),/* 3 bpt */
I(0),                      /* 4 into */
I(0),                      /* 5 bounds */
I(0),                      /* 6 illegal instr */
I(0),                      /* 7 fp */
#ifdef USE_OLD_PIC
I(SchedulingInterrupt),    /* 8 double fault IRQ0: timer tick */
#else
I(0),    /* 8 double fault IRQ0: timer tick */
#endif
I(0),                      /* 9 seg overrun  IRQ1: keyboard */
I(0),                      /* 10 bad tss     IRQ2: slave PIC */
I(0),                      /* 11 seg fault   IRQ3: com2 */
I(0),                      /* 12 stack fault IRQ4: com1 */
I(InterruptWithCode),      /* 13 gp          IRQ5: network */
I(0),                      /* 14 page fault  IRQ6: floppy */
I(0),                      /* 15 undefined   IRQ7: lpt */
I(0),                      /* 16 fp error */
I(0),                      /* 17 486 unaligned */
I(0),                      /* 18 586 machine check */
I(0),                      /* 19 */
I(0),                      /* 20 */
I(0),                      /* 21 */
I(0),                      /* 22 */
I(0),                      /* 23 */
I(0),                      /* 24 */
I(0),                      /* 25 */
I(0),                      /* 26 */
I(0),                      /* 27 */
I(0),                      /* 28 not -- IRQ8:  rtc*/
I(0),                      /* 29 not -- IRQ9:  video retrace*/
I(0),                      /* 30 not -- IRQ10: */
I(0),                      /* 31 not -- IRQ11: */
I(0),                      /* 32 not -- IRQ12: mouse */
I(0),                      /* 33 not -- IRQ13: x87 */
I(0),                      /* 34 not -- IRQ14: IDE */
#if SHRINK
I(0)                       /* 35 not -- IRQ15: anything goes...*/
#else
I(0),                      /* 35 not -- IRQ15: anything goes...*/
I(0),                      /* 36 */
I(0),                      /* 37 */
I(0),                      /* 38 */
I(0),                      /* 39 */
/*  40 */ I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),
/*  50 */ I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),
/*  60 */ I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),
/*  70 */ I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),
/*  80 */ I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),
/*  90 */ I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),
/* 100 */ I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),I(0),
/* 110 */ I(0),I(0),I(0/*RTCInterrupt*/),I(0),I(0),I(0),I(0),I(0),I(0),I(0)
#endif
};

IDT_POINTER idt = {
        INITIAL_IDTS * sizeof(I386_GATE_DESCRIPTOR) - 1,
        (UINT32) idt_data };

/*
 * This is to help the linker.
 * At runtime we swap OFFSET's high word with SELECTOR.
 */
static void SwapIdtEntries(
        I386_GATE_DESCRIPTOR *d,
        unsigned int n)
{
        register union u {
                SELECTOR s;
                UINT16 i;
        } t0, t1;

        while (n--) {
                t0.s = d->selector;
                t1.i = d->offset_16_31;
                d->selector = t1.s;
                d->offset_16_31 = t0.i;
                d++;
        }
}  
#pragma warning(default:4214)

/*
 * Initialization
 */
void IdtCreate(void)
{
    UINT32 LinearAddressOfZero;
    UINT i;

    /*
     * IDT and GDT must be linear addresses
     */
    LinearAddressOfZero = ((PDOSX_INTERFACE) DosxPointer())->RelocationBase;
    idt.base_0_31 += LinearAddressOfZero;

    /*
     * Cover for compilerbug.  Somewhere in the assembly pass it
     * turns an initializer like "_foo+4" into "_foo". Umbug.
     */
    for (i = 0; i < INITIAL_IDTS; i++)
        if (idt_data[i].offset == 0)
            idt_data[i].offset = Reflect(i);

    /*
     * Fix descriptors from linktime to runtime rep
     */
    SwapIdtEntries( (I386_GATE_DESCRIPTOR*) idt_data,
               INITIAL_IDTS);

    /* Now switch to our IDT
     */
    __asm {
        lidt idt;       /* switch to our IDT */
        xor  eax,eax;   /* invalid LDT for now */
        lldt ax;
    }
}

/* Install/Remove an interrupt handler entry
 */
void InstallIsr( UINT InterruptNumber, ADDRESS Isr,
                UINT RawTrapNumber, UINT UserAccessible)
{
    static LINKTIME_GATEDESCRIPTOR Template =
           { 0, 0, 0, I386_A_INT_GATE, 0, X86_PRIV_KERNEL, 1, SEG_G_IC };
    LINKTIME_GATEDESCRIPTOR e;
    UINT Eflags;

    /* Prepare the new entry
     */
    e = Template;
    e.offset = Isr;
    if (UserAccessible)
        e.dpl = X86_PRIV_USER;
    else
        e.dpl = X86_PRIV_KERNEL;
    SwapIdtEntries( (I386_GATE_DESCRIPTOR*) &e, 1);

    /* Which IDT entry
     */
    if (RawTrapNumber == FALSE) {
        if (InterruptNumber < 8)
            InterruptNumber += PIC0_FIRST;
        else
            InterruptNumber += PIC1_FIRST;
    }

    /* Removing an ISR means go back to reflecting it
     */
    if (Isr == (ADDRESS)0)
        Isr = (ADDRESS)Reflect(InterruptNumber);

    /* Save IF state, turn interrupts off.
     */
    TURN_INTERRUPTS_OFF(Eflags);

    /* Set the new entry
     */
    idt_data[ InterruptNumber ] = e;

    /* Turn IF back on, ifso
     */
    RESTORE_INTERRUPTS(Eflags);
}

/* Reflect back to DOS/BIOS an interrupt we dont handle
 */
UINT nReflected = 0;

static void __cdecl ReflectIt(UINT IntNo)
{
#if SHRINK
#else
    static
#endif
//    DOSX_CALLBACK_ARGUMENTS Regs; /* dont care */

#ifdef _DEBUG
printf("{INT%d}", IntNo);
#endif
//    SafelyCallback( IntNo, &Regs, &Regs );
}

void __cdecl BiosTick(void)
{
//    DOSX_CALLBACK_ARGUMENTS Regs; /* dont care */

//    SafelyCallback( 28, &Regs, &Regs );
}

static void __cdecl DumpIt(UINT IntNo, PCXTINFO c, BOOL StopIt, UINT32 ErrorCode)
{
    UINT32 faultaddr;

    __asm {
        mov eax, cr2;
        mov faultaddr, eax;
    }
#ifdef _DEBUG
#ifdef _MSC_VER
#pragma warning(disable:6064)   /* deviant printf */
#endif


    printf("CONTEXT DUMP: Int%d err=%x cr2=%x Cxt=%p\npFpa=%p edi=%x esi=%x ebp=%x pad=%x ebx=%x edx=%x ecx=%x eax=%x\nfs=%x gs=%x es=%x ds=%x EIP=%x cs=%x efl=%x (esp=)%x (ss=)%x (..)%x\n%x %x %x %x %x %x %x %x   %x %x %x %x %x %x %x %x\n%x %x %x %x %x %x %x %x   %x %x %x %x %x %x %x %x\n%x %x %x %x %x %x %x %x   %x %x %x %x %x %x %x %x\n",
           IntNo, ErrorCode, faultaddr, c,
           c->pFpa, c->EDI, c->ESI, c->EBP, c->PAD, c->EBX, c->EDX, c->ECX, c->EAX,
           c->FS, c->GS, c->ES, c->DS,
           c->EIP, c->CS, c->EFL, c->ESP, c->SS, *(UINT32*)(c+1));
#else
    UnusedParameter(c);
    UnusedParameter(ErrorCode);
#endif
    if (StopIt || IntNo == 14 || IntNo == 13 || !StopIt) /* BUGBUG: prot fault */
        BaseDelete();
}

/* Dispatching code for reflector.
 * Notice we only handle upto 124.
 * Interrupts come in skewed by their IRQ number.
 */
#define INTR0(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch0 }
#define INTR1(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch1 }
#define INTR2(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch2 }
#define INTR3(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch3 }

__declspec(naked) void __cdecl ReflectInterrupt(void)
{
    INTR0( 0); INTR0( 1); INTR0( 2); INTR0( 3);
    INTR0( 4); INTR0( 5); INTR0( 6); INTR0( 7);
    INTR0( 8); INTR0( 9); INTR0(10); INTR0(11);
    INTR0(12); INTR0(13); INTR0(14); INTR0(15);
    INTR0(16); INTR0(17); INTR0(18); INTR0(19);
    INTR0(20); INTR0(21); INTR0(22); INTR0(23);
    INTR0(24); INTR0(25); INTR0(26); INTR0(27);
    INTR0(28); INTR0(29); INTR0(30); INTR0(31);
 Dispatch0:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR1(32); INTR1(33); INTR1(34); INTR1(35);
#if SHRINK
 Dispatch1:
#else
    INTR1(36); INTR1(37); INTR1(38); INTR1(39);
    INTR1(40); INTR1(41); INTR1(42); INTR1(43);
    INTR1(44); INTR1(45); INTR1(46); INTR1(47);
    INTR1(48); INTR1(49); INTR1(50); INTR1(51);
    INTR1(52); INTR1(53); INTR1(54); INTR1(55);
    INTR1(56); INTR1(57); INTR1(58); INTR1(59);
    INTR1(60); INTR1(61); INTR1(62); INTR1(63);
 Dispatch1:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR2(64); INTR2(65); INTR2(66); INTR2(67);
    INTR2(68); INTR2(69); INTR2(70); INTR2(71);
    INTR2(72); INTR2(73); INTR2(74); INTR2(75);
    INTR2(76); INTR2(77); INTR2(78); INTR2(79);
    INTR2(80); INTR2(81); INTR2(82); INTR2(83);
    INTR2(84); INTR2(85); INTR2(86); INTR2(87);
    INTR2(88); INTR2(89); INTR2(90); INTR2(91);
    INTR2(92); INTR2(93); INTR2(94); INTR2(95);
 Dispatch2:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR3(96); INTR3(97); INTR3(98); INTR3(99);
    INTR3(100); INTR3(101); INTR3(102); INTR3(103);
    INTR3(104); INTR3(105); INTR3(106); INTR3(107);
    INTR3(108); INTR3(109); INTR3(110); INTR3(111);
    INTR3(112); INTR3(113); INTR3(114); INTR3(115);
    INTR3(116); INTR3(117); INTR3(118); INTR3(119);
    INTR3(120); INTR3(121); INTR3(122); INTR3(123);
    INTR3(124); INTR3(125); INTR3(126); INTR3(127);
 Dispatch3:
    __asm {
    }
#endif

 Dispatch:
    __asm {
        /* On stack we have:
         * (high)
         *              saved SS     only if from user level  ;; 32bits
         *              saved ESP    only if from user level  ;; 32bits
         *              saved EFLAGS     ;; 32bits
         *              saved CS         ;; 32bits
         *              saved eip        ;; 32bits
         * esp->        intrNo           ;; 32bits
         *
         */
        inc nReflected;

        /* ds slot is occupied by intrNo */
        push es;
        push gs;
        push fs;
        pushad;         /* eax, ecx, edx, ebx, bogus esp, ebp, esi, edi */
        push 0;         /* pFpa */

        /* Finally put ds where it belongs and get the code out */
        mov ax, ds;
        xchg [esp+48], eax;

#if 1
        /* Set segment registers to ring0 conventions */
        mov  dx,ss;
        mov  ds,dx;   /* Reference kernel data */
        mov  es,dx;   /* Reference kernel data */
        xor  dx,dx;
        mov  fs,dx;   /* Zapped */
        mov  gs,dx;   /* Zapped */
#endif

#if (!SHRINK || _DEBUG)
        mov     esi,esp;        /* save pCxt in callee saved register */
        push eax                /* Push IntNo for ReflectIt */
        push    0;              /* ErrorCode */
        push    0;              /* StopIt */
        push    esi;            /* pCxt */
        push    eax;            /* IntNo */
        call    DumpIt;
        add     esp,16;         /* pop two args, leave IntNo as arg */
#else
        mov     esi, esp;       /* save pCxt in callee saved register */
        push    eax;
#endif
        call    ReflectIt;
        push    esi;
        call HWLoadThreadContext;
        int 3;
    }
}

/* Bad instruction executed.
 * Dump Context.
 */
__declspec(naked) void __cdecl InterruptWithCode()
{
    /* On stack we have:
     * (high)
     *              saved SS     only if from user level  ;; 32bits
     *              saved ESP    only if from user level  ;; 32bits
     *              saved EFLAGS     ;; 32bits
     *              saved CS         ;; 32bits
     *              saved eip        ;; 32bits
     * esp->        Error code       ;; 32bits
     */
    __asm {
        /* push ds;   occupied by error code */
        push es;
        push gs;
        push fs;
        pushad;         /* eax, ecx, edx, ebx, bogus esp, ebp, esi, edi */
        push 0;         /* pFpa */

        /* Finally put ds where it belongs and get the code out */
        mov ax, ds;
        xchg [esp+48], eax;

#if 1
        /* Set segment registers to ring0 conventions */
        mov  dx,ss;
        mov  ds,dx;   /* Reference kernel data */
        mov  es,dx;   /* Reference kernel data */
        xor  dx,dx;
        mov  fs,dx;   /* Zapped */
        mov  gs,dx;   /* Zapped */
#endif

        mov esi,esp;    /* save pCxt in callee saved register */

        push eax;       /* ErrorCode */
        push 1;         /* StopIt */
        push esi;       /* pCxt */
        push 666;       /* IntNo */

        call    DumpIt;

        push ebx;
        call HWLoadThreadContext;
        int 3;
    }
}

