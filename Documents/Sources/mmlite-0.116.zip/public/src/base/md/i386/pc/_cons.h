/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Specifications for machine-dependent object constructors.
 */

extern void IdtCreate(void);
extern void GateA20(BOOL enable);
