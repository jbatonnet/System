/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __irq_h_
#define __irq_h_

/* SA's Interrupt controller
 */
struct _TheHWPic
{
    volatile UINT32  IrqPending;
    volatile UINT32  Mask;
    volatile UINT32  Level;
    volatile UINT32  Control;
    volatile UINT32  FiqPending;
             UINT32  Reserved[3];
    volatile UINT32  Pending;
};
#define TheHWPic ((struct _TheHWPic *)0x90050000)

/* Some interrupts come from the GPIO registers
 */
struct _GPIO {
    volatile UINT32 Level;
    volatile UINT32 Direction;
    volatile UINT32 Set;
    volatile UINT32 Clear;
    volatile UINT32 DetectRaising;
    volatile UINT32 DetectFalling;
    volatile UINT32 DetectStatus;
    volatile UINT32 Alternate;
};

#define GPIO ((struct _GPIO *)0x90040000)



#endif /* __irq_h_*/
