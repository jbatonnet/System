/* Copyright (c) Microsoft Corporation. All rights reserved. */

#include "sci.h"

#define NULL ((void *)0)

void Sci_WriteStr(char *s)
{
	while(*s)
		Sci_WriteChar(*s++);
}

static void Sci_WriteHex4bit(unsigned char n)
{
	if (n < 10) {
		n += '0';
	} else {
		n += 'A' - 10;
	}
	Sci_WriteChar(n);
}

void Sci_WriteHexByte(unsigned char n)
{
	Sci_WriteHex4bit((n & 0xf0) >> 4);
	Sci_WriteHex4bit(n & 0x0f);
}

void Sci_WriteHexShort(unsigned short n)
{
	Sci_WriteHexByte((n >> 8) & 0xff);
	Sci_WriteHexByte(n & 0xff);
}

void Sci_WriteHexLong(unsigned long n)
{
	Sci_WriteHexShort((n >> 16) & 0xffff);
	Sci_WriteHexShort(n & 0xffff);
}

int Sci_ReadStr(char *buff, unsigned int bufflen)
{
	unsigned char c;
	int ret = 0;
	
	for(;;) {
		c = Sci_ReadChar();
		if (bufflen) {
			*buff++ = c;
			bufflen--;
			ret++;
			if (bufflen == 0) {
				break;
			}
		}
		
		if (c == '\r') {
			break;
		}
	}

	return ret;
}

void Sci_WaitEnter(void)
{
	Sci_WriteStr("\r\n[Enter]\r\n");
	Sci_ReadStr(NULL,0);
}
