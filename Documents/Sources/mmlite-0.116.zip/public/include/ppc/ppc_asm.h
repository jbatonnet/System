/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* Offsets in the CXTINFO structure
 */
#define CXT_GPR      (0 * 8)
#define CXT_LR       (32 * 8)
#define CXT_PC       (33 * 8)
#define CXT_CTR      (34 * 8)
#define CXT_CR       (35 * 8)
#define CXT_XER      (36 * 8)
#define CXT_MSR      (37 * 8)
#define CXT_SIZE     (38 * 8)

#define _EQU             EQU

SIZEOF_CXTINFO  _EQU CXT_SIZE
CXTLR  _EQU CXT_LR
CXTPC  _EQU CXT_PC
CXTCR  _EQU CXT_CR
CXTCTR _EQU CXT_CTR
CXTXER _EQU CXT_XER
CXTMSR _EQU CXT_MSR
CXTR0  _EQU (0 * 8)+CXT_GPR
CXTR1  _EQU (1 * 8)+CXT_GPR
CXTR2  _EQU (2 * 8)+CXT_GPR
CXTR3  _EQU (3 * 8)+CXT_GPR
CXTR4  _EQU (4 * 8)+CXT_GPR
CXTR5  _EQU (5 * 8)+CXT_GPR
CXTR6  _EQU (6 * 8)+CXT_GPR
CXTR7  _EQU (7 * 8)+CXT_GPR
CXTR8  _EQU (8 * 8)+CXT_GPR
CXTR9  _EQU (9 * 8)+CXT_GPR
CXTR10 _EQU (10 * 8)+CXT_GPR
CXTR11 _EQU (11 * 8)+CXT_GPR
CXTR12 _EQU (12 * 8)+CXT_GPR
CXTR13 _EQU (13 * 8)+CXT_GPR
CXTR14 _EQU (14 * 8)+CXT_GPR
CXTR15 _EQU (15 * 8)+CXT_GPR
CXTR16 _EQU (16 * 8)+CXT_GPR
CXTR17 _EQU (17 * 8)+CXT_GPR
CXTR18 _EQU (18 * 8)+CXT_GPR
CXTR19 _EQU (19 * 8)+CXT_GPR
CXTR20 _EQU (20 * 8)+CXT_GPR
CXTR21 _EQU (21 * 8)+CXT_GPR
CXTR22 _EQU (22 * 8)+CXT_GPR
CXTR23 _EQU (23 * 8)+CXT_GPR
CXTR24 _EQU (24 * 8)+CXT_GPR
CXTR25 _EQU (25 * 8)+CXT_GPR
CXTR26 _EQU (26 * 8)+CXT_GPR
CXTR27 _EQU (27 * 8)+CXT_GPR
CXTR28 _EQU (28 * 8)+CXT_GPR
CXTR29 _EQU (29 * 8)+CXT_GPR
CXTR30 _EQU (30 * 8)+CXT_GPR
CXTR31 _EQU (31 * 8)+CXT_GPR

MSR_EE_MASK _EQU 08000H
MSR_RI_MASK _EQU   00002H
MSR_EERI_MASK _EQU 08002H

/*
 * Macro definitions for compatibility among assembly tools
 */
#define _IMPORT(n)       EXTRN n:NEAR
#define _EXPORT(n)       PUBLIC n

#define ENTRY(_name_) _name_ PROC
#define END(_name_) _name_ ENDP

#define _FUNCTION(n)     n LABEL NEAR

#define _F(n)            n
#define _L(n)            n
#define _LABEL(n)        n##:

/* Sometimes used to identify the entry-point to an executable image */
#define _ENTRY

#define _ORG(h)          ORG h

#define _CODESEG(n)      n SEGMENT PARA 'CODE'
#define _ENDSEG(n)       n ENDS

#define _CODE(x)         _CODESEG(_TEXT)
#define _ENDCODE         _ENDSEG(_TEXT)

#define _BSS(n,s)        COMM n:byte:s
#define _ENDBSS

#define _DATA(x)         _DATA SEGMENT PARA 'DATA'
#define _ENDDATA         _ENDSEG(_DATA)

#define _DCD             .int /* BUGBUG */
#define _SKIP            .skip  /* BUGBUG */
/* .align would work also methinks */
#define _ALIGN(n)        .balign n  /* BUGBUG */

#define _END             END
