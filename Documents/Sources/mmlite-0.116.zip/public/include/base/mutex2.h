/* Header file for src/base/mutex2.c
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef _OLDSCHED

#ifndef __MUTEX2_H__
#define __MUTEX2_H__

#include <util/list-single.h>
#include <base/kconstraint2.h>

/* Mutex is a concrete class (doesn't have a vtbl)
 * pSchedObject points to the scheduler object that owns the mutex.
 * The list of waiters hangs off of owner's thread structure (see thread.c).
 * If a thread owns more then one mutex the list contains all threads waiting
 * on all mutexes.  The LSB of pThdOwner is set if the list is not empty.  
 * That causes Mutex_Unlock to call the scheduler, which wakes up all waiters.
 */
typedef struct _MX { /* Internal definition */
  PTR  pSchedObject; /* Owner, or NULL if free. */
  LIST lWaiterQueue;
  NODE nListNode;
} MX, *PMX;

#define pMX(_pMutex_) ((PMX)(_pMutex_))

#if _UINTSIZE == 16
#define BAD_MUTEX 0xFFFF
#elif _UINTSIZE == 32
#define BAD_MUTEX 0xFFFFBAD0
#elif _UINTSIZE == 64
#define BAD_MUTEX 0xFFFFFFFFFFFFBAD0
#endif

#ifdef _DEBUG
/* This debug mechanism allows us to force the debugger into explicitly using
 * the private MX kernel struct so we can see its members.
 * MutexPrologue must be after all variable declarations but before any
 * statements.
 */
#define Mutex_Prologue() PMX pMXProxy = pMX(pMutex)
#define pMutexArg pMXProxy
#else
#define Mutex_Prologue()
#define pMutexArg pMutex
#endif /* _DEBUG */

#define /* PTR */                                                             \
Mutex_GetSchedObject(/* PMUTEX */ _pm_)                                       \
     ((PTR)((UINT)pMX(_pm_)->pSchedObject & ~1))

#define /* PTR */                                                             \
Mutex_GetSchedObjectAddr(/* PMUTEX */ _pm_)                                   \
     (&(pMX(_pm_)->pSchedObject))

#define /* void */                                                            \
Mutex_SetSchedObject(/* PMUTEX */ _pm_,                                       \
                    /* PTR */ _pSchedObject_)                                 \
     (pMX(_pm_)->pSchedObject = (PTR)(_pSchedObject_))

#define /* PLIST */                                                           \
Mutex_GetWaiterQueue(/* PMUTEX */ _pm_)                                       \
     &(pMX(_pm_)->lWaiterQueue)

#define /* void */                                                            \
Mutex_WaiterQueueAddConstraint(/* PMUTEX */ _pm_,                             \
                              /* PKCONSTRAINT */ _pkc_)                       \
    List_InsertSortedDescending(Mutex_GetWaiterQueue(_pm_),                  \
                                 KConstraint_UrgencyGT,                       \
                                 KConstraint_GetWaitQueueNode(_pkc_))

#define /* void */                                                            \
Mutex_WaiterQueueInit(/* PMUTEX */ _pm_)                                      \
    List_Init(Mutex_GetWaiterQueue(_pm_))

#define /* void */                                                            \
Mutex_WaiterQueueClear(/* PMUTEX */ _pm_)                                     \
    List_Clear(Mutex_GetWaiterQueue(_pm_))

#define /* BOOL */                                                            \
Mutex_WaiterQueueIsEmpty(/* PMUTEX */ _pm_)                                   \
    List_IsEmpty(Mutex_GetWaiterQueue(_pm_))

#define /* BOOL */                                                            \
Mutex_IsBad(/* PMUTEX */ _pm_)                                                \
    ((INT)Mutex_GetSchedObject(_pm_) == BAD_MUTEX)

#define /* void */                                                            \
Mutex_SetBad(/* PMUTEX */ _pm_)                                               \
    (Mutex_SetSchedObject(_pm_, BAD_MUTEX))

/* #define /\* BOOL *\/                                                            \ */
/* Mutex_IsTaken(/\* PMUTEX *\/ _pm_)                                              \ */
/*      (((UINT)(pMX(_pm_)->pSchedObject) & 1) == 1) */

#define /* BOOL */                                                            \
Mutex_SetTaken(/* PMUTEX */ _pm_)                                             \
    ((pMX(_pm_)->pSchedObject) = (PTR)((UINT)(pMX(_pm_)->pSchedObject) | 1))

/* #define /\* BOOL *\/                                                            \ */
/* Mutex_ClearTaken(/\* PMUTEX *\/ _pm_)                                           \ */
/*      ((pMX(_pm_)->pSchedObject) = (PTR)((UINT)(pMX(_pm_)->pSchedObject) & ~1)) */

#define /* PNODE */                                                          \
Mutex_GetListNode(/* PMUTEX */ _pm_)                                          \
     &(pMX(_pm_)->nListNode)

#define /* void */                                                            \
Mutex_ListNodeInit(/* PMUTEX */ _pm_)                                         \
     Node_Init(Mutex_GetListNode(_pm_), (_pm_))

#define /* PKCONSTRAINT */                                                    \
Mutex_WaiterQueueRemoveMostUrgentConstraint(/* PMX */ _pm_)                   \
     Node_GetData(List_HeadRemove(Mutex_GetWaiterQueue(_pm_)))

#define /* void */                                                            \
Mutex_WaiterQueueRemoveConstraint(/* PMX */ _pm_,                             \
                                 /* PKCONSTRAINT */ _pkc_)                    \
     List_FindDataAndRemove(Mutex_GetWaiterQueue(_pm_), (_pkc_))

#endif /* __MUTEX2_H__ */

#endif /* _OLDSCHED */
