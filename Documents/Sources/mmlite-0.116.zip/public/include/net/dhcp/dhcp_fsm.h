/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _DHCP_FSM_H_
#define _DHCP_FSM_H_

/*
 * DHCP finite state machine states.
 * We combine the "Init-Reboot" state with the "Init" state and invent
 * the "Closed" state.
 *
 * Note: The draft spec does not specify numbers for the states, just names.
 */

#define DHCP_NSTATES 8

#define DHCPS_INIT       0   /* initialization (or lease expired) */
#define DHCPS_SELECTING  1   /* bcast discover; selecting from recv'd offers */
#define DHCPS_REBOOTING  2   /* sent [reuse] request; awaiting DHCPACK */
#define DHCPS_REQUESTING 3   /* bcast request; awaiting DHCPACK */
/* states < DHCPS_BOUND are those where we don't have a valid lease */
#define DHCPS_BOUND      4   /* normal operation */
#define DHCPS_RENEWING   5   /* T1 expired, sent request; awaiting DHCPACK */
#define DHCPS_REBINDING  6   /* T2 expired, bcast request; awaiting DHCPACK */
#define DHCPS_CLOSED     7   /* deliberately released our lease */

#ifdef WANT_DHCP_STATE_NAMES
char *DhcpStates[] = {
    "INIT", "SELECTING", "REBOOTING", "REQUESTING", "BOUND",
    "RENEWING", "REBINDING", "CLOSED",
};
#endif

#endif /* _DHCP_FSM_H_ */
