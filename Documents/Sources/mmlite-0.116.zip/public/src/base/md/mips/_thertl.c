/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <tchar.h>      /* for StrFormat */
#include <wchar.h>      /* for wprintf, wcstol, etc */
#include <stdlib.h>
#include <base/cons.h>

struct BASERTL {
    const struct IBaseRtlVtbl *v;
    UINT RefCnt;
};

SCODE BaseRtlQueryInterface(PIBASERTL This, REFIID Iid, void **ppObject)
{
    UnusedParameter(This);
    UnusedParameter(Iid);
    UnusedParameter(ppObject);
    return E_NOT_IMPLEMENTED;
}

UINT BaseRtlAddRef(PIBASERTL This)
{
    UnusedParameter(This);
    return 1;
}

UINT BaseRtlRelease(PIBASERTL This)
{
    UnusedParameter(This);
    return 1;
}

#include "s_BaseRtl_v.c"
static const struct BASERTL _TheRtlObject = { &BaseRtlVtbl, 1 };
typedef ADDRESS *PADDRESS;
const PADDRESS RtlTable = (PADDRESS) &_TheRtlObject;

const PIBASERTL pTheBaseRtl = (PIBASERTL) &_TheRtlObject;
