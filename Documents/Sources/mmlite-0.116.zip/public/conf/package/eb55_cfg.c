/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>
#include <drivers/serp.h>

#define isSEAL 1
#define USE_SERPLEX 1

const DRIVER_CONFIG DriverConfigs[] = {
  {_T("null"), _T("COB/null.cob"), 0, },

  {_T("com1"), _T("COB/eb63usart.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_LEVEL_TRIGGER|DEVICE_FLAGS_POSITIVE_LEVEL, 0xfffc0000, 2, NULL, NULL, 38400, },
  {_T("com2"), _T("COB/eb63usart.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_LEVEL_TRIGGER|DEVICE_FLAGS_POSITIVE_LEVEL, 0xfffc4000, 3, NULL, NULL, 38400, },
  /* the third m63200 serial line (0xfffc8000,4) is not connected */

#if USE_SERPLEX
  /* Console, hostfs and sernet share one serial port. Run serplexd.exe on NT side. */
  {_T("serplex6a"), _T("COB/serplex.cob"), DEVICE_FLAGS_MANUAL_START | DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, FSSerplexAddr, },
  {_T("srfs"), _T("COB/hostfs.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("serplex6a"), },

  /* secure channel */
  {_T("serplex6d"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com2"), NULL, 0, NICSerplexAddr, },
  {_T("sr0"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6d"), _T("192.168.0.0"),},
#if !isSEAL
  /* public channel */
  {_T("serplex6b"), _T("COB/serplex.cob"), DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, NICSerplexAddr, },
  {_T("sr1"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER | DEVICE_FLAGS_INTERRUPTS, 0, 0,
              _T("serplex6b"), NULL,},
#endif

  {_T("serplex6c"), _T("COB/serplex.cob"), DEVICE_FLAGS_MANUAL_START | DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, CONSerplexAddr, },

#else
  /* Run hostfsd.exe on NT side */
  {_T("serplex6a"), _T("COB/serplex.cob"), DEVICE_FLAGS_MANUAL_START | DEVICE_FLAGS_NO_THREAD, 0, 0,
              _T("com1"), NULL, 0, FSSerplexAddr, },
  /* Without serplex. Must run hostnic.exe on NT side */
  {_T("sr0"), _T("COB/sernet.cob"), DEVICE_FLAGS_NET_DRIVER, 0, 0, _T("com1"), },
#endif

  {NULL,}    
};
