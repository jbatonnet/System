/* Copyright (c) Microsoft Corporation. All rights reserved. */


#ifndef __TCPSERVER__
#define __TCPSERVER__


#include <mmlite.h>
#include <netif.h>
#include <util/list-double2.h>
#include <wsif.h>
#include <soapif.h>
#include <httpif.h>
#include <winsock.h>
#include <web/ssoap.h>

#define MAXENDP 10
typedef struct _TcpServer {
    struct IListenerVtbl const *  v;
    UINT Refs;

    MUTEX mx;
    CONDITION cd;

    UINT Count;
    UINT inuse;
    PIENDPOINT eps[MAXENDP];
    PARSE_URL_FLAGS flags[MAXENDP];
    PIUNKNOWN keys[MAXENDP];
    ENDPOINT_REQ_TYPES reqs[MAXENDP];
    TIME timeouts[MAXENDP];
    TIME NextTimeout;

    SESSIONKEY SKey;
    BOOL isSKeyValid;
    PINAMESPACE NameSpace;
} TcpServer;

#endif /* __TCPSERVER__ */
