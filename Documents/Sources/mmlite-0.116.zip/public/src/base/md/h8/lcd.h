/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef _LCD_H_
#define _LCD_H_

void Lcd_Init(void);
void Lcd_Locate(unsigned char x, unsigned char y);
void Lcd_WriteChar(unsigned char c);
void Lcd_WriteStr(char *s);

void Lcd_WriteHexByte(unsigned char n);
void Lcd_WriteHexShort(unsigned short n);
void Lcd_WriteHexLong(unsigned long n);

#endif

