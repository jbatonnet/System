/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * This file provides an IModule interface to the NT loader.
 * It allows dynamic linking with external NT libraries from within
 * the MMLite loader in a simulated environment (that is, MMLite is
 * running as an NT process).
 */

#include <import_windows.h>
#include <mmlite.h>
#include <tchar.h>
#include <stdio.h>
#include <assert.h>

#define printf NT_printf
EXTERN_C INT __cdecl NT_printf(const char *format, ...);

typedef struct {
    CONST_VTBL struct IModuleVtbl *v; /* Our primary methods table   */
    UINT  RefCnt;         /* Reference count for this object         */

    _TCHAR * pName;
    HMODULE Handle;

} NTMODULE, *PNTMODULE;
#define pMD(_x_) ((PNTMODULE)_x_)
#define iMD(_x_) ((PIMODULE)_x_)

PRIVATE SCODE MCT NMQueryInterface (
            IModule *pThis,
            /* [in] */ REFIID pIid,
            /* [out] */ void **ppObject)
{
    return GenericQueryInterface((IUnknown *)pThis,pIid,ppObject,&IID_IModule);
}

PRIVATE UINT MCT NMAddRef (
            IModule *pThis)
{
    UINT RefCnt;

    RefCnt = AtomicInc(&pMD(pThis)->RefCnt);

    return RefCnt;
}

PRIVATE UINT MCT NMRelease (
            IModule *pThis)
{
    UINT RefCnt;
    PNTMODULE pMod = pMD(pThis);

    RefCnt = AtomicDec(&pMD(pThis)->RefCnt);

    if (RefCnt == 0) {
        FreeLibrary(pMod->Handle);
        CurrentHeap()->v->Free(CurrentHeap(),0,pMod);
    }

    return RefCnt;
}

PRIVATE SCODE MCT NMGetFunctionAddress (
            IModule *pThis,
            const _TCHAR * Name,
            UINT Ordinal,
            /* [out] */ ADDRESS *pAddress)
{
    PNTMODULE pMod = pMD(pThis);
    FARPROC Ret;
    SCODE sc;
    const char *name;
#ifdef _UNICODE
    name = _wcstos(Name);
#else
    name = Name;
#endif

    if (Name != NULL) {
        Ret = GetProcAddress(pMod->Handle, name);
#if 0
        _tprintf(_T("NT_ModuleGetFunctionAddress %s(%s) returned %x\n"),
                 pMod->pName, Name, Ret);
#endif
    } else {
        Ret = GetProcAddress(pMod->Handle, (const char *) Ordinal);

#if 0
        printf("NT_ModuleGetFunctionAddress %s(%x) returned %x\n",
               pMod->pName, Ordinal, Ret);
#endif
    }

#ifdef _UNICODE
    free((void*) name);
#endif
    if (Ret) {
        *pAddress = (ADDRESS) Ret;
        sc = S_OK;
    } else {
        sc = E_INVALID_PARAMETER;
    }

    return sc;
}

PRIVATE SCODE MCT NMGetName (
            IModule *pThis,
            /* [size_is][out] */ _TCHAR *Buffer,
            /* [in] */ UINT BufSize)
{
    if (Buffer)
        _tcsncpy(Buffer,pMD(pThis)->pName,BufSize);
    return NO_ERROR;
}

PRIVATE SCODE MCT NMGetArgs (
            IModule *pThis,
            /* [size_is][out] */ _TCHAR * Buffer,
            /* [in] */ UINT BufSize)
{
    UnusedParameter(pThis);
    UnusedParameter(BufSize);

    if (Buffer)
        Buffer[0] = _T('\0');
    return NO_ERROR;
}

PRIVATE SCODE MCT NMGetEntryPoint (
            IModule *pThis,
            /* [out] */ ADDRESS *pEntry)
{
    UnusedParameter(pThis);

    if (pEntry)
        *pEntry = 0;
    return NO_ERROR;
}

SCODE Unimplemented() {
    return E_NOT_IMPLEMENTED;
}

PRIVATE CONST_VTBL struct IModuleVtbl ModuleVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    NMQueryInterface,
    NMAddRef,
    NMRelease,
    NMGetFunctionAddress,
    NMGetName,
    NMGetArgs,
    NMGetEntryPoint
};

/* Find module by name */
PIMODULE NT_LookupModule(const _TCHAR *pModName, UINT VersionCheck)
{
    PNTMODULE pMod;
    HANDLE Handle;

    /* Time stamp or crc or whatever the linker gives to check versions */
    UnusedParameter(VersionCheck);

    Handle = LoadLibrary(pModName);

    if (Handle == NULL) {               /* NOTE: Win32's LoadLibrary returns NULL on error, not INVALID_HANDLE_VALUE */
        printf("NT_LookupModule(%s) failed (%d)\n", pModName, GetLastError());
        return NULL;
    }

    pMod = CurrentHeap()->v->Alloc(CurrentHeap(), HEAP_DEBUG_NAME("ntmodul"),
                          sizeof(*pMod) + _tcslen(pModName)*sizeof(_TCHAR), 0);
    assert (pMod);
    if (pMod == NULL)
        return NULL;

    pMod->v = &ModuleVtbl;
    pMod->RefCnt = 1;
    pMod->pName = (_TCHAR*)((PBYTE) pMod + sizeof(*pMod));
    _tcscpy(pMod->pName, pModName);

    pMod->Handle = Handle;

#if 1
    printf("NT_LookupModule(%s) returned handle %x pMod=%x\n",
           pModName, Handle, pMod);
#endif

    return iMD(pMod);
}
