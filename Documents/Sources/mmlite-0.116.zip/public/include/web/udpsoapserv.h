/* Copyright (c) Microsoft Corporation. All rights reserved. */

#define SOAP_SERVER_PORT_UDP         9901
#define SOAP_SERVER_PORT_TCP         9901
#define SOAP_SERVER_PORT_UDP_XTE     9902
#define SOAP_SERVER_PORT_UDP_AES     9903
#define SOAP_SERVER_PORT_UDP_XTE_AES 9904
#define SOAP_SERVER_PORT_UDP_DIME    9905

/* For key distribution on secure channel */
#define MulticastIPAddr2 "224.1.1.1"
/* For service discovery on public channel */
#define MulticastIPAddr1 "224.1.2.1"

#define PubChannel  "sr1"
#define SecChannel  "sr0"
