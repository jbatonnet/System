/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __DRIVERS_H
#define __DRIVERS_H 1

#include <netif.h>
#include <driverif.h>

#if defined(NO_DLL_LINKAGE) || !defined(_MSC_VER) || 1
#undef DLL_LINKAGE
#define DLL_LINKAGE
#define DLL_EXPORT
#define DLL_IMPORT
#endif

#ifndef DLL_EXPORT
#define DLL_EXPORT __declspec(dllexport)
#define DLL_IMPORT __declspec(dllimport)
#endif

#ifndef DLL_LINKAGE
#define DLL_LINKAGE DLL_IMPORT
#endif

#ifdef _MSC_VER
//#pragma warning(disable:4705) /* compilerbug: statement has no effect */
//#pragma warning(disable:4275) /* deriving from non-dll base class */
#pragma warning(disable:4251) /* exported struct non dll-linkage */
#endif


/*
 * Device drivers derive from this Concrete class
 */
typedef struct CDevice *PCDEVICE;

#if defined(__cplusplus)

struct DLL_LINKAGE CDevice : IDevice {

    /* To allow implementation&overloading:
     */
    virtual SCODE MCT QueryInterface ( REFIID pIid, void **ppNew);
    virtual UINT MCT AddRef (void);
    virtual UINT MCT Release (void);

    virtual SCODE MCT ReadAt (UINT64 Position, BYTE *pBuffer, 
                              UINT Size, PUINT pSizeRead);
    virtual SCODE MCT WriteAt (UINT64 Position, const BYTE *pBuffer,
                               UINT Size, PUINT pSizeWritten);
    virtual SCODE MCT SetSize( UINT64 Size);
    virtual SCODE MCT GetSize( PUINT64 pSize);

    /* Methods proper
     */
    virtual BOOL MCT Isr(PBOOL pWakeup);
    virtual BOOL MCT HandleInterrupt(void);
    virtual INT  MCT Initialize(void);
    virtual void MCT ThreadLoop(void);

    UINT RefCnt;
    CONDITION IntrPoint;
    PTR SpareForMBufFact;
};

#else /* __cplusplus */

typedef struct CDeviceVtbl {
    __VTABLE_COMPATIBILITY_FILLER_DECLARATION

    SCODE     (MCT *QueryInterface)(PCDEVICE pThis, REFIID Iid, void* *ppNew);
    UINT      (MCT *AddRef)(PCDEVICE pThis);
    UINT      (MCT *Release)(PCDEVICE pThis);
    /*
     * An CDevice derives from IFile
     */
    SCODE     (MCT *ReadAt)(PCDEVICE pThis, UINT64 Position, BYTE *pBuffer, UINT Size, PUINT pSizeRead);
    SCODE     (MCT *WriteAt)(PCDEVICE pThis, UINT64 Position, const BYTE *pBuffer, UINT Size, PUINT pSizeWritten);
    SCODE     (MCT *SetSize)(PCDEVICE pThis, UINT64 Size);
    SCODE     (MCT *GetSize)(PCDEVICE pThis, PUINT64 Size);
    /*
     * Methods specific to CDevice
     */
    BOOL      (*Isr)(PCDEVICE pThis, PBOOL pWakeup);
    BOOL      (*HandleInterrupt)(PCDEVICE pThis);
    INT       (*Initialize)(PCDEVICE pThis);
    void      (*ThreadLoop)(PCDEVICE pThis);
} CDeviceVtbl;

/* Inherited to net/if.h */
struct CDevice {
    struct CDeviceVtbl *v;
    UINT RefCnt;
    CONDITION IntrPoint;
    PTR SpareForMBufFact;
};

/* Defaults for these methods are in drivers.cpp
 */

EXTERN_C DLL_EXPORT SCODE CDevice_QueryInterface (struct CDevice *pThis, REFIID Iid, void* *ppNew);
EXTERN_C DLL_EXPORT UINT CDevice_AddRef ( struct CDevice *pThis);
EXTERN_C DLL_EXPORT UINT CDevice_Release ( struct CDevice *pThis);
EXTERN_C DLL_EXPORT SCODE CDevice_ReadAt ( struct CDevice *pThis, UINT64 Position,
                                               BYTE *pBuffer, UINT Size, PUINT pSizeRead);
EXTERN_C DLL_EXPORT SCODE CDevice_WriteAt ( struct CDevice *pThis, UINT64 Position,
                                                const BYTE *pBuffer,
                                                UINT Size, PUINT pSizeWritten);
EXTERN_C DLL_EXPORT SCODE CDevice_SetSize(  struct CDevice *pThis, UINT64 Size);
EXTERN_C DLL_EXPORT SCODE CDevice_GetSize(  struct CDevice *pThis, PUINT64 pSize);
EXTERN_C DLL_EXPORT BOOL CDevice_Isr( struct CDevice *pThis, PBOOL pWakeup);
EXTERN_C DLL_EXPORT BOOL CDevice_HandleInterrupt(  struct CDevice *pThis );
EXTERN_C DLL_EXPORT INT  CDevice_Initialize(  struct CDevice *pThis );
EXTERN_C DLL_EXPORT void CDevice_ThreadLoop(  struct CDevice *pThis );

/* There MUST be one and only one allocator across
 * all device drivers, regardless of language.
 */
EXTERN_C DLL_EXPORT void * operator_new( UINT size);
#define New operator_new
EXTERN_C DLL_EXPORT void operator_delete( void *pThis);
#define Delete operator_delete

#endif /* __cplusplus */


/*
 * Network device drivers derive from this Concrete class
 */
#ifndef __SOCK__
struct mbuf;
struct rtentry;
#endif

typedef struct CNetDriver *PCNETDRIVER;

#if defined(__cplusplus)
struct DLL_LINKAGE CNetDriver : IDevice {
    virtual SCODE MCT QueryInterface ( REFIID pIid, void **ppNew);

    virtual INT MCT Output(struct mbuf *Pkt, struct sockaddr *Addr, struct rtentry *Route);
    virtual void MCT Start(void);
    virtual INT MCT Ioctl( UINT Cmd, PTR Data);
    virtual INT MCT Watchdog(void);
};
#else /* __cplusplus */

typedef struct CNetDriverVtbl {
    __VTABLE_COMPATIBILITY_FILLER_DECLARATION

    SCODE (MCT *QueryInterface)(PCNETDRIVER pThis, PIID pIid, void* *ppNew);
    INT   (MCT *AddRef)(PCNETDRIVER pThis);
    INT   (MCT *Release)(PCNETDRIVER pThis);
    /*
     * An CNetDriver derives from IDevice
     */
    SCODE (MCT *ReadAt)(PCNETDRIVER pThis, UINT64 Position, BYTE *pBuffer, UINT Size, PUINT pSizeRead);
    SCODE (MCT *WriteAt)(PINETDRIVER pThis, UINT64 Position, const UINT8 *pBuffer, UINT Size, PUINT pSizeWritten);
    SCODE (MCT *SetSize)(PCNETDRIVER pThis, UINT64 Size);
    SCODE (MCT *GetSize)(PCNETDRIVER pThis, PUINT64 Size);

    BOOL  (MCT *Isr)(PCNETDRIVER pThis, PBOOL pWakeup);
    BOOL  (MCT *HandleInterrupt)(PCNETDRIVER pThis);
    INT   (MCT *Initialize)(PCNETDRIVER pThis);
    void  (MCT *ThreadLoop)(PCNETDRIVER pThis);
    /*
     * Methods specific to CNetDriver
     */
    INT   (MCT *Output)(PCNETDRIVER pThis, struct mbuf *Pkt, 
                           struct sockaddr *Addr, struct rtentry *Route);
    void  (MCT *Start)(PCNETDRIVER pThis);
    INT   (MCT *Ioctl)(PCNETDRIVER pThis, UINT Cmd, PTR Data);
    INT   (MCT *Watchdog)(PCNETDRIVER pThis);
} CNetDriverVtbl;

struct CNetDriver {
    struct CNetDriverVtbl *v;
    UINT RefCnt;
    CONDITION IntrPoint;
    PIENDPOINTFACTORY MBufFact;
};

/* Defaults for these methods are in drivers.cpp
 */
EXTERN_C INT  CNetDriver_Output(PINETDRIVER pThis,
                                PIBUFFER Pkt,
                                     struct sockaddr *Addr,
                                     struct route_in *Route);
EXTERN_C void CNetDriver_Start(struct CNetDriver *pThis);
EXTERN_C INT  CNetDriver_Ioctl( struct CNetDriver *pThis,
                                    UINT Cmd, PTR Data);
EXTERN_C INT  CNetDriver_Watchdog(PINETDRIVER This);

#endif /* __cplusplus */

/* Configuration entries */
typedef struct _DRIVER_CONFIG {
  _TCHAR *Name;
  _TCHAR *CobName;
  DEVICE_FLAGS Flags;
  ADDRESS RegisterBase;
  UINT Interrupt;
  _TCHAR *s1;
  _TCHAR *s2;
  UINT u1;
  UINT u2;
  PTR  u3;
  UINT u4;
  UINT u5;
} DRIVER_CONFIG, *PDRIVER_CONFIG;

/* Driver default COB Object */
typedef struct _DRIVERCOB {
    struct IDeviceConstructorVtbl *v;
    UINT RefCnt;
} *PDRIVERCOB;

/* IUnknown::<this> points to v-table
 * pDC (pointer of Driver Cob) converts interface ptr to implementation.
 * iDC (interface of DC)  converts implementation ptr to interface ptr.
 */
#define pDriverCob(_i_) ((PDRIVERCOB)(_i_))
#define iDriverCob(_p_) ((PIDEVICECONSTRUCTOR)(_p_))

/* Leftover junk */
EXTERN_C DLL_LINKAGE PIDMA CreateDmaChannel( PTR Description, PUINT nomr);

#define GetRtlFunctionAddress(_f_) _f_

/* TRUE if DLLs are supported, FALSE if libraries are statically linked */
#if !defined(USE_DLLS)
#define USE_DLLS TRUE
#endif

#endif // __DRIVERS_H
