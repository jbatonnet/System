/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * To be implemented in separate assembly file
 * [or does this compiler support inline asm ?]
 */

/* In _start.s
 */
extern BOOL AtomicCmpAndSwap(PUINT pTarget, UINT OldVal, UINT NewVal);

/* *** AtomicSwap
 *
 * Atomically swaps NewCount with *pCount and returns the old value.
 */
UINT AtomicSwap(PUINT pCount, UINT NewCount)
{
    UINT OldCount;

    for (;;) {
        OldCount = *pCount;
        if (AtomicCmpAndSwap(pCount, OldCount, NewCount))
            return NewCount;
    }
}

