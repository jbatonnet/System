/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmmach.h>

#ifdef TIGON
#define _rt_udiv __udivsi3
#define _rt_umod __umodsi3
#define _rt_idiv __divsi3
#define _rt_imod __modsi3
#define _rt_mul  __mulsi3
/* BUGBUG missing more ? */
#else
/* Code shared with TriMedia, keep names */
#endif

static unsigned int _udiv_Normalize(unsigned int dividend, unsigned int divisor)
{
    unsigned int count;

    count=0;
    if (divisor <= dividend>>(count+16)) count+=16;
    if (divisor <= dividend>>(count+8))  count+=8;
    if (divisor <= dividend>>(count+4))  count+=4;
    if (divisor <= dividend>>(count+2))  count+=2;
    if (divisor <= dividend>>(count+1))  count+=1;
    return count;
}

unsigned int _rt_udiv(unsigned int dividend, unsigned int divisor)
{
    unsigned int result,count;

    count = _udiv_Normalize(dividend,divisor);
    divisor <<= count;

    /* now do the division */
    result = 0;
    do
    {
        result = (result<<1) | (dividend >= divisor);
        if (dividend >= divisor)
            dividend -= divisor;
        divisor >>= 1;
        if (!count--) return result;

        result = (result<<1) | (dividend >= divisor);
        if (dividend >= divisor)
            dividend -= divisor;
        divisor >>= 1;
     } while (count--);

    return result;
}

unsigned int _rt_umod(unsigned int dividend, unsigned int divisor)
{
    unsigned int count;

    count = _udiv_Normalize(dividend,divisor);
    divisor <<= count;

    /* now do the division */
    do
    {
        if (dividend >= divisor)
            dividend -= divisor;
        divisor >>= 1;
        if (!count--) return dividend;

        if (dividend >= divisor)
            dividend -= divisor;
        divisor >>= 1;
     } while (count--);

    return dividend;
}

int _rt_idiv(int dividend, int divisor)
{
    int DividendNegSign,DivisorNegSign;
    int result;

    DividendNegSign = dividend & 0x80000000;
    DivisorNegSign  = divisor  & 0x80000000;

    if (DividendNegSign)
        dividend = -dividend;
    if (DivisorNegSign)
        divisor = -divisor;

    result = (int)_rt_udiv(dividend,divisor);
    if (DividendNegSign ^ DivisorNegSign)
        result = -result;

    return result;
}

int _rt_imod(int dividend, int divisor)
{
    int DividendNegSign,DivisorNegSign;
    int result;

    DividendNegSign = dividend & 0x80000000;
    DivisorNegSign  = divisor  & 0x80000000;

    if (DividendNegSign)
        dividend = -dividend;
    if (DivisorNegSign)
        divisor = -divisor;

    result = (int)_rt_umod(dividend,divisor);
    if (DividendNegSign)
        result = -result;

    return result;
}

#ifdef TIGON
/* OPTIMIZE!!! */
unsigned int _rt_mul(unsigned int a, unsigned int b)
{
    unsigned int i, r;

    r = 0;
    for (i = 0; i < 32; i++)
        if (a & (1 << i))
            r += b << i;
    return r;
}

unsigned int umulm(unsigned int a, unsigned int b)
{
    unsigned int i, r;

    r = 0;
    for (i = 1; i < 32; i++)
        if (a & (1 << i))
            r += b >> (32 - i);
    return r;
}
#endif

#if 0
#include <stdio.h>

int tests[] = {
    0x80, 0x10, 8, 0,
    100, 10, 10, 0,
    50, 5, 10, 0
};
#define NTESTS ((sizeof tests)/(4*sizeof tests[0]))

int nerr = 0;
void Test(unsigned int udivd, unsigned int udivs)
{
    unsigned int uret;

    uret = _rt_udiv(udivd,udivs);
    if (uret != udivd/udivs) 
    {
            nerr++;
            printf("Bug: %d / %d = %d not %d !\n", udivd, udivs, udivd/udivs, uret);
    }

    uret = _rt_umod(udivd,udivs);
        if (uret != udivd%udivs) 
    {
            nerr++;
            printf("Bug: %d mod %d = %d not %d !\n",
                   udivd, udivs, udivd%udivs, uret);
        }
}

int main(int argc, char **argv)
{
    int i;
    unsigned int udivs, udivd;

    for (udivd=1;udivd!=0;udivd<<=1)
    {
        Test(udivd,0xFFFFFFFF);
        Test(udivd,0x0000FFFF);
        Test(udivd,0x00FF00FF);
        Test(udivd,0x0F0F0F0F);
        Test(udivd,0x0F0F0F0F);
        Test(udivd,0xCCCCCCCC);
        Test(udivd,0xAAAAAAAA);

        for (udivs=1;udivs!=0;udivs<<=1)
        {
            Test(udivd,udivs);

            Test(udivd,udivs | 0x01);
            Test(udivd | 0x01, udivs);
            Test(udivd | 0x01, udivs | 0x01);
        }
        }

    for (udivs=1;udivs!=0;udivs<<=1)
    {
        Test(0xFFFFFFFF,udivs);
        Test(0x0000FFFF,udivs);
        Test(0x00FF00FF,udivs);
        Test(0x0F0F0F0F,udivs);
        Test(0x0F0F0F0F,udivs);
        Test(0xCCCCCCCC,udivs);
        Test(0xAAAAAAAA,udivs);
        Test(0,udivs);
    }

    for ( i = 0; i < NTESTS; i += 4)
    {
        /* Test unsigned division & modulus */
            udivd = tests[i];
            udivs = tests[i+1];

        Test(udivd,udivs);
    }


    for (udivd=1;udivd<0x800;udivd++)
    {
        for (udivs=1;udivs<0x800;udivs++)
        {
            Test(udivd,udivs);
        }
        }

    if (nerr)
        printf("Bad code: %d errors in %d tests\n", nerr, NTESTS);
    else
        printf("Test passed.\n");
    return nerr;
}
#endif
