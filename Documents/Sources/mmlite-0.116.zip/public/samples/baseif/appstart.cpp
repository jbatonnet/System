/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* XXX This sample program makes no sense */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif


#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Example 1: Start an application. */
/* ... */
CurrentProcess()->LoadImage(_TEXT("bin/echo.exe"), _TEXT("Hi!"),
        LOAD_IMAGE_CALL_ENTRY_POINT | LOAD_IMAGE_CREATE_THREAD,
                            NULL);

/* Example 2: Load a DLL. */
/* Pointer and reference to current namespace. */

IProcess *pPrc = CurrentProcess();
IModule *pModule;    /* Pointer to module object. */
IUnknown *pUnk;      /* Pointer to unknown object. */
IHello *pIHello;     /* Pointer to hello object,
                      * implemented in "ihello.dll". */
typedef IUnknown * (*IHELLO_CONSTRUCTOR) (void);
IHELLO_CONSTRUCTOR pNewHello;
SCODE StatusCode;
/*    IHello interface ID definition. */
const IID IID_IHello = {0x1241d450, 0x1c2f, 0x11ce,
                        {0xb0,0x2e,0x00,0xaa,0x00,0x44,0xba,0x7d}};

/* Load the DLL that implements IHello. */
StatusCode = pPrc->LoadImage(_TEXT("bin\\ihello.dll"), NULL, &pModule);
if (FAILED(StatusCode)) {
    _tprintf(_TEXT("Error loading module: %x\n"), StatusCode);
    exit(0);
}

/* This DLL's entry point is known to create IHello objects. */
StatusCode = pModule->GetEntryPoint((ADDRESS *) &pNewHello);
if (FAILED(StatusCode)) {
    _tprintf(_TEXT("Could not bind to hello3: %x\n"), StatusCode);
    exit(0);
}

/* Create an IHello object and verify it. */
StatusCode = pUnk->QueryInterface(IID_IHello, (void **)&pIHello);
pUnk->Release();
if (FAILED(StatusCode)) {
    _tprintf(_TEXT("Could not QueryInterface for IHello.\n"));
    pModule->Release();
    exit(0);
}

/* Execute some methods, then release. */
StatusCode = pIHello->SayHello(_TEXT("Hello, world (from COM
                                      server IHello)\n"));
pIHello->Release();
pModule->Release();
if (FAILED(StatusCode)) {
    _tprintf(_TEXT("Error in SayHello method: %x\n"), StatusCode);
    exit(0);
}
/* END_SAMPLE */
return 0;
}
