/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __X86_CPU_H__
#define __X86_CPU_H__   1

#pragma pack (push, x86_cpu_h, 1)
/*
 * Definitions and data structures for Intel x86 processors
 */
#pragma warning(disable:4214)

/*
 * Definitions for all processors
 */
typedef INT8    REGISTER8;  /* 8bit registers, 8080 days */

typedef union {         /* 16bit registers, '86 */
        struct {
                INT16   rx;
        } r16;
        struct {
                INT8    rl;
                INT8    rh;
        } r8;
} REGISTER16;

typedef UINT16  SEGMENT16;/* segmentation */

typedef union {         /* 32bit registers, 3-4-586 */
        struct {
                INT32   erx;
        } r32;
        struct {
                INT16   rx;
                INT16   h16;
        } r16;
        struct {
                INT8    rl;
                INT8    rh;
                INT16   h16;
        } r8;
} REGISTER32;


/*
 * 8x86 processor
 */
/* General purpose registers */
typedef struct {
        UINT16          di;     /* in 286' PUSHA order */
        UINT16          si;
        UINT16          bp;
        UINT16          sp;

        REGISTER16      bx;
        REGISTER16      dx;
        REGISTER16      cx;
        REGISTER16      ax;    /* end PUSHA */

        SEGMENT16       es;
        SEGMENT16       cs;
        SEGMENT16       ss;
        SEGMENT16       ds;
} I86_GP_REGS;

/* Processor state */
typedef struct {
    UINT16  ip;         /* in 286' TSS order */
        REGISTER16      flags;
#       define X86_FLAG_CF                      0x0001
#       define X86_FLAG_PF                      0x0004
#       define X86_FLAG_AF                      0x0010
#       define X86_FLAG_ZF                      0x0040
#       define X86_FLAG_SF                      0x0080
    /* end 8080 flags */

#       define X86_FLAG_TF                      0x0100
#       define X86_FLAG_IF                      0x0200
#       define X86_FLAG_DF                      0x0400
#       define X86_FLAG_OF                      0x0800

        I86_GP_REGS     gp_regs;

} I86_MACHINE_REGS;

/*
 * 286 processor
 */
/* segmentation::selectors */
typedef struct {
    UINT16  rpl : 2,            /* see X86_PRIV_* */
                        table : 1,
#define X86_TI_LDT                              0x1
#define X86_TI_GDT                              0x0
                        index : 13;
} SELECTOR;

/* segmentation::descriptors */
typedef struct {
        UINT16  limit_0_15;
        UINT32  base_0_23 : 24,
                        type : 4,
    /* code or data segments */
#   define X86_A_EXECUTE            0x8 /* if cd_sg==1   */
#   define X86_A_ACCESSED           0x1
#   define X86_A_READABLE           0x2 /* if EXECUTE==1 */
#   define X86_A_CONFORMING         0x4 /*               */
#   define X86_A_WRITEABLE          0x2 /* if EXECUTE==0 */
#   define X86_A_EXPAND_DOWN        0x4 /*               */
    /* system segments */
#   define I286_A_READY_TASK        0x1 /* if sd_sg==0   */
#   define X86_A_LDT                0x2
#   define I286_A_BUSY_TASK         0x3
                        cd_sg : 1,
#       define X86_SEG_CODE_OR_DATA             1
#   define X86_SEG_SYSTEM_OR_GATE   0
                        dpl : 2,
#       define X86_PRIV_KERNEL                  0
#       define X86_PRIV_EXECUTIVE               1
#       define X86_PRIV_SUPERVISOR              2
#       define X86_PRIV_USER                    3
                        present : 1;
        UINT16  xxxx;
} I286_SEGMENT_DESCRIPTOR;


typedef struct {
        UINT16          offset_0_15;
        SELECTOR        selector;
        UINT16  word_count : 5,
                        xxxx : 3,
                        type : 4,
    /* gate descriptors */
#       define I286_A_CALL_GATE                 0x4
#       define X86_A_TASK_GATE                  0x5
#       define I286_A_INT_GATE                  0x6
#       define I286_A_TRAP_GATE                 0x7
                        mbz : 1,
                        dpl : 2,
                        present : 1;
        UINT16  xxxx1;
} I286_GATE_DESCRIPTOR;


typedef union {
        I286_SEGMENT_DESCRIPTOR seg;
        I286_GATE_DESCRIPTOR    gate;
} I286_DESCRIPTOR;

/* segmentation::table_entries (in IDT and GDT) */
typedef struct {
        UINT16  limit_0_15;
    UINT32  base_0_31;          /* ONLY 0_23 for 286, 24_32 mbz */
} IDT_POINTER, GDT_POINTER;

/* General purpose registers */
#define I286_GP_REGS I86_GP_REGS

/* Processor state */
typedef struct {
        I86_MACHINE_REGS        i86;
    /* all of the I86_FLAG_xx, plus: */
#       define X86_FLAG_IOPL                    0x3000
#       define X86_FLAG_NT                      0x4000

        UINT16  msw;
#       define X86_MSW_PE                       0x0001
#       define X86_MSW_MP                       0x0002
#       define X86_MSW_EM                       0x0004
#       define X86_MSW_TS                       0x0008

        GDT_POINTER     gdtr;
        IDT_POINTER     idtr;
    SELECTOR    ldtr;   /* or is it cached ? */
    SELECTOR    tr;     /* or is it cached ? */

} I286_MACHINE_REGS;

/* Task State Segment */
typedef struct {
        SELECTOR        previous_tss;
        UINT16          ksp;
        SEGMENT16               kss;
        UINT16          esp;
        SEGMENT16               ess;
        UINT16          ssp;
        SEGMENT16               sss;
    I86_MACHINE_REGS    task_state; /* note: no msw-?dtr-tr */
    SELECTOR    ldt;        /* in GDT, ldt for this task */
} I286_TSS;

/* Interrupt Vector Assignments */
#define X86_DIVIDE_EXCEPTION                    0
#define X86_SSTEP_INTERRUPT                     1
#define X86_NMI_INTERRUPT                       2
#define X86_BPT_INTERRUPT                       3
#define X86_INTO_EXCEPTION                      4
#define X86_BOUND_EXCEPTION                     5
#define X86_ILLEGAL_INSTRUCTION_EXCEPTION       6
#define X86_COPROCESSOR_UNAVAILABLE_EXCEPTION   7
                                               /*  8..15 Intel reserved */
#define X86_INTAB_SMALL_EXCEPTION               8   /* real mode */
#define X86_DOUBLE_EXCEPTION                    8   /* prot mode */
#define X86_ESC_SEGMENT_OVERRUN_EXCEPTION       9
#define X86_INVALID_TSS_EXCEPTION              10
#define X86_MISSING_SEGMENT_EXCEPTION          11
#define X86_STACK_SEGMENT_EXCEPTION            12
#define X86_SEGMENT_OVERRUN_EXCEPTION          13  /* real mode */
#define X86_GP_FAULT                           13  /* prot mode */

#define X86_COPROCESSOR_ERROR_INTERRUPT        16
                                               /* 17..31 Intel reserved */
                                               /* 32..255 User defined */

/*
 * 386 processors
 */
/* segmentation::descriptors */
typedef struct {
        UINT16  limit_0_15;
        UINT32  base_0_23 : 24,
                        type : 4,
    /* code or data segments, same as 286  */

    /* system segments, includes 286 plus: */
#   define I386_A_READY_TASK        0x9 /* if sd_sg==0 */
#       define I386_A_BUSY_TASK                 0xb
                        cd_sg : 1,
                        dpl : 2,
            present : 1;            /* end 286 compat */
        UINT16  limit_16_19 : 4,
                        avl : 1,
                        mbz : 1,
                        seg32 : 1,
                        granularity : 1,
                        base_24_32 : 8;
} I386_SEGMENT_DESCRIPTOR;

typedef struct {
        UINT16          offset_0_15;
        SELECTOR        selector;
        UINT16  word_count : 5,
                        xxxx : 3,
                        type : 4,
    /* gate descriptors, includes 286 plus: */
#       define I386_A_TASK_GATE         0x5
#       define I386_A_CALL_GATE         0xc
#       define I386_A_INT_GATE          0xe
#       define I386_A_TRAP_GATE         0xf
                        mbz : 1,
                        dpl : 2,
                        present : 1;
        UINT16  offset_16_31;
} I386_GATE_DESCRIPTOR;

typedef union {
        I286_SEGMENT_DESCRIPTOR seg16;
        I286_GATE_DESCRIPTOR    gate16;
        I386_SEGMENT_DESCRIPTOR seg32;
        I386_GATE_DESCRIPTOR    gate32;
} I386_DESCRIPTOR;

/* segmentation::table_entries. same as 286 */
/* segmentation::selectors, same as 286     */

/* General purpose registers */
typedef struct {
    UINT32  edi;        /* in PUSHA order                     */
    UINT32  esi;
    UINT32  ebp;
    UINT32  esp;

    REGISTER32  ebx;
    REGISTER32  edx;
    REGISTER32  ecx;
    REGISTER32  eax;    /* end PUSHA                          */

    UINT32  es;         /* WRONG! these are 16bit as usual,   */
    UINT32  cs;         /* WRONG! but are padded in the TSS   */
    UINT32  ss;         /* WRONG! so we make it easy and      */
    UINT32  ds;         /* WRONG! use a single structure.     */
    UINT32  fs;         /* WRONG! Cache hopefully wont cry.   */
    UINT32  gs;         /* WRONG!                             */
} I386_GP_REGS;

/* Processor state (TSS overlap) */
typedef struct {
        UINT32  cr3;
        UINT32  eip;
        REGISTER32      eflags;
    /* all of the i86/i286 flags, plus: */
#       define X86_FLAG_FIXED_ONE               0x00000002
#       define X86_FLAG_RF                      0x00010000
#       define X86_FLAG_VM                      0x00020000

        I386_GP_REGS    gp_regs;
        
        SELECTOR        ldt;
        UINT16          ldt_pad;
        UINT16          t_bit;
        UINT16          io_bitmap_offset;
        /* end of TSS overlap */

        SELECTOR        tr;
    GDT_POINTER gdtr;/*?*/
        UINT16          gdtr_pad;
    IDT_POINTER idtr;/*?*/


        REGISTER32      cr0;
    /* contains 286' msw, plus: */
#       define X86_MSW_R                        0x00000010
#       define X86_MSW_PG                       0x80000000

    UINT32      cr1;    /* unused                */
    UINT32      cr2;    /* virtual fault address */

    UINT32      dr0;    /* breakpoint 0          */
    UINT32      dr1;    /* .. 1                  */
    UINT32      dr2;    /* .. 2                  */
    UINT32      dr3;    /* breakpoint 3          */
    UINT32      dr4;    /* reserved              */
    UINT32      dr5;    /* reserved              */
    UINT32      dr6;    /* breakpoint status     */
#   define X86_DR6_BPT_0            0x00000001
#   define X86_DR6_BPT_1            0x00000002
#   define X86_DR6_BPT_2            0x00000004
#   define X86_DR6_BPT_3            0x00000008
#   define X86_DR6_DB_ACCESS        0x00002000
#   define X86_DR6_SSTEP            0x00004000
#   define X86_DR6_TSS_T_BIT        0x00008000

    UINT32      dr7;    /* breakpoint control */
#   define X86_DR7_LOCAL_0          0x00000001
#   define X86_DR7_GLOBAL_0         0x00000002
#   define X86_DR7_LOCAL_1          0x00000004
#   define X86_DR7_GLOBAL_1         0x00000008
#   define X86_DR7_LOCAL_2          0x00000010
#   define X86_DR7_GLOBAL_2         0x00000020
#   define X86_DR7_LOCAL_3          0x00000040
#   define X86_DR7_GLOBAL_3         0x00000080
#   define X86_DR7_LOCALLY_EXACT    0x00000100
#   define X86_DR7_GLOBALLY_EXACT   0x00000200
#   define X86_DR7_DR_DISABLE       0x00002000

#   define X86_DR7_RW0_SHIFT        16
#   define X86_DR7_RW1_SHIFT        20
#   define X86_DR7_RW2_SHIFT        24
#   define X86_DR7_RW3_SHIFT        28
#   define X86_DR7_EXECUTE          0x0
#   define X86_DR7_WRITE            0x1
#   define X86_DR7_READ_WRITE       0x3

#   define X86_DR7_1_BYTE           0x0
#   define X86_DR7_2_BYTES          0x1
#   define X86_DR7_4_BYTES          0x3


    UINT32      tr6;    /* test (TLB) control */
#       define X86_TR6_TLB_LOOKUP               0x00000001
#       define X86_TR6_NOT_WRITEABLE            0x00000020
#       define X86_TR6_WRITEABLE                0x00000040
#       define X86_TR6_NOT_USER                 0x00000080
#       define X86_TR6_USER                     0x00000100
#       define X86_TR6_NOT_DIRTY                0x00000200
#       define X86_TR6_DIRTY                    0x00000400
#       define X86_TR6_VALID                    0x00000800
#       define X86_TR6_ADDR_MASK                0xfffff000

    UINT32      tr7;    /* test status */
#       define X86_TR7_REP                      0x0000000c
#       define X86_TR7_PL                       0x00000010
#       define X86_TR7_PADDR_MASK               0xfffff000

} I386_MACHINE_REGS;


/* Interrupt Vector Assignments */
/* 0..13 and 16 are same as in 286, plus: */
#define X86_PAGE_FAULT 14

/* Task State Segment */
typedef struct {
        SELECTOR        previous_tss;
        UINT16          pad0;

        UINT32          ksp;
        SEGMENT16               kss;
        UINT16          pad1;

        UINT32          esp;
        SEGMENT16               ess;
        UINT16          pad2;

        UINT32          ssp;
        SEGMENT16               sss;
        UINT16          pad3;

    I386_MACHINE_REGS   regs;   /* has actually more than */
                                /* what is HW-defined     */
} I386_TSS;

/* Paging support */
typedef union {
        UINT32          bits;
#define X86_PE_ADDR_MASK                        0xfffff000
#define X86_PE_OS_USE                           0x00000e00
#define I386_PE_MBZ                             0x00000198
#define X86_PE_DIRTY                            0x00000040
#define X86_PE_ACCESSED                         0x00000020
#define X86_PE_USER                             0x00000004
#define X86_PE_WRITEABLE                        0x00000002
#define X86_PE_VALID                            0x00000001
        struct {
                UINT32  valid : 1,
                                writeable : 1,
                                user : 1,
                                mbz : 2,
                                accessed : 1,
                dirty : 1,      /* not for pde */
                                mbz1 : 2,
                                os_res : 3,
                                phys_address : 20;
        } f;
} I386_PDE, I386_PTE;

/* 16bit fault reason code (pushed on stack) */
#define X86_PF_KREAD_MISS           0
#define X86_PF_KWRITE_MISS          2
#define X86_PF_UREAD_MISS           4
#define X86_PF_UWRITE_MISS          6

#define X86_PF_KREAD_ACCESS         1
#define X86_PF_KWRITE_ACCESS        3
#define X86_PF_UREAD_ACCESS         5
#define X86_PF_UWRITE_ACCESS        7


/*
 * 486 Processors
 */

/* segmentation::descriptors */
#define i486_segment_descriptor_t i386_segment_descriptor_t
#define i486_gate_descriptor_t i386_gate_descriptor_t
#define i486_descriptor_t i386_descriptor_t
/* segmentation::table_entries. same as 286 */
/* segmentation::selectors, same as 286     */

/* General purpose registers */
#define I486_GP_REGS I386_GP_REGS

/* Processor state */
typedef struct {
        UINT32  cr3;
#       define X86_CR3_PWT                      0x00000010
#       define X86_CR3_PCD                      0x00000020

        UINT32  eip;
        REGISTER32      eflags;
    /* all of the i86/i286/i386 flags, plus: */
#       define X86_FLAG_AC                      0x00040000

        I486_GP_REGS    gp_regs;
        
        SELECTOR                ldt;
        UINT16                  ldt_pad;
        UINT16                  t_bit;
        UINT16                  io_bitmap_offset;
        /* end of TSS overlap */

        SELECTOR                tr;
        GDT_POINTER             gdtr;
        UINT16                  gdtr_pad;
        IDT_POINTER             idtr;

        REGISTER32              cr0;
    /* same as 386, plus: */
#       define I486_MSW_IS_ONE          I386_MSW_R
#       define X86_MSW_NE                       0x00000020
#       define X86_MSW_WP                       0x00010000
#       define X86_MSW_AM                       0x00040000
#       define X86_MSW_NW                       0x20000000
#       define X86_MSW_CD                       0x40000000

    UINT32      cr1;    /* unused                         */
    UINT32      cr2;    /* virtual fault address          */

    UINT32      dr0;    /* breakpoint 0                   */
    UINT32      dr1;    /* .. 1                           */
    UINT32      dr2;    /* .. 2                           */
    UINT32      dr3;    /* breakpoint 3                   */
    UINT32      dr4;    /* reserved                       */
    UINT32      dr5;    /* reserved                       */
    UINT32      dr6;    /* breakpoint status, same as 386 */
    UINT32      dr7;    /* breakpoint control, same as 386*/

    UINT32      tr3;    /* cache test data                */
    UINT32      tr4;    /* cache test status              */
#       define X86_TR4_TAG_MASK                 0xfffff800
#       define X86_TR4_VALID                    0x00000400
#       define X86_TR4_R_LRU_BITS               0x00000380
#       define X86_TR4_R_VALID_BITS             0x00000078

    UINT32      tr5;    /* cache test control */
#       define X86_TR5_SET_SELECT               0x000007f0
#       define X86_TR5_ENTRY_SELECT             0x0000000c
#       define X86_TR5_CONTROL                  0x00000003
#       define X86_TR5_CACHE_ENABLE             0
#       define X86_TR5_CACHE_WRITE              1
#       define X86_TR5_CACHE_READ               2
#       define X86_TR5_CACHE_FLUSH              3

    UINT32      tr6;    /* test (TLB) control, same as 386  */
    UINT32      tr7;    /* test status, same as 386 plus:   */
#   define X86_TR7_LRU_BITS     0x00000380
#       define X86_TR7_PWT                      0x00000400
#       define X86_TR7_PCD                      0x00000800

} I486_MACHINE_REGS;


/* Interrupt Vector Assignments */
/* 0..14 and 16 are same as in 386, plus: */
#define X486_ALIGNMENT_CHECK    17

/* Task State Segment */
/* The HW structure is actually the same as 386 */
typedef struct {
        SELECTOR        previous_tss;
        UINT16          pad0;

        UINT32          ksp;
        SEGMENT16               kss;
        UINT16          pad1;

        UINT32          esp;
        SEGMENT16               ess;
        UINT16          pad2;

        UINT32          ssp;
        SEGMENT16               sss;
        UINT16          pad3;

    I486_MACHINE_REGS   regs;   /* has actually more than */
                                /* what is HW-defined     */
} I486_TSS;

/* Paging support */
#define I486_PDE I386_PDE
#define I486_PTE I386_PTE
#define I486_PE_MBZ                             0x00000180
#define X86_PE_PCD                              0x00000004
#define X86_PE_PWT                              0x00000002


/*
 * Pentium (586) Processors
 */

/*
 * Define the structure of the P6 APIC interface.
 */

struct APIC_QUAD {
    UINT32 val;
    UINT32 Filler[3];
};

typedef struct _I586_APIC {
    UINT8 Reserved1[0x20];

    UINT32 LocalId;
#define APIC_LOCAL_ID_ID_SHIFT 24
#define APIC_LOCAL_ID_MAX_ID 255
#define APIC_LOCAL_ID_ID_MASK 0x0f000000
        UINT32 LocalIdUnused[3];

    UINT32 Version;
#define APIC_VERSION_VERSION_82489DX 0
#define APIC_VERSION_VERSION_APIC 1
#define APIC_VERSION_VERSION_MASK 0xff
#define APIC_VERSION_MAX_LVT_ENTRY_SHIFT 16
#define APIC_VERSION_MAX_LVT_ENTRY_MAX 63
#define APIC_VERSION_MAX_LVT_ENTRY_MASK 0x003f0000
#define APIC_VERSION_SUPPORT_EIO_SHIFT 24
#define APIC_VERSION_SUPPORT_EIO_MASK 0x01000000
        UINT32 VersionUnused[3];

    UINT8 Reserved2[0x40];

    UINT32 TaskPriority;
#define APIC_PRIORITY_SUBCLASS_MASK 0x0000000f
#define APIC_PRIORITY_PRIORITY_SHIFT 4
#define APIC_PRIORITY_PRIORITY_MAX 15
#define APIC_PRIORITY_PRIORITY_MASK 0x000000f0
        UINT32 PriorityUnused0[3];
    UINT32 ArbitrationPriority;
        UINT32 PriorityUnused1[3];
    UINT32 ProcessorPriority; /* r/o */
        UINT32 PriorityUnused2[3];

    UINT32 EndOfInterrupt;
        UINT32 UnusedEOI[3];

    UINT8 Reserved3[0x10];      /* Remote read */

    UINT32 Destination;
#define APIC_DESTINATION_ID_SHIFT 24
#define APIC_DESTINATION_ID_MAX 255
#define APIC_DESTINATION_ID_MASK 0xff000000
        UINT32 DestinationUnused[3];
    UINT32 DestinationFormat;
#define APIC_DESTINATION_FORMAT_MODEL_SHIFT 28
#define APIC_DESTINATION_FORMAT_MODEL_MASK 0xf0000000
#define APIC_DESTINATION_FORMAT_MODEL_FLAT 0
#define APIC_DESTINATION_FORMAT_MODEL_CLUSTER 0xf0000000
        UINT32 DestinationFromatUnused[3];

    UINT32 SpuriousVector;
    /* On P6 the low 4 bits cannot be used (unlike P4) */
#define APIC_SPURIOUS_INTERRUPT_VECTOR_MUSTBEONES 0x0000000f
#define APIC_SPURIOUS_INTERRUPT_VECTOR_SHIFT 15
#define APIC_SPURIOUS_INTERRUPT_VECTOR_MAX 15
#define APIC_SPURIOUS_INTERRUPT_VECTOR_MASK 0x000000f0
#define APIC_SPURIOUS_INTERRUPT_VECTOR_SWENABLED 0x00000100
#define APIC_SPURIOUS_INTERRUPT_VECTOR_FOCUS_CHECKING 0x00000200
#define APIC_SPURIOUS_INTERRUPT_VECTOR_FOCUS_CHECKING_ENABLED 1
#define APIC_SPURIOUS_INTERRUPT_VECTOR_EIO_BROADCAST_SUPPRESS 0x00001000
        UINT32 SpuriousVectorUnused[3];

#define APIC_NUMBER_OF_INTERRUPT_SOURCES   256
    struct APIC_QUAD Isr[8];           /* 32 bits per quad */
    struct APIC_QUAD Tsr[8];
    struct APIC_QUAD Irr[8];

    UINT32 ErrorStatus;
#define APIC_ERROR_STATUS_SEND_CS 0x00000001
#define APIC_ERROR_STATUS_RECEIVE_CS 0x00000002
#define APIC_ERROR_STATUS_SEND_ACCEPT 0x00000004
#define APIC_ERROR_STATUS_RECEIVE_ACCEPT 0x00000008
#define APIC_ERROR_STATUS_SEND_ILLEGAL_VECTOR 0x00000020
#define APIC_ERROR_STATUS_RECEIVE_ILLEGAL_VECTOR 0x00000040
#define APIC_ERROR_STATUS_ILLEGAL_ADDRESS 0x00000080
        UINT32 ErrorStatusUnused[3];
    UINT8 Reserved4[0x60];

    UINT32 LvtCmgi;
        UINT32 LvtCmgiUnused[3];

    UINT32 InterruptCommand;
#define APIC_COMMAND_VECTOR_MAX 255
#define APIC_COMMAND_VECTOR_MASK 0xff
#define APIC_COMMAND_DELIVERY_FIXED  0x00000000
#define APIC_COMMAND_DELIVERY_LOWEST_PRIORITY 0x00000100
#define APIC_COMMAND_DELIVERY_SMI 0x00000200
#define APIC_COMMAND_DELIVERY_NMI 0x00000400
#define APIC_COMMAND_DELIVERY_INIT 0x00000500
#define APIC_COMMAND_DELIVERY_STARTUP 0x00000600
#define APIC_COMMAND_DELIVERY_MASK 0x00000700
#define APIC_COMMAND_DESTINATION_LOGICAL 0x00000800
#define APIC_COMMAND_STATUS_PENDING 0x00001000
#define APIC_COMMAND_LEVEL_ASSERT 0x00004000
#define APIC_COMMAND_TRIGGER_LEVEL 0x00008000
#define APIC_COMMAND_SHORTHAND_DEST_MASK 0x00030000
#define APIC_COMMAND_SHORTHAND_DEST 0x00000000
#define APIC_COMMAND_SHORTHAND_SELF 0x00010000
#define APIC_COMMAND_SHORTHAND_ALL 0x00020000
#define APIC_COMMAND_SHORTHAND_ALL_BUT_SELF 0x00030000
        UINT32 InterruptCommandUnused[3];

    UINT32 InterruptCommandHigh;
        UINT32 InterruptCommandHighUnused[3];

    UINT32 LocalVectorTimer;
#define APIC_LOCAL_VECTOR_MAX 255
#define APIC_LOCAL_VECTOR_MASK 0x000000ff
#define APIC_LOCAL_VECTOR_MODE_MASK 0x00000700
#define APIC_LOCAL_VECTOR_MODE_FIXED 0x00000000
#define APIC_LOCAL_VECTOR_MODE_SMI 0x00000200
#define APIC_LOCAL_VECTOR_MODE_NMI 0x00000400
#define APIC_LOCAL_VECTOR_MODE_EXTINT 0x00000700
#define APIC_LOCAL_VECTOR_MODE_INIT 0x00000500
#define APIC_LOCAL_VECTOR_STATUS_PENDING 0x00001000
#define APIC_LOCAL_VECTOR_POLARITY 0x00002000
#define APIC_LOCAL_VECTOR_REMOTE_IRR 0x00004000
#define APIC_LOCAL_VECTOR_TRIGGER_LEVEL 0x00008000
#define APIC_LOCAL_VECTOR_MASKED 0x00010000
#define APIC_LOCAL_VECTOR_TIMER_PERIODIC 0x00020000
        UINT32 LocalVectorTimerUnused[3];

    UINT32 LocalVectorThermal;
        UINT32 LocalVectorThermalUnused[3];
    UINT32 LocalVectorPerformance;
        UINT32 LocalVectorPerformanceUnused[3];
    UINT32 LocalVectorLINT0;
        UINT32 LocalVectorLINT0Unused[3];
    UINT32 LocalVectorLINT1;
        UINT32 LocalVectorLINT1Unused[3];
    UINT32 LocalVectorError;
        UINT32 LocalVectorErrorUnused[3];

#define APIC_LOCAL_VECTOR_SPURIOUS 0
#define APIC_LOCAL_VECTOR_TIMER 1
#define APIC_LOCAL_VECTOR_THERMAL 2
#define APIC_LOCAL_VECTOR_PERFORMANCE 3
#define APIC_LOCAL_VECTOR_LINT0 4
#define APIC_LOCAL_VECTOR_LINT1 5
#define APIC_LOCAL_VECTOR_ERROR 6
#define APIC_LOCAL_VECTOR_COUNT 7

    UINT32 TimerInitial;
        UINT32 TimerInitialUnused[3];
    UINT32 TimerCurrent;
        UINT32 TimerCurrentUnused[3];

    UINT8 Reserved6[0x40];
    UINT32 TimerConfiguration;
    /* XXX These flags are wrong. Bit 2 is not used. The bits are apparently
     * little endiand in the book.
     * http://www.intel.com/Assets/PDF/manual/253668.pdf page 472
     */
#define APIC_TIMER_DIVIDER_MASK 0x0000000f
#define APIC_TIMER_DIVIDER_2 0
#define APIC_TIMER_DIVIDER_4 1
#define APIC_TIMER_DIVIDER_8 2
#define APIC_TIMER_DIVIDER_16 3
#define APIC_TIMER_DIVIDER_32 4
#define APIC_TIMER_DIVIDER_64 5
#define APIC_TIMER_DIVIDER_128 6
#define APIC_TIMER_DIVIDER_1 7
        UINT32 TimerConfigurationUnused[3];

    UINT8 Reserved7[0x10];
} I586_APIC;

/* P6 addresses */
#define APIC_PHYSICAL_ADDRESS 0xfee00000

#pragma pack(pop, x86_cpu_h)
#pragma warning(default:4214)

#endif  /* __X86_CPU_H__ */
