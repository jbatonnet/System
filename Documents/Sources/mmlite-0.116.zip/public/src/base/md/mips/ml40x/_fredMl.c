/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define DBGLVL 0
#define DEVICE_ORDER BIG_ENDIAN
#include <mmlite.h>
#include <mmhal.h>
#include <mmmacros.h>
#include <fred.h>
#include <mips/ml40x.h>

extern void _start(void); /* truly our image's start */
extern void MMUEnable(void);
extern void DbgPortInit(void);

#define _p2v(x) (0x80000000 | (x))

#define ThePmc ((struct _Pmc*)POWER_MGR_DEFAULT_ADDRESS)

void BoardInit(void)
{
#if 0
    /* Spin a bit to let the serplex start.
     * It runs on the same serial line we have been downloaded from
     */
    Delay(50000);
#endif

    /* Turn the clock on to all the peripherals we (know we'll) use
     */
    ThePmc->PeripheralPowerEnable = _bs32(PMCPC_USART);

    /* Debug serial line
     */
    DbgPortInit();

    /* ..Any other peripherals that need initialization
     */
    MMUEnable();
}


/* See how much SRAM we have
 * Get it from the SRAM controller.
 */
static struct _Sram *SramCtl(void)
{
    static struct _Sram *Sram = NULL;

    if (Sram == NULL) {
        struct _Pmt *Pmt = ThePmt;
        for (;;Pmt--) {
            if (Pmt->Tag == PMTTAG_SRAM) {
                Sram = (struct _Sram *)(Pmt->TopOfPhysicalAddress << 16);
                break;
            }
            if (Pmt->Tag == PMTTAG_END_OF_TABLE) {
                /* Give it one more try, in case the bootloader is screwed up */
                struct _Sram *Sram0 = (struct _Sram *)SRAM_0_DEFAULT_ADDRESS;
                if (Sram0->BaseAddressAndTag != PMTTAG_SRAM)
                    return NULL; /* Maybe we have DDRAM */
                Sram = Sram0;
                break;
            }
        }
    }
    return Sram;
}

static struct _Ddram *DdramCtl(void)
{
    static struct _Ddram *Ddram = NULL;

    if (Ddram == NULL) {
        struct _Pmt *Pmt = ThePmt;
        for (;;Pmt--) {
            if (Pmt->Tag == PMTTAG_DDRAM) {
                Ddram = (struct _Ddram *)(Pmt->TopOfPhysicalAddress << 16);
                break;
            }
            if (Pmt->Tag == PMTTAG_END_OF_TABLE) {
                /* BUGBUG hackattack: should fix bram loader instead! */
                struct _Ddram * Tmp = (struct _Ddram *)DDRAM_0_DEFAULT_ADDRESS;
                if (PMTTAG_DDRAM == (Tmp->BaseAddressAndTag & DDRAMBT_TAG)) {
                    Ddram = Tmp;
                    //printf("CTL.hack! %x\n",Tmp);
                    return Ddram;
                }
                return NULL; /* dont have any */
            }
        }
    }
    return Ddram;
}

static ADDRESS RAM_Base(void)
{
    static ADDRESS Base = ~0;
    UINT32 Size;

    if (Base == ~0) {
        struct _Sram *Sram = SramCtl();
        struct _Ddram *Ddram = DdramCtl();
        //printf("RB s=%x d=%x\n",Sram,Ddram);

        if (Sram)
            Base = Sram->BaseAddressAndTag & SRAMBT_BASE;

        /* Check to see if we have any DDRAM, and if its lower than SRAM
         * Regardless, make them contiguous.
         * BUGBUG Does not handle two DDRAMs or more.
         */
        if (Ddram) {
            ADDRESS Base2 = Ddram->BaseAddressAndTag & DDRAMBT_BASE;
            //printf("bases: %x %x\n", Base, Base2);
            if (Sram == NULL)
                Base = Base2;
            else {
                if (Base2 < Base) {
                    /* DDRAM comes first here */
                    /* See if we can make DDRAM contiguous to the SRAM segment */
                    Size = Ddram->Control & DDRAMST_SIZE;
                    if (Base > (Base2 + Size)) {
                        //printf("contig0? %x %x %x\n", Base, Size, Base2);
                        Sram->BaseAddressAndTag = PMTTAG_SRAM |
                            ((Base2 + Size) & SRAMBT_BASE);
                    }
                    /* Swap bases */
                    Base = Base2;
                } else {
                    /* SRAM comes first here (or same) */
                    /* See if we can make it contiguous to the DDRAM segment */
                    Size = Sram->Control & SRAMST_SIZE;
                    if (Base2 > (Base + Size)) {
                        //printf("contig1? %x %x %x\n", Base, Size, Base2);
                        Ddram->BaseAddressAndTag = PMTTAG_DDRAM |
                            ((Base + Size) & DDRAMBT_BASE);
                    }
                }
            }
        }
        if (Base == ~0) {
            printf("Could not find any memory controllers!!\n");
            TheEnd();
            /* notreached */
        }
        Base = _p2v(Base);
    }
    return Base;
}

UINT MemorySize(void)
{
    struct _Sram *Sram  = SramCtl();
    struct _Ddram *Ddram = DdramCtl();

    //printf("MS s=%x d=%x\n",Sram,Ddram);

    /* Do we have SRAM+DDRAM and are they contiguous? */
    if (Sram && Ddram) {
        UINT32 Size, Size2;
        ADDRESS Base, Base2;
        Base = Sram->BaseAddressAndTag & SRAMBT_BASE;
        Size = Sram->Control & SRAMST_SIZE;
        Base2 = Ddram->BaseAddressAndTag & DDRAMBT_BASE;
        Size2 = Ddram->Control & DDRAMST_SIZE;
        //printf("b&s: %x,%x %x,%x\n",Base,Size,Base2,Size2);
        if ((Base2 == (Base + Size)) || (Base == (Base2 + Size2)))
            return Size + Size2;
        return (Base < Base2) ? Size : Size2;
    }
    if (Sram)
        return Sram->Control & SRAMST_SIZE;
    if (Ddram)
        return Ddram->Control & DDRAMST_SIZE;
    return 0; /* uhu?? */
}

/* Create the system heap.  Left to machdep code because messy otherwise.
 * The heap should account for all available memory, carved out of memory
 * that is already used or unavailable (like the 640K-1meg hole on PCs).
 * It does not have to account for all the memory in the system.
 * Returns a PIHEAP pointer.
 */

PIHEAP MachineHeapCreate( void )
{
    PIHEAP pIHeap;
    ADDRESS MemBase = (ADDRESS) _end;
    ADDRESS ImageBase = (ADDRESS) _start;
    ADDRESS RAM = RAM_Base();
    UINT32 MemSize = MemorySize();
    ADDRESS MemTop = (RAM+MemSize);

    DBGME(1,printf("MachineHeapCreate: RAM=%x..%x start=%x end=%x delta=",
                   RAM, MemTop, ImageBase, MemBase));

    if ((RAM == 0x80000000) || (ImageBase < RAM) || (ImageBase > MemTop)) {
        DBGME(1,printf("%x ROM/Flash\n", MemBase-RAM));
        /* If we are running from ROM/Flash, assume .data is at the
         * beginning of RAM so start the heap after it.
         * Does not account for image in heap size (the heap is .data + .bss
         * smaller than RAM size).
         */
        MemSize -= MemBase - RAM;
        pIHeap = CreateHeapFrom(MemBase, 0, MemSize, MemSize);
    } else {
        DBGME(1,printf("%x RAM\n", MemBase-ImageBase));
        /* If instead .text is in RAM then the image might be in the middle
         * of it so make a heap out of the entire RAM and then carve out the
         * image. This assumes there is space for the heap metadata at
         * start of RAM.
         * Accounts for image in heap size (the heap size is that of RAM size)
         */
        pIHeap = CreateHeapFrom(RAM, 0, MemSize, MemSize);

        if (MemTop > MemBase) {
            MemSize = MemBase - ImageBase;
            pIHeap->v->Extract(pIHeap, 0, (PTR) ImageBase, MemSize);
        }
    }

    return pIHeap;
}

void TheEnd(void)
{
    void (*Reset)(void) = (void (*)(void))BRAM_DEFAULT_ADDRESS;
    UINT32 psr;

    /* Say we are resetting
     */
    printf("Jumping to %x cuz I'm stoop (seeya!)\n", (ADDRESS)Reset);
    /* Turn off interrupts and cause a reset
     */
    TURN_INTERRUPTS_OFF(psr);
    psr |= (1 << 7);  /* soft-reset bit */
    RESTORE_INTERRUPTS(psr);
    /* Will never get here but
     */
    for(;;)
        Reset();
}


/* .. */
void MipsMachineIdle(ADDRESS Arg)
{
    UINT32 psr;

    UnusedParameter(Arg);

    TURN_INTERRUPTS_OFF(psr);
    psr |= (1 << 27);  /* reduced-power bit */
    RESTORE_INTERRUPTS(psr);
}

/* Say we are #1
 */
#undef CurrentProcessorOEM
UINT CurrentProcessorOEM(void)
{
    return 1;
}

void DebuggerOutputString( const unsigned char *String, int nBytes )
{
    int i;
    for (i = 0; i < nBytes; i++)
        DCPutChar(String[i]);
}
