/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <web/gentypeinfo.h>

PRIVATE const struct {
    ANY_ENTRY any; INT Count;
    CPANY_ENTRY Table[DS_NAMESPACES_COUNT];
} The_ns_table = {
    NE, DS_NAMESPACES_COUNT, {
        DS_NAMESPACES
}};

CPNS_TABLE pTheNamespaceNamespace = (CPNS_TABLE) &The_ns_table;
