/* Copyright (c) Microsoft Corporation. All rights reserved. */
//
// FirstThread for H8
//
// 2005-07-13 takeshim
//

#define TMPXXX 1 /* XXX temporarily disabled some for preliminary merge //jvh */

#include <mmlite.h>
#include <machdep.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>

#include <util/list-double2.h>
#include <wsif.h>
#include <soapif.h>
#include <sampleif.h>
#include <web/proxy.h>

#include <ctype.h>  // for isprint

#include "sci.h"
#include "lcd.h"

#include <httpif.h>
#include <netif.h>
#include <winsock.h>
#include <net/if.h>             /* for struct ifreq */

#include <base/thread.h>

extern PIUNKNOWN Ax88796CobMain(void);
extern PIUNKNOWN TmpHeapCobMain(void);
extern PIUNKNOWN testserviceCobMain(void);

//
// Cob refers ThePreCobTable
//
const struct PRECOB ThePreCobTable[] = {
    {"drivercfg.cob",  DriverCfgCobMain  },
    {"drivers.cob",    DriversCobMain    },
    {"ax88796.cob",    Ax88796CobMain    },   // Ethernet Driver
    {"protocol.cob",   ProtocolCobMain   },
///////// http
    {"http.cob",       httpCobMain       },
    {"soap.cob",       soapCobMain       },
    {"tokenizer.cob",  tokenizerCobMain  },
    {"tmp_heap.cob",   TmpHeapCobMain    },
///////// soap
    {"sax.cob",        saxCobMain        },
    {"wsaddr.cob",     wsaddrCobMain     },
///////// wsd
    {"wsdiscov.cob",   wsdiscovCobMain   },
    {"wsman.cob",      wsmanCobMain   },
    {"cimdb.cob",      cimdbCobMain   },
    {"cimsample.cob",  cimsampleCobMain   },
/////////
    {"testservice.cob",testserviceCobMain   },
    {0, 0}
};

//
// StartDriver calls ConfigureDrivers
// ConfigureDrivers refers DriverConfigs
//
const DRIVER_CONFIG DriverConfigs[] = {
  {"ne0", "COB/ax88796.cob", DEVICE_FLAGS_NET_DRIVER },
  {NULL,}
};

#define _DEBUG
#include <assert.h>

void Sleep(INT32 ms)
{
    TIME t;
    t.HighPart = (UINT32)-1;
    t.LowPart = (UINT32)(ms * 10000 * -1);
    SleepUntil(t);
}

void memdump(UINT8 *p, UINT32 len)
{
    UINT8 *q = p + len;

    for(; p < q; p += 16)
    {
        UINT32 i;
        Sci_WriteHexLong((UINT32)p);
        Sci_WriteStr(" : ");
        for(i=0; i<16; i++) {
        	if ((p+i)<q) {
	        	Sci_WriteHexByte(p[i]);
	            Sci_WriteStr(" ");
        	} else {
	            Sci_WriteStr("   ");
        	}
        }
        for(i=0; i<16 && (p+i)<q; i++) {
            if (isprint(p[i]))
                Sci_WriteChar(p[i]);
            else
                Sci_WriteChar('.');
        }
        Sci_WriteStr("\r\n");
    }
}

#if 0
BYTE buff[2048];
void UdpEchoTest(PIENDPOINTFACTORY epf)
{
    METHOD_DECLARE_NOTHIS("UdpTest");
	PIENDPOINT ep = NULL;
	struct sockaddr_in sin;

	// socket()
    sc = epf->v->CreateEndpoint(epf, AF_INET, SOCK_DGRAM, 0, &ep);
	if (FAILED(sc)) {
		goto ErrorExit;
	}

	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = 666;
	sc = ep->v->Bind(ep, (struct sockaddr *)&sin, sizeof(sin));
	if (FAILED(sc)) {
		goto ErrorExit;
	}

	for(;;)
	{
		struct sockaddr_in sin_cli;
		UINT32 sin_cli_len;
		UINT32 len;

		memset(&sin_cli, 0, sizeof(sin_cli));
		sin_cli_len = sizeof(sin_cli);

		len = 0;
		sc = ep->v->RecvFrom(ep, buff, sizeof(buff), &len, 0, (struct sockaddr *)&sin_cli, sizeof(sin_cli), &sin_cli_len);
		if (FAILED(sc)) {
			goto ErrorExit;
		}

		if (len) {
			Sci_WriteStr("0x");
			Sci_WriteHexLong(len);
			Sci_WriteStr(" bytes received.\r\n");

			sc = ep->v->SendTo(ep, buff, len, &len, 0, (struct sockaddr *)&sin_cli, sin_cli_len);
			if (FAILED(sc)) {
				goto ErrorExit;
			}

			if (len < sizeof(buff))
			{
				buff[len] = '\0';
			}
			else
			{
				buff[sizeof(buff)-1] = '\0';
			}
			Sci_WriteStr((char *)buff);
			Sci_WriteStr("\r\n");
		}
		Sleep(100);
	}

ErrorExit:
	if (ep) {
		ep->v->Release(ep);
		ep = NULL;
	}
}

const char http_msg[] = "HTTP/1.1 200 OK\r\n"
"Connection: close\r\n"
"Content-Type: text/html\r\n"
"\r\n"
"<HTML><BODY>fake</BODY></HTML>";

void FakeHttpTest(PIENDPOINTFACTORY epf)
{
    METHOD_DECLARE_NOTHIS("FakeHttpTest");
	PIENDPOINT ep = NULL;
	struct sockaddr_in sin;

	// socket()
    sc = epf->v->CreateEndpoint(epf, AF_INET, SOCK_STREAM, 0, &ep);
	if (FAILED(sc)) {
		Sci_WriteStr("fakehttp: CreateEndpoint failed = 0x");
		Sci_WriteHexLong(sc);
		Sci_WriteStr("\r\n");
		goto ErrorExit;
	}

	// bind()
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = 80;
	sc = ep->v->Bind(ep, (struct sockaddr *)&sin, sizeof(sin));
	if (FAILED(sc)) {
		Sci_WriteStr("fakehttp: Bind failed = 0x");
		Sci_WriteHexLong(sc);
		Sci_WriteStr("\r\n");
		goto ErrorExit;
	}

	// listen()
    sc = ep->v->Listen(ep, 3);
	if (FAILED(sc)) {
		Sci_WriteStr("fakehttp: Listen failed = 0x");
		Sci_WriteHexLong(sc);
		Sci_WriteStr("\r\n");
		goto ErrorExit;
	}

	for(;;)
	{
		struct sockaddr_in sin_cli;
		UINT32 sin_cli_len;
		UINT32 len;
	    PIENDPOINT ep_cli;

		memset(&sin_cli, 0, sizeof(sin_cli));
		sin_cli_len = sizeof(sin_cli);

		// accept
		ep_cli = NULL;
        sc = ep->v->Accept(ep, &ep_cli, (struct sockaddr *)&sin_cli, sizeof(sin_cli), &sin_cli_len);
		if (FAILED(sc)) {
			Sci_WriteStr("fakehttp: Accept failed = 0x");
			Sci_WriteHexLong(sc);
			Sci_WriteStr("\r\n");
			goto ErrorExit;
		}

Sci_WriteStr("accepted\r\n");

		if (ep_cli)
		{
			sc = ep_cli->v->WriteAt(ep_cli, UINT64_ZERO, (BYTE *)http_msg, (UINT)(sizeof(http_msg)-1), (PUINT)&len);
			ep_cli->v->Close(ep_cli);
			ep_cli->v->Release(ep_cli);
			ep_cli = NULL;
			if (FAILED(sc)) {
				Sci_WriteStr("fakehttp: WriteAt failed = 0x");
				Sci_WriteHexLong(sc);
				Sci_WriteStr("\r\n");
				goto ErrorExit;
			}
Sci_WriteStr("sent fake msg\r\n");
		}
	}

ErrorExit:
	if (ep) {
		ep->v->Close(ep);

		ep->v->Release(ep);
		ep = NULL;
	}
}
#endif

void FirstThread(UINT32 arg)
{
//  SOCKET s = INVALID_SOCKET;
    METHOD_DECLARE_NOTHIS(h8, FirstThread);
    PINAMESPACE pNs;
    PIUNKNOWN Unk;
    PIPROGRAM prog;
    PIPROCESS pPrc;
    INT i;
    PUINT8 p;
    struct in_addr ipaddr;
    char _sw0 = 0;
    IThread* pMyThread = NULL;
	IHeap* Heap;

    pPrc = CurrentProcess();
Sci_WriteStr("CurrentProcess = ");
Sci_WriteHexLong((UINT32)pPrc);
Sci_WriteStr("\r\n");

	Sci_WriteStr("GetPC = ");
	p = (PUINT8)GetPC();
	Sci_WriteHexLong((UINT32)p);
	Sci_WriteStr("\r\n");

	Heap = CurrentHeap();
    p = Heap->v->Alloc(Heap, HEAP_ZERO_MEMORY, 256, 0);
	for(i=0; i<256; i++) {
		if (p[i])
		{
			Sci_WriteStr("HEAP_ZERO_MEMORY was ignored!!!\r\n");
			memdump(p, 256);
			Sci_WriteStr("Please check CarveBlk() in src/heaps/ff_heap.c.\r\n");
			for(;;)
				;
		}
	}
	Heap->v->Free(Heap, 0, p);

Sci_WriteStr("BindToObject driver.cob\r\n");
    pNs = CurrentNameSpace();
    sc = BindToObject(pNs, _T("COB/drivers.cob"), NAME_SPACE_READ,
                      &IID_IUnknown, (void **) &Unk);
    CHECKSC("load drivers");

    /* XXX Should make this an IProgram method on drivercfg.cob */
Sci_WriteStr("ConfigureDrivers ne0\r\n");
    ConfigureDrivers(NULL, "ne0", FALSE );

Sci_WriteStr("BindToObject protocol.cob\r\n");
    sc = BindToObject(pNs, _T("COB/protocol.cob"), NAME_SPACE_READ,
                      &IID_IProgram, (void **) &prog);
    CHECKSC("load network stack");

#if 0
    Sci_WriteStr("prog->v->Main \"start\"\r\n");
    sc = prog->v->Main(prog, "start");
#else
#if 0
	Sci_WriteStr("prog->v->Main \"dhcp\"\r\n");
    sc = prog->v->Main(prog, "dhcp");
#else
//    Sci_WriteStr("prog->v->Main \"* inet 163.181.220.151\"\r\n");
//    sc = prog->v->Main(prog, "ne0 inet 163.181.220.151");
    //sc = prog->v->Main(prog, "ne0 inet 192.168.0.130");  //Barry's requested IP
    Sci_WriteStr("prog->v->Main \"* inet 192.168.0.3\"\r\n");
    sc = prog->v->Main(prog, "ne0 inet 192.168.0.3");
#endif
#endif
    prog->v->Release(prog);
    CHECKSC("protocol statrt");


sc = BindToObject(pNs,_T("COB/cimdb.cob"), NAME_SPACE_READ,
                  &IID_IProgram, (void **) &prog);
CHECKSC("load network stack");
sc = prog->v->Main(prog,_T(""));
prog->v->Release(prog);
CHECKSC("cimdb start");

///////////// UDP ECHO TEST ////////////
#if 0
{
	PIENDPOINTFACTORY epf = NULL;
    prog->v->QueryInterface(prog, &IID_IEndpointFactory, (void**)&epf);
	if (epf)
	{
		UdpEchoTest(epf);
	}
}
#endif
///////////////////////////////////

///////////// FAKE HTTP TEST ////////////
#if 0
{
	PIENDPOINTFACTORY epf = NULL;
    prog->v->QueryInterface(prog, &IID_IEndpointFactory, (void**)&epf);
	if (epf)
	{
		FakeHttpTest(epf);
	}
}
#endif
///////////////////////////////////

    /* Create /wsman name in namespace */
    sc = BindToObject(pNs, _T("COB/wsman.cob"), NAME_SPACE_READ,
                      &IID_IUnknown, (void **) &Unk);
    CHECKSC("load wsman.cob");

    sc = pNs->v->Register(pNs, _T("wsman"), Unk, 0, NULL);
    Unk->v->Release(Unk);

    Sci_WriteStr("starting HTTP SOAP server...\r\n");
    sc = BindToObject(pNs, _T("COB/http.cob"), NAME_SPACE_READ,
                      &IID_IProgram, (void **) &prog);
    CHECKSC("load http.cob");

    sc = prog->v->Main(prog, "http");
    if (FAILED(sc)) {
        prog->v->Release(prog);
        CHECKSC("start http server on port 80");
    }

/*
    //sc = prog->v->Main(prog, "x-udp-soap://239.255.255.250:3702/");
    prog->v->Release(prog);
    //CHECKSC("start Ws-Discovery server");

    sc = BindToObject(pNs, _T("COB/cimsample.cob"), NAME_SPACE_READ,
                      &IID_IProgram, (void **) &prog);
    CHECKSC("load cimsample.cob");

    sc = prog->v->Main(prog, "");
    prog->v->Release(prog);
*/

CLEANUP:
	;
Out:
	Sci_WriteStr("FirstThread Enters Idle Loop\r\n");
	i = 0;
	for(;;)
	{
#if 0
		Sci_WriteStr("(idle");
		Sci_WriteHexShort((UINT16)i);
		i++;
		Sci_WriteStr(")");
#endif
		Sleep(3000);
	}
    BaseDelete();
}
