/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>
#include <string.h>

#include "sci.h"

extern char end[];

#ifdef AKI_LAN_3052F
// H8_3052F
// 128K
const UINT32 MemorySize = 0x020000;
const UINT32 MemoryBase = 0x220000;
#endif

#ifdef AKI_LAN_3069F
// 1M
const UINT MemorySize = 0x100000;
const UINT MemoryBase = 0x490000;
#endif

#ifdef RENESAS_OPMA_2168F
// H8S/2168F
// 256K
const UINT MemorySize = 0x040000;
const UINT MemoryBase = 0x080000;
#endif

/* The end of the world as we know it.
 */
void TheEnd(void)
{
    DebugBreak();
}

#if 1
PIHEAP MachineHeapCreate( void )
{
	memset((void *)MemoryBase, 0xcc, MemorySize);
	return CreateHeapFrom(MemoryBase, 0, MemorySize, MemorySize);
}
#else
PIHEAP MachineHeapCreate( void )
{
    ADDRESS MemBase;
    ADDR_SIZE MemSize;

Sci_WriteStr("Entering MachineHeapCreate\r\n");

Sci_WriteStr("MemorySize = ");
Sci_WriteHexLong(MemorySize);
Sci_WriteStr("\r\n");
	
    /* Return memory between BSS and Fixed buffer */
    MemBase = (ADDRESS)  end;

Sci_WriteStr("MemBase = ");
Sci_WriteHexLong(MemBase);
Sci_WriteStr("\r\n");

Sci_WriteStr("end = ");
Sci_WriteHexLong((unsigned long)end);
Sci_WriteStr("\r\n");
	
	MemSize = MemoryBase + MemorySize - MemBase;
	
Sci_WriteStr("MemSize = ");
Sci_WriteHexLong(MemSize);
Sci_WriteStr("\r\n");
	
//    DBG(("Memory: %x bytes from 0x%x to 0x%x\n", MemSize, MemBase, MemBase+MemSize));
Sci_WriteStr("Memory: 0x");
Sci_WriteHexLong(MemSize);
Sci_WriteStr(" bytes from 0x");
Sci_WriteHexLong(MemBase);
Sci_WriteStr(" to 0x");
Sci_WriteHexLong(MemBase+MemSize);
Sci_WriteStr("\r\n");
	
	memset(MemBase, 0, MemSize);
	
	return CreateHeapFrom(MemBase, 0, MemSize, MemSize);
}
#endif

