/* Implementation of condition variable functions.
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

/* enable Base.h optimizations, since all your base are belong to us. */
#define OPTIMIZE

#include <mmlite.h>
#include <fred.h>
#include <diagnostics.h>
#include <base/thread2.h>
#include <base/mutex2.h>
#include <base/condition2.h>
#include <base/schedul.h>
#include <schedulif.h>

/* Multiprocessor locking */
/* some compilers do not like empty decls e.g. ';' */
#if !defined(__ARMCC_VERSION) && !defined(ecog)
DEFINE_MPSPINLOCK(ConditionMpLock);
#endif

#if !defined(__ARMCC_VERSION)
static INLINE 
#endif

/* Wait on a condition.
 * If not signalled put thread on a waiting queue.  If pMutex !=
 * NULL unlock the mutex.  If pTimeOut != NULL also put thread on sleep queue.
 * Called either from within IPC path or from vtbl function.
 * Preemption must be disabled.
 *
 * Note that relative timeouts are converted to absolute time in place.
 * That way if the caller of this function loops around (spurious wakeup)
 * it passes back a correct timeout.
 */
void WaitCond(
    PCONDITION pCond,
    PMUTEX pMutex,
    PTIME pTimeOut
    )
{
  UINT IntrState;

  Mutex_Prologue();
  Condition_Prologue();

  assert(!pTheScheduler->v->PreemptionIsEnabled(pTheScheduler));

  /* Put this thread on condition's queue.  Since interrupts are enabled,
   * a signal from an interrupt may come at any time.  This works because
   * in the calls below, ConditionSignalDeferred modify different things.
   * And because no one else tries to queue up in parallel.
   * Notice that WaitForCondition will assert RescheduleNeeded().
   */
  pTheScheduler->v->WaitForCondition(pTheScheduler,
				     (PCONDITION)pCondArg,
				     pTimeOut);

  /* Now we are on the queue and all is well. But.  After we took
   * the scheduler lock, and before (and during) our enqueueing,
   * the condition might have been signalled. (It still could).
   * That routine (might have) found noone in the queue, so it only
   * left an indication that the event happened.
   * Cope with this now, making sure when the scheduler is unlocked
   * the DeferredCondition queue will include this condition.
   *
   * Notice that this also covers the case the condition had been
   * signalled before we took the lock (and noone else cared).
   */

  TURN_INTERRUPTS_OFF(IntrState);
  /* MMLITE_MP need to guard against other cpus */
  MpSpinLock(&ConditionMpLock);

  if (Condition_IsSignalled(pCondArg)) {

    /* Consume the signal.
     */
    Condition_ClearSignalled(pCondArg);

    /* Has been signalled from an interrupt.  If already waited it has
     * been put on the Deferred Condition Signal list, will be processed
     * soon.  Since this thread is now on the waiting list this thread
     * will be processed as well.  If not waited it wasn't put on the
     * deferred list.  Put it on the list now.
     */
    if (!Condition_IsQueued(pCondArg)) {
      Condition_Push((PCOND)pCondArg);
    }
  }

  MpSpinUnlock(&ConditionMpLock);
  RESTORE_INTERRUPTS(IntrState);

  if (pMutexArg != NULL) {
    Mutex_Unlock((PMUTEX)pMutexArg);
  }

  /* Off we go to pick the next runnable thread (possibly us again)
   */
}

/* Release one or more threads which are waiting on a condition.
 * Preemption must be disabled.
 */
PRIVATE void UnwaitCond(
    PCONDITION pCond,
    BOOL fAll,
    SCODE sc
    )
{
  Condition_Prologue();

  assert(!pTheScheduler->v->PreemptionIsEnabled(pTheScheduler));
  assert(pCond != NULL);

  if (!Condition_WaiterQueueIsEmpty(pCondArg)) {
    pTheScheduler->v->WakeUpOnCondition(pTheScheduler,
					(PCONDITION)pCondArg, fAll);
  }
  Condition_ClearSignalled(pCond);
}

/* ==== Interface functions
 */

void Condition_Signal(
    PCONDITION pCond
    )
{
  Condition_Prologue();

  pTheScheduler->v->DisablePreemption(pTheScheduler,FALSE);
  UnwaitCond((PCONDITION)pCondArg, FALSE, S_OK);
  pTheScheduler->v->EnablePreemption(pTheScheduler,FALSE);
}

void Condition_TimedOut(
    PCONDITION pCond
    )
{
  Condition_Prologue();
/* We are only called from WakeStartingThreads, which always has preemption disabled */
  assert(pTheScheduler->v->PreemptionIsEnabled(pTheScheduler) == FALSE);
  UnwaitCond((PCONDITION)pCondArg, FALSE, E_TIMED_OUT);
}

void Condition_Broadcast(
    PCONDITION pCond
    )
{
  Condition_Prologue();

  pTheScheduler->v->DisablePreemption(pTheScheduler,FALSE);
  UnwaitCond((PCONDITION)pCondArg, TRUE, S_OK);
  pTheScheduler->v->EnablePreemption(pTheScheduler,FALSE);
}

SCODE Condition_Wait(
    PCONDITION pCond,
    PMUTEX pMutex,
    PTIME pTimeout
    )
{
  SCODE sc;
  TIME t;
  PITHREAD th = CurrentThread();

  Condition_Prologue();
  Mutex_Prologue();

  /* Make a copy because pTimeout is strictly an input. */
  if (pTimeout) {
    t = *pTimeout;
    pTimeout = &t;
  }

  pTheScheduler->v->DisablePreemption(pTheScheduler, FALSE);
  Thread_SetLastError(CurrentThread(), S_OK);
  WaitCond((PCONDITION)pCondArg, (PMUTEX)pMutexArg, pTimeout);

  pTheScheduler->v->EnablePreemption(pTheScheduler,FALSE);

  sc = th->v->GetValue(th, THREAD_VALUE_LAST_ERROR);

  /* BUGBUG the lock should be taken inside the scheduler
   * so that a signal can pick the right thread. Else
   * the thread wakes up, just to be blocked again here.
   */
  if (pMutex != NULL) {
    Mutex_Lock((PMUTEX)pMutexArg);
  }
  return sc;
}

SCODE Condition_WaitAndBeginConstraint(
    PCONDITION pCond,
    PMUTEX pMutex,
    PTIME pTimeout,
    BOOL EndPrevious,
    PTIME_CONSTRAINT pTimeConstraint,
    PTIME pTimeTaken)
{
  TIME t;

  Condition_Prologue();
  Mutex_Prologue();

  /* Make a copy because pTimeout is strictly an input. */
  if (pTimeout) {
    t = *pTimeout;
    pTimeout = &t;
  }

  return pTheScheduler->v->ConditionTimedWaitAndBeginConstraint(
      pTheScheduler,
      (PCONDITION)pCond,
      (PMUTEX)pMutexArg,
      pTimeout,
      EndPrevious,
      pTimeConstraint,
      pTimeTaken,
      WaitCond);
}


void Condition_Init(PCONDITION pCondition)
{
  Condition_WaiterQueueInitialize(pCondition);
  Condition_SetNext(pCondition, NULL);
  Condition_ClearSignalled(pCondition);
  Condition_ClearQueued(pCondition);
}

void Condition_Destroy(PCONDITION pCondition)
{
  Condition_WaiterQueueInitialize(pCondition);
  Condition_SetBad(pCondition);
}

/* Signal a condition, but from special context (a device ISR).
 * Only assumption that can be made here is *all* interrupts are disabled.
 * [Relaxing this assumption is not that hard though]
 * Returns TRUE if reschedule should happen.  Caller is supposed to return
 * that value to its caller; ultimately get back to the interrupt dispatcher.
 */
BOOL Condition_InterruptSignal(PCONDITION pCond)
{
  /* Assume interrupts are disabled
   */
  /* MMLITE_MP need to guard against other cpus */
  MpSpinLock(&ConditionMpLock);

  /* If the condition is already signalled there is nothing to do (rare) */
  if (Condition_IsAloneAndCleared(pCond)) {
      
    /* Send the condition to the scheduler IFF there are waiters;
     * otherwise just set the signalled bit.  The bit also serves
     * as an indication to WaitCond that this condition has been
     * signalled.  This resolve races where a thread is about to
     * wait on the condition and it gets signalled from an interrupt
     */
    if (!Condition_WaiterQueueIsEmpty(pCond)) {
      Condition_Push((PCOND)pCond);
	  
      MpSpinUnlock(&ConditionMpLock);
      return TRUE;
    }
    else {
      /* There are no waiters, no need for scheduler
       */
      Condition_SetSignalled(pCond);
    }
  }

  MpSpinUnlock(&ConditionMpLock);
  return (FALSE);
}

