/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * StrongArm SA-1100 Interrupt Controller support.
 */

#include <mmlite.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <drivers/drivers.h>
#include <fred.h>
#include <mmhal.h>
#include <_irqSA.h>
#include "_picSA.h"

UINT16 ReadCounter(void);
PCXTINFO _Reschedule(PCXTINFO pContext);
void ChainException(PCXTINFO pContext, UINT ExceptionNum);

typedef struct _ITABLE {
    INTERRUPT_SERVICE_ROUTINE Isr;  /* isr for IRQn*/
    void *pDevice;                  /* Argument to pass to it*/
} ITABLE;

/* The interrupt dispatcher uses a simple table of handlers. */
typedef struct _PIC {
    const struct IPicVtbl *v;
    UINT IRQMask;
    ITABLE InterruptTable[IRQ_ID_COUNT];
} PIC;

/* Forward decl */
extern PIC ThePIC;

/*
 * Only handles IRQ.
 *
 * ToDo:  Is it edge triggered or level triggered?
 *        Is it active high or active low?
 * Meaning, look at Flags.
 */

void MCT EnableInterrupt( IPic *pThis, DEVICE_FLAGS Flags, UINT Irq,
                          INTERRUPT_SERVICE_ROUTINE Isr, void *pDevice)
{
    PIC *pic = (PIC *) pThis;
    UINT i, m;

    /* The order of the following operations is NOT irrelevant
     *
     * First, the argument. Failure case is if interrupt was
     * active and we are called with interrupts on and we get
     * an interrupt right after this statement. Wont happen.
     */
    pic->InterruptTable[ Irq ].pDevice = pDevice;

    /* Second, the ISR. If the interrupt was active we are done already.
     * If not, must activate it.
     */
    pic->InterruptTable[ Irq ].Isr = Isr;

    /* Third, the hardware.
     */
    TheHWPic->Level = TheHWPic->Level & ~(1 << Irq);

    pic->IRQMask |= 1 << Irq;

    i = IntOff();

    m = TheHWPic->Mask;
    m |= 1 << Irq;
    TheHWPic->Mask = m;

    SetPsr(i);

    return;
}

#if 0
void PicDump(void)
{
    dprintf("IPend %08x Mask %08x Level %08x Control %08x FPend %08x Pend %08x\n",
        TheHWPic->IrqPending,TheHWPic->Mask,TheHWPic->Level,TheHWPic->Control,TheHWPic->FiqPending,TheHWPic->Pending);
}
#endif

/*
 * Undo the above EnableInterrupt
 */
void MCT DisableInterrupt( IPic *pThis, UINT Irq, void **pOldDevice)
{
    PIC *pic = (PIC *) pThis;
    UINT i, m;

    /* Remove the ISR and its argument from our tables after setting
     * the hardware.
     */
    pic->IRQMask &= ~(1 << Irq);

    i = IntOff();

    m = TheHWPic->Mask;
    m &= ~(1 << Irq);
    TheHWPic->Mask = m;

    SetPsr(i);

    pic->InterruptTable[ Irq ].Isr = NULL;
    *pOldDevice = pic->InterruptTable[ Irq ].pDevice; /* Return the old one */
    pic->InterruptTable[ Irq ].pDevice = NULL;

    return;
}

/*
 * Mask *all* interrupts.
 */
void MCT MaskAll( IPic *pThis )
{
    PIC *pic = (PIC *) pThis;
    UINT i, m;

    i = IntOff();

    m = TheHWPic->Mask;
    m &= ~pic->IRQMask;
    TheHWPic->Mask = m;

    SetPsr(i);
}

/*
 * Unmask all interrupts that should be unmasked.
 */
void MCT UnmaskAll( IPic *pThis )
{
    PIC *pic = (PIC *) pThis;
    UINT i, m;

    i = IntOff();

    m = TheHWPic->Mask;
    m |= pic->IRQMask;
    TheHWPic->Mask = m;

    SetPsr(i);
}

static const struct IPicVtbl picVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    EnableInterrupt,
    DisableInterrupt,
    MaskAll,
    UnmaskAll
};

PIC ThePIC = {
    &picVtbl,
    0               /* IRQMask */
};

/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
    UnusedParameter(pThis);

    /* Enable all channels*/
    MaskAll(pThis);
}


IPic *PicCreate(void)
{
    IPic *pThis;

    TheHWPic->Mask = 0;
    pThis = (IPic *)&ThePIC;

    return pThis;
}

/******************************************************************************/
/* Normal Interrupt Traps*/
/******************************************************************************/

/* PICGetInterrupt: This function acknowledges the highest priority*/
/* interrupt and returns the level of that interrupt.*/
int PICGetInterrupt(void)
{
    UINT32 picStatus;
    static int picIndex = 0;
    int b, i;

    picStatus = TheHWPic->IrqPending;

    /* Ignore pending interrupts handled by Angel.
     */
    picStatus &= ThePIC.IRQMask;

    if (picStatus) {
        switch (picStatus) {
        case IRQ_MASK_TIMER0:
            return IRQ_ID_TIMER0;
        case IRQ_MASK_RTC:
            return IRQ_ID_RTC;
        default:
            assert(picIndex < 32);

            b = 1 << picIndex;
            for (i = 32; i > 0; --i) {
                if (++picIndex < 32) {
                    b = b << 1;
                } else {
                    picIndex = 0;
                    b = 1;
                }

                if (b & picStatus)
                    return picIndex;
            }
        }
    }

    return -1;
}


#if !defined(ANGELX)

CXTINFO *TrapIRQ(CXTINFO *pContext)
{
    UINT32 DoReschedule;
    BOOL NotMyInterrupt;
    int Index;
    ITABLE *IntSource;

    pContext->PC -= 4;

    /* Try to handle all pending interrupts at once */
    DoReschedule = 0;
    while ( (Index=PICGetInterrupt())>0 ) {
        IntSource=&ThePIC.InterruptTable[Index];

        if (IntSource->Isr)
            DoReschedule |= (IntSource->Isr)(IntSource->pDevice, &NotMyInterrupt);
    }

    /* If any handlers requested a reschedule, it will get done */
    if (DoReschedule)
        pContext = _Reschedule(pContext);

    return pContext;
}

#else

UINT32  maxIrqTime = 0;
UINT32  minIrqTime = 0xFFFF;
UINT32  hiTime;
TIME    IrqStartTime = Int64Initializer(0, 0);
BOOL    IRQTracking = FALSE;

INT     IrqReenterCount = -1;
INT     maxIrqReenterCount;
UINT    startAngelTime;
UINT    maxUserAngel;

UINT    IrqChain;
UINT    IrqSimIRQ;
UINT    maxAngel;

UINT    AngelActive;
UINT    maxAngelActive;

CXTINFO *FromAngelIrq(CXTINFO *pContext)
{
    UINT32 stopAngelTime, elapsedTime;

    if ((0x80 & IntOff()) == 0)
        DebugBreak();

    --AngelActive;

    stopAngelTime = ReadCounter();
    elapsedTime = (UINT16) (startAngelTime - stopAngelTime);
    if (elapsedTime > maxUserAngel)
        maxUserAngel = elapsedTime;

    if (IRQTracking && 0 == IrqReenterCount) {
        static first = FALSE;
        TIME endTime;
        UINT32 elapsedTime;

        if (first) {
            first = FALSE;
        } else {
            endTime = GetKernelTime();
            endTime = TimeSubtract(endTime, IrqStartTime);
            hiTime |= Int64ToInt32(Int64RShift(endTime, 32));
            elapsedTime = Int64ToInt32(endTime);

            if (elapsedTime < minIrqTime) minIrqTime = elapsedTime;
            if (elapsedTime > maxIrqTime) maxIrqTime = elapsedTime;
        }
    }


    if ((0x80 & IntOff()) == 0)
        DebugBreak();

    --IrqReenterCount;

    return pContext;
}

void PICHandleAlternateIrq(CXTINFO *pContext)
{
    UINT16 picStatus;
    extern void SimulateAngelIRQ(CXTINFO *);
    extern void ToAngelIrqHandler(CXTINFO *);

    if ((0x80 & IntOff()) == 0)
        DebugBreak();

    picStatus = TheHWPic->IrqPending;

    /* Pass all unhandled IRQ's to Angel.
     * N.B.  ChainException does not return.
     */
    if (picStatus & ~ThePIC.IRQMask) {
#if 0
--IrqReenterCount;
ChainException(pContext,0);
#endif
        if ((pContext->CPSR & 0x1f) == 0x13) {
            UINT32 start, end, elapsed;

            ++IrqSimIRQ;
            start = ReadCounter();
            SimulateAngelIRQ(pContext);     // This returns
            end = ReadCounter();
            elapsed = start - end;
            if (elapsed > maxAngel)
                maxAngel = elapsed;

            if ((0x80 & IntOff()) == 0)
                DebugBreak();
        } else {
            ++IrqChain;
#if 0
--IrqReenterCount;
ChainException(pContext,0);
#endif
            startAngelTime = ReadCounter();
            ++AngelActive;
            if (AngelActive > maxAngelActive)
                maxAngelActive = AngelActive;

            // THIS DOES NOT RETURN.  Control returns
            // to FromAngelIrq().
            ToAngelIrqHandler(pContext);
            DebugBreak();
        }
    }
}

CXTINFO *TrapIRQ(CXTINFO *pContext)
{
    UINT32 DoReschedule;
    BOOL NotMyInterrupt;
    int Index;
    ITABLE *IntSource;

    pContext->PC -= 4;

    /* No interrupt chaining allowed */
    ++IrqReenterCount;
    if (IrqReenterCount > maxIrqReenterCount)
        maxIrqReenterCount = IrqReenterCount;

    /* Try to handle all pending interrupts at once */
    DoReschedule = 0;
    while ( (Index=PICGetInterrupt())>0 )
    {
        IntSource=&ThePIC.InterruptTable[Index];

        if (IntSource->Isr) {
            DoReschedule |= (IntSource->Isr)(IntSource->pDevice, &NotMyInterrupt);
        }
    }

    if (IRQTracking && 0 == IrqReenterCount)
        IrqStartTime = GetKernelTime();

    /* If any handlers requested a reschedule, it will get done */
    if (DoReschedule) {
        if (0 == IrqReenterCount) {
            pContext = _Reschedule(pContext);
        } else {
            static TIME t = Int64Initializer(0,TIME_MICROS(500));

            SetNextInterrupt(t, NULL);
        }
    }

    /* Won't return if any alternate IRQ (e.g one of Angel's) needs servicing. */
    PICHandleAlternateIrq(pContext);

    if (IRQTracking && 0 == IrqReenterCount) {
        static first = FALSE;
        TIME endTime;
        UINT32 elapsedTime;

        if (first) {
            first = FALSE;
        } else {
            endTime = GetKernelTime();
            endTime = TimeSubtract(endTime, IrqStartTime);
            hiTime |= Int64ToInt32(Int64RShift(endTime, 32));
            elapsedTime = Int64ToInt32(endTime);

            if (elapsedTime < minIrqTime) minIrqTime = elapsedTime;
            if (elapsedTime > maxIrqTime) maxIrqTime = elapsedTime;
        }
    }

    --IrqReenterCount;

    return pContext;
}

enum {Enabled, Disabled} IRQMaskState = Disabled;

UINT32 MaskAllIRQ(void)
{
    UINT32 s;

    if (IRQMaskState == Disabled)
        return Disabled;

    MaskAll((IPic *) &ThePIC);

    s = IRQMaskState;
    IRQMaskState = Disabled;

    return s;
}

void RestoreAllIRQMask(UINT32 s)
{
    assert(s == Disabled || s == Enabled);
    assert(IRQMaskState == Disabled);

    if (s == Enabled) {
        IRQMaskState = Enabled;
        UnmaskAll((IPic *) &ThePIC);
    }
}

void UnmaskAllIRQ(void)
{
    if (IRQMaskState == Disabled) {
        IRQMaskState = Enabled;
        UnmaskAll((IPic *) &ThePIC);
    }
}
#endif
