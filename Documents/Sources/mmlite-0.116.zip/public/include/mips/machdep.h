/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Machine-dependent functions and definitions 
 * which are not otherwise defined in fred.h
 *
 */

//#define __MEMFUNC_ARE_INLINED 0
#define __NEED_M_THDINFO 0

#define MachineSpecificInfo(a,b) (E_NOT_IMPLEMENTED)

#ifdef TIGON
#include <mips/tigon.h>

#define DEFAULT_STACK_SIZE (2*1024)

#else

#define CurrentProcessorKind() (PROCESSOR_KIND_MIPS)
extern UINT CurrentProcessorOEM(void);

extern void MipsMachineIdle(ADDRESS Arg);
#define MACHINE_IDLE(_arg_) MipsMachineIdle((ADDRESS)_arg_)

/* Munging with interrupt enables from C
 */

extern UINT32 IntOff(void);
extern UINT32 IntOn(void);
extern void SetPsr(UINT32 PsrValue);

#define TURN_INTERRUPTS_OFF(_s_) _s_ = IntOff()
#define RESTORE_INTERRUPTS(_s_)  SetPsr(_s_)
#define ENABLE_INTERRUPTS() ((void) IntOn())
#define DISABLE_INTERRUPTS() ((void) IntOff())

#define __SUPPORTS_COB_NAMESPACE 1

//#define DEFAULT_STACK_SIZE (128*1024)  /* use to run SPECmarks on simulator */
#define DEFAULT_STACK_SIZE (4*1024)

#endif /* !TIGON */

extern UINT64 CurrentProcessorSpeed(void);

/* interrupt path: isr->scheduler */
extern PCXTINFO _Reschedule(PCXTINFO);

void SchedulingInterrupt(void); /* ditto */
UINT HWSaveThreadContext(PCXTINFO pCxt); /* ditto */

/* OPTIMIZATION SECTION
 */
