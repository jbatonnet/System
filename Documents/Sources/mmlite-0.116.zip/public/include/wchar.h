/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* wchar.h - definitions for multibyte and wide character utilities */

#ifndef _INC_WCHAR
#define _INC_WCHAR

#define __NEEDS_WCHAR_T 1
#define __NEEDS_WCTYPE_T 1
#define __NEEDS_EXTERN_C 1
#define __NEEDS_SIZE_T 1
#include <__defs.h>

#include <sal.h>

#ifdef __cplusplus
extern "C" {
#endif

/* STRING.H */
size_t __cdecl wcslen(_In_z_ const wchar_t *);
wchar_t *  __cdecl wcscpy(_Out_ wchar_t *, _In_z_ const wchar_t *);
wchar_t *  __cdecl wcscat(_Inout_z_ wchar_t *, _In_z_ const wchar_t *);
int __cdecl wcscmp(const wchar_t *, const wchar_t *);
int __cdecl wcsncmp(const wchar_t *, const wchar_t *, size_t);
wchar_t *  __cdecl wcsncpy(_Out_z_cap_(len) wchar_t *, _In_z_ const wchar_t *, _In_ size_t len);
wchar_t *  __cdecl wcschr(const wchar_t *, int);
int __cdecl _wcsicmp(const wchar_t *, const wchar_t *);
wchar_t *  __cdecl wcspbrk(const wchar_t *, const wchar_t *);
size_t  __cdecl wcscspn(const wchar_t *, const wchar_t *);
size_t  __cdecl wcsspn(const wchar_t *, const wchar_t *);
wchar_t *  __cdecl wcsstr(const wchar_t *, const wchar_t *);

wchar_t * __cdecl _strtow(const char *str); /* strdup to unicode */
char * __cdecl _wcstos(const wchar_t *wcstr); /* strdup to ASCII */
wchar_t * _wcsdup(const wchar_t *wcstr); /* strdup unicode to unicode */
wchar_t * _wcsndup(const wchar_t *wcstr, size_t maxlen);
wchar_t * __cdecl _wcssplit(wchar_t *s1, const wchar_t *delimit);
/*BOOL*/ int _wcsnequal(const wchar_t *s1, size_t l1, const wchar_t *s2, size_t l2);

/* STDIO.H */
int __cdecl wprintf(const wchar_t *, ...);
INT __cdecl getwchar(void);
int __cdecl _putws( const wchar_t *s);
INT __cdecl swprintf(wchar_t *s, const wchar_t *format, ...);
INT __cdecl _snwprintf( wchar_t *s, size_t count, const wchar_t *format, ...);
INT __cdecl wscanf(const wchar_t *format, ...);
INT __cdecl swscanf(const wchar_t *s, const wchar_t *format, ...);
wint_t __cdecl putwchar(wchar_t c);
#ifdef _INC_STDIO /* Define FILE* dependent stuff if stdio.h was included. */
INT __cdecl _wremove(const wchar_t *filename);
FILE* __cdecl _wfopen(const wchar_t *filename, const wchar_t *mode);
wint_t __cdecl fgetwc(FILE *stream);
wint_t __cdecl fputwc(wint_t c, FILE *stream);
int __cdecl fputws(const wchar_t *s, FILE *stream);
wchar_t * __cdecl fgetws(wchar_t *s, int n, FILE *stream);
INT __cdecl fwprintf(FILE *stream, const wchar_t *format, ...);
#ifdef _INC_STDARG /* mandatory pre-inclusion of both stdarg.h and stdio.h */
INT __cdecl vfwprintf(FILE *stream, const wchar_t *format, va_list arg);
#endif
#endif
#ifdef _INC_STDARG /* mandatory pre-inclusion of stdarg.h */
INT __cdecl vswprintf(wchar_t *s, const wchar_t *format, va_list arg);
INT __cdecl _vsnwprintf(wchar_t *s,
                        size_t count,
                        const wchar_t *format,
                        va_list arg);
#endif

/* IO.H */
#ifdef _INC_IO /* mandatory pre-inclusion of io.h */
FILE_HANDLE _wopen(const wchar_t *path, int oflag, ...);
#endif

/* STDLIB */
int __cdecl _wtoi(const wchar_t *);
INT32 __cdecl wcstol(const wchar_t *, wchar_t **, int);
UINT32 __cdecl wcstoul(const wchar_t *nptr, wchar_t **endptr, int base);
UINT __cdecl _wtoh(const wchar_t *);

INT64 __cdecl _wtoi64(const wchar_t *);
INT64 __cdecl _wcstoi64(const wchar_t *, wchar_t **, INT);
UINT32 __cdecl _wcstoui64(const wchar_t *nptr, wchar_t **endptr, INT base);

#ifdef __cplusplus
}
#endif

#endif  /* _INC_WCHAR */
