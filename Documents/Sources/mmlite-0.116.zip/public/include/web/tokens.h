/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* Prefefined ids for some well-known namespaces */
#define NS_any 18
//#define NS_tnstype 27
/* 28... defined in conf/sampleif.xml et al */

/* Tokens corresponding to predefined namespaces in gentypeinfo.c */
/* XXX should generate from XML */

#define TOKEN_any_ANY 0
#define TOKEN_any_href 1
#define TOKEN_any_id 2
#define TOKEN_any_root 3
#define TOKEN_any_Item 4
