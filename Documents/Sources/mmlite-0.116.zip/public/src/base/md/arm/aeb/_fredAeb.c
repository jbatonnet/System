/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * ..placeholder for compile..
 */
#include <mmlite.h>
#include <fred.h>

#define USE_CACHE 0
#define USE_SCRATCHPAD 0

/* Register defines
 */
#define BCR              ((UINT32 *)(0xffffa100))
#define MSR              ((UINT32 *)(0xffffa000))
#define MSRsdr           (MSR+16)
#define MSRstop          (MSR+8)
#define MSRstart         (MSR+0)
#define MSRword(i)       *((UINT32 *)(0xffffa000+(i)))
#define MSRhalfword(i)   (*((UINT32 *)(0xffffa000+(i))) & 0xFFFF)
#define BCRhalfword(i)   (*((UINT32 *)(0xffffa100+(i))) & 0xFFFF)
#define BCRbyte(i)       *((UINT8 *)(0xffffa100+(i)))
#define SDR8             ((UINT32 *)0xffffa060)
#define CCR              ((UINT8 *)0xffffa400)
#define LSCR             ((UINT32 *)0xffffa404)
#define SWRST            ((volatile UINT32 *)0xffffac38)
#define LED              (volatile UINT8 *)(0xFFFF1C08)

#define SCRATCHPAD_START ((UINT32 *)0x60000000)

/* Angel semi-host support
 */
#define angel_SWIreason_ReportException 0x18
#define ADP_Stopped_ApplicationExit     0x20026
#define angel_SWI_ARM                   0x123456

void SetLED(UINT v)
{
    *LED = v << 4;
}

UINT32 MMUFaultAddress(void)
{
    return 0;
}

UINT32 MMUFaultStatus(void)
{
    return 0;
}

void ArmMachineIdle(ADDRESS Arg)
{
    UnusedParameter(Arg);
    /* nothing yet */
}

/* Check for 128K or 256K part */
UINT32 SizeMem()
{
    volatile UINT32 *pa = (UINT32 *)0x3fff8;
    volatile UINT32 *pb = (UINT32 *)0x3fffc;
    volatile UINT32 a, b;
    UINT32 sz;

    /* Save two memory words just below 256K */
    a = *pa;
    b = *pb;

    /* Set memory A, followed by writing a different value on the bus */
    *pa = a + 1;
    *pb = a;

    /* Look for valid memory */
    if (*pa != a + 1) {
         sz = 0x20000;
    } else {
        *pa = a;
        *pb = b;
         sz = 0x40000;
    }
    return sz;
}


/* Flush the cache.
 */
extern void _FlushCache(void); /* the real code */

void FlushCache(void)
{
#if USE_CACHE
    _FlushCache();
#endif
}

#if 0
void DumpAEBMMU(void)
{
    int i;

    for (i=0;i<0x40;i+=4)
        printf("%08x: %08x\n", i, MSRword(i));
    for ( ;i<0x64;i+=4)
        printf("%08x: %08x\n", i, MSRhalfword(i));

    for (i=0;i<0x20;i+=4)
        printf("%08x: %08x\n", i, BCRhalfword(i));
    for ( ;i<0x28;i+=4)
        printf("%08x: %08x\n", i, BCRbyte(i));
    printf("%08x: %08x\n", i, BCRhalfword(i));
    printf("CCR %08x LSCR %08x\n", *CCR, *LSCR);
/* This is for newer board rev C
MSRWord start
00000000: 00000000
00000004: 04000000
00000008: 00000000
0000000c: 00034000
00000010: 00000000
00000014: 00000000
00000018: 00000000
0000001c: 00000000
stop
00000020: 00000000
00000024: 04040000
00000028: 00034000
0000002c: 00040000
00000030: 00000000
00000034: 00000000
00000038: 00000000
0000003c: 00000000
MSRHalf sdr
00000040: 00000000
00000044: 00002c02
00000048: 00007804
0000004c: 00007c08
00000050: 00000000
00000054: 00000000
00000058: 00000000
0000005c: 00000000
00000060: 00007801
BCRHalf bcr
00000000: 00008c00
00000004: 00003003
00000008: 0000900c
0000000c: 0000900c
00000010: 00000000
00000014: 00000000

00000018: 00000000
0000001c: 00000000
00000020: 00000000
BCRByte
00000024: 00000000
00000028: 00000000
CCR 00000001 LSCR 00000000  

And this is with older B revision board:
[same except.. START3->0,STOP2->20000,STOP3->0,SDR3->0,BCR3->0,LSCR=1]
MSRWord start
00000000: 00000000
00000004: 04000000
00000008: 00000000
0000000c: 00000000
00000010: 00000000
00000014: 00000000
00000018: 00000000
0000001c: 00000000
stop
00000020: 00000000
00000024: 04040000
00000028: 00020000
0000002c: 00000000
00000030: 00000000
00000034: 00000000
00000038: 00000000
0000003c: 00000000
MSRHalf sdr
00000040: 00000000
00000044: 00002c02
00000048: 00007804
0000004c: 00000000
00000050: 00000000
00000054: 00000000
00000058: 00000000
0000005c: 00000000
00000060: 00007801
BCRHalf bcr
00000000: 00008c00
00000004: 00003003
00000008: 0000900c
0000000c: 00000000
00000010: 00000000
00000014: 00000000

00000018: 00000000
0000001c: 00000000
00000020: 00000000
BCRByte
00000024: 00000000
00000028: 00000000
CCR 00000001 LSCR 00000001
*/

}
#endif

char REV = '?';

/* Segment layout & config
 */
struct mmu {
   UINT32 bcr;
   UINT32 sdr;
   UINT32 start;
   UINT32 stop;
} AEB1_REV_B_C[8] = {

   /* BANK0: describes the default access properties e.g. SDR8
    * BCR: 8bit SRAM, 0 wait cycles, chip enable CE5
    * SDR: illegal
    * Range: 0..ffffffff
    */
   { 0x8c00, 0, 0, 0},

   /* BANK1:
    * BCR: 16bit SRAM, 3 wait cycles, chip enable CE0
    * SDR: S+U r/o, cached, 32bit, BANK1
    * Range: 256K @ 64M
    */
   { 0x3003, 0x2c02, 0x04000000, 0x04040000},

#define SRAM_SEGMENT 2
   /* BANK2:
    * BCR: 8bit SRAM, 1 wait state, CE1
    * SDR: S+U r/w, cached; 32bit, BANK2
    * Range: 256K @ 0
    */
   { 0x900c, 0x7c04, 0, 0x00040000},

   /* BANKs3-7: Unused
    */
   { 0,0,0,0},
   { 0,0,0,0},
   { 0,0,0,0},
   { 0,0,0,0},
   { 0,0,0,0}
};

/* Possibly multiple configs
 */
static struct mmu *mmu = NULL;

void InitMMU(void)
{
    UINT32 i;

    /* Make sure default segment is set.
     * We got to be able to access this register,
     * else we cant handle the machine at all.
     * NB: After this we could probably touch all
     * registers, UNLESS the ROM has cut us off them.
     * So do the MMU thing next.
     */
    *SDR8 = 0x7801;

    /* Now setup the MMU mappings the way we want them.
     * BUGBUG be nice to be able to tellwhat board we got..
     */
    mmu = AEB1_REV_B_C;
    for (i=0;i<8;++i) {
        if (i<6)
            *(BCR+i)  = mmu[i].bcr;
        *(MSRsdr+i)   = mmu[i].sdr;
        *(MSRstop+i)  = mmu[i].stop;
        *(MSRstart+i) = mmu[i].start;
    }

    /* Flush the cache if necessary
     */
#if USE_CACHE
    if ((*CCR & 1) == 0)
        *CCR  = 1;                              /* enable cache */
    FlushCache();
#else
    *CCR  = 0;                              /* disable cache */
#endif

    /* Adjust the RAM segment according to actual size
     */
    i = SizeMem();
    mmu[SRAM_SEGMENT].stop = i;
    *(MSRstop+SRAM_SEGMENT) = i;

    /* Only way we know to distinguish the boards... sigh.
     */
    REV = (i == 0x20000) ? 'B' : 'C';

#if USE_SCRATCHPAD
    /* Enable local SRAM at 0
     * NB: This is for the newer boards
     */
    if ((*LSCR & 3) != 1) {
        *LSCR = 3;                          /* enable SRAM high */

        /* Copy low 2k of memory into SRAM */
        memcpy(SCRATCHPAD_START, 0, 0x800);

        *LSCR = 1;                          /* enable SRAM low */
    }
#else
    *LSCR = 0;
#endif

}

/* Create the system heap.  Left to machdep code because messy otherwise.
 * The heap should account for all available memory, carved out of memory
 * that is already used or unavailable (like the 640K-1meg hole on PCs).
 * It does not have to account for all the memory in the system.
 * Returns a PIHEAP pointer.
 */

PIHEAP MachineHeapCreate( void )
{
    PIHEAP pIHeap;
    ADDRESS Base = (ADDRESS) _end;

#define MemTop  ((ADDRESS)(mmu[SRAM_SEGMENT].stop))
#define MemBase ((ADDRESS)0x80)      /* memory starts after vector table */
#define MemSize (MemTop - MemBase)
#define _HOLE_STARTS ((ADDRESS)0x8000)
#define _HOLE_SIZE (Base-_HOLE_STARTS)

    pIHeap = CreateHeapFrom(MemBase, 0, MemSize, MemSize);

    /* Carve out "the hole"
     */
    if (MemTop > Base) {
        pIHeap->v->Extract(pIHeap, 0,
                           (PTR)_HOLE_STARTS,
                           _HOLE_SIZE);
    }

    return pIHeap;
}

void TheEnd(void)
{
    /* Too bad this is not connected
     */
    *SWRST = 1;
#if defined(ANGEL_SEMIHOST)
    __asm {
        mov     r0, angel_SWIreason_ReportException
        mov     r1, ADP_Stopped_ApplicationExit
        swi     angel_SWI_ARM
    }
#endif
    DebugBreak();
}
