/* Header file for src\base\list-single.c
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __SET_H__
#define __SET_H__

#include <util/util.h>

/******************************************************************************
 * TYPE DEFINITIONS AND MACROS 
 */

/* Single-linked list and pointer type defines */
typedef struct _SET SET, *PSET;

/* Macros for casting */
#define pS(_ps_) ((PSET)(_ps_))

/* Data structure for set as a linked-list with non-duplicate insertions */
struct _SET {
  PLIST
  PSNODE psnHead;
  PSNODE psnTail;
};

/******************************************************************************
 * NODE MACROS AND METHODS
 */

/*** Node read macros ***/

#define /* PTR */                                                             \
SNode_GetData(/* PSNODE */ _psn_)                                             \
     (pSN(_psn_)->pData)

#define /* PSNODE */                                                          \
SNode_GetNext(/* PSNODE */ _psn_)                                             \
     (pSN(_psn_)->psnNext)

#define /* BOOL */                                                            \
SNode_IsAlone(/* PSNODE */ _psn_)                                             \
     (SNode_GetNext(_psn_) == NULL)


/*** Node write macros ***/

#define /* void */                                                            \
SNode_Init(/* PSNODE */ _psn_,                                                \
           /* PTR    */ _ptr_)                                                \
     SNode_SetNext((_psn_), NULL);                                            \
     SNode_SetData((_psn_), (_ptr_))

#define /* void */                                                            \
SNode_SetData(/* PSNODE */ _psn_,                                             \
            /* PTR    */ _pData_)                                             \
     (SNode_GetData(_psn_) = (_pData_))

#define /* void */                                                            \
SNode_SetNext(/* PSNODE */ _psn_,                                             \
            /* PSNODE */ _psnNext_)                                           \
     (SNode_GetNext(_psn_) = pSN(_psnNext_))


/*** Node methods ***/

PSNODE SNode_Push(
    PSNODE psnStackHead,
    PSNODE psnNew
    );

PSNODE SNode_Pop(
    PSNODE  psnStackHead,
    PPSNODE ppsnPopped
    );

void SNode_InsertAfter(
    PSNODE psnInsertAfter,
    PSNODE psnNew
    );

void SNode_RemoveAfter(
    PSNODE psnPrevious
    );

PSNODE SNode_StackRemove(
    PSNODE psnStackHead,
    PSNODE psnRemove
    );

PSNODE SNode_StackClear(
    PSNODE psnStackHead
    );


/******************************************************************************
 * LIST MACROS AND METHODS
 */

/*** List read macros ***/

#define /* PSLIST */                                                          \
SList_GetHead(/* PSLIST */ _psl_)                                             \
     (pSL(_psl_)->psnHead)

#define /* PSLIST */                                                          \
SList_GetTail(/* PSLIST */ _psl_)                                             \
     (pSL(_psl_)->psnTail)

#define /* BOOL */                                                            \
SList_IsEmpty(/* PSLIST */ _psl_)                                             \
     (SList_GetHead(_psl_) == NULL)


/*** List write macros ***/

#define /* void */                                                            \
SList_SetHead(/* PSLIST */ _psl_,                                             \
              /* PSNODE */ _psnNewHead_)                                      \
     (SList_GetHead(_psl_) = pSN(_psnNewHead_))

#define /* void */                                                            \
SList_SetTail(/* PSLIST */ _psl_,                                             \
              /* PSNODE */ _psnNewTail_)                                      \
     (SList_GetTail(_psl_) = pSN(_psnNewTail_))

#define /* void */                                                            \
SList_Init(/* PSLIST */ _psl_)                                                \
     SList_SetHead((_psl_), NULL);                                            \
     SList_SetTail((_psl_), NULL)


/*** List methods ***/

void SList_Clear(
    PSLIST pslClear
    );

void SList_HeadAdd(
    PSLIST pslAddTo,
    PSNODE psnNew
    );

void SList_TailAdd(
    PSLIST pslAddTo,
    PSNODE psnNew
    );

PSNODE SList_HeadRemove(
    PSLIST pslRemoveFrom
    );

PSNODE SList_TailRemove(
    PSLIST pslRemoveFrom
    );

void SList_Remove(
    PSLIST pslRemoveFrom,
    PSNODE psnRemove
    );

PSNODE SList_FindData(
    PSLIST pslThis,
    PTR pFindData
    );

PSNODE SList_FindDataAndRemove(
    PSLIST pslRemoveFrom,
    PTR pFindData
    );

PTR SList_FindDataMax(
    PSLIST pslThis,
    CompareFunc CompareGT
    );

PTR SList_RemoveDataMax(
    PSLIST pslThis,
    CompareFunc CompareGT
    );

void SList_TransformData(
    PSLIST pslThis,
    TransformFunc Transform
    );

void SList_TransformDataWithArg(
    PSLIST pslThis,
    TransformArgFunc Transform,
    PTR pArg
);

void SList_InsertSortedDescending(
    PSLIST pslThis,
    CompareFunc CompareGT,
    PSNODE psnNew
    );

#endif /* __LIST_SINGLE_H__ */
