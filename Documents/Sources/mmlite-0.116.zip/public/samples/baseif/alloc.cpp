/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Get a pointer to the current process heap. */
IHeap *pHeap = CurrentHeap();
void *ptr = NULL;    /* Pointer to void and initially equal to NULL. */
UINT AllocSize = 50;
UINT RealSize;

ptr = pHeap->Alloc(HEAP_ZERO_MEMORY, AllocSize, 0);
if(ptr == NULL)    {
    _tprintf(_TEXT("Memory allocation failed.\n"));
    return 0;
}
/* Determine the actual size of the allocated memory block. */
RealSize = pHeap->Size(0, ptr);
if(AllocSize <= RealSize)
    _tprintf(_TEXT("There were %d extra bytes allocated.\n"), 
             RealSize - AllocSize);
/* END_SAMPLE */
return 0;
}
