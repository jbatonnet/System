/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __KERNEL__THREAD_H__
#define __KERNEL__THREAD_H__

#include "list.h"
#include <util/list-double2.h>

typedef struct _KURGENCY {

    TIME RestartBy;             /* [KernelTime] */
    INT Criticality;

/* CRITICAL/NON_CRITICAL take the first bit */
#define CRITICALITY_MASK 0x1
#define TIME_SHARING 0x2

} KURGENCY, *PKURGENCY;

/* Constraint determines local urgency.
 *
 * Inheritance of all appropriate local urgencies
 * determines inherited urgency.
 */

typedef struct _KCONSTRAINT *PKCONSTRAINT;
typedef struct _KCONSTRAINT {

    TIME TimeOfLastRefresh;     /* [KernelTime] Last time urgency recalc'd  */
    KURGENCY LocalUrgency;      /* Urgency, not including inheritance       */
    PKCONSTRAINT SurroundingConstraint;/* Outer-next surrounding constraint */
    TIME InitialRestartBy;      /* [KernelTime] for calculating TimeTaken   */
    PITHREAD Thread;            /* Currently associated thread              */
    PKCONSTRAINT Owner;         /* Constr. which owns the obj we wait for   */
    PKCONSTRAINT FirstWaiter;   /* First constr. waiting for an obj we own  */
    PKCONSTRAINT NextWaiter;    /* Next constr. waiting for same obj as us  */
    KURGENCY CachedInheritedUrgency; /* Cached inherited urgency            */
    BOOL CachedInheritedUrgencyValid; /* Is CachedInheritedUrgency valid?   */

} KCONSTRAINT;

typedef struct _KPENDING_CONSTRAINT {

    PTIME TimeTaken;            /* (Relative Time) */
    BOOL EndPrevious;
    INT Criticality;
    TIME Start;
    TIME Estimate;
    TIME Deadline;

} KPENDING_CONSTRAINT, *PKPENDING_CONSTRAINT;

typedef struct _THDINFO *PTHDINFO;
typedef struct _THDINFO {
    const struct IThreadVtbl *v;
    UINT RefCnt;               /* Reference count (see below)               */

    CXTINFO *CxtInfo;          /* Full context (when not running)           */

    SCODE LastError;           /* Get/SetLastError                          */
    PTR pTls;                  /* Support for Thread Local Storage          */

                               /* resource tracking                         */
    PBYTE  StackBase;          /* Stack info                                */
    UINT   StackSize;
    PIPROCESS StartedIn;       /* initially created in this process/module  */

#define NEWLIST 1
#if NEWLIST
    ListNodeDeclare(_THDINFO, QueueLink); /* List of threads in a queue */
#define TQ_off offsetof(struct _THDINFO, QueueLink)
#else
    LISTNODE Queue;            /* List of threads in a queue                */
#endif
    INT QueueType;             /* Type of queue thread is on, if any        */
#define QUEUE_NONE      0       /* Not on a queue                            */
#define QUEUE_READY     1       /* On the global ready queue                 */
#define QUEUE_MUTEX     3       /* On a mutex-specific queue                 */
#define QUEUE_CONDITION 4       /* On a condition-specific queue             */
#define QUEUE_RWLOCK    5       /* On a rwlock-specific queue                */

    UINT State;                /* What to do at context switch              */
#define THD_READY       0       /* Able to be run but not yet running        */
#define THD_WAITING     1       /* Waiting for object and/or timeout         */
#define THD_RUNNING     2       /* Current thread (for a given cpu)          */
#define THD_DEAD        4       /* Going away                                */
#define THD_IDLE        5       /* Playing IdleThread                        */

    PTR WaitObject;            /* What object am I waiting on               */
    UINT WaitData;             /* Together with WaitObject                  */
    INT WaitType;              /* What type of object am I waiting on       */
#define WAIT_TIMER      0       /* Sleep                                     */
#define WAIT_MUTEX      1       /* Mutex_Lock                                */
#define WAIT_CONDITION  2       /* Condition_Wait                            */

    /* Another queue link, for sleeping only */
#define SLEEPLIST 1
#if SLEEPLIST
    ListNodeDeclare(_THDINFO, SleepQueueLink);
#define TSQ_off offsetof(struct _THDINFO, SleepQueueLink)
#else
    LISTNODE SleepQueue;       /* Another queue link, for sleeping only     */
#endif

    TIME StartTime;            /* [CurrentTime] When to reschedule again    */
    PKCONSTRAINT Constraint;   /* Current constraint for this thread        */
    PKPENDING_CONSTRAINT PendingConstraint; /* Pending constraint, if any   */

    PKCONSTRAINT FreeConstraint; /* Used when constraint stops pending      */

#if NEWLIST
    PTHDINFO ThdMxWaiters;     /* Thds waiting on mutexes owned by this thd */
    PTHDINFO ThdCdWaiters;     /* Thds waiting on cond waited by this thd   */
#else
    PLISTNODE plnThdMxWaiters; /* Thds waiting on mutexes owned by this thd */
    PLISTNODE plnThdCdWaiters; /* Thds waiting on cond waited by this thd   */
#endif
#if 0                           /* not used */
    PIUNKNOWN pIActivity;       /* Activity associated with this thread      */
#endif

    /* Storage for constraints and pending constraints */
    KPENDING_CONSTRAINT PConst;/* The one available pending constraint      */
    KCONSTRAINT InitialConstraint;/* The initial constraint                 */

    /* The virtual memory space page faults should be resolved in. NULL=phys */
    PIVMVIEW pVmView;

    /* State for post-processing of RPCs */
    PTR RpcContinuation;
    PTR SchedBar;

#if __NEED_M_THDINFO
    /* Struct below is machine-specific                           */
    M_THDINFO ThreadMInfo; /* If defined must be multiple of 8 bytes */
#endif
} THDINFO;

/* Macros
 */
#define pTH(iThd)  ((PTHDINFO)  (iThd))
#define iTH(pThd)  ((PITHREAD)  (pThd))
#define GetThreadFrom(_ptr_,_field_) ((PTHDINFO)((UINT)(_ptr_) - offsetof(THDINFO,_field_)))

#define ThreadGetState(_t_) pTH(_t_)->State
#define ThreadSetState(_t_,_v_) pTH(_t_)->State = _v_

#endif /* !__KERNEL__THREAD_H__ */
