/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Copyright (c) 1982, 1986, 1993
 *    The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the University of
 *    California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *    @(#)tcp_var.h    8.1 (Berkeley) 6/10/93
 */

/*
 * Kernel variables for tcp.
 */

/*
 * Tcp control block, one per tcp; fields:
 */
struct tcpcb {
    struct tcpiphdr *seg_next;    /* sequencing queue */
    struct tcpiphdr *seg_prev;
    INT16 t_state;                /* state of this connection */
    INT16 t_timer[TCPT_NTIMERS];  /* tcp timers */
    INT16 t_rxtshift;             /* log(2) of rexmt exp. backoff */
    INT16 t_rxtcur;               /* current retransmit value */
    INT16 t_dupacks;              /* consecutive dup acks recd */
    UINT16 t_maxseg;              /* maximum segment size */
    INT8 t_force;                 /* 1 if forcing out a byte */
    UINT16 t_flags;
#define TF_ACKNOW      0x0001     /* ack peer immediately */
#define TF_DELACK      0x0002     /* ack, but try to delay it */
#define TF_NODELAY     0x0004     /* don't delay packets to coalesce */
#define TF_NOOPT       0x0008     /* don't use tcp options */
#define TF_SENTFIN     0x0010     /* have sent FIN */
#define TF_REQ_SCALE   0x0020     /* have/will request window scaling */
#define TF_RCVD_SCALE  0x0040     /* other side has requested scaling */
#define TF_REQ_TSTMP   0x0080     /* have/will request timestamps */
#define TF_RCVD_TSTMP  0x0100     /* a timestamp was received in SYN */
#define TF_SACK_PERMIT 0x0200     /* other side said I could SACK */

    struct tcpiphdr *t_template;  /* skeletal packet for transmit */
    struct inpcb *t_inpcb;        /* back pointer to internet pcb */
/*
 * The following fields are used as in the protocol specification.
 * See RFC783, Dec. 1981, page 21.
 */
/* send sequence variables */
    tcp_seq snd_una;              /* send unacknowledged */
    tcp_seq snd_nxt;              /* send next */
    tcp_seq snd_up;               /* send urgent pointer */
    tcp_seq snd_wl1;              /* window update seg seq number */
    tcp_seq snd_wl2;              /* window update seg ack number */
    tcp_seq iss;                  /* initial send sequence number */
    UINT32 snd_wnd;               /* send window */
/* receive sequence variables */
    UINT32 rcv_wnd;               /* receive window */
    tcp_seq rcv_nxt;              /* receive next */
    tcp_seq rcv_up;               /* receive urgent pointer */
    tcp_seq irs;                  /* initial receive sequence number */
/*
 * Additional variables for this implementation.
 */
/* receive variables */
    tcp_seq rcv_adv;              /* advertised window */
/* retransmit variables */
    tcp_seq snd_max;              /* highest sequence number sent;
                                   * used to recognize retransmits
                                   */
/* congestion control (for slow start, source quench, retransmit after loss) */
    UINT32 snd_cwnd;              /* congestion-controlled window */
    UINT32 snd_ssthresh;          /* snd_cwnd size threshhold for
                                   * for slow start exponential to
                                   * linear switch
                                   */
/*
 * transmit timing stuff.  See below for scale of srtt and rttvar.
 * "Variance" is actually smoothed difference.
 */
    INT16 t_idle;                 /* inactivity time */
    INT16 t_rtt;                  /* round trip time */
    tcp_seq t_rtseq;              /* sequence number being timed */
    INT16 t_srtt;                 /* smoothed round-trip time */
    INT16 t_rttvar;               /* variance in round-trip time */
    UINT16 t_rttmin;              /* minimum rtt allowed */
    UINT32 max_sndwnd;            /* largest window peer has offered */

/* out-of-band data */
    char t_oobflags;              /* have some */
    char t_iobc;                  /* input character */
#define TCPOOB_HAVEDATA 0x01
#define TCPOOB_HADDATA  0x02
    INT16 t_softerror;            /* possible error not yet reported */

/* RFC 1323 variables */
    UINT8 snd_scale;              /* window scaling for send window */
    UINT8 rcv_scale;              /* window scaling for recv window */
    UINT8 request_r_scale;        /* pending window scaling */
    UINT8 requested_s_scale;
    UINT32 ts_recent;             /* timestamp echo data */
    UINT32 ts_recent_age;         /* when last updated */
    tcp_seq    last_ack_sent;

};

#define intotcpcb(ip) ((struct tcpcb *)(ip)->inp_ppcb)
#define sototcpcb(so) (intotcpcb(sotoinpcb(so)))

/*
 * The smoothed round-trip time and estimated variance
 * are stored as fixed point numbers scaled by the values below.
 * For convenience, these scales are also used in smoothing the average
 * (smoothed = (1/scale)sample + ((scale-1)/scale)smoothed).
 * With these scales, srtt has 3 bits to the right of the binary point,
 * and thus an "ALPHA" of 0.875.  rttvar has 2 bits to the right of the
 * binary point, and is smoothed with an ALPHA of 0.75.
 */
#define TCP_RTT_SCALE    8  /* multiplier for srtt; 3 bits frac. */
#define TCP_RTT_SHIFT    3  /* shift for srtt; 3 bits frac. */
#define TCP_RTTVAR_SCALE 4  /* multiplier for rttvar; 2 bits */
#define TCP_RTTVAR_SHIFT 2  /* multiplier for rttvar; 2 bits */

/*
 * The initial retransmission should happen at rtt + 4 * rttvar.
 * Because of the way we do the smoothing, srtt and rttvar
 * will each average +1/2 tick of bias.  When we compute
 * the retransmit timer, we want 1/2 tick of rounding and
 * 1 extra tick because of +-1/2 tick uncertainty in the
 * firing of the timer.  The bias will give us exactly the
 * 1.5 tick we need.  But, because the bias is
 * statistical, we have to test that we don't drop below
 * the minimum feasible timer (which is 2 ticks).
 * This macro assumes that the value of TCP_RTTVAR_SCALE
 * is the same as the multiplier for rttvar.
 */
#define TCP_REXMTVAL(tp) \
    (((tp)->t_srtt >> TCP_RTT_SHIFT) + (tp)->t_rttvar)

/* XXX
 * We want to avoid doing m_pullup on incoming packets but that
 * means avoiding dtom on the tcp reassembly code.  That in turn means
 * keeping an mbuf pointer in the reassembly queue (since we might
 * have a cluster).  As a quick hack, the source & destination
 * port numbers (which are no longer needed once we've located the
 * tcpcb) are overlayed with an mbuf pointer.
 */
#define REASS_MBUF(ti) (*(struct mbuf **)&((ti)->ti_t))

/*
 * TCP statistics.
 * Many of these should be kept per connection,
 * but that's inconvenient at the moment.
 */
struct tcpstat {
    UINT tcps_connattempt;      /* connections initiated */
    UINT tcps_accepts;          /* connections accepted */
    UINT tcps_connects;         /* connections established */
    UINT tcps_drops;            /* connections dropped */
    UINT tcps_conndrops;        /* embryonic connections dropped */
    UINT tcps_closed;           /* conn. closed (includes drops) */
    UINT tcps_segstimed;        /* segs where we tried to get rtt */
    UINT tcps_rttupdated;       /* times we succeeded */
    UINT tcps_delack;           /* delayed acks sent */
    UINT tcps_timeoutdrop;      /* conn. dropped in rxmt timeout */
    UINT tcps_rexmttimeo;       /* retransmit timeouts */
    UINT tcps_persisttimeo;     /* persist timeouts */
    UINT tcps_keeptimeo;        /* keepalive timeouts */
    UINT tcps_keepprobe;        /* keepalive probes sent */
    UINT tcps_keepdrops;        /* connections dropped in keepalive */

    UINT tcps_sndtotal;         /* total packets sent */
    UINT tcps_sndpack;          /* data packets sent */
    UINT tcps_sndbyte;          /* data bytes sent */
    UINT tcps_sndrexmitpack;    /* data packets retransmitted */
    UINT tcps_sndrexmitbyte;    /* data bytes retransmitted */
    UINT tcps_sndacks;          /* ack-only packets sent */
    UINT tcps_sndprobe;         /* window probes sent */
    UINT tcps_sndurg;           /* packets sent with URG only */
    UINT tcps_sndwinup;         /* window update-only packets sent */
    UINT tcps_sndctrl;          /* control (SYN|FIN|RST) packets sent */

    UINT tcps_rcvtotal;         /* total packets received */
    UINT tcps_rcvpack;          /* packets received in sequence */
    UINT tcps_rcvbyte;          /* bytes received in sequence */
    UINT tcps_rcvbadsum;        /* packets received with ccksum errs */
    UINT tcps_rcvbadoff;        /* packets received with bad offset */
    UINT tcps_rcvshort;         /* packets received too short */
    UINT tcps_rcvduppack;       /* duplicate-only packets received */
    UINT tcps_rcvdupbyte;       /* duplicate-only bytes received */
    UINT tcps_rcvpartduppack;   /* packets with some duplicate data */
    UINT tcps_rcvpartdupbyte;   /* dup. bytes in part-dup. packets */
    UINT tcps_rcvoopack;        /* out-of-order packets received */
    UINT tcps_rcvoobyte;        /* out-of-order bytes received */
    UINT tcps_rcvpackafterwin;  /* packets with data after window */
    UINT tcps_rcvbyteafterwin;  /* bytes rcvd after window */
    UINT tcps_rcvafterclose;    /* packets rcvd after "close" */
    UINT tcps_rcvwinprobe;      /* rcvd window probe packets */
    UINT tcps_rcvdupack;        /* rcvd duplicate acks */
    UINT tcps_rcvacktoomuch;    /* rcvd acks for unsent data */
    UINT tcps_rcvackpack;       /* rcvd ack packets */
    UINT tcps_rcvackbyte;       /* bytes acked by rcvd acks */
    UINT tcps_rcvwinupd;        /* rcvd window update packets */
    UINT tcps_pawsdrop;         /* segments dropped due to PAWS */
};

#ifdef KERNEL
extern struct inpcb tcb;        /* head of queue of active tcpcb's */
extern struct tcpstat tcpstat;  /* tcp statistics */
extern UINT32 tcp_now;          /* for RFC 1323 timestamps */

INT tcp_attach(struct socket *);
void tcp_canceltimers(struct tcpcb *);
struct tcpcb * tcp_close(struct tcpcb *);
void tcp_ctlinput(INT, struct sockaddr *, caddr_t);
INT tcp_ctloutput(INT, struct socket *, INT, INT, struct mbuf **);
struct tcpcb * tcp_disconnect(struct tcpcb *);
struct tcpcb * tcp_drop(struct tcpcb *, INT);
void tcp_dooptions(struct tcpcb *, UINT8 *, INT, struct tcpiphdr *, INT *,
                   UINT32 *, UINT32 *);
void tcp_drain(void);
void tcp_fasttimo(void);
void tcp_init(void);
void tcp_input(struct mbuf *, INT);
INT tcp_mass(struct tcpcb *, UINT);
struct tcpcb * tcp_newtcpcb(struct inpcb *);
void tcp_notify(struct inpcb *, INT);
INT tcp_output(struct tcpcb *);
void tcp_pulloutofband(struct socket *, struct tcpiphdr *, struct mbuf *);
void tcp_quench(struct inpcb *, INT);
INT tcp_reass(struct tcpcb *, struct tcpiphdr *, struct mbuf *);
void tcp_respond(struct tcpcb *, struct tcpiphdr *, struct mbuf *, UINT32,
                 UINT32, INT);
void tcp_setpersist(struct tcpcb *);
void tcp_slowtimo(void);
struct tcpiphdr * tcp_template(struct tcpcb *);
struct tcpcb * tcp_timers(struct tcpcb *, INT);
struct tcpcb * tcp_usrclosed(struct tcpcb *);
INT tcp_usrreq(struct socket *, INT, struct mbuf *, struct mbuf *,
               struct mbuf *);
void tcp_xmit_timer(struct tcpcb *, INT);
INT tcp_mss(register struct tcpcb *tp, UINT16 offer);
#endif
