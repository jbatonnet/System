/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
IModule *pModule;
SCODE StatusCode;
_TCHAR pName[100];

StatusCode = GetCurrentModule(&pModule);
if (FAILED(StatusCode)) {
    _tprintf(_T("Error getting current module: %x\n"), StatusCode);
    exit(0);
}

/* Get the name of the current module. */
if((StatusCode = pModule->GetName(pName, 100)) != 0) {
    _tprintf(_T("Error getting module name: %x\n"), StatusCode);
    exit(0);
}
_tprintf(_T("The module name is %s.\n"), pName);
/* END_SAMPLE */
return 0;
}
