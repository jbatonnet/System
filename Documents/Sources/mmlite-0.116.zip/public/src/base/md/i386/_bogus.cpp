/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <stdio.h>

/* synthdbg calls this */
void AssertMessage(const _TCHAR *pszValue, const _TCHAR *pszFile, int nLine)
{
    printf("ASSERTMESSAGE: Assertion `%s' failed at %s:%u\n", pszValue, pszFile, nLine);
}
