/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <machdep.h>
#include <fred.h>
#include <base/debugger.h>

/* Values to set given baud rates */
#define BAUD_230400 0x000 
#define BAUD_115200 0x001 
#define BAUD_57600  0x003 
#define BAUD_38400  0x005 
#define BAUD_19200  0x00B 
#define BAUD_14400  0x00F 
#define BAUD_9600   0x017 
#define BAUD_2400   0x05F 
#define BAUD_1200   0x0BF    
#define DEFAULT_BAUD     BAUD_115200

typedef struct _UART {
    volatile UINT32  cr0;
    volatile UINT32  cr1;
    volatile UINT32  cr2;
    volatile UINT32  cr3;
    volatile UINT32  cr4;
    volatile UINT32  data;
    volatile UINT32  reserved1;
    volatile UINT32  sr0;
    volatile UINT32  sr1;
} UART;

#define Uart1 ((UART *) 0x80010000)
#define Uart2 ((UART *) 0x80030000)
#define Uart3 ((UART *) 0x80050000)

typedef struct _SDLC {
    volatile UINT32 cr0;
    volatile UINT32 cr1;
    volatile UINT32 cr2;
    volatile UINT32 cr3;
    volatile UINT32 cr4;
    volatile UINT32 reserved0;
    volatile UINT32 data;
    volatile UINT32 reserved1;
    volatile UINT32 sr0;
    volatile UINT32 sr1;
} SDLC;

#define Sdlc  ((SDLC *) 0x80020060)

typedef struct _HSSP {
    volatile UINT32 cr0;
    volatile UINT32 cr1;
    volatile UINT32 reserved0;
    volatile UINT32 data;
    volatile UINT32 reserved1;
    volatile UINT32 sr0;
    volatile UINT32 sr1;
} HSSP;

#define Hssp ((HSSP *) 0x80040060)

typedef struct _PPC {
    volatile UINT32 direction;
    volatile UINT32 state;
    volatile UINT32 assignment;
    volatile UINT32 sleepdir;
    volatile UINT32 flag;
    volatile UINT32 reserved1;
    volatile UINT32 reserved2;
    volatile UINT32 reserved3;
    volatile UINT32 reserved4;
    volatile UINT32 reserved5;
    volatile UINT32 hssp_cr2;
    volatile UINT32 reserved6;
    volatile UINT32 mcp_cr1;
} PPC;

#define Ppc   ((PPC *) 0x90060000)

typedef struct _GPIO {
    volatile UINT32 level;
    volatile UINT32 direction;
    volatile UINT32 outSet;
    volatile UINT32 outClear;
    volatile UINT32 risingDetect;
    volatile UINT32 fallingDetect;
    volatile UINT32 edgeDetect;
    volatile UINT32 alternate;
} GPIO;

#define Gpio  ((GPIO *) 0x90040000)

#define IRSPD       0x01
#define TVRMT       0x02
#define HLEDD_MASK  0x0F
#define HL0ST       0x10
#define HL1ST       0x20
#define VIDCAP      0x40
#define ENINT       0x80

#define Hled  ((volatile UINT32 *) 0x18C00000)

//hornet+sidearm+cerfboard
#define DbgPort Uart3

UART *DxPort = DbgPort;

/* *** ComPortInit
 *
 * Initializes a COM port for low-level (polling) debugging use.
 *
 */
void ComPortInit(UART *Port, UINT Baud, BOOL UseFifo)
{
#if 0
    UINT32 tmp;
    UINT divisor;

    UnusedParameter(UseFifo);

    switch (Baud) {
        case   9600:
            divisor = BAUD_9600;
            break;
        case  19200:
            divisor = BAUD_19200;
            break;
        case  38400:
            divisor = BAUD_38400;
            break;
        case  57600:
            divisor = BAUD_57600;
            break;
        case 115200:
            divisor = BAUD_115200;
            break;
        default:     
            divisor = DEFAULT_BAUD;
    }

    if (Port == Uart1) {

        /* set up GPIO pins 14:15 for UART tx/rx */

        /* Set up UART Pin Reassignment bit in PPC Pin Assignment Register */
        Ppc->assignment = 0x1000;   /* set bit 12: serial port 1 defaults to SDLC,
                                            GPIO[14] = Rx, GPIO[15] = Tx, SUS ignored. */

        /* set up the GADR and GAFR registers correctly */
        tmp = Gpio->direction;
        tmp |= 0x4000;              /* 14 = output, 15 = input */
        Gpio->direction = tmp;

        tmp = Gpio->alternate;
        tmp |= 0xC000;              /* pins 15:14 are used for UART RX and TX */
        Gpio->alternate = tmp;
    
    } else if (Port == Uart2) {

        Gpio->alternate = Gpio->alternate & ~(1 << 19);

        *Hled = HL1ST | 8;          /* bit0 0=SIR, 1=FIR */

        Port->cr3 = 0x0;
        Port->sr0 = 0xff;           /* clear sticky bits */

        Hssp->cr0 = 0;

        Ppc->hssp_cr2 = (Ppc->hssp_cr2 & ~0x000C0000) | 0x000C0000;

        Port->cr4 = 1;
        Port->cr0 = 8;

        Port->cr2 = divisor;
        Port->cr1 = 0;
        Port->cr3 = 3;

        return;
    
    } else if (Port == Uart3) {

#if 0
        /* make sure direction is read */
        tmp = Gpio->direction;
        tmp &= ~0x1;
        Gpio->direction = tmp;
#endif

    }

    Port->cr3 = 0;

    /* clear */
    Port->sr0 = 0xff;

    /* 8 bit, no parity, 1 stop */
    Port->cr0 = 0x08;

    /* upper baud rate select */
    Port->cr1 = 0x00;

    /* set baud rate */
    Port->cr2 = divisor;

    /* enable tx and rx bits and disable interrupts */
    Port->cr3 = 0x03;
#endif
}


/* *** ComPortPut
 *
 * Write a byte to the specified port.
 */
void ComPortPut(UART *Port, UINT8 Byte)
{
    /* wait until we can transmit */
    while ((Port->sr1 & 4) == 0)
        continue;

    Port->data = Byte;
}


UINT ComPortErrors = 0;

/* *** ComPortGet
 *
 * Read a byte from the specified port.
 * Returns FALSE if there was no byte ready
 * to be read, or in case of error.
 */
BOOL ComPortGet(UART *Port, UINT8 *pByte)
{
    UINT32 status = Port->sr1;

    if (status & 0x2) {
        *pByte = (UINT8) Port->data;

        if (status & 0x38) {            /* Check for errors */
            ComPortErrors++;
            if ((status & 0x20) == 0)   /* Overrun? */
                return FALSE;           /*  no, parity or framing error */
        }

        return TRUE;
    }

    return FALSE;
}

#define USE_SERIAL_LINE 1
#define USE_DEBUGGER_OUTPUT 1
#define dputc DCPutChar
unsigned char dgetc(int);


void DbgPortInit(void)
{
#if defined(USE_SERIAL_LINE)

    /* wait for any characters to drain */
    while ((DxPort->sr1 & 1) != 0)
        continue;

    ComPortInit(DxPort, 38400, FALSE);

    /* We dont need a go-ahead, as we dont use ANGEL debugging
     */
#if 0
    {
        int i;
        printf("MMLite...press mm\n");

        /* Wait for someone to give us the go-ahead.
         */
        for (i = 2; i > 0; --i)
            if ('m' != dgetc(FALSE))
                i = 3;
    }
#endif
#endif
}

static BOOL dxInit = TRUE;

void dputc(unsigned char c)
{
#if defined(USE_SERIAL_LINE)
#if defined(USE_DEBUGGER_OUTPUT)
    DebuggerOutputString(&c, 1);
#else
    if (dxInit) {
        dxInit = FALSE;
        DbgPortInit();
    }

    if (c == '\n')
        ComPortPut(DxPort, '\r');
    ComPortPut(DxPort, c);
#endif
#endif
}

unsigned char dgetc(int echo)
{
#if defined(USE_SERIAL_LINE)
    unsigned char c;

    while (!ComPortGet(DxPort, &c)) {
        //SleepUntil(TIME_ORIGIN);
        continue;
    }

    if (echo == TRUE)       
        dputc(c);

    if (/*DebuggerAttached &&*/ (c == 3)) /* ^C , likely from GDB */
        DebugBreak();

    return c;
#else
    return 0;
#endif
}

void putDebugChar(unsigned char c)
{
    if (dxInit) {
        dxInit = FALSE;
        DbgPortInit();
    }
    ComPortPut(DxPort, c);
}

int getDebugChar(void)
{
    unsigned char c;

    while (!ComPortGet(DxPort, &c))
        continue;

    return c;
}

