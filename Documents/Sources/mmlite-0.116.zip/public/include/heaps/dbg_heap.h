/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Debugging heap: see src/heaps/dbg_heap.c */

/* Convenience macros for conditional compilation */
#ifdef _USE_DEBUG_HEAP
#define _GetHeap(_name_, _maxsize_) CreateDebugHeap(_name_, HEAP_NESTED_HEAP, _maxsize_, 8)
#define _PutHeap(_iheap_) (_iheap_)->v->Release((_iheap_))
#else
#define _GetHeap(_name_, _maxsize_) CurrentHeap()
#define _PutHeap(_iheap_)
#endif

/* Constructor */
PIHEAP CreateDebugHeap(const _TCHAR *Name,
                       UINT Flags,
                       UINT MaxSize,
                       UINT TrailerSize);
