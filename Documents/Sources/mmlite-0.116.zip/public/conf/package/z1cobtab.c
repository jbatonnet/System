/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <loaders/cobtab.h>

extern PIUNKNOWN FMRadioCobMain(void);
extern PIUNKNOWN SerialCobMain(void);
extern PIUNKNOWN DriverCfgCobMain(void);

const struct PRECOB ThePreCobTable[] = {
  {"drivercfg.cob", DriverCfgCobMain },
  {"drivers.cob", DriversCobMain },
  {"at91x40.cob", SerialCobMain },
#if 0 /* This is only for the sensor board */
  {"fmradio.cob", FMRadioCobMain },
#endif
  {0,0}
};
