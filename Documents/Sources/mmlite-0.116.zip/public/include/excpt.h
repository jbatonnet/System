/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* empty file. Windows.h needs it */

/* Well, with SDK V7 one definition is required from it to compile winnt.h. */
typedef enum _EXCEPTION_DISPOSITION EXCEPTION_DISPOSITION;
