/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <stdio.h>
#include <mmlite.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <diagnostics.h>
#include <loaders/cobtab.h>

SCODE FirstApp(const _TCHAR *Args)
{
    UnusedParameter(Args);
    //return RunSoapServer(_T("x-udp-aes-soap://sr1"), TRUE);
    printf("ntusec.c: CODE DELETED\n");
    return E_NOT_IMPLEMENTED;
}

const struct PRECOB ThePreCobTable[] = {
#if 1
    NTUSEC_COBS
#else
    BASIC_NET_COBS
    BASIC_SOAP_UDP_COBS
    PRIVATE_SOAP_COBS
    {_T("sernet.cob"), SerNetCobMain }, \
    {_T("serplex.cob"), SerplexCobMain }, \
    {_T("hostfs.cob"), HostfsCobMain },
#endif
    {0, 0}
};

/* XXX Leftover */
INT MODENTRY CrtInit(INT Op)
{
    UnusedParameter(Op);
    return TRUE;
}
