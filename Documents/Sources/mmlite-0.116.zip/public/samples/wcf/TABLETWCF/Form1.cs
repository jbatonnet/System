/* Copyright (c) Microsoft Corporation. All rights reserved. */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Ink;
using System.Xml;
using System.IO;

namespace tabletWCF
{
    public partial class Form1 : Form
    {
        public InkOverlay inkOverlay;

        public Form1()
        {
            InitializeComponent();
            inkOverlay = new InkOverlay(groupBox1);
            inkOverlay.Enabled = true;
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            
            //get the coordinates of the input area
            int iX = inkOverlay.AttachedControl.DisplayRectangle.X;
            iX += groupBox1.Location.X;
            int iY = inkOverlay.AttachedControl.DisplayRectangle.Y;
            iY = +groupBox1.Location.Y;
            
            TabletService.convertISFToStr isfConv = new TabletService.convertISFToStr();
            TabletService.tabletInkInfo tabletInk = isfConv.convertISFCl(inkOverlay.Ink, iX, iY);
            TabletService.tabletClientImpl locClient = new TabletService.tabletClientImpl();

            tabletInk.width = inkOverlay.AttachedControl.DisplayRectangle.Width;

            try
            {
                tabletInk.height = inkOverlay.AttachedControl.DisplayRectangle.Height;
                locClient.clientSendMessage(tabletInk);
            }
            catch (Exception eX)
            {
                //textStatus.Text = "Last error: " + eX.Message;
            }
            
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            inkOverlay.Enabled = false;
            inkOverlay.Ink.DeleteStrokes(inkOverlay.Ink.Strokes);
            groupBox1.Refresh();
            inkOverlay.Enabled = true;
            textStatus.Text = "";
        }

        private void textStatus_TextChanged(object sender, EventArgs e)
        {

        }
    }
}