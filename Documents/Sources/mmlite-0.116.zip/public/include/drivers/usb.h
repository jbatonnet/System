/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* --------------------------------------------------------------------------
 *
 * Module:
 *
 *    usb.h
 *
 * Purpose:
 *
 *    Definitions for the Universal Serial Bus (USB).
 *
 * Author:
 *    A. Forin (sandrof)
 *
 * --------------------------------------------------------------------------
 *
 */

#define USB_SYNC 0x80

/* Packet ID types
 */
#define USB_PID_OUT   0x1
#define USB_PID_ACK   0x2
#define USB_PID_DATA0 0x3
#define USB_PID_SOF   0x5
#define USB_PID_IN    0x9
#define USB_PID_NAK   0xa
#define USB_PID_DATA1 0xb
#define USB_PID_SETUP 0xd
#define USB_PID_STALL 0xe
/* Software defined value (brrr)
 */
#define USB_PID_EVENT 0xff   /* connection/disconnection/reset events */

# define USB_MAKE_PID(_p_)  (((_p_)|((~(_p_))<<4))&0xff)

/* Compilers are funny with alignment and padding, some wont give you control.
 * So use arrays of bytes instead of structs, work around shorts.
 * NB: A struct of bytes doesnt work because of padding, sigh.
 * NB: Methinks that handles byteorder too.
 */
#define Get2(_f_)      ((_f_)[0] | ((_f_)[1] << 8))
#define Set2(_f_,_v_)  {(_f_)[0] = (UINT8)((_v_) & 0xff);(_f_)[1] = (UINT8)(((_v_) & 0xff00)>>8);}
#define Con2(_v_)      (UINT8)(_v_), (UINT8)((_v_)>>8)
#define Get4(_f_)      (Get2(_f_) | (Get2((_f_)+2) << 16))
#define Set4(_f_,_v_)  {Set2(_f_,(UINT16)(_v_));Set2((_f_)+2,(UINT16)((_v_)>>16));}
#define Con4(_v_)      (UINT8)(_v_), (UINT8)((_v_)>>8), (UINT8)((_v_)>>16), (UINT8)((_v_)>>24)

/* Requests
 */
typedef UINT8 USB_REQUEST_PACKET[8];

typedef _PACKED struct _USB_REQUEST_struct {
    UINT8   RequestType;
    UINT8   Request;
    UINT8   Value[2];
    UINT8   Index[2];
    UINT8   Length[2];
} USB_REQUEST_struct, *PUSB_REQUEST_struct;

/* bmRequestType
 */
#define USB_RT_HTD    0x00
#define USB_RT_DTH    0x80
#define USB_RT_STD    0x00
#define USB_RT_CLASS  0x20
#define USB_RT_VENDOR 0x40
#define USB_RT_xxx    0x60
#define USB_RT_DEV    0x00
#define USB_RT_IFACE  0x01
#define USB_RT_ENDP   0x02
#define USB_RT_OTHER  0x03
# define USB_RT_RECIPIENT  0x0f

/* bRequest
 */
#define USB_R_GET_STATUS      0x00
#define USB_R_CLEAR_FEATURE   0x01
#define USB_R_SET_FEATURE     0x03
#define USB_R_SET_ADDRESS     0x05
#define USB_R_GET_DESCRIPTOR  0x06
#define USB_R_SET_DESCRIPTOR  0x07
#define USB_R_GET_CONFIG      0x08
#define USB_R_SET_CONFIG      0x09
#define USB_R_GET_IFACE       0x0a
#define USB_R_SET_IFACE       0x0b
#define USB_R_SYNCH_FRAME     0x0c

#define USB_R_GET_REPORT      0x01
#define USB_R_GET_IDLE        0x02
#define USB_R_GET_STATE       0x02
#define USB_R_GET_PROTOCOL    0x03
#define USB_R_SET_REPORT      0x09
#define USB_R_SET_IDLE        0x0a
#define USB_R_SET_PROTOCOL    0x0b
#define USB_R_GET_MAX_LUN     0xfe
#define USB_R_STORAGE_RESET   0xff

/* descriptor types
 */
#define USB_DT_DEVICE    0x01
#define USB_DT_CONFIG    0x02
#define USB_DT_STRING    0x03
#define USB_DT_IFACE     0x04
#define USB_DT_ENDP      0x05
#define USB_DT_QUALIF    0x06       /* USB2.0 */

#define USB_DT_HID       0x21
#define USB_DT_REPORT    0x22
#define USB_DT_PHYS      0x23
#define USB_DT_AUDIO_IF  0x24
#define USB_DT_AUDIO_EP  0x25
#define USB_DT_HUB       0x29

/* descriptor subtypes (audio)
 */
#define USB_DST_HEADER             0x01 /* AC */
#define USB_DST_INPUT_TERMINAL     0x02
#define USB_DST_OUTPUT_TERMINAL    0x03
#define USB_DST_MIXER_UNIT         0x04
#define USB_DST_SELECTOR_UNIT      0x05
#define USB_DST_FEATURE_UNIT       0x06
#define USB_DST_PROCESSING_UNIT    0x07
#define USB_DST_EXTENSION_UNIT     0x08

#define USB_DST_AS_GENERAL         0x01 /* AS */
#define USB_DST_FORMAT_TYPE        0x02
#define USB_DST_FORMAT_SPECIFIC    0x03

#define USB_DST_EP_GENERAL         0x01

/* feature selectors
 */
#define USB_FS_REMOTE_WAKEUP       0x01
#define USB_FS_ENDP_STALL          0x00

#define USB_FS_HUB_LOCAL_POWER     0x00
#define USB_FS_HUB_OVERCURRENT     0x01

#define USB_FS_PORT_CONNECTION     0x00
#define USB_FS_PORT_ENABLE         0x01
#define USB_FS_PORT_SUSPEND        0x02
#define USB_FS_PORT_OVERCURRENT    0x03
#define USB_FS_PORT_RESET          0x04
#define USB_FS_PORT_POWER          0x08
#define USB_FS_PORT_LOW_SPEED      0x09
#define USB_FS_C_PORT_CONNECTION   0x10
#define USB_FS_C_PORT_ENABLE       0x11
#define USB_FS_C_PORT_SUSPEND      0x12
#define USB_FS_C_PORT_OVERCURRENT  0x13
#define USB_FS_C_PORT_RESET        0x14

/* statuses
 */
#define USB_ST_SELF_POWERED    0x01
#define USB_ST_REMOTE_WAKEUP   0x02
#define USB_ST_STALL           0x01

#define USB_ST_HUB_LOCAL_POWER     0x0001
#define USB_ST_HUB_OVERCURRENT     0x0002
#define USB_ST_PORT_CONNECTION     0x0001
#define USB_ST_PORT_ENABLE         0x0002
#define USB_ST_PORT_SUSPEND        0x0004
#define USB_ST_PORT_OVERCURRENT    0x0008
#define USB_ST_PORT_RESET          0x0010
#define USB_ST_PORT_POWER          0x0100
#define USB_ST_PORT_LOW_SPEED      0x0200
#define USB_ST_PORT_HIGH_SPEED     0x0400 /* USB2*/
#define USB_ST_PORT_TEST_MODE      0x0800
#define USB_ST_PORT_INDICATOR      0x1000

/* report types
 */
#define USB_RP_INPUT           0x01
#define USB_RP_OUTPUT          0x02
#define USB_RP_FEATURE         0x03

/* Descriptors.
 */
typedef UINT8 USB_DEVICE_DESCRIPTOR[18];

typedef _PACKED struct _USB_DEVICE_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   BcdUSB[2];
    UINT8   DeviceClass;
    UINT8   DeviceSubClass;
    UINT8   DeviceProtocol;
    UINT8   MaxPacketSize0;
    UINT8   IdVendor[2];
    UINT8   IdProduct[2];
    UINT8   BcdDevice[2];
    UINT8   ixManufacturer;
    UINT8   ixProduct;
    UINT8   ixSerialNumber;
    UINT8   NumConfigurations;
} USB_DEVICE_struct, *PUSB_DEVICE_struct;

#define USB_v1_0  0x100
#define USB_v1_1  0x110
#define USB_v2_0  0x200

/* DeviceClass (aka interface class) */
#define USB_DC_MULTICLASS      0x00  /* class is per interface */
#define USB_DC_AUDIO           0x01
#define USB_DC_CDC             0x02
#define USB_DC_HID             0x03
#define USB_DC_PHYS            0x05
#define USB_DC_PRINTER         0x07
#define USB_DC_STORAGE         0x08
#define USB_DC_HUB             0x09
#define USB_DC_CDC_DATA        0x0a
#define USB_DC_SMART_CARD      0x0b
#define USB_DC_SECURE_CONTENT  0x0d
#define USB_DC_VENDOR_SPECIFIC 0xff

/* Subclasses */
#define USB_DS_AUDIO_CONTROL   0x01   /* Audio */
#define USB_DS_AUDIO_STREAMING 0x02
#define USB_DS_MIDI_STREAMING  0x03

#define USB_DS_DIRECT_LINE     0x01   /* Communication Device Class (CDC) */
#define USB_DS_ABSTRACT        0x02
#define USB_DS_TELEPHONE       0x03
#define USB_DS_MULTICHANNEL    0x04
#define USB_DS_CAPI            0x05
#define USB_DS_ETHERNET        0x06
#define USB_DS_ATM             0x07

#define USB_DS_BOOT            0x01   /* HID */

#define USB_DS_PRINTER         0x01   /* Printer */

#define USB_DS_RBC             0x01   /* Storage */
#define USB_DS_ATAPI           0x02
#define USB_DS_QIC             0x03
#define USB_DS_UFI             0x04
#define USB_DS_SFF_8070i       0x05
#define USB_DS_SCSI            0x06

/* Protocols */
#define USB_DP_V_25ter         0x01   /* CDC */

#define USB_DP_KEYBOARD        0x01   /* HID */
#define USB_DP_MOUSE           0x02

#define USB_DP_UNIDIRECTIONAL  0x01   /* Printer */
#define USB_DP_BIDIRECTIONAL   0x02
#define USB_DP_IEEE_1284_4     0x03

#define USB_DP_CBI             0x00   /* Storage */
#define USB_DP_CBI_NO_CC       0x01
#define USB_DS_BULK_ONLY       0x50

#define USB_DP_NORMAL_SPEED    0x00   /* Hub */
#define USB_DP_SINGLE_TT       0x01
#define USB_DP_MULTIPLE_TT     0x02

#define USB_DP_ISDN            0x30   /* CDC Data */
#define USB_DP_HDLC            0x31
#define USB_DP_TRANSPARENT     0x32
#define USB_DP_Q921M           0x50
#define USB_DP_Q921            0x51
#define USB_DP_Q921TM          0x52

typedef UINT8 USB_DEVICE_QUALIFIER_DESCRIPTOR[10];         /* USB2.0 */

typedef _PACKED struct _USB_DEVICE_QUALIFIER_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   BcdUSB[2];
    UINT8   DeviceClass;
    UINT8   DeviceSubClass;
    UINT8   DeviceProtocol;
    UINT8   MaxPacketSize0;
    UINT8   NumConfigurations;
    UINT8   Reserved;
} USB_DEVICE_QUALIFIER_struct, *PUSB_DEVICE_QUALIFIER_struct;

typedef UINT8 USB_CONFIGURATION_DESCRIPTOR[9];

typedef _PACKED struct _USB_CONFIGURATION_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   TotalLength[2];
    UINT8   NumInterfaces;
    UINT8   ConfigurationValue;
    UINT8   ixConfiguration;
    UINT8   Attributes;
    UINT8   MaxPower;
} USB_CONFIGURATION_struct, *PUSB_CONFIGURATION_struct;

/* Attributes */
#define USB_AT_BUS_POWERED     0x80
#define USB_AT_SELF_POWERED    0x40
#define USB_AT_REMOTE_WAKEUP   0x20

typedef UINT8 USB_INTERFACE_DESCRIPTOR[9];

typedef _PACKED struct _USB_INTERFACE_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   InterfaceNumber;
    UINT8   AlternateSetting;
    UINT8   NumEndpoints;
    UINT8   InterfaceClass;
    UINT8   InterfaceSubClass;
    UINT8   InterfaceProtocol;
    UINT8   ixInterface;
} USB_INTERFACE_struct, *PUSB_INTERFACE_struct;

typedef UINT8 USB_ENDPOINT_DESCRIPTOR[7];

typedef _PACKED struct _USB_ENDPOINT_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   EndpointAddress;
    UINT8   Attributes;
    UINT8   MaxPacketSize[2];
    UINT8   Interval;
} USB_ENDPOINT_struct, *PUSB_ENDPOINT_struct;

/* Endpoint address */
#define USB_EA_ADDRESS_MASK    0x0f
#define USB_EA_OUT             0x00
#define USB_EA_IN              0x80

/* Attributes */
#define USB_AE_CONTROL         0x00
#define USB_AE_ISOCHRONOUS     0x01
#define USB_AE_BULK            0x02
#define USB_AE_INTERRUPT       0x03
# define USB_AE_MASK           0x03
#define USB_AE_NO_SYNCHRO      0x00
#define USB_AE_ASYNCHRONOUS    0x04
#define USB_AE_ADAPTIVE        0x08
#define USB_AE_SYNCHRONOUS     0x0c
# define USB_AE_SMASK          0x0c
#define USB_AE_DATA            0x00
#define USB_AE_FEEDBACK        0x10
#define USB_AE_IMPL_FEEDBACK   0x20
# define USB_AE_UMASK          0x30

/* MaxPacketSize */
#define USB_MP_MASK            0x07ff
#define USB_MP_2xuf            0x0800
#define USB_MP_3xuf            0x1000

typedef UINT16 USB_STRING;
typedef USB_STRING *USB_STRING_DESCRIPTOR;

typedef _PACKED struct _USB_STRING_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    USB_STRING  String[1];      /*varsize, UNICODE */
} USB_STRING_struct, *PUSB_STRING_struct;

typedef UINT8 USB_HUB_DESCRIPTOR[9];

typedef _PACKED struct _USB_HUB_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   NumberOfPorts;
    UINT8   HubCharacteristics[2];
    UINT8   PowerOnGood;
    UINT8   ControlCurrent;
    UINT8   DeviceRemovable;
    UINT8   Compat10;
} USB_HUB_struct, *PUSB_HUB_struct;

typedef UINT8 USB_HID_DESCRIPTOR[9];

typedef _PACKED struct _USB_HID_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   BcdHID[2];
    UINT8   CountryCode;
    UINT8   NumDescriptors;
    UINT8   ReportDescriptorType;
    UINT8   ReportDescriptorLength[2];
} USB_HID_struct, *PUSB_HID_struct;

/* Audio Control descriptors
 */
typedef UINT8 USB_AC_DESCRIPTOR[9];

typedef _PACKED struct _USB_AC_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   BcdADC[2];
    UINT8   TotalLength[2];
    UINT8   InCollection;
    UINT8   InterfaceNumber[1]; /* VARSIZE */
} USB_AC_struct, *PUSB_AC_struct;

typedef UINT8 USB_INPUT_TERMINAL_DESCRIPTOR[12];

typedef _PACKED struct _USB_INPUT_TERMINAL_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   TerminalID;
    UINT8   TerminalType[2];
    UINT8   AssociatedTerminal;
    UINT8   NumberOfChannels;
    UINT8   ChannelConfig[2];
    UINT8   ChannelNames;
    UINT8   ixTerminal;
} USB_INPUT_TERMINAL_struct, *PUSB_INPUT_TERMINAL_struct;

typedef UINT8 USB_OUTPUT_TERMINAL_DESCRIPTOR[9];

typedef _PACKED struct _USB_OUTPUT_TERMINAL_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   TerminalID;
    UINT8   TerminalType[2];
    UINT8   AssociatedTerminal;
    UINT8   SourceID;
    UINT8   ixTerminal;
} USB_OUTPUT_TERMINAL_struct, *PUSB_OUTPUT_TERMINAL_struct;

typedef UINT8 USB_MIXER_UNIT_DESCRIPTOR[12];

typedef _PACKED struct _USB_MIXER_PIN_struct {
    UINT8   SourceID;
    UINT8   NumberOfChannels;
    UINT8   ChannelConfig[2];
    UINT8   AssociatedTerminal;
    UINT8   Terminal;
} USB_MIXER_PIN_struct;

typedef _PACKED struct _USB_MIXER_UNIT_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   UnitID;
    UINT8   NumberOfPins;
    USB_MIXER_PIN_struct Pins[1]; /* VARSIZE */
    UINT8   ixMixer; /* follows, sigh */
} USB_MIXER_UNIT_struct, *PUSB_MIXER_UNIT_struct;

typedef UINT8 USB_SELECTOR_UNIT_DESCRIPTOR[7];

typedef _PACKED struct _USB_SELECTOR_PIN_struct {
    UINT8   SourceID;
} USB_SELECTOR_PIN_struct;

typedef _PACKED struct _USB_SELECTOR_UNIT_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   UnitID;
    UINT8   NumberOfPins;
    USB_SELECTOR_PIN_struct Pins[1]; /* VARSIZE */
    UINT8   ixSelector; /* follows, sigh */
} USB_SELECTOR_UNIT_struct, *PUSB_SELECTOR_UNIT_struct;

typedef UINT8 USB_FEATURE_UNIT_DESCRIPTOR[9];

typedef _PACKED struct _USB_FEATURE_CONTROL_struct {
    UINT8   Bitmap[2]; /* MINIMUM */
} USB_FEATURE_CONTROL_struct;

typedef _PACKED struct _USB_FEATURE_UNIT_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   UnitID;
    UINT8   NumberOfControls;
    USB_FEATURE_CONTROL_struct Controls[1]; /* VARSIZE */
    UINT8   ixFeature; /* follows, sigh */
} USB_FEATURE_UNIT_struct, *PUSB_FEATURE_UNIT_struct;

typedef UINT8 USB_PROCESSING_UNIT_DESCRIPTOR[15];

typedef _PACKED struct _USB_PROCESSING_CONTROL_struct {
    UINT8   Bitmap[2]; /* MINIMUM */
} USB_PROCESSING_CONTROL_struct;

typedef _PACKED struct _USB_PROCESSING_UNIT_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   UnitID;
    UINT8   ProcessType;
    UINT8   NumberOfPins;
    UINT8   SourceID[1]; /* VARSIZE */
    UINT8   NumberOfChannels;
    UINT8   ChannelConfig[2];
    UINT8   ChannelNames;
    UINT8   NumberOfControls;
    USB_PROCESSING_CONTROL_struct Controls[1]; /* VARSIZE */
    UINT8   ixProcessing; /* follows, sigh */
} USB_PROCESSING_UNIT_struct, *PUSB_PROCESSING_UNIT_struct;

/* wProcessType
 */
#define USB_PT_UPDOWNMIX           0x0001
#define USB_PT_DOLBY_PROLOGIC      0x0002
#define USB_PT_3D_STEREO           0x0003
#define USB_PT_REVERBERATION       0x0004
#define USB_PT_CHORUS              0x0005
#define USB_PT_DYN_RANGE_COMP      0x0006

typedef USB_PROCESSING_UNIT_DESCRIPTOR USB_EXTENSION_UNIT_DESCRIPTOR;
typedef USB_PROCESSING_UNIT_struct
  USB_EXTENSION_UNIT_struct, *PUSB_EXTENSION_UNIT_struct;

/* Audio streaming descriptors
 */
typedef UINT8 USB_AS_GENERAL_DESCRIPTOR[7];

typedef _PACKED struct _USB_AS_GENERAL_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   TerminalLink;
    UINT8   Delay;
    UINT8   FormatTag[2];
} USB_AS_GENERAL_struct, *PUSB_AS_GENERAL_struct;

typedef UINT8 USB_AS_FORMAT_TYPE1_DESCRIPTOR[11];

typedef _PACKED struct _USB_AS_FORMAT_TYPE1_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   FormatType;
    UINT8   NumberOfChannels;
    UINT8   SubframeSize;
    UINT8   BitResolution;
    UINT8   SamplingFrequencyType;
    UINT8   SamplingFrequency[1][3];/*VARSIZED*/
} USB_AS_FORMAT_TYPE1_struct, *PUSB_AS_FORMAT_TYPE1_struct;

typedef UINT8 USB_AS_FORMAT_TYPE2_DESCRIPTOR[12];

typedef _PACKED struct _USB_AS_FORMAT_TYPE2_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   FormatType;
    UINT8   MaxBitRate[2];
    UINT8   SamplesPerFrame[2];
    UINT8   SamplingFrequencyType;
    UINT8   SamplingFrequency[1][3];/*VARSIZED*/
} USB_AS_FORMAT_TYPE2_struct, *PUSB_AS_FORMAT_TYPE2_struct;

typedef USB_AS_FORMAT_TYPE1_DESCRIPTOR USB_AS_FORMAT_TYPE3_DESCRIPTOR;
typedef USB_AS_FORMAT_TYPE1_struct
   USB_AS_FORMAT_TYPE3_struct, *PUSB_AS_FORMAT_TYPE3_struct;


typedef UINT8 USB_AS_ENDPOINT_DESCRIPTOR[7];

typedef _PACKED struct _USB_AS_ENDPOINT_struct {
    UINT8   Length;
    UINT8   DescriptorType;
    UINT8   DescriptorSubType;
    UINT8   Attributes;
    UINT8   LockDelayUnits;
    UINT8   LockDelay[2];
} USB_AS_ENDPOINT_struct, *PUSB_AS_ENDPOINT_struct;

/* Country-codes (for keyboards) */
#define USB_CC_NotSupported        0
#define USB_CC_Arabic              1
#define USB_CC_Belgian             2
#define USB_CC_Canadian_Bilingual  3
#define USB_CC_Canadian_French     4
#define USB_CC_CzechRepublic       5
#define USB_CC_Danish              6
#define USB_CC_Finnish             7
#define USB_CC_French              8
#define USB_CC_German              9
#define USB_CC_Greek              10
#define USB_CC_Hebrew             11
#define USB_CC_Hungary            12
#define USB_CC_ISO                13
#define USB_CC_Italian            14
#define USB_CC_Japan_Katakana     15
#define USB_CC_Korean             16
#define USB_CC_LatinAmerican      17
#define USB_CC_Dutch              18
#define USB_CC_Norwegian          19
#define USB_CC_Persian_Farsi      20
#define USB_CC_Poland             21
#define USB_CC_Portuguese         22
#define USB_CC_Russia             23
#define USB_CC_Slovakia           24
#define USB_CC_Spanish            25
#define USB_CC_Swedish            26
#define USB_CC_Swiss_French       27
#define USB_CC_Swiss_German       28
#define USB_CC_Switzerland        29
#define USB_CC_Taiwan             30
#define USB_CC_Turkish_Q          31
#define USB_CC_UK                 32
#define USB_CC_US                 33
#define USB_CC_Yugoslavia         34
#define USB_CC_Turkish_F          35

/* Implementation parameters */
#define USB_11_BUS_BANDWIDTH      12000
#define USB_20_BUS_BANDWIDTH     400000

