/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Reference:
 * "AT91 ARM Thumb Microcontrollers; AT91M55800A"
 * Rev 1745B-ATARM-04/02
 * Editor: Atmel Corporation, 2002 http://www.atmel.com
 *
 * Definitions specific to the Atmel M55800 chip
 */

/*
 * External Bus Interface (EBI) definitions
 */
struct _Ebi {
    volatile UINT32  ChipSelect[8];
# define               EBICS_DBW_16    0x00000001
# define               EBICS_DBW8      0x00000002
# define               EBICS_NWS(_n_)  (((_n_)&0x7)<<2)
# define               EBICS_WSE       0x00000020
# define               EBICS_PS_1M     0x00000000
# define               EBICS_PS_4M     0x00000080
# define               EBICS_PS_16M    0x00000100
# define               EBICS_PS_64M    0x00000180
# define               EBICS_PS(_n_)   (((_n_)&0x3)<<7)
# define               EBICS_PS_G(_n_) (((_n_)>>7)&0x3)
# define               EBICS_TDF(_n_)  (((_n_)&0x7)<<9)
# define               EBICS_BAT_W     0x00000000
# define               EBICS_BAT_S     0x00001000
# define               EBICS_CSEN      0x00002000
# define               EBICS_BA(_a_)   ((_a_)&0xfff00000)

    volatile UINT32  RemapControl; /* NB: write-only */
# define               EBIRC_NO_REMAP  0x00000001

    volatile UINT32  MemoryControl;    
# define               EBIMC_DRP_EARLY 0x00000010

};
#define TheEbi ((struct _Ebi *)0xffe00000)

/*
 * Advanced Interrupt Controller (AIC)
 */
struct _Aic {
    volatile UINT32  SourceMode[32];
# define               AICSM_PRIO(_n_) ((_n_)&0x7)
# define               AICSM_LEVEL     0x00000000
# define               AICSM_EDGE      0x00000020
# define               AICSM_POSITIVE  0x00000040
/* ..meaning.. */
# define               AICSM_LEVEL_LO  0x00000000
# define               AICSM_EDGE_NEG  0x00000020
# define               AICSM_LEVEL_HI  0x00000040
# define               AICSM_EDGE_POS  0x00000060

    volatile UINT32  SourceVector[32];
    volatile UINT32  IrqVector;
    volatile UINT32  FiqVector;

    volatile UINT32  Status;
# define               AICST_MASK      0x0000001f

    volatile UINT32  Pending;
    volatile UINT32  Mask;
# define               AICI_FIQ        0x00000001
# define               AICI_SWI        0x00000002
# define               AICI_USART0     0x00000004
# define               AICI_USART1     0x00000008
# define               AICI_USART2     0x00000010
# define               AICI_SPI        0x00000020
# define               AICI_TIMER0     0x00000040
#define IRQ_ID_TIMER0 6
# define               AICI_TIMER1     0x00000080
#define IRQ_ID_TIMER1 7
# define               AICI_TIMER2     0x00000100
# define               AICI_TIMER3     0x00000200
# define               AICI_TIMER4     0x00000400
# define               AICI_TIMER5     0x00000800
# define               AICI_WATCHDOG   0x00001000
# define               AICI_PIO_A      0x00002000
# define               AICI_PIO_B      0x00004000
# define               AICI_AD0        0x00008000
# define               AICI_AD1        0x00010000
# define               AICI_DA0        0x00020000
# define               AICI_DA1        0x00040000
# define               AICI_RTC        0x00080000
# define               AICI_PMC        0x00100000
# define               AICI_xx         0x00600000
# define               AICI_SLCK       0x00800000
# define               AICI_IRQ5       0x01000000
# define               AICI_IRQ4       0x02000000
# define               AICI_IRQ3       0x04000000
# define               AICI_IRQ2       0x08000000
# define               AICI_IRQ1       0x10000000
# define               AICI_IRQ0       0x20000000
# define               AICI_COMMRX     0x40000000
# define               AICI_COMMTX     0x80000000

    volatile UINT32  CoreStatus;
# define               AICCS_NFIQ      0x00000001
# define               AICCS_NIRQ      0x00000002

    volatile UINT32  reserved[2];

    volatile UINT32  Enable; /* see AICI_* for these four guys */
    volatile UINT32  Disable;
    volatile UINT32  Clear;
    volatile UINT32  Set;

    volatile UINT32  EndOfInterrupt;
    volatile UINT32  SpuriousVector;
};
#define TheAic ((struct _Aic *)0xfffff000)

/*
 * Parallel I/O Controller (PIO)
 */
struct _Pio {
    volatile UINT32  Enable;
    volatile UINT32  Disable;
    volatile UINT32  Status;
    volatile UINT32  reserved1;
    volatile UINT32  OutEnable;
    volatile UINT32  OutDisable;
    volatile UINT32  OutStatus;
    volatile UINT32  reserved2;
    volatile UINT32  FilterEnable;
    volatile UINT32  FilterDisable;
    volatile UINT32  FilterStatus;
    volatile UINT32  reserved3;
    volatile UINT32  SetData;
    volatile UINT32  ClearData;
    volatile UINT32  DataStatus;
    volatile UINT32  PinDataStatus;
    volatile UINT32  IntrEnable;
    volatile UINT32  IntrDisable;
    volatile UINT32  IntrMask;
    volatile UINT32  IntrStatus;
    volatile UINT32  MultiDriverEnable;
    volatile UINT32  MultiDriverDisable;
    volatile UINT32  MultiDriverStatus;
    volatile UINT32  reserved4;
    /* Bit assignments for connection control */
# define               PIOA_TCLK3      0x00000001
# define               PIOA_TIOA3      0x00000002
# define               PIOA_TIOB3      0x00000004
# define               PIOA_TCLK4      0x00000008
# define               PIOA_TIOA4      0x00000010
# define               PIOA_TIOB4      0x00000020
# define               PIOA_TCLK5      0x00000040
# define               PIOA_TIOA5      0x00000080
# define               PIOA_TIOB5      0x00000100
# define               PIOA_IRQ0       0x00000200
# define               PIOA_IRQ1       0x00000400
# define               PIOA_IRQ2       0x00000800
# define               PIOA_IRQ3       0x00001000
# define               PIOA_FIQ        0x00002000
# define               PIOA_SCLK0      0x00004000
# define               PIOA_TXD0       0x00008000
# define               PIOA_RXD0       0x00010000
# define               PIOA_SCLK1      0x00020000
# define               PIOA_TXD1       0x00040000
# define               PIOA_RXD1       0x00080000
# define               PIOA_SCLK2      0x00100000
# define               PIOA_TXD2       0x00200000
# define               PIOA_RXD2       0x00400000
# define               PIOA_SPCK       0x00800000
# define               PIOA_MISO       0x01000000
# define               PIOA_MOSI       0x02000000
# define               PIOA_NPCS0      0x04000000
# define               PIOA_NPCS1      0x08000000
# define               PIOA_NPCS2      0x10000000
# define               PIOA_NPCS3      0x20000000

# define               PIOB_PB0        0x00000001
# define               PIOB_PB1        0x00000002
# define               PIOB_PB2        0x00000004
# define               PIOB_IRQ4       0x00000008
# define               PIOB_IRQ5       0x00000010
# define               PIOB_PB5        0x00000020
# define               PIOB_AD0_TRIG   0x00000040
# define               PIOB_AD1_TRIG   0x00000080
# define               PIOB_PB8        0x00000100
# define               PIOB_PB9        0x00000200
# define               PIOB_PB10       0x00000400
# define               PIOB_PB11       0x00000800
# define               PIOB_PB12       0x00001000
# define               PIOB_PB13       0x00002000
# define               PIOB_PB14       0x00004000
# define               PIOB_PB15       0x00008000
# define               PIOB_PB16       0x00010000
# define               PIOB_PB17       0x00020000
# define               PIOB_BMS        0x00040000
# define               PIOB_TCLK0      0x00080000
# define               PIOB_TIOA0      0x00100000
# define               PIOB_TIOB0      0x00200000
# define               PIOB_TCLK1      0x00400000
# define               PIOB_TIOA1      0x00800000
# define               PIOB_TIOB1      0x01000000
# define               PIOB_TCLK2      0x02000000
# define               PIOB_TIOA2      0x04000000
# define               PIOB_TIOB2      0x08000000
};
#define PioA ((struct _Pio *)0xfffec000)
#define PioB ((struct _Pio *)0xffff0000)

/*
 * Universal Synch/Asynch Receiver/Transmitter (USART)
 */
typedef struct _USART {
    volatile UINT32  Control; /* NB: wo */
# define               USC_RSTRX       0x00000004
# define               USC_RSTTX       0x00000008
# define               USC_RXEN        0x00000010
# define               USC_RXDIS       0x00000020
# define               USC_TXEN        0x00000040
# define               USC_TXDIS       0x00000080
# define               USC_RSTSTA      0x00000100
# define               USC_STTBRK      0x00000200
# define               USC_STPBRK      0x00000400
# define               USC_STTO        0x00000800
# define               USC_SENDA       0x00001000

    volatile UINT32  Mode;
# define               USM_CLK_MCKI    0x00000000
# define               USM_CLK_MCKI_8  0x00000010
# define               USM_CLK_EXT     0x00000020
# define               USM_BPC_5       0x00000000
# define               USM_BPC_6       0x00000040
# define               USM_BPC_7       0x00000080
# define               USM_BPC_8       0x000000c0
# define               USM_BPC_9       0x00020000
# define               USM_SYNC        0x00000100
# define               USM_EVEN        0x00000000
# define               USM_ODD         0x00000200
# define               USM_SPACE       0x00000400 /* forced 0 */
# define               USM_MARK        0x00000600 /* forced 1 */
# define               USM_NONE        0x00000800
# define               USM_MDROP       0x00000c00
# define               USM_1STOP       0x00000000
# define               USM_1_5STOP     0x00001000
# define               USM_2STOP       0x00002000
# define               USM_ECHO        0x00004000 /* rx->tx, tx disabled */
# define               USM_LOOPBACK    0x00008000 /* tx->rx, rx/tx disabled */
# define               USM_ECHO2       0x0000c000 /* rx->tx, rx disabled */
# define               USM_SCK_ENABLE  0x00040000

    volatile UINT32  IntrEnable;
    volatile UINT32  IntrDisable;
    volatile UINT32  IntrMask;
    volatile UINT32  ChannelStatus; /* all these with.. */
# define               USI_RXRDY       0x00000001
# define               USI_TXRDY       0x00000002
# define               USI_RXBRK       0x00000004
# define               USI_ENDRX       0x00000008
# define               USI_ENDTX       0x00000010
# define               USI_OVRE        0x00000020
# define               USI_FRAME       0x00000040
# define               USI_PARE        0x00000080
# define               USI_TIMEOUT     0x00000100
# define               USI_TXEMPTY     0x00000200

    volatile UINT32  RxData;
    volatile UINT32  TxData;
    volatile UINT32  Baud;
    volatile UINT32  RxTimeout;
    volatile UINT32  TxTimeout;
    volatile UINT32  reserved;
    volatile UINT32  RxPointer;
    volatile UINT32  RxCounter;
    volatile UINT32  TxPointer;
    volatile UINT32  TxCounter;
} USART;

#define Usart0 ((USART *) 0xfffc0000)
#define Usart1 ((USART *) 0xfffc4000)
#define Usart2 ((USART *) 0xfffc8000)


/*
 * Serial Peripheral Interface
 */
struct _Spi {
    volatile UINT32  Control;
# define               SPIC_ENABLE     0x00000001
# define               SPIC_DISABLE    0x00000002
# define               SPIC_RESET      0x00000080

    volatile UINT32  Mode;
# define               SPIM_SLAVE      0x00000000
# define               SPIM_MASTER     0x00000001
# define               SPIM_VARIABLE   0x00000002
# define               SPIM_DECODER    0x00000004
# define               SPIM_MCKI_32    0x00000008
# define               SPIM_LOOPBACK   0x00000080
# define               SPIM_PCS(_n_)   (((_n_)&0xf)<<16)
# define               SPIM_PCS_G(_v_) (((_v_)>>16)&0xf)
# define               SPIM_DELAY(_n_) (((_n_)&0xff)<<24)

    volatile UINT32  RxData;
    volatile UINT32  TxData;

    volatile UINT32  Status;
    volatile UINT32  IntrEnable;
    volatile UINT32  IntrDisable;
    volatile UINT32  IntrMask; /* all these.. */
# define               SPIS_RXFULL     0x00000001
# define               SPIS_TXEMPTY    0x00000002
# define               SPIS_FAULT      0x00000004
# define               SPIS_OVERRUN    0x00000008
# define               SPIS_SPENDRX    0x00000010
# define               SPIS_SPENDTX    0x00000020
# define               SPIS_ENABLED    0x00010000

    volatile UINT32  RxPointer;
    volatile UINT32  RxCounter;
    volatile UINT32  TxPointer;
    volatile UINT32  TxCounter;

    volatile UINT32  Cs0;
    volatile UINT32  Cs1;
    volatile UINT32  Cs2;
    volatile UINT32  Cs3;
# define               SPICS_CPOL      0x00000001
# define               SPICS_NCPHA     0x00000002
# define               SPICS_BPC_8     0x00000000
# define               SPICS_BPC_9     0x00000010
# define               SPICS_BPC_10    0x00000020
# define               SPICS_BPC_11    0x00000030
# define               SPICS_BPC_12    0x00000040
# define               SPICS_BPC_13    0x00000050
# define               SPICS_BPC_14    0x00000060
# define               SPICS_BPC_15    0x00000070
# define               SPICS_BPC_16    0x00000080
# define               SPICS_BAUD(_n_) (((_n_)&0xff)<<8)
# define               SPICS_DBS(_n_)  (((_n_)&0xff)<<16)
# define               SPICS_DBCT(_n_) (((_n_)&0xff)<<24)

};
#define TheSpi ((struct _Spi *) 0xfffbc000)


/*
 * Timer/Counter (TC)
 */
typedef struct _Tchan {
    volatile UINT32  Control;
# define               TCHC_ENABLE     0x00000001
# define               TCHC_DISABLE    0x00000002
# define               TCHC_TRIGGER    0x00000004

    volatile UINT32  Mode;
# define               TCHM_WAVE       0x00008000
# define               TCHM_MCKI_2     0x00000000
# define               TCHM_MCKI_8     0x00000001
# define               TCHM_MCKI_32    0x00000002
# define               TCHM_MCKI_128   0x00000003
# define               TCHM_MCKI_1024  0x00000004
# define               TCHM_XC0        0x00000005
# define               TCHM_XC1        0x00000006
# define               TCHM_XC2        0x00000007
# define               TCHM_INVERTED   0x00000008
# define               TCHM_GATED_XC0  0x00000010
# define               TCHM_GATED_XC1  0x00000020
# define               TCHM_GATED_XC2  0x00000030
# define               TCHM_EXT_RAISE  0x00000100
# define               TCHM_EXT_FALL   0x00000200
# define               TCHM_EXT_BOTH   0x00000300
# define               TCHM_TRG_TIOB   0x00000000
# define               TCHM_TRG_RC     0x00004000
/* if WAVE==0 */
# define               TCHM_LDBSTOP    0x00000040
# define               TCHM_LDBDIS     0x00000080
# define               TCHM_TRG_TIOA   0x00000400
# define               TCHM_AA_RAISE   0x00010000
# define               TCHM_AA_FALL    0x00020000
# define               TCHM_AA_BOTH    0x00030000
# define               TCHM_AB_RAISE   0x00040000
# define               TCHM_AB_FALL    0x00080000
# define               TCHM_AB_BOTH    0x000c0000
/* if WAVE==1 */
# define               TCHM_CPCSTOP    0x00000040
# define               TCHM_CPCDIS     0x00000080
# define               TCHM_TRG_XC0    0x00000400
# define               TCHM_TRG_XC1    0x00000800
# define               TCHM_TRG_XC2    0x00000c00
# define               TCHM_ENETRG     0x00001000
# define               TCHM_AA_SET     0x00010000
# define               TCHM_AA_CLEAR   0x00020000
# define               TCHM_AA_TOGGLE  0x00030000
# define               TCHM_CA_SET     0x00040000
# define               TCHM_CA_CLEAR   0x00080000
# define               TCHM_CA_TOGGLE  0x000c0000
# define               TCHM_EA_SET     0x00100000
# define               TCHM_EA_CLEAR   0x00200000
# define               TCHM_EA_TOGGLE  0x00300000
# define               TCHM_SA_SET     0x00400000
# define               TCHM_SA_CLEAR   0x00800000
# define               TCHM_SA_TOGGLE  0x00c00000
# define               TCHM_BB_SET     0x01000000
# define               TCHM_BB_CLEAR   0x02000000
# define               TCHM_BB_TOGGLE  0x03000000
# define               TCHM_CB_SET     0x04000000
# define               TCHM_CB_CLEAR   0x08000000
# define               TCHM_CB_TOGGLE  0x0c000000
# define               TCHM_EB_SET     0x10000000
# define               TCHM_EB_CLEAR   0x20000000
# define               TCHM_EB_TOGGLE  0x30000000
# define               TCHM_SB_SET     0x40000000
# define               TCHM_SB_CLEAR   0x80000000
# define               TCHM_SB_TOGGLE  0xc0000000

    volatile UINT32  reserved[2];
    volatile UINT32  Counter;
    volatile UINT32  A;
    volatile UINT32  B;
    volatile UINT32  C;

    volatile UINT32  Status;
# define               TCHS_ENABLED    0x00010000
# define               TCHS_TIOA       0x00020000
# define               TCHS_TIOB       0x00040000
                        /* bits in low byte same as next three guys: */
    volatile UINT32  IntrEnable;
    volatile UINT32  IntrDisable;
    volatile UINT32  IntrMask;
# define               TCHI_OVERFLOW   0x00000001
# define               TCHI_OVERRUN    0x00000002
# define               TCHI_A_COMPARE  0x00000004
# define               TCHI_B_COMPARE  0x00000008
# define               TCHI_C_COMPARE  0x00000010
# define               TCHI_A_LOAD     0x00000020
# define               TCHI_B_LOAD     0x00000040
# define               TCHI_E_TRIGGER  0x00000080
} TC_CHANNEL;
struct _Tc {
    struct _Tchan    Channel0;
    volatile UINT32  xx0[4];
    struct _Tchan    Channel1;
    volatile UINT32  xx1[4];
    struct _Tchan    Channel2;
    volatile UINT32  xx2[4];

    volatile UINT32  BlockControl;
# define               TCBC_SYNCRHO    0x00000001

    volatile UINT32  BlockMode;
# define               TCBM_0_TCLK0    0x00000000
# define               TCBM_0_NONE     0x00000001
# define               TCBM_0_TIOA1    0x00000002
# define               TCBM_0_TIOA2    0x00000003
# define               TCBM_1_TCLK1    0x00000000
# define               TCBM_1_NONE     0x00000004
# define               TCBM_1_TIOA0    0x00000008
# define               TCBM_1_TIOA2    0x0000000c
# define               TCBM_2_TCLK2    0x00000000
# define               TCBM_2_NONE     0x00000010
# define               TCBM_2_TIOA0    0x00000020
# define               TCBM_2_TIOA1    0x00000030

};
#define Tc0 ((struct _Tc *) 0xfffd0000)
#define Tc1 ((struct _Tc *) 0xfffd4000)

/*
 * Watchdog Timer (WD)
 */
struct _Wd {
    volatile UINT32  OvflMode;
# define               WDOM_WDEN       0x00000001
# define               WDOM_RSTEN      0x00000002
# define               WDOM_IRQEN      0x00000004
# define               WDOM_EXTEN      0x00000008
# define               WDOM_KEY(_n_)   (((_n_)&0xfff)<<4)
# define               WDOM_ENABLE_KEY WDOM_KEY(0x234)

    volatile UINT32  ClockMode;
# define               WDCM_MCK32      0x00000000
# define               WDCM_MCK128     0x00000001
# define               WDCM_MCK1024    0x00000002
# define               WDCM_MCK4096    0x00000003
# define               WDCM_HPCV(_n_)  (((_n_)&0xf)<<2)
# define               WDCM_KEY(_n_)   (((_n_)&0xff)<<8)
# define               WDCM_ENABLE_KEY WDCM_KEY(0x6e)

    volatile UINT32  Control;
# define               WDCR_KEY(_n_)   ((_n_)&0xffff)
# define               WDCR_ENABLE_KEY WDCR_KEY(0xc071)

    volatile UINT32  Status;
# define               WDS_OVERFLOW    0x00000001

};
#define TheWd ((struct _Wd *) 0xffff8000)

/*
 * Advanced Power Management Controller (PMC)
 */
struct _Pmc {
    volatile UINT32  SysClockEnable;
# define               PMCSC_CPU       0x00000001
    volatile UINT32  SysClockDisable;
    volatile UINT32  SysClockStatus;

    volatile UINT32  reserved1;

    volatile UINT32  PerClockEnable;
# define               PMCPC_USART0    0x00000004
# define               PMCPC_USART1    0x00000008
# define               PMCPC_USART2    0x00000010
# define               PMCPC_SPI       0x00000020
# define               PMCPC_TC0       0x00000040
# define               PMCPC_TC1       0x00000080
# define               PMCPC_TC2       0x00000100
# define               PMCPC_TC3       0x00000200
# define               PMCPC_TC4       0x00000400
# define               PMCPC_TC5       0x00000800
# define               PMCPC_PIOA      0x00002000
# define               PMCPC_PIOB      0x00004000
# define               PMCPC_ADC0      0x00008000
# define               PMCPC_ADC1      0x00010000
# define               PMCPC_DAC0      0x00020000
# define               PMCPC_DAC1      0x00040000
    volatile UINT32  PerClockDisable;
    volatile UINT32  PerClockStatus;

    volatile UINT32  reserved2;

    volatile UINT32  ClockGeneratorMode;
# define               PMCCM_MOSBYP    0x00000001
# define               PMCCM_MOSCEN    0x00000002
# define               PMCCM_MCKODS    0x00000004
# define               PMCCM_PRES_NONE 0x00000000
# define               PMCCM_PRES_2    0x00000010
# define               PMCCM_PRES_4    0x00000020
# define               PMCCM_PRES_8    0x00000030
# define               PMCCM_PRES_16   0x00000040
# define               PMCCM_PRES_32   0x00000050
# define               PMCCM_PRES_64   0x00000060
# define               PMCCM_MUL(_n_)   (((_n_)&0x3f)<<8)
# define               PMCCM_MUL_G(_v_) (((_v_)>>8)&0x3f)
# define               PMCCM_CSS_LF    0x00000000
# define               PMCCM_CSS_MOSC  0x00004000
# define               PMCCM_CSS_PLL   0x00008000
# define               PMCCM_OSCNT(_n_)   (((_n_)&0xff)<<16)
# define               PMCCM_OSCNT_G(_v_) (((_v_)>>16)&0xff)
# define               PMCCM_PLLCNT(_n_)   (((_n_)&0x3f)<<24)
# define               PMCCM_PLLCNT_G(_v_) (((_v_)>>24)&0x3f)

    volatile UINT32  reserved3;

    volatile UINT32  PowerControl;
# define               PMCPC_SDAHLC    0x00000001
# define               PMCCM_WKACKC    0x00000002

    volatile UINT32  PowerMode;
# define               PMCPM_SDAHL_TRI 0x00000000
# define               PMCPM_SDAHL_L0  0x00000001
# define               PMCPM_SDAHL_L1  0x00000002
# define               PMCPM_WKACK_TRI 0x00000000
# define               PMCPM_WKACK_L0  0x00000004
# define               PMCPM_WKACK_L1  0x00000008
# define               PMCPM_ALWKEN    0x00000010
# define               PMCPM_ALSHEN    0x00000020
# define               PMCPM_WKEDG_NON 0x00000000
# define               PMCPM_WKEDG_POS 0x00000040
# define               PMCPM_WKEDG_NEG 0x00000080 /* OR them too */

    volatile UINT32  Status;
    volatile UINT32  InterruptEnable;
    volatile UINT32  InterruptDisable;
    volatile UINT32  InterruptMask; /* all these.. */
# define               PMCS_MOSCS      0x00000001
# define               PMCS_LOCK       0x00000002

};
#define ThePmc ((struct _Pmc *)0xffff4000)

/*
 * Special Functions (SF)
 */
struct _Sf {
    volatile UINT32  ChipID;
# define               SFID_VERSION    0x0000001f
# define               SFID_FXMASK     0x000000e0
# define               SFID_FX         0x00000040
# define               SFID_NVPSIZ     0x00000f00
# define               SFID_NVDSIZ     0x0000f000
# define               SFID_VDSIZ      0x000f0000
# define               SFID_ARCH       0x0ff00000
# define               SFID_NVPTYP     0x70000000
# define               SFID_EXT        0x80000000
    volatile UINT32  ChipIDExt;

    volatile UINT32  ResetStatus;
# define               SFRS_EXT        0x0000006c
# define               SFRS_WD         0x00000053

    volatile UINT32  reserved[3];

    volatile UINT32  ProtectMode;
# define               SFPM_KEY        0x27a80000
# define               SFPM_AIC        0x00000020

};
#define TheSf ((struct _Sf *)0xfff00000)

/*
 * Real Time Clock (RTC)
 */
struct _Rtc {
    volatile UINT32  Mode;
# define               RTCM_UPDTIM     0x00000001
# define               RTCM_UPDCAL     0x00000002
# define               RTCM_MINUTE_CHG 0x00000000
# define               RTCM_HOUR_CHG   0x00000100
# define               RTCM_MIDNIGHT   0x00000200
# define               RTCM_NOON       0x00000300
# define               RTCM_WEEK_CHG   0x00000000
# define               RTCM_MONTH_CHG  0x00010000
# define               RTCM_YEAR_CHG   0x00020000

    volatile UINT32  HourMode;
# define               RTCHM_24_HOURS  0x00000000
# define               RTCHM_12_HOURS  0x00000001

    volatile UINT32  Time;
# define               RTCT_SEC(_n_)   ((_n_)&0x7f)
# define               RTCT_SEC_G(_v_) ((_v_)&0x7f)
# define               RTCT_MIN(_n_)   (((_n_)&0x7f)<<8)
# define               RTCT_MIN_G(_v_) (((_v_)>>8)&0x7f)
# define               RTCT_HR(_n_)    (((_n_)&0x3f)<<16)
# define               RTCT_HR_G(_v_)  (((_v_)>>16)&0x3f)
# define               RTCT_PM         0x00400000

    volatile UINT32  Calendar;
# define               RTCC_CENT(_n_)   ((_n_)&0x3f)
# define               RTCC_CENT_G(_v_) ((_v_)&0x3f)
# define               RTCC_YEAR(_n_)   (((_n_)&0xff)<<8)
# define               RTCC_YEAR_G(_v_) (((_v_)>>8)&0xff)
# define               RTCC_MNTH(_n_)   (((_n_)&0x1f)<<16)
# define               RTCC_MNTH_G(_v_) (((_v_)>>16)&0x1f)
# define               RTCC_WDAY(_n_)   (((_n_)&0x7)<<21)
# define               RTCC_WDAY_G(_v_) (((_v_)>>21)&0x7)
# define               RTCC_MDAY(_n_)   (((_n_)&0x3f)<<24)
# define               RTCC_MDAY_G(_v_) (((_v_)>>24)&0x3f)

    volatile UINT32  TimeAlarm; /* same as Time plus.. */
# define               RTCTA_SECEN     0x00000080
# define               RTCTA_MINEN     0x00008000
# define               RTCTA_HOUREN    0x00800000

    volatile UINT32  CalendarAlarm; /* MDAY and MNTH plus.. */
# define               RTCCA_MNTHEN    0x00800000
# define               RTCCA_MDAYEN    0x80000000

    volatile UINT32  Status;
    volatile UINT32  Clear;
    volatile UINT32  IntrEnable;
    volatile UINT32  IntrDisable;
    volatile UINT32  IntrMask; /* all these.. */
# define               RTCS_ACK_UPD    0x00000001
# define               RTCS_ALARM      0x00000002
# define               RTCS_SECOND     0x00000004
# define               RTCS_TIME       0x00000008
# define               RTCS_CALENDAR   0x00000010

    volatile UINT32  ValidEntry;
# define               RTCV_TIME       0x00000001
# define               RTCV_CALENDAR   0x00000002
# define               RTCV_TIM_ALARM  0x00000004
# define               RTCV_CAL_ALARM  0x00000008

};
#define TheRtc ((struct _Rtc *)0xfffb8000)

/*
 * Analog to Digital Converter (ADC)
 */
struct _Adc {
    volatile UINT32  Control;
# define               ADCC_RESET      0x00000001
# define               ADCC_START      0x00000002

    volatile UINT32  Mode;
# define               ADCM_SW_TRIGGER 0x00000000
# define               ADCM_HW_TRIGGER 0x00000001
# define               ADCM_TIOA0      0x00000000
# define               ADCM_TIOA1      0x00000002
# define               ADCM_TIOA2      0x00000004
# define               ADCM_TIOA3      0x00000006
# define               ADCM_TIOA4      0x00000008
# define               ADCM_TIOA5      0x0000000a
# define               ADCM_EXTERNAL   0x0000000c
# define               ADCM_10_BITS    0x00000000
# define               ADCM_8_BITS     0x00000010
# define               ADCM_SLEEP      0x00000020
# define               ADCM_PRESCALE(_n_)  (((_n_)&0x3f)<<8)

    volatile UINT32  reserved1[2];

    volatile UINT32  ChannelEnable;
    volatile UINT32  ChannelDisable;
    volatile UINT32  ChannelStatus; /* all these.. */
# define               ADCS_CH0        0x00000001
# define               ADCS_CH1        0x00000002
# define               ADCS_CH2        0x00000004
# define               ADCS_CH3        0x00000008
# define               ADCS_CHANNEL(_n_) (1<<((_n_)&3))

    volatile UINT32  reserved2;

    volatile UINT32  Status;
    volatile UINT32  IntrEnable;
    volatile UINT32  IntrDisable;
    volatile UINT32  IntrMask; /* all these same as above plus.. */
# define               ADCS_OVERRUN0   0x00000010
# define               ADCS_OVERRUN1   0x00000020
# define               ADCS_OVERRUN2   0x00000040
# define               ADCS_OVERRUN3   0x00000080
# define               ADCS_OVERRUN(_n_) (0x10<<((_n_)&3))

    volatile UINT32  Data[4];
};
#define Adc0 ((struct _Adc *)0xfffb0000)
#define Adc1 ((struct _Adc *)0xfffb4000)

/*
 * Digital to Analog Converter (DAC)
 */
struct _Dac {
    volatile UINT32  Control;
# define               DACC_RESET      0x00000001

    volatile UINT32  Mode;
# define               DACM_SW_TRIGGER 0x00000000
# define               DACM_HW_TRIGGER 0x00000001
# define               DACM_TIOA0      0x00000000
# define               DACM_TIOA1      0x00000002
# define               DACM_TIOA2      0x00000004
# define               DACM_TIOA3      0x00000006
# define               DACM_TIOA4      0x00000008
# define               DACM_TIOA5      0x0000000a
# define               DACM_10_BITS    0x00000000
# define               DACM_8_BITS     0x00000010

    volatile UINT32  DataHold;
    volatile UINT32  Data;

    volatile UINT32  Status;
    volatile UINT32  IntrEnable;
    volatile UINT32  IntrDisable;
    volatile UINT32  IntrMask; /* all these.. */
# define               DACM_READY      0x00000001

};
#define Dac0 ((struct _Dac *)0xfffa8000)
#define Dac1 ((struct _Dac *)0xfffac000)
