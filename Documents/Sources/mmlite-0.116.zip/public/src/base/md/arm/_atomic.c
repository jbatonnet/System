/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * To be implemented in separate assembly file
 * [or does this compiler support inline asm ?]
 */

/* *** AtomicCmpAndSwap
 *
 * Compare *pTarget with OldVal.  If equal, set *pTarget to NewVal,
 * return TRUE; else return FALSE.
 */
BOOL AtomicCmpAndSwap(PUINT pTarget, UINT OldVal, UINT NewVal);

/* *** AtomicSwap
 *
 * Atomically swaps NewCount with *pCount and returns the old value.
 */
UINT AtomicSwap(PUINT pCount, UINT NewCount);
