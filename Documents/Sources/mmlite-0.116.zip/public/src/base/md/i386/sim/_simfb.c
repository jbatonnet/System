/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#define DBGLVL 3
#include <diagnostics.h>
#include <drivers\drivers.h>
#include <assert.h>

PRIVATE SCODE Instantiate(
    PIDEVICECONSTRUCTOR pDevCons,
    _TCHAR *DriverName,
    UINT Index,
    _TCHAR *InstanceName)
{
    PIUNKNOWN pUnk = NULL;
    PINAMESPACE Ns;
    SCODE sc;

    sc = pDevCons->v->Constructor(pDevCons,
                                  InstanceName,
                                  Index,0,
                                  &pUnk,
                                  NULL,
                                  NULL,
                                  (ADDRESS) 0,
                                  (ADDRESS) 0,
                                  0,0,0);

    if (FAILED(sc)) {    /* constructor failed */
        DBGME(3,_tprintf(_T("%s.%s constructor failed sc=%x\n"),
                         DriverName, InstanceName, sc));
        return sc;
    }

    /* Register it */
    Ns = CurrentNameSpace();
    sc = Ns->v->Register(Ns,
                         InstanceName,
                         pUnk, 0, NULL);

    DBGME(0,_tprintf(_T("%s.%s Register() got sc=%x\n"),
                     DriverName, InstanceName, sc));

    /* Let our ref go
     */
    (void) pUnk->v->Release(pUnk);
    return sc;
}

void InitFrameBuffer(void)
{
    _TCHAR *CobName = _T("COB\\simfb.cob");
    SCODE sc;
    PIDEVICECONSTRUCTOR pDevCons = NULL;

    /* Load the driver & find the constructor
     */
    DBGME(2,_tprintf(_T("Loading driver %s\n"),CobName));
    sc = BindToObject(CurrentNameSpace(),
                      CobName,
                      NAME_SPACE_READ | NAME_SPACE_WRITE,
                      &IID_IDeviceConstructor,
                      (void **) &pDevCons);

    if (FAILED(sc)) {
        DBGME(3,_tprintf(_T("COB %s did not load, sc=%x\n"),
                         CobName, sc));
        return;
    }

    /* Create the framebuffer object first
     */
    sc = Instantiate(pDevCons, CobName, 0, _T("display"));
    if (FAILED(sc)) goto Out;

    /* Now create the keyboard object
     */
    sc = Instantiate(pDevCons, CobName, 1, _T("keyboard"));
    if (FAILED(sc)) goto Out;

    /* Now create the mouse object
     */
    sc = Instantiate(pDevCons, CobName, 2, _T("mouse"));
    if (FAILED(sc)) goto Out;

    /* Release all refs
     */
 Out:
    (void) pDevCons->v->Release(pDevCons);
}
