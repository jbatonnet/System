#ifndef __ROUTE_H_
#define __ROUTE_H_

#include <net/if.h>
#include <net/if_dl.h>

#include <ip/in.h>

/*
 * Specifies where and through which interface to send a packet.
 * Given as an answer to a "I need to send a packet to this address"-query.
 */
struct route_in {
    INT rt_valid;
    struct ifaddr *rt_ifa;
    struct sockaddr_in rt_gw;
};

struct gateway {
    struct route_in gw_rt;
};
#define gw_valid gw_rt.rt_valid
#define gw_ifa gw_rt.rt_ifa
#define gw_gw gw_rt.rt_gw

INT rt_addgw(struct in_addr);
void rt_delgw(void);
struct ifaddr *rt_getgw(void);
INT rt_ifaout(struct in_addr, struct ifaddr **, struct sockaddr_in *);

void rt_ifmsg(struct ifnet *);
INT rtioctl(INT, PTR);

#endif /* __ROUTE_H_ */
