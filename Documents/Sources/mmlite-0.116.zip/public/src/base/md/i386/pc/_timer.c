/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Time is kept using both the RTC and the PIT (timer 0).
 * The former gives an RTCDelta interrupt granularity, and
 * is the sole responsible for the drift [temperature & co.].
 * The latter gives fine grain resolution, and is used for
 * scheduling purposes.
 *
 * The basic idea is that the current time is given by
 *
 *      Now = TOY + ReloadDelta + (Ticks - PIT)
 *
 * where TOY is the accumulated count of the RTC interrupts,
 * ReloadDelta is the accumulated count of PIT reloads (one
 * reload per rescheduling), Ticks is the value the PIT was
 * last reloaded with, and PIT is the current reading of
 * the PIT.
 *
 * An important but subtle point is how the subexpression
 * in parens is evaluated.  PIT is a 16 bit counter, which
 * counts down from the (Ticks) value it is loaded with.
 * When it reaches zero it keeps decrementing from xFFFF.
 * (We use the Intel 8254 in Mode0).
 * By using signed 16 bits arithmetic we are guaranteed that
 * the (unsigned!) result of the subtraction is precisely
 * the number of ticks elapsed.  Assuming only that we did
 * not ignore the PIT interrupt for e.g. 54 milliseconds,
 * which is a safe assumption (else this whole OS is garbage..).
 *
 *
 * Formal analysis was based on the following pseudo code.
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (Ticks - PIT)
 *
 * PIT.Set(t) ::
 *      ReloadDelta += (Ticks - PIT)
 *      PIT = t
 *      Ticks = t
 *
 * PIT.Interrupt() :: <nothing needed>
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, 16msec
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * All functions are assumed atomic interrupt-wise.
 *
 * Notice that the above proof still holds if we remove
 * the RTC chip: just cancel RTC.Interrupt() and wire TOY==0.
 * Drift analysis (in PIT.Set()) becomes important, e.g. the
 * time between the first and second statement.
 *
 * MultiP extensions should decouple per-processor scheduling
 * from system-wide TOY services. For instance, only one
 * processor might get the RTC interrupt (global TOY) and
 * each processor uses its own PIT (separate ReloadDelta,
 * Ticks and PIT "variables").
 */

#include <mmlite.h>
#include <stdio.h>
#include <mmhal.h>
#include <x86_cpu.h>
#include <machdep.h>
#include "_pic.h"

void __cdecl BiosTick(void);

/* Defines for PIC ports
 */
#define PIC0_PORT 0x20
#define PIC1_PORT 0xA0
#define PIC_NS_EOI 0x20

/* Defines for RTC port
 */
#define RTC_PORT 0x70

/* Defines for PIT ports
 */
#define PIT_PORT 0x40
#define PIT_T0 (PIT_PORT+0)
#define PIT_CONTROL (PIT_PORT+3)

/* 64Hz was chosen because it is the only value, among the
 * possibilities offered by the Motorola MC 146818 chip,
 * that does not generate roundoff errors in our TIME domain.
 */
#define RTCDelta 156250                   /* TIME units, e.g. 15.625 msec */

/* The 8254 is serviced by a 1.19.. Mhz crystal.
 * This is the one that controls resolution.
 */
#define max_toy_resolution 0.838095110385 /* microsecs (documentation) */

/* Some functions in here are exposed directly
 * via the names used in the MI code.
 */
#define RTCGetTime GetKernelTime

#define PITSetNextInterrupt SetNextInterrupt
#define PITInterrupt SchedulingInterrupt

/*
 * XXXX This global data structure should
 * be split into per-processor and global.
 */
volatile struct {
    TIME Toy;           /* Time-of-year */
    UINT ReloadDelta;   /* PIT Ticks since Toy */
    INT16 TicksDelta;   /* Current PIT reload value */
    INT16 __pad;        /* beware */
    UINT BiosNeedsTicks;

    /* Assembly code needs to know
     */
#define _OFF_Toy 0
#define _OFF_ReloadDelta 8
#define _OFF_TicksDelta 12
#define _OFF_BiosNeedsTicks 16

} SystemTimers;

/* ---- PIT specific code
 */

/* Read the current value of the PIT (as Ticks)
 * Caller makes sure no interrupt messes with PIT.
 * BEWARE: This is called from RTCInterrupt, and
 *         with segments messed up.
 */
#pragma warning(disable:4035)
__declspec(naked) INT16 __cdecl PITRead ()
{
    __asm {
        /* Tell PIT to latch counter 0
         */
        xor eax,eax;
        out PIT_CONTROL,al;
        /* delay to digest 
         */
        jmp l1; 
    l1: jmp l2;
    l2:

        /* Read lsb then msb
         */
        in al,PIT_T0;
        xchg ah,al;
        in al,PIT_T0;
        xchg ah,al;

        ret;
    }
}
#pragma warning(default:4035)

/* Arm the PIT to trigger in NTICKS
 * Caller makes sure no interrupt messes with PIT.
 */
void PITWrite (UINT nTicks)
{
    __asm {
        /* Pick up argument before we mess up the stack
         */
        mov edx,nTicks;

        /* Interrupts off
         */
        pushfd;
        cli;

        /* Counter 0, Mode 0, lsb then msb, binary
         */
        mov al,0x30;
        out PIT_CONTROL,al;
        jmp l1;
    l1: jmp l2;
    l2:

        /* nTicks.lsb
         */
        mov eax,edx;
        out PIT_T0,al;
        jmp l3;
    l3:
        /* nTicks.msb
         */
        xchg ah,al;
        out PIT_T0,al;

        /* Restore interrupts
         */
        popfd;
    }
}

/* Arm the PIT for a TIME (100ns) DELTA
 */
static void RTCPoke(void);

BOOL PITSetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    UINT Ticks;
    INT16 Pit, Tks;
    UINT16 r;
    UINT IntrState;
    BOOL StateWas;

    static BOOL FirstCall = TRUE;
    if (FirstCall) {
        FirstCall = FALSE;
        RTCPoke();
    }

    /*
     * Timers are fed by a 1.193182 Mhz clock signal.
     * max_toy_resolution is then 838.095110385.. ns.
     * Max interval 0x10000 * res == 549254.165.. *100ns,
     * which is to say the max for Delta is 0:0x86186 (54 ms).
     * [wizquiz: the precise calculation is 14318180/(3*4*65536)]
     */
    /* Subtract some time (1ms) to avoid wrap around when no RTC is running */
#define PIT_MAX_INTERVAL 0x86186 - 10000

    /* Can't use zero ticks as overflow would again result */
    if (Delta > ((TIME)PIT_MAX_INTERVAL))
      Delta = (TIME) PIT_MAX_INTERVAL;

    {
        /*
         * To get from TIME-Delta to Ticks:
         *
         *  Ticks       = Delta * 0.1193182
         *              = Delta * (1/0x10 + 0xe8ba/0x100000)
         */
        TIME tmp = Delta * (INT) 0xe8ba; /* XXX overflows -> modulo arith... */
        tmp >>= 20;
        Ticks = ((INT32)tmp) + ( ((INT32)Delta) >> 4 );
        if (Ticks < 2)
          Ticks = 2; /* sanity minimum */
    }

    /*
     * Got the tick count, program the timer now
     */
    TURN_INTERRUPTS_OFF(IntrState);

    /* Careful about the 16bit math
     */
    Pit = PITRead();
    Tks = SystemTimers.TicksDelta;
    r = (UINT16)(Tks - Pit);

    /* Say when we reloaded the PIT
     */
    SystemTimers.ReloadDelta += r;

    /* Say how we did it
     */
    SystemTimers.TicksDelta = (volatile INT16)Ticks;

    /* And do it
     */
    PITWrite (Ticks);

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);

    return StateWas;

}

/* Interrupt from PIT chip.
 * Call scheduler.
 */
__declspec(naked) void __cdecl PITInterrupt()
{
    /* On stack we have:
     * (high)
     *              saved SS     only if from user level  ;; 32bits
     *              saved ESP    only if from user level  ;; 32bits
     *              saved EFLAGS     ;; 32bits
     *              saved CS         ;; 32bits
     * esp->        saved eip        ;; 32bits
     */
    __asm {
        /* Interrupt frame setup
         */
        push ds;
        push es;
        push gs;
        push fs;
        pushad;
        push 0;                 /* pFpa */

#if 1
        /* Set segment registers to ring0 conventions */
        mov  dx,ss;
        mov  ds,dx;   /* Reference kernel data */
        mov  es,dx;   /* Reference kernel data */
        xor  dx,dx;
        mov  fs,dx;   /* Zapped */
        mov  gs,dx;   /* Zapped */
#endif

        /* Quiet PIC (PIT always hangs off master PIC)
         */
        mov al,PIC_NS_EOI;
        out PIC0_PORT,al;

        /* Do not return here, go directly
         * where we came from (via an iretd)
         */
        jmp _Reschedule;
    }
}


/* ---- RTC specific code
 */
#define USE_RTC 0

#if USE_RTC
/* Write to one of the RTC registers.
 * Needs interrupt protection.
 */
static void WriteRTC( int RegNum, int Value)
{
    __asm {
        /* Select the register
         */
        mov eax,RegNum
        out RTC_PORT,al;

        /* Wait for slow chip
         */
        mov eax,Value;
        jmp l0;
l0:     jmp l1;

        /* Write to selected register
         */
l1:     out (RTC_PORT+1),al;

        /* Sanity-wait
         */
        jmp l2;                 /* wait */
l2:
    }
}
#endif

/* Read one of the RTC registers.
 * Needs interrupt protection.
 */
static UINT8 ReadRTC( int RegNum )
{
    UINT Value;
    __asm {
        /* Select the register
         */
        mov eax,RegNum
        out RTC_PORT,al;

        /* Wait for slow chip
         */
        jmp l0;
l0:     jmp l1;

        /* Read the register
         */
l1:     in al,(RTC_PORT+1);
        mov Value,eax;
    }
    return (UINT8)Value;
}

/* XXX Debug printouts
 */
static void RTCPoke()
{
    UINT IntrState;

    TURN_INTERRUPTS_OFF(IntrState);
    ReadRTC(0xc);
    RESTORE_INTERRUPTS(IntrState);
}

#ifdef _DEBUG
void RTCState()
{
    printf("SysT: %x.%x %x %x %x ",
            SystemTimers.Toy, SystemTimers.ReloadDelta,
            SystemTimers.TicksDelta, SystemTimers.BiosNeedsTicks);
    printf("RTC: A %x B %x C %x D %x\n",
            ReadRTC(0xa), ReadRTC(0xb), ReadRTC(0xc), ReadRTC(0xd) );
}
#endif

/*
 * Return the current epoch (time&year), as
 * stored in the NVRAM of the RTC chip.
 */
const TIME  SecondsToStartOf1980 = 0x00000002c8df3700;
const UINT8 DaysPerMonth[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
static int RTCCenturyByte = 0x32; /* ISA&co */

UINT8 BCDToInt( UINT8 Bcd )
{
    return (UINT8)((Bcd & 0xf) + ((Bcd >> 4) * 10));
}

TIME RTCGetEpoch()
{
    TIME Now = 0;
    UINT IntrState, Seconds, Year;
    UINT8 Month;

    /* BUGBUG For MCA and some other PS1 machines the Century byte
     * is at 0x37. To recognize these machines we should read
     * from 0x10 to 0x2d and sum (unsigned). The result should
     * be stored at 0x2e(high):0x2f(low) in all but MCA machines.
     */

    TURN_INTERRUPTS_OFF(IntrState);

    /* Beware of UIP 
     */
    while (ReadRTC(0xa) & 0x80)
        Delay(10);

    /* Pick RTC, in seconds
     */
    Seconds  = BCDToInt(ReadRTC(0x00));                  /* sec  in m */
    Seconds += BCDToInt(ReadRTC(0x02)) * (60);           /* min  in h */
    Seconds += BCDToInt(ReadRTC(0x04)) * (60 * 60);      /* hour in d */
    Seconds += BCDToInt(ReadRTC(0x07)) * (60 * 60 * 24); /* day  in mo */

    /* Pick the rest, we'll have to grind it
     */
    Month = BCDToInt(ReadRTC(0x08));
    Year  = BCDToInt(ReadRTC(0x09));
    Year += 100 * BCDToInt(ReadRTC(RTCCenturyByte));

    RESTORE_INTERRUPTS(IntrState);

    Now = ((UINT64)Seconds + SecondsToStartOf1980) * 10000000;

    /* Sanity check
     */
    if (Year < 1995)
        return 0;

#define IS_LEAP(_y_)  (((_y_) & 3) == 0)
#define Days Seconds
    Days = 0;
    /* Month is 1-based */
    while (--Month > 0) {
        Days += DaysPerMonth[Month-1];
        if (Month == 2 && IS_LEAP(Year))
            Days++;
    }

    while (--Year >= 1980) {
        Days += 365;
        if (IS_LEAP(Year))
            Days++;
    }

    Now = Now + 
          (((UINT64)Days) * ((UINT64)864000000000));

#undef Days

    return Now;
}

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is max_toy_resolution
 */
TIME RTCGetTime0 ()
{
    UINT Deltas;
    UINT IntrState;
    TIME r;
    INT16 b,c;
    UINT16 a;

#define REVERSE_FLOW_BUG (_DEBUG || 0)

#if REVERSE_FLOW_BUG
    TIME LastTimeWeSaw;
    static TIME LastT;
    static UINT NumErrors = 0, Threshold = 1;
#endif
        
    /* Cache a few values with interrupt protection
     */
    TURN_INTERRUPTS_OFF(IntrState);

    Deltas = SystemTimers.ReloadDelta;
    b = SystemTimers.TicksDelta;
    c = PITRead();
    r = SystemTimers.Toy;
#if REVERSE_FLOW_BUG
    LastTimeWeSaw = LastT;
#endif

    RESTORE_INTERRUPTS(IntrState);

    /* Careful with math here
     */
    a = (UINT16)(b - c);
    Deltas += a;

    /* Must convert from Ticks to TIME.
     *
     * Note that the sum of all deltas is less than
     * the frequency at which the RTC runs, e.g. 16 msec.
     * In Ticks this is 0x4a92, e.g. Deltas will have at most 15 bits.
     * This means we need at most 16 bits of fractional part in
     * the following conversion:
     *
     *          t = Nticks * max_toy_resolution(sec) * 10^7
     *
     * In numbers this is
     *
     *          t = Deltas * 0x8.6186e4b7....
     *            = Deltas * (8 + 0x6186/0x10000)
     *
     * A second nice thing is we can do the multiply in 32 bits.
     */
    Deltas = (Deltas << 3)  +  ((Deltas * 0x6186) >> 16);

    /* Now put them all toghether
     */
    r += (TIME) Deltas;

#if (REVERSE_FLOW_BUG && 0)
    /* We might have been pre-empted
     */
    TURN_INTERRUPTS_OFF(IntrState);
    if (LastTimeWeSaw == LastT) {
        if ((r <= LastT) && (++NumErrors == Threshold)) {
            DBGOUT(DBGCONTEXT,1,printf("TIME error: -x%x\n", (UINT)(LastT - r)));
            Threshold *= 2; /* exponential backoff on error reporting */
        }
        LastT = r;
    }
   /* else we are behind in time */
/*    else DBGOUT(DBGCONTEXT,1,printf(" PR ")); */
    RESTORE_INTERRUPTS(IntrState);
#endif

#if REVERSE_FLOW_BUG
    TURN_INTERRUPTS_OFF(IntrState);
    if (r < LastT)
        r = LastT + 1;
    LastT = r;
    RESTORE_INTERRUPTS(IntrState);
#endif

    return r;
}

/* Ensure that RTCGetTime returns monotonically increasing values, regardless
 * of what the "real" RTCGetTime function (RTCGetTime0, above) does.
 * These routines will be merged once Sandrof and Joebar can coordinate.
 */
TIME RTCGetTime ()
{
    TIME r;
    UINT IntrState;
    static TIME LastT;

    r = RTCGetTime0();

    TURN_INTERRUPTS_OFF(IntrState);
    if (r < LastT)
        r = LastT + 1;
    LastT = r;
    RESTORE_INTERRUPTS(IntrState);

    return r;
}

/* Interrupt from RTC chip.
 * Adjust elapsed time count.
 */
UINT nRTC;

__declspec(naked) void __cdecl RTCInterrupt()
{
    __asm {
        /* Preserve registers, segments dont
         */
        push    eax;
        push    edx;

inc nRTC;
        /* Quiet the RTC chip
         */
        mov     al,0xc;         /* enable NMI, select register C */
        out     RTC_PORT,al;
        jmp     l1;                     /* wait for chip to digest it */
l1:     jmp     l2;                     /* wait for chip to digest it */
l2:     in      al,(RTC_PORT+1);

        /* Save a few inlined zeroes (in the code)
         */
        xor     edx, edx;

        /* SystemTimers.Toy += (TIME) RTCDelta;
         */
        add     DWORD PTR SystemTimers+_OFF_Toy, RTCDelta;
        adc     DWORD PTR SystemTimers+_OFF_Toy+4, edx;

        /* SystemTimers.ReloadDelta = 0;
         */
        mov     DWORD PTR SystemTimers+_OFF_ReloadDelta, edx;

        /* SystemTimers.TicksDelta = PITRead();
         * if (SystemTimers.BiosNeedsTicks)
         *     BiosTick();
         */
        call    PITRead;
        cmp     DWORD PTR SystemTimers+_OFF_BiosNeedsTicks, edx;  /* BEWARE edx==zero */
        mov     DWORD PTR SystemTimers+_OFF_TicksDelta, eax; /* BEWARE __pad */

        /* RTC always hangs off slave PIC.  BiosTicks will
         * instead generate a PIT interrupt, which quiets
         * only the master PIC. So we do the slave here.
         */
        mov     al,PIC_NS_EOI;
        out     PIC1_PORT,al;   /* one for slave  */

        jz      notick;

        dec     DWORD PTR SystemTimers+_OFF_BiosNeedsTicks;
        mov     edx, DWORD PTR SystemTimers+_OFF_BiosNeedsTicks;
        and     edx,3;
        jz      DoBiosTick;
    notick:

        /* Wont go to BIOS, so quiet master PIC.
         */
        out     PIC0_PORT,al;   /* one for master */

/*  Done: */
        /* Restore registers and return
         */
        pop     edx;
        pop     eax;
        iretd;

    DoBiosTick:
        /* Reset them regs to original values */
        pop     edx;
        pop     eax;

        /* Mumble, lotsa work here, but no rush.
         * Save all regs and segments.  Might as well be standard frame.
         */
        push ds;
        push es;
        push gs;
        push fs;
        pushad;
        push 0;                 /* pFpa */

#if 1
        /* Set segment registers to ring0 conventions */
        mov  dx,ss;
        mov  ds,dx;   /* Reference kernel data */
        mov  es,dx;   /* Reference kernel data */
        xor  dx,dx;
        mov  fs,dx;   /* Zapped */
        mov  gs,dx;   /* Zapped */
#endif
#if 1  /*notyet*/
        /* Let BIOS know.
         * WARNING: This call should not endup signalling conditions.
         */
        call BiosTick;
#endif

        /* Restore all regs and segments, then out
         */
/* GetOut: */
        push esp;
        call HWLoadThreadContext;
        int 3;
    }
}

/* Say if the BIOS needs clock interrupts,
 * and how many of them.
 */
void BiosNeedsTicks( UINT Count)
{
    SystemTimers.BiosNeedsTicks = Count << 2; /* 15.612 * 4 ~~ 54 */
}

/* Initialization, common to RTC and PIC.
 */
void EnableTimers( void )
{
    BiosNeedsTicks(50);         /* XXX.  Turn off floppy at boot. */

#if USE_RTC
    /* Beware of UIP 
     */
    while (ReadRTC(0xa) & 0x80)
        Delay(10);

    WriteRTC(0xb,0x82); /* stop RTC, to reprogram it */
    WriteRTC(0xa,0x2a); /* interrupt every RTCDelta (64 Hz) */
    WriteRTC(0xb,0x42); /* get it rolling again */
#endif

#if !defined(USE_OLD_PIC)
    /* Make sure we have the right ISR setup */
    InstallIsr(8, PitInterrupt, TRUE, FALSE);
#endif

    /* Took a bit of a struggle to get this right...
     *
     * There appeared to be no way to stop the timer, so at first
     * I just changed the code such that EnablePreemption is called at
     * startup only when we really are ready to (re)schedule the 
     * first thread.  Else init would not complete.
     *
     * But then Murray Sargent brightly suggested that I just never
     * finish the loading of the counter! Although the specs
     * are murky on this, testing showed that yes indeed we do
     * not get an interrupt, and later we can still reload fine.
     * Thanks, and a tip of the hat to Murray.
     */

    IOSpaceWriteInt8(PIT_CONTROL,0x30); /* Timer 0, Mode 0, lsb then msb, binary */
    IOSpaceWriteInt8(PIT_T0,1);
    /* IOSpaceWriteInt8(PIT_T0,0);  DONT !! */
}

/* Finalization
 * Interrupts must be off already
 */
void DisableTimers( void )
{
#if USE_RTC
    /* Stop RTC, BIOS might use it
     */
    WriteRTC(0xb,0x2);
    WriteRTC(0xa,0x26);  /* interrupt every 976.562 usec */
#endif

    /* Put the PIT back the way it was
     */
    IOSpaceWriteInt8(PIT_CONTROL,0x36); /* Timer 0, Mode 3, lsb then msb, binary */
    IOSpaceWriteInt8(PIT_T0,0);
    IOSpaceWriteInt8(PIT_T0,0);
}

/* Estimate the current processor speed
 */
UINT64 CurrentProcessorSpeed(void)
{
#if 1
    return 0;
#else
    /* On Pentium class systems one can do the following:
     * 1- disable interrupts
     * 2- loop until the PIT bumps by one
     * 3- read the performance counter -> p0
     * 4- loop until the PIT bumps again
     * 5- read the performance counter -> p1
     * 6- enable interrupts
     * 7- Do the division (p1 - p0) / max_toy_resolution
     *
     * Alternatively, to reduce ganularity issues, one might:
     * 1- BeginConstraint( start=now, est=100msec, dead=now+200msec)
     * 2- read the performance counter -> p0
     * 3- SleepUntil( -100msec)
     * 4- read the performance counter -> p0
     * 5- EndConstraint( &timeTaken)
     * 6- Do the division (p1 - p0) / timeTaken
     */
#endif
}
