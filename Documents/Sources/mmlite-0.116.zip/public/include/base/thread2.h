/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef _OLDSCHED

#ifndef __THREAD2_H__
#define __THREAD2_H__

#include <util/list-single.h>
#include <base/mutex2.h>
#include <base/condition2.h>
#include <base/kconstraint2.h>

typedef enum _THREAD_STATE_ENUM {
  THREAD_READY,             /* 0 - Able to be run but not yet running        */
  THREAD_RUNNING,           /* 1 - Current thread (for a given cpu)          */
  THREAD_DEAD,              /* 2 - Going away                                */
  THREAD_IDLE,              /* 3 - Playing IdleThread                        */
  THREAD_SLEEPING,          /* 4 - Suspended                                 */
  THREAD_WAITING
} THREAD_STATE_ENUM;

typedef enum _THREAD_WAIT_ENUM {
  THREAD_WAIT_NONE,
  THREAD_WAIT_MUTEX,
  THREAD_WAIT_CONDITION
} THREAD_WAIT_ENUM;

#define THREAD_IDLE_BIT 0x1
#define THREAD_IDLE_MASK (~THREAD_IDLE_BIT)
#define THREAD_IDLE_INVERSE_MASK THREAD_IDLE_BIT

typedef struct _THDINFO {
    const struct IThreadVtbl *v;
    UINT RefCnt;               /* Reference count (see below)               */
    CXTINFO *CxtInfo;          /* Full context (when not running)           */
    SCODE LastError;           /* Get/SetLastError                          */
    PIPROCESS StartedIn;       /* initially created in this process/module  */

    PKCONSTRAINT pkcCurrent;

    LIST lMutexList;           /* List of mutexes owned by this thread */

    THREAD_STATE_ENUM State;   /* What to do at context switch              */
    THREAD_WAIT_ENUM WaitState;
    PTR pWaitObject;           /* What object am I waiting on               */

    PTR RpcContinuation;        /* State for post-processing of RPCs */

    /* Thread specific resources */
    PBYTE  StackBase;          /* Stack info                                */
    UINT   StackSize;
    /* The virtual memory space page faults should be resolved in. NULL=phys */
    PIVMVIEW pVmView;
    //   PTR pTls;             /* Support for Thread Local Storage          */
#if __NEED_M_THDINFO
    /* Struct below is machine-specific                           */
    M_THDINFO ThreadMInfo; /* If defined must be multiple of 8 bytes */
#endif
} THDINFO, *PTHDINFO;

#define pTH(_pThd_)  ((PTHDINFO) (_pThd_))

#ifdef _DEBUG
/* This debug mechanism allows us to force the debugger into explicitly using
 * the private THDINFO kernel struct so we can see its members.
 * ThreadPrologue must be after all variable declarations but before any
 * statements.
 */
#define Thread_Prologue() PTHDINFO pTHProxy = pTH(pThd)
#define pThdArg pTHProxy
#else
#define Thread_Prologue()
#define pThdArg pThd
#endif /* _DEBUG */

#define /* THREAD_STATE_ENUM */                                               \
Thread_GetState(/* PITHREAD */ _pThd_ )                                       \
     (pTH(_pThd_)->State)

#define /* void */                                                            \
Thread_SetState(/* PITHREAD */ _pThd_,                                        \
               /* THREAD_STATE_ENUM */ _state_)                               \
     (Thread_GetState(_pThd_) = (_state_))

#define /* THREAD_WAIT_ENUM */                                               \
Thread_GetWaitState(/* PITHREAD */ _pThd_ )                                   \
     (pTH(_pThd_)->WaitState)

#define /* void */                                                            \
Thread_SetWaitState(/* PITHREAD */ _pThd_,                                    \
               /* THREAD_WAIT_ENUM */ _state_)                               \
     (Thread_GetWaitState(_pThd_) = (_state_))

#define /* PCXTINFO */                                                        \
Thread_GetContext(/* PITHREAD */ _pThd_)                                      \
     (pTH(_pThd_)->CxtInfo)

#define /* void */                                                            \
Thread_SetContext(/* PITHREAD */ _pThd_,                                      \
                 /* PCXTINFO */ _pcx_)                                        \
     (pTH(_pThd_)->CxtInfo = (_pcx_))

#define /* PLIST */                                                          \
Thread_GetMutexList(/* PITHREAD */ _pThd_)                                    \
     &(pTH(_pThd_)->lMutexList)

#define /* PTR */                                                             \
Thread_GetWaitObject(/* PITHREAD */ _pThd_)                                   \
     ((PTR)((UINT)(pTH(_pThd_)->pWaitObject) & THREAD_IDLE_MASK))

#define /* void */                                                            \
Thread_SetWaitObject(/* PITHREAD */ _pThd_,                                   \
                    /* PTR */ _ptr_)                                          \
     (pTH(_pThd_)->pWaitObject = (PTR)(((UINT)(_ptr_) & THREAD_IDLE_MASK) | ((UINT)(pTH(_pThd_)->pWaitObject) & THREAD_IDLE_INVERSE_MASK)))

#define /* void */                                                            \
Thread_ClearWaiting(/* PITHREAD */ _pThd_)                                    \
     Thread_SetState((_pThd_), THREAD_READY);                                 \
     Thread_SetWaitState((_pThd_), THREAD_WAIT_NONE);                         \
     Thread_SetWaitObject((_pThd_), NULL)

#define /* void */                                                            \
Thread_MutexListInitialize(/* PITHREAD */ _pThd_)                             \
     List_Init(Thread_GetMutexList(_pThd_));

#define /* PKCONSTRAINT */                                                    \
Thread_GetCurrentConstraint(/* PITHREAD */ _pThd_)                            \
     (pTH(_pThd_)->pkcCurrent)

#define /* void */                                                            \
Thread_SetCurrentConstraint(/* PITHREAD */ _pThd_,                            \
                           /* PKCONSTRAINT */ _pkc_)                          \
     (Thread_GetCurrentConstraint(_pThd_) = pKC(_pkc_))

#define /* void */                                                            \
Thread_SetWaiting(/* PITHREAD */ _pThd_,                                      \
                 /* WAIT_STATE_ENUM */ _wse_,                                 \
                 /* PTR */ _pWaitObject_)                                     \
     Thread_SetState((_pThd_), THREAD_WAITING);                               \
     Thread_SetWaitState((_pThd_), (_wse_));                                  \
     Thread_SetWaitObject((_pThd_), (_pWaitObject_))

#define Thread_IsDead(_pThd_)     (Thread_GetState(_pThd_) == THREAD_DEAD    )
#define Thread_IsRunning(_pThd_)  (Thread_GetState(_pThd_) == THREAD_RUNNING )
#define Thread_IsWaiting(_pThd_) (Thread_GetState(_pThd_) == THREAD_WAITING)
#define Thread_IsSleeping(_pThd_) (Thread_GetState(_pThd_) == THREAD_SLEEPING)
#define Thread_IsReady(_pThd_)    (Thread_GetState(_pThd_) == THREAD_READY   )

#define /* BOOL */                                                            \
Thread_IsIdle(_pThd_)                                                         \
    (((UINT)(pTH(_pThd_)->pWaitObject) & THREAD_IDLE_BIT) == THREAD_IDLE_BIT)

#define /* void */                                                            \
Thread_SetIdle(_pThd_)                                                        \
    (pTH(_pThd_)->pWaitObject = (PTR)((UINT)(pTH(_pThd_)->pWaitObject) | THREAD_IDLE_BIT))

#define /* void */                                                            \
Thread_ClearIdle(_pThd_)                                                      \
    (pTH(_pThd_)->pWaitObject = (PTR)((UINT)(pTH(_pThd_)->pWaitObject) & ~THREAD_IDLE_BIT))

#define /* BOOL */                                                            \
Thread_IsWaitingForTimeout(/* PITHREAD */ _pThd_)                             \
     (Thread_GetState(_pThd_) == THREAD_SLEEPING)

#define /* BOOL */                                                            \
Thread_IsWaitingForMutex(/* PITHREAD */ _pThd_)                               \
     (Thread_GetWaitState(_pThd_) == THREAD_WAIT_MUTEX)

#define /* BOOL */                                                            \
Thread_IsWaitingForCondition(/* PITHREAD */ _pThd_)                           \
     (Thread_GetWaitState(_pThd_) == THREAD_WAIT_CONDITION)

#define /* void */                                                            \
Thread_MutexListAdd(                                                          \
    /* PITHREAD */ _pThd_,                                                    \
    /* PMUTEX   */ _pmx_)                                                     \
  (List_TailAdd(Thread_GetMutexList(_pThd_), Mutex_GetListNode(_pmx_)))

#define /* void */                                                            \
Thread_MutexListRemove(                                                       \
    /* PITHREAD */ _pThd_,                                                    \
    /* PMUTEX   */ _pmx_)                                                     \
  (List_Remove(Thread_GetMutexList(_pThd_), Mutex_GetListNode(_pmx_)))

#define /* SCODE */                                                           \
Thread_GetLastError(                                                          \
    /* PITHREAD */ _pThd_)                                                    \
  (pTH(_pThd_)->LastError)

#define /* void */                                                            \
Thread_SetLastError(/* PITHREAD */ _pThd_,                                    \
                   /* SCODE */ _sc_)                                          \
     (Thread_GetLastError(_pThd_) = (_sc_))

SCODE MCT ThreadCreate( 
    PIPROCESS pProcess,
    THREAD_FUNCTION pStart,
    THREAD_ARGUMENT Arg,
    ADDR_SIZE StackSize,
    UINT32 Flags,
    /*optional*/     PIVMVIEW pVmView,
    /*optional,out*/ PTR *pStack,
    /*optional,out*/ IThread **ppNewThread);

void Thread_Init(
     PTHDINFO pThd
     );

void Thread_UnlockMutexes(
     PTHDINFO pThd
     );

PKCONSTRAINT Thread_FindMostUrgentMutexWaiter(
     PTHDINFO pThd
     );

BOOL Thread_MutexWaiterCompareGT(
     PTR pMX1,
     PTR pMX2
     );

void Thread_MutexUnlock(
     PTR pMutex
     );

#endif /* __THREAD2_H__ */

#endif /* _OLDSCHED */
