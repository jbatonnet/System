/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include <drivers.h>
#include <../src/drivers/pccard/pccard.h>

typedef struct {
    volatile UINT32 Level;
    volatile UINT32 Direction;
    volatile UINT32 Set;
    volatile UINT32 Clear;
    volatile UINT32 DetectRaising;
    volatile UINT32 DetectFalling;
    volatile UINT32 DetectStatus;
    volatile UINT32 Alternate;    
} GPIO;
#define Gpio ((GPIO*)0x90040000)


EXTERN_C PCNETDRIVER RTLCALLTYPE
CW10New(PUINT pPortBase, PUINT pIrq, PUINT pAttribBase, PUINT pPortType, _TCHAR *NameStr, _TCHAR *SsidStr);

int main(int argc, char **argv)
{
    UINT PortBase = 0x20000000;
    UINT Irq = 43; /* 32+(GPIO 22-11) */
    UINT AttributeBase = 0x28000000;
    UINT portType = 1; /* BSS */
    //UINT portType = 3; /* IBSS (ad-hoc) */
    _TCHAR *stationName = "CERF0";  
    //_TCHAR *ssid = "tsunami";
    _TCHAR *ssid = "MSFTWLAN";
    UINT r, i;
    PCNETDRIVER Dev;
    TIME Idle;
    PUINT16 linkStat_p;
    INT64 sleepTime;
    
    UINT16 manfID,productID;
    UINT8 versionMajor, versionMinor;
    PINT8 manStr,productStr,infoStr1,infoStr2;

    UINT IoBase = 0x20000000;
    UINT MemoryBase = 0x2c000000;
    UINT32 ConfigBase;
//#define CONFIG_BASE 0x3e0

    //volatile UINT8 *ps = (volatile UINT8*) 0x28000000; // CF attribute space
   
    /* Take the chip out of sleep
     */
#define CW10_SLEEP_PIN (1<<21)
    //Gpio->Direction |= CW10_SLEEP_PIN; /* its an output */
    //Gpio->Set = (0x5) | CW10_SLEEP_PIN | (Gpio->Level & Gpio->Direction);
    //_tprintf(_TEXT("GPIO: l=%x d=%x 1=%x 0=%x r=%x f=%x s=%x a=%x\n"), *Gpio);

  
      //_tprintf(_TEXT("Hi mom!\n"));
  
    Gpio->Direction &= ~(1<<22); /* set 22 as input */
    if ( !(Gpio->Level & (1<<23)) ) {
        _tprintf(_TEXT("Card detected\n"));
    }    
    else {
        _tprintf(_TEXT("Card not detected\n"));
        return 0;
    }

    Gpio->Direction &= ~(1<<22); /* set 22 as input */

    if( Gpio->Level & (1<<22) ) { 
        _tprintf(_TEXT("CF Ready (GPIO 22: high)\n"));
    }
    else 
    {
        _tprintf(_TEXT("CF not ready - GPLR: 0x%x\n"),*(UINT32 *)0x90040000); 
        _tprintf(_T("Attempting reset...\n"));
        /* Reset CF card */
        Gpio->Set |= 1<<21;
        Int32ToInt64(sleepTime,TIME_RELATIVE(TIME_MILLIS(200)));
        SleepUntil(sleepTime);
        Gpio->Clear |= 1<<21;
        Int32ToInt64(sleepTime,TIME_RELATIVE(TIME_MILLIS(200)));
        SleepUntil(sleepTime);

        if( Gpio->Level & (1<<22) ) { 
            _tprintf(_TEXT("CF ready (GPIO 22 high)\n"));
        }
        else _tprintf(_TEXT("CF not ready; GPLR: 0x%x\n"),Gpio->Level);
        return 0;
    }


    /* check cis */
    if(PcCardGetManufacturerData(AttributeBase,&manfID,&productID)) {
        _tprintf(_T("Manufacturer ID = 0x%x\n"),manfID);
        _tprintf(_T("Product ID = 0x%x\n"),productID);
    }
    else {
        _tprintf(_T("PcCardGetManufacturerData failed\n"));
    }

    /* check cis */
    if(PcCardGetVersionInfo(AttributeBase,&versionMajor,&versionMinor,&manStr,
                    &productStr,&infoStr1,&infoStr2)) {
         _tprintf(_T("manfStr = %s\n"),manStr);
         _tprintf(_T("productStr = %s\n"),productStr);
         _tprintf(_T("infoStr1 = %s\n"),infoStr1);
         _tprintf(_T("infoStr2 = %s\n"),infoStr2);
        _tprintf(_T("versionMajor = 0x%x\n"),versionMajor);
        _tprintf(_T("versionMinor = 0x%x\n"),versionMinor);
    }
    else {
        _tprintf(_T("PcCardGetVersionInfo failed\n"));
    }

    PcCardGetConfigBase(AttributeBase, &ConfigBase);
    _tprintf(_T("ConfigBase = 0x%x\n"), ConfigBase);
  
    PcCardEnableDefaultConfig(AttributeBase);

    _tprintf(_TEXT("Calling CW10New @%x\n"),CW10New);
    Dev = CW10New(&PortBase,&Irq,&AttributeBase,&portType,stationName,ssid);
    _tprintf(_TEXT("Got @%x\n"),Dev);

    if (Dev != NULL) {
        /* Init condition */
        Condition_Init(&Dev->IntrPoint);

        /* Install ISR and enable interrupt pin */
        _tprintf(_TEXT("Installing ISR CW10Isr @%x\n"),Dev->v->Isr);
        r = AddDevice(Dev,(PTR)Dev->v->Isr,0,Irq,0);
        _tprintf(_TEXT("Got %x\n"),r);

#define CW10_INTR_PIN (1<<22) /* active low */
        Gpio->Direction &= ~CW10_INTR_PIN; /* it's an input */

        Gpio->DetectRaising &= ~CW10_INTR_PIN;
        Gpio->DetectFalling |= CW10_INTR_PIN;
        Gpio->DetectStatus   = CW10_INTR_PIN; /* ack */

        /* Initialize it */
        _tprintf(_TEXT("Calling CW10Reset @%x\n"),CW10New);
        r = Dev->v->Initialize(Dev);
        _tprintf(_TEXT("Got %x\n"),r);

        /* Let it work for a while */
        Int32ToInt64(Idle,TIME_RELATIVE(TIME_SECONDS(1)));
        for (i = 0; i < 30; ) {

            r = Condition_Wait(&Dev->IntrPoint, NULL, &Idle);

            if (r != E_TIMED_OUT) {
                /* Handle interrupt */
                r = Dev->v->HandleInterrupt(Dev);
#if 0
                /* Print status, just for fun */
                r = Dev->v->Ioctl(Dev,1,NULL);
#endif
            } else {
                _tprintf(_T("Idle.....\n"));
                CW10GetLinkStatus(Dev, linkStat_p);
                _tprintf(_T("Linkstatus = %d\n"),*linkStat_p);
                i++;
            }
        }

        /* Silence it */
        Gpio->DetectRaising &= ~CW10_INTR_PIN;
        Gpio->DetectStatus   = CW10_INTR_PIN; /* ack */
        _tprintf(_TEXT("Removing ISR CW10Isr @%x\n"),Dev->v->Isr);
        r = RemoveDevice(Dev,Irq);
        _tprintf(_TEXT("Got %x\n"),r);
        
        /* Let it die */
        Dev->v->Release(Dev);
    }
 
}

#define STUB(x,n) \
PTR x(UINT32 arg) \
{ \
  _tprintf(_TEXT("%s was called with arg0=%x\n"),n,arg);\
  return NULL; \
}

STUB(ether_output,"ether_output")
STUB(NetLock,"NetLock")
STUB(NetUnlock,"NetUnlock")
STUB(if_attach,"if_attach")


/*=============================================================*/
/*=============================================================*/
/*=============================================================*/
/*=============================================================*/
/*=============================================================*/
#define MSIZE 128
#define MCLBYTES 2048
#define MLEN (MSIZE - sizeof(struct m_hdr))   /* normal data len */
#define MHLEN (MLEN - sizeof(struct pkthdr))  /* data len w/pkthdr */
#define MINCLSIZE (MHLEN + MLEN)   /* smallest amount to put in cluster */

#define mtod(m,t) ((t)((m)->m_data))

/* header at beginning of each mbuf: */
struct m_hdr {
    struct mbuf *mh_next;     /* next buffer in chain */
    struct mbuf *mh_nextpkt;  /* next chain in queue/record */
    INT mh_len;               /* amount of data in this mbuf (in bytes) */
    PBYTE mh_data;            /* location of data */
    UINT16 mh_type;           /* type of data in this mbuf */
    UINT16 mh_flags;          /* flags; see below */
};

/* record/packet header in first mbuf of chain; valid if M_PKTHDR set */
struct pkthdr {
    INT len;              /* total packet length */
    struct ifnet *rcvif;  /* rcv interface */
};

/* description of external storage mapped into mbuf, valid if M_EXT set */
struct m_ext {
    PBYTE ext_buf;       /* start of buffer */
    void (*ext_free)(PBYTE, UINT);  /* free routine if not the usual */
    UINT ext_size;       /* size of buffer, for ext_free */
};

struct mbuf {
    struct m_hdr m_hdr;
    union {
        struct {
            struct pkthdr MH_pkthdr;     /* M_PKTHDR set */
            union {
                struct m_ext MH_ext;     /* M_EXT set */
                char MH_databuf[MHLEN];
            } MH_dat;
        } MH;
        char M_databuf[MLEN];            /* !M_PKTHDR, !M_EXT */
    } M_dat;
};
#define m_next m_hdr.mh_next
#define m_len m_hdr.mh_len
#define m_data m_hdr.mh_data
#define m_type m_hdr.mh_type
#define m_flags m_hdr.mh_flags
#define m_nextpkt m_hdr.mh_nextpkt
#define m_act m_nextpkt
#define m_pkthdr M_dat.MH.MH_pkthdr
#define m_ext M_dat.MH.MH_dat.MH_ext
#define m_pktdat M_dat.MH.MH_dat.MH_databuf
#define m_dat M_dat.M_databuf

/* mbuf flags */
#define M_EXT    0x0001  /* has associated external storage */
#define M_PKTHDR 0x0002  /* start of record */

/* mbuf pkthdr flags, also in m_flags */
#define M_BCAST  0x0100  /* send/received as link-level broadcast */
#define M_MCAST  0x0200  /* send/received as link-level multicast */

/* flags copied when copying m_pkthdr */
#define M_COPYFLAGS (M_PKTHDR|M_EOR|M_BCAST|M_MCAST)

/*
 * Mbuf cluster macros.
 * MCLALLOC(caddr_t p, INT how) allocates an mbuf cluster.
 * MCLGET adds such clusters to a normal mbuf;
 * the flag M_EXT is set upon success.
 * MCLFREE releases a reference to a cluster allocated by MCLALLOC,
 * freeing the cluster if the reference count has reached 0.
 *
 * Normal mbuf clusters are normally treated as character arrays
 * after allocation, but use the first word of the buffer as a free list
 * pointer while on the free list.
 */
union mcluster {
    union mcluster *mcl_next;
    char mcl_buf[MCLBYTES];
};


struct mbuf * RTLCALLTYPE m_get(INT how, INT type)
{
    struct mbuf *m;

    m = malloc(sizeof(struct mbuf));
    if (m) {
        (m)->m_type = (UINT16)(type);
        (m)->m_next = (struct mbuf *)NULL;
        (m)->m_nextpkt = (struct mbuf *)NULL;
        (m)->m_data = (PTR) (m)->m_dat;
        (m)->m_flags = 0;
    }
    return (m);
}

struct mbuf * RTLCALLTYPE m_gethdr(INT how, INT type)
{
    struct mbuf *m;

    m = malloc(sizeof(struct mbuf));
    if (m) {
        (m)->m_type = (UINT16)(type);
        (m)->m_next = (struct mbuf *)NULL;
        (m)->m_nextpkt = (struct mbuf *)NULL;
        (m)->m_data = (PTR) (m)->m_pktdat;
        (m)->m_flags = M_PKTHDR;
    }
    return (m);
}
struct mbuf * RTLCALLTYPE m_clget(struct mbuf *m, INT how)
{
    (m)->m_ext.ext_buf = malloc(MCLBYTES);

    if ((m)->m_ext.ext_buf != NULL) {
        (m)->m_data = (PTR) (m)->m_ext.ext_buf;
        (m)->m_flags |= M_EXT;
        (m)->m_ext.ext_size = MCLBYTES;
    }

    return (m);
}

void RTLCALLTYPE m_freem(struct mbuf *m)
{
    struct mbuf *nn;

    if (m == NULL)
        return;
    do {
        if ((m)->m_flags & M_EXT) {
            free((m)->m_ext.ext_buf);
        }
        (nn) = (m)->m_next;
        free(m);
        m = nn;
    } while (m);
}

/*==========================================*/
/*==========================================*/
/*==========================================*/
/*==========================================*/
/*==========================================*/
struct ether_header {
    UINT8 ether_dhost[6];
    UINT8 ether_shost[6];
    UINT16 ether_type;
};

UINT32 nBroadcasts = 0;

void RTLCALLTYPE
ether_input(struct ifnet *ifp, struct ether_header *eh, struct mbuf *m)
{
    struct _c {
        UINT32 d03;
        UINT16 d45;
        UINT16 s01;
        UINT32 s25;
        UINT16 t;
    } *p = (struct _c *)eh;
    
    if ((p->d03 == 0xffffffff) &&
        (p->d45 == 0xffff)) {
        nBroadcasts++;
    } else {
        printf("[B%d] %08x%04x %04x%08x %04x\n",
               nBroadcasts,
               p-> d03,
               p-> d45,
               p-> s01,
               p-> s25,
               p-> t);
    }

    m_freem(m);
}
