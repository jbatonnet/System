/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* --------------------------------------------------------------------------
 *
 * Module:
 *
 *    compat.h
 *
 * Purpose:
 *
 *    NT Compatibility defines.
 *
 * Author:
 *    A. Forin (sandrof)
 *
 * --------------------------------------------------------------------------
 */
/*
 * Actually, after cleanup this file just contains two abstractions
 * present in NT and not provided/exported in MMOSA.
 *
 * The first is the interlocked queue abstraction. Should probably be
 * part of the RTL in MMOSA as well, but alas everyone has hir own
 * personal idea of what queues are. So here goes yet-another-one...
 *
 * The IoQueue is a variation over the basic queue, with sorting and
 * callbacks for starting I/O operations on disks&co.
 *
 * The second one is the I/O Request Packet (IRP), e.g. what we put in
 * that queue.  Eventually this should become a common, uniform facility
 * provided in e.g. drivers.cpp or some other (static) link library.
 * For now, we define just the bare minimum, and implement the code inline.
 */

/*
 * Macros
 */
#define IN
#define OUT

/* #define offsetof(s,m)  ((ADDRESS)&(((s *)0)->m)) */

#ifndef CONTAINING_RECORD
#define CONTAINING_RECORD(_a_,_t_,_f_) \
        ((_t_ *)((ADDRESS)(_a_) - offsetof(_t_,_f_)))
#endif

//
//      Yet another redefinition of a link list entry struct. This one is 
//      100% semantically compatible yet syntactically different to confuse
//      the masses.
//

typedef struct _LINK_ENTRY  *   PLINK_ENTRY;

typedef struct _LINK_ENTRY
{
        PLINK_ENTRY     pNextLink;
        PLINK_ENTRY     pPrevLink;

} LINK_ENTRY;

/*
 * Interlocked Lists
 */

#define InitializeListHead(_head_) \
        (_head_)->pNextLink = (_head_)->pPrevLink = _head_

#define ListIsEmpty(_head_) \
        ((_head_)->pNextLink == (_head_))

#define ListFirst(_head_) \
        ((_head_)->pNextLink)

#define InterlockedInsertTailList(_head_,_entry_,_mutex_) \
        { \
              (_entry_)->pNextLink = _head_; \
              Mutex_Lock(_mutex_); \
              (_entry_)->pPrevLink = (_head_)->pPrevLink; \
              (_head_)->pPrevLink->pNextLink = _entry_; \
              (_head_)->pPrevLink = _entry_; \
              Mutex_Unlock(_mutex_); \
        }

#define InterlockedInsertHeadList(_head_,_entry_,_mutex_) \
        { \
              (_entry_)->pPrevLinkious = _head_; \
              Mutex_Lock(_mutex_); \
              (_entry_)->pNextLink = (_head_)->pNextLink; \
              (_head_)->pNextLink->pPrevLink = _entry_; \
              (_head_)->pNextLink = _entry_; \
              Mutex_Unlock(_mutex_); \
        }

#define InterlockedRemoveHeadList(_head_,_entry_ptr_,_mutex_) \
        { \
              PLINK_ENTRY _r_; \
              Mutex_Lock(_mutex_); \
              (_r_) = (_head_)->pNextLink; \
              if ((_r_) != (_head_)) { \
                  (_head_)->pNextLink = (_r_)->pNextLink; \
                  (_r_)->pNextLink->pPrevLink = _head_; \
              } else \
                  _r_ = NULL; \
              Mutex_Unlock(_mutex_); \
              *(_entry_ptr_) = _r_; \
        }


/*
 * Io Queues
 */
typedef struct _IO_QUEUE {
    LINK_ENTRY Link;
    UINT Key;
} IO_QUEUE, *PIO_QUEUE;

typedef SCODE (*IO_QUEUE_WORKER)( PIO_QUEUE pHead, PIO_QUEUE pElement);

EXTERN_C DLL_LINKAGE SCODE IoQueueInitialize(
    PIO_QUEUE pThis);

EXTERN_C DLL_LINKAGE SCODE IoQueueAdd(
    PIO_QUEUE pThis,
    PIO_QUEUE pElement,
    PMUTEX pLock,
    IO_QUEUE_WORKER StartIo);

EXTERN_C DLL_LINKAGE SCODE IoQueuePop(
    PIO_QUEUE pThis,
    PMUTEX pLock,
    IO_QUEUE_WORKER StartIo,
    UINT Key);

/*
 * I/O Request Packets
 */

typedef struct {
    UINT MajorFunction;
#define IRP_MJ_READ 1
#define IRP_MJ_WRITE 2
    union {
        struct {
            PTR         pDevice;
            UINT64      ByteOffset;
            UINT        Length;
        } ReadWrite;
    } Parameters;
} IRP_ARGUMENTS, *PIRP_ARGUMENTS;

typedef struct {
    IO_QUEUE Tail;
    SCODE IoStatus;
    CONDITION Completion;
    PUINT8      pData;
    IRP_ARGUMENTS Args;
} IRP, *PIRP;

#define IrpArguments(_i_) (&(_i_)->Args)
#define IrpCompleted(_i_) Condition_Signal(&(_i_)->Completion)

/*
 * NT has an ErrorLogging facility and we dont.
 * Here are some codes taken from NT.
 */

#define IO_WRN_BAD_FIRMWARE              ((SCODE)0x8004001A)

#define IO_ERR_CONTROLLER_ERROR          ((SCODE)0xC004000B)
#define IO_ERR_RESET                     ((SCODE)0xC0040013)
#define IO_ERR_SEEK_ERROR                ((SCODE)0xC0040006)
#define IO_ERR_DRIVER_ERROR              ((SCODE)0xC0040004)
#define IO_ERR_OVERRUN_ERROR             ((SCODE)0xC0040008)
#define IO_ERR_RETRY_SUCCEEDED           ((SCODE)0x00040001)
#define IO_ERR_TIMEOUT                   ((SCODE)0xC0040009)

