/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _DHCP_H_
#define _DHCP_H_

#define DHCP_SERVER_PORT 67  /* internet standard */
#define DHCP_CLIENT_PORT 68  /* internet standard */

#define DHCP_REXMIT_DEFAULT 4  /* seconds */

/*
 * Structure of a DHCP header.
 * This is followed by a variable length options field.
 */
struct Dhcp {
    UINT8 Op;                /* operation */
    UINT8 HdwrAddrType;      /* hardware address type */
    UINT8 HdwrAddrLen;       /* hardware address length */
    UINT8 Hops;              /* hop count */
    UINT32 XId;              /* transaction id */
    UINT16 Secs;             /* seconds elapsed since boot start */
    UINT16 Flags;            /* flags */
    UINT32 ClntIpAddr;       /* client IP address */
    UINT32 YourIpAddr;       /* "your" IP address */
    UINT32 SrvrIpAddr;       /* (boot) server IP address */
    UINT32 GateIpAddr;       /* gateway IP address */
    UINT8 ClntHdwrAddr[16];  /* client hardware address */
    char SrvrName[64];       /* server host name */
    char File[128];          /* (boot) file name */
};

/*
 * Values for Op field:
 */
#define DHCP_OP_REQUEST 1  /* bootp BOOTREQUEST */
#define DHCP_OP_REPLY 2    /* bootp BOOTREPLY */

/*
 * Values for HdwrAddrType field:
 * (same as for ARP "Hardware Type" as given by "Assigned Numbers" RFC)
 */
#define DHCP_HARDWARE_TYPE_10MB_EITHERNET  1
#define DHCP_HARDWARE_TYPE_ATM             19

/*
 * DHCP Standard Options.
 */
#define DHCP_OPTION_PAD                      0
#define DHCP_OPTION_SUBNET_MASK              1
#define DHCP_OPTION_TIME_OFFSET              2
#define DHCP_OPTION_ROUTER_ADDRESS           3
#define DHCP_OPTION_TIME_SERVERS             4
#define DHCP_OPTION_IEN116_NAME_SERVERS      5
#define DHCP_OPTION_DOMAIN_NAME_SERVERS      6
#define DHCP_OPTION_LOG_SERVERS              7
#define DHCP_OPTION_COOKIE_SERVERS           8
#define DHCP_OPTION_LPR_SERVERS              9
#define DHCP_OPTION_IMPRESS_SERVERS          10
#define DHCP_OPTION_RLP_SERVERS              11
#define DHCP_OPTION_HOST_NAME                12
#define DHCP_OPTION_BOOT_FILE_SIZE           13
#define DHCP_OPTION_MERIT_DUMP_FILE          14
#define DHCP_OPTION_DOMAIN_NAME              15
#define DHCP_OPTION_SWAP_SERVER              16
#define DHCP_OPTION_ROOT_DISK                17
#define DHCP_OPTION_EXTENSIONS_PATH          18

/*
 * IP Layer Parameters - per host
 */
#define DHCP_OPTION_BE_A_ROUTER              19
#define DHCP_OPTION_NON_LOCAL_SOURCE_ROUTING 20
#define DHCP_OPTION_POLICY_FILTER_FOR_NLSR   21
#define DHCP_OPTION_MAX_REASSEMBLY_SIZE      22
#define DHCP_OPTION_DEFAULT_TTL              23
#define DHCP_OPTION_PMTU_AGING_TIMEOUT       24
#define DHCP_OPTION_PMTU_PLATEAU_TABLE       25

/*
 * IP Layer Parameters - per interface.
 */
#define DHCP_OPTION_MTU                      26
#define DHCP_OPTION_ALL_SUBNETS_MTU          27
#define DHCP_OPTION_BROADCAST_ADDRESS        28
#define DHCP_OPTION_PERFORM_MASK_DISCOVERY   29
#define DHCP_OPTION_BE_A_MASK_SUPPLIER       30
#define DHCP_OPTION_PERFORM_ROUTER_DISCOVERY 31
#define DHCP_OPTION_ROUTER_SOLICITATION_ADDR 32
#define DHCP_OPTION_STATIC_ROUTES            33
#define DHCP_OPTION_TRAILERS                 34
#define DHCP_OPTION_ARP_CACHE_TIMEOUT        35
#define DHCP_OPTION_ETHERNET_ENCAPSULATION   36

/*
 * TCP Paramters - per host
 */
#define DHCP_OPTION_TTL                      37
#define DHCP_OPTION_KEEP_ALIVE_INTERVAL      38
#define DHCP_OPTION_KEEP_ALIVE_DATA_SIZE     39

/*
 * Application Layer Parameters
 */
#define DHCP_OPTION_NETWORK_INFO_SERVICE_DOM 40
#define DHCP_OPTION_NETWORK_INFO_SERVERS     41
#define DHCP_OPTION_NETWORK_TIME_SERVERS     42

/*
 * Vender Specific Information Option
 */
#define DHCP_OPTION_VENDOR_SPEC_INFO         43

/*
 * NetBIOS Over TCP/IP Name Server Options
 */
#define DHCP_OPTION_NETBIOS_NAME_SERVER      44
#define DHCP_OPTION_NETBIOS_DATAGRAM_SERVER  45
#define DHCP_OPTION_NETBIOS_NODE_TYPE        46
#define DHCP_OPTION_NETBIOS_SCOPE_OPTION     47

/*
 * X Window System Options
 */
#define DHCP_OPTION_XWINDOW_FONT_SERVER      48
#define DHCP_OPTION_XWINDOW_DISPLAY_MANAGER  49

/*
 * DHCP Extensions
 */
#define DHCP_OPTION_REQUESTED_ADDRESS        50
#define DHCP_OPTION_LEASE_TIME               51
#define DHCP_OPTION_OK_TO_OVERLAY            52
#define DHCP_OPTION_MESSAGE_TYPE             53
#define DHCP_OPTION_SERVER_IDENTIFIER        54
#define DHCP_OPTION_PARAMETER_REQUEST_LIST   55
#define DHCP_OPTION_MESSAGE                  56
#define DHCP_OPTION_MESSAGE_LENGTH           57
#define DHCP_OPTION_RENEWAL_TIME             58      /* T1 */
#define DHCP_OPTION_REBIND_TIME              59      /* T2 */
#define DHCP_OPTION_CLIENT_CLASS_INFO        60
#define DHCP_OPTION_CLIENT_ID                61

/*
 * More Application Layer Parameters
 */
#define DHCP_OPTION_NIS_PLUS_DOM             64
#define DHCP_OPTION_NIS_PLUS                 65

/*
 * Overlayed Header Field Replacements
 */
#define DHCP_OPTION_TFTP_SERVER_NAME         66
#define DHCP_OPTION_TFTP_BOOTFILE_NAME       67

/*
 * Even More Application Layer Parameters
 */
#define DHCP_OPTION_MOBILE_IP_HOME_AGENTS    68
#define DHCP_OPTION_SMTP_SERVERS             69
#define DHCP_OPTION_POP_SERVERS              70
#define DHCP_OPTION_NNTP_SERVERS             71
#define DHCP_OPTION_WWW_SERVERS              72
#define DHCP_OPTION_FINGER_SERVERS           73
#define DHCP_OPTION_IRC_SERVERS              74
#define DHCP_OPTION_STREETTALK_SERVERS       75
#define DHCP_OPTION_STREETTALK_DIR_SERVERS   76

/*
 * Option codes from 77 to 127 are reserved through the
 * Internet Assigned Numbers Authority (iana@isi.edu).
 *
 * Option codes from 128 to 254 are for site-specific options.
 */

#define DHCP_OPTION_END                      255

/*
 * Values for "Message Type" option:
 */
#define DHCP_TYPE_DISCOVER 1
#define DHCP_TYPE_OFFER    2
#define DHCP_TYPE_REQUEST  3
#define DHCP_TYPE_DECLINE  4
#define DHCP_TYPE_ACK      5
#define DHCP_TYPE_NAK      6
#define DHCP_TYPE_RELEASE  7
#define DHCP_TYPE_INFORM   8

#endif /* _DHCP_H_ */
