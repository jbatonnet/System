/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Machine-dependent functions and definitions 
 * which are not otherwise defined in fred.h
 *
 */

//#define __MEMFUNC_ARE_INLINED 0
#define __NEED_M_THDINFO 0

#define MachineSpecificInfo(a,b) (E_NOT_IMPLEMENTED)

#define CurrentProcessorKind() (PROCESSOR_KIND_PPC)
extern UINT CurrentProcessorOEM(void);

extern void PpcMachineIdle(ADDRESS Arg);
#define MACHINE_IDLE(_arg_) PpcMachineIdle((ADDRESS)&(_arg_))

#define __NEED_FLUSH_CACHE 1
extern void FlushCache(ADDRESS BaseAddress, ADDR_SIZE nBytes);

/* Munging with interrupt enables from C
 */

extern UINT32 IntOff(void);
extern UINT32 IntOn(void);
extern void SetPsr(UINT32 PsrValue);

#define TURN_INTERRUPTS_OFF(_s_) _s_ = IntOff()
#define RESTORE_INTERRUPTS(_s_)  SetPsr(_s_)
#define ENABLE_INTERRUPTS() ((void) IntOn())
#define DISABLE_INTERRUPTS() ((void) IntOff())

#define __SUPPORTS_COB_NAMESPACE 1

#define DEFAULT_STACK_SIZE (8*1024)

extern UINT64 CurrentProcessorSpeed(void);

/* interrupt path: isr->scheduler */
extern PCXTINFO _Reschedule(PCXTINFO);

void SchedulingInterrupt(void); /* ditto */
UINT HWSaveThreadContext(PCXTINFO pCxt); /* ditto */

/* OPTIMIZATION SECTION
 */
