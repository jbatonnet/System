/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __irq_h_
#define __irq_h_

/*
 * Prototypes for IRQ dispatching code (in assembly)
 */
extern void IrqCreate(void);

struct _TheHWPic
{
    volatile UINT32  Config0;        /* 16 bit register */
    volatile BYTE    Config1;
    BYTE     pad0[3];
    volatile UINT32  Clear;          /* 16 bit register */
    volatile UINT32  IrqEnable;      /* 16 bit register */
    volatile UINT32  FiqEnable;      /* 16 bit register */
    volatile UINT32  IrqStatus;      /* 16 bit register */
    volatile UINT32  FiqStatus;      /* 16 bit register */
    volatile UINT32  Poll;           /* 16 bit register */
};
#define TheHWPic ((struct _TheHWPic *)0xFFFFA800)

#endif /* __irq_h_*/
