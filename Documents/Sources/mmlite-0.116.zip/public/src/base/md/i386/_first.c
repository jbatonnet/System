/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <mmmacros.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <fred.h>
#include <pc/_pic.h>

PINAMESPACE OpenFloppyRoot(void);
PINAMESPACE InitMemoryFileSystem(void);
PINAMESPACE InitHostFileSystem(_TCHAR *LinkName);
SCODE InitDebugConsole(void);
void InitFrameBuffer(void);
EXTERN_C INT MODENTRY CrtInit(INT Op);
const char *BootCmdLine(void);

void RunFirstApp(const _TCHAR *Args);

void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    SCODE sc;
    PINAMESPACE pRoot;
    const _TCHAR *Args;

    UnusedParameter(arg);

#ifdef SIM
    pRoot = InitHostFileSystem(NULL);
#else
    pRoot = InitMemoryFileSystem();
#endif
    /* pRoot = OpenFloppyRoot(); */
    if (pRoot == NULL) {
            printf("FirstThread: Init File System failed\n");
    } else {
        SetImageNameSpace(pRoot);
        /* SetImageNameSpace takes ref */
        pRoot->v->Release(pRoot);
    }

#ifdef SIM
    InitFrameBuffer();
#endif

    sc = InitDebugConsole();
    if (FAILED(sc)) {
        printf("Failed to create debug console (sc = x%x)\n", sc);
        goto Out;
    }

	if (CrtInit(DLL_PROCESS_ATTACH) != TRUE) {
		printf("CrtInit failed (C++ static constructors)\n");
		goto Out;
	}

#ifdef _UNICODE
    Args = _strtow(BootCmdLine());
    if (!Args) {
        printf("Could not convert args to unicode (malloc)\n");
        goto Out;
    }
#else
    Args = BootCmdLine();
#endif

    DBG(("LAUNCHING CPU1\n"));
    StartCpu(1);
    DBG(("LAUNCHED!\n"));

    FirstApp(Args);

#ifdef _UNICODE
    free((void *) Args);
#endif

 Out:
    BaseDelete();
}
