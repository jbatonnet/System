/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <base/cons.h>
#include <base/loader.h>
#include <tchar.h>
#include <fred.h>

#define __SECURE_FS 0

extern PIBASERTL pTheBaseRtl;

#if __SECURE_FS
static PINAMESPACE ImageNameSpace = NULL;
#endif

PINAMESPACE GetImageNameSpace(void)
{
#if __SECURE_FS
    /* This forbids changing the filesystem where code comes from */
    return ImageNameSpace;
#else
    SCODE r;
    PIUNKNOWN pUnk;
    PINAMESPACE pNs = CurrentNameSpace();

    r = pNs->v->Bind(pNs,
                     _T("fs"),
                     0,
                     &pUnk);
    if (FAILED(r))
        return NULL;

    /* Ok, but is it a namespace
     */
    r = pUnk->v->QueryInterface(pUnk,
                                &IID_INameSpace,
                                (void **) &pNs);

    (void) pUnk->v->Release(pUnk);

    if (FAILED(r))
        return NULL;

    /* This one is not supposed to take a ref so lets do this horrible one */
    (void) pNs->v->Release(pNs);
    
    return pNs;
#endif
}

void SetImageNameSpace(PINAMESPACE pINS)
{
    CurrentNameSpace()->v->Register(CurrentNameSpace(), _T("fs"),
                                    (PIUNKNOWN) pINS, 0, NULL);
#if __SECURE_FS
    ImageNameSpace = pINS;
#endif
}

/* Should be somewhere else but fornow 
*/
SCODE InitConsole(const _TCHAR *DriverName)
{
    PIUNKNOWN pUnk;
    PINAMESPACE Ns = CurrentNameSpace();
    SCODE sc;

    sc = Ns->v->Bind(Ns,DriverName, 0, &pUnk);
    if (FAILED(sc))
        return sc;

    sc = Ns->v->Register(Ns, _TEXT("stdin"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = Ns->v->Register(Ns, _TEXT("stdout"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = Ns->v->Register(Ns, _TEXT("stderr"), pUnk, 0, NULL);
    if (FAILED(sc))
      goto Error;

 Error:
    /* Let our own reference go
     */
    (void) pUnk->v->Release(pUnk);

    return sc;
}

#if defined(m68k)
/* NO LOADER */
void THREAD_LINKAGE FirstThread(THREAD_ARGUMENT arg)
{
    printf("Hello world!\n");
    printf("No loader, exiting\n");
    BaseDelete();
}
#endif
