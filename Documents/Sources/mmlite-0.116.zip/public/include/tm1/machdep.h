/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Machine-dependent functions and definitions
 * which are not otherwise defined in fred.h
 */

#ifndef _machdep_h_
#define _machdep_h_

#define DCACHELINESIZE           (64)  /* Size in bytes of data-cache line   */

#define __MEMFUNC_ARE_INLINED 0
#define __SUPPORTS_COB_NAMESPACE 1

extern SCODE MachineSpecificInfo(MACHINE_INFO_FLAVOR Kind, void *pInfo);
#define CurrentProcessorKind() (PROCESSOR_KIND_TRIMEDIA)
#define CurrentProcessorOEM() (0)
extern UINT64 CurrentProcessorSpeed(void);

#define DEFAULT_STACK_SIZE (2*1024)

/* Define access to TM-1 custom ops from C.
 */
#define MUX(a,b,c)     (izero((a),(b)) | inonzero((a),(c)))
custom_op UINT readpcsw(void);
custom_op void writepcsw(UINT val, UINT mask);
custom_op INT  carry(UINT a, UINT b);
custom_op INT  borrow(UINT a, UINT b);
custom_op UINT umulm(UINT a, UINT b);
custom_op UINT iabs(INT a);
custom_op INT  izero(INT a, INT b);
custom_op INT  inonzero(INT a, INT b);
custom_op void iclr(void);
#if oldway
custom_op void dcb()(ADDRESS a);
#define DCB(_a_) dcb(0)(_a_)
#else
custom_op void copyback(void *a, int n);
#define DCB(_a_) copyback((void *)(_a_),1)
#endif

/* Munging with interrupt enables from C
 */

#define PCSW_IEN 0x400
#define TURN_INTERRUPTS_OFF(_s_) { _s_ = readpcsw(); writepcsw(0, PCSW_IEN); }
#define RESTORE_INTERRUPTS(_s_)  writepcsw(_s_,PCSW_IEN);
#define ENABLE_INTERRUPTS() writepcsw(PCSW_IEN,PCSW_IEN);

#endif  /*   _machdep_h_ */
