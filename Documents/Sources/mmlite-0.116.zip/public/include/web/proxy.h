/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Object that represents remote object -jvh */

#include <web/typeinfo.h>
#include <util/list-double2.h>
#include <wsif.h>

#include <base/cobdesc.h>       /* for CUnknown */

#if defined(_MSC_VER) && !defined(arm)
/* Only 386 VC++ */
#else
#define __fastcall
#define __stdcall
#endif

/* Set when pContext was entirely allocated in a single call 
 * and must be freed when the proxy is released:
 */
#define CONT_FLAGS_SHOULD_FREE_CONTEXT 0x8000

typedef struct _PROXY {
    struct CUnknown super;
    UINT Flags;

    PIUNKNOWN RealObj;             /* The undlerying object. LOCAL only. */

    CPXMLNAMESPACE NameSpace; /* XXX should be in interface */
    Pbar pRsrv;
    _TCHAR *ScoreName;
} *PPROXY;

typedef struct _SOAPPROXY {
    struct _PROXY super;

    PIHTTPCONNECTOR pConnector;
    PWSCONTEXT pContext;
} *PSOAPPROXY;

#define pPX(_o_) ((PPROXY) (_o_))
#define pSPX(_o_) ((PSOAPPROXY) (_o_))

UINT ProxyCodeInit(PUINT8 Where, CPMETHOD_DESCR pDescr,
        INT32 (__fastcall *Interpreter)(UINT index, ADDRESS *pArgs));
