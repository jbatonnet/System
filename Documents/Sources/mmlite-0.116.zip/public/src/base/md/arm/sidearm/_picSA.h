/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __irq_h_
#define __irq_h_

/*
 * Prototypes for IRQ dispatching code (in assembly)
 */
extern void IrqCreate(void);

struct _TheHWPic
{
    volatile UINT32  IrqPending;
    volatile UINT32  Mask;
    volatile UINT32  Level;
    volatile UINT32  Control;
    volatile UINT32  FiqPending;
             UINT32  Reserved[3];
    volatile UINT32  Pending;
};
#define TheHWPic ((struct _TheHWPic *)0x90050000)

#endif /* __irq_h_*/
