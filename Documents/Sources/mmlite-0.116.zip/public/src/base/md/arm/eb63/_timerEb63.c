/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Time might be kept using both an RTC and the PIT (timer 0).
 * The former gives an RTCDelta interrupt granularity, and
 * is the sole responsible for the drift [temperature & co.].
 * The latter gives fine grain resolution, and is used for
 * scheduling purposes.
 *
 * The basic idea is that the current time is given by
 *
 *      Now = TOY + ReloadDelta + (Ticks - PIT)
 *
 * where TOY is the accumulated count of the RTC interrupts,
 * ReloadDelta is the accumulated count of PIT reloads (one
 * reload per rescheduling), Ticks is the value the PIT was
 * last reloaded with, and PIT is the current reading of
 * the PIT.
 *
 * An important but subtle point is how the subexpression
 * in parens is evaluated.  PIT is a 16 bit counter, which
 * counts down from the (Ticks) value it is loaded with.
 * When it reaches zero it keeps decrementing from xFFFF.
 * (We use the Intel 8254 in Mode0).
 * By using signed 16 bits arithmetic we are guaranteed that
 * the (unsigned!) result of the subtraction is precisely
 * the number of ticks elapsed.  Assuming only that we did
 * not ignore the PIT interrupt for e.g. 54 milliseconds,
 * which is a safe assumption (else this whole OS is garbage..).
 *
 *
 * Formal analysis was based on the following pseudo code.
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (Ticks - PIT)
 *
 * PIT.Set(t) ::
 *      ReloadDelta += (Ticks - PIT)
 *      PIT = t
 *      Ticks = t
 *
 * PIT.Interrupt() :: <nothing needed>
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, 16msec
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * All functions are assumed atomic interrupt-wise.
 *
 * Notice that the above proof still holds if we remove
 * the RTC chip: just cancel RTC.Interrupt() and wire TOY==0.
 * Drift analysis (in PIT.Set()) becomes important, e.g. the
 * time between the first and second statement.
 *
 * UPDATE UPDATE UPDATE --for Atmel board-- UPDATE UPDATE UPDATE
 *
 * Here the PIT counts up, not down. One way to work around this
 * is to set COUNTER at MAX-desired_delta and take the interrupt
 * at overflow. At interrupt time COUNTER measures our latency,
 * so we can account for it.
 * One useful idea here is to use ARM's "swap" instruction, which
 * atomically does a read+write operation, e.g. on the COUNTER.
 * Darn, the counter is infact read-only. So much for that one.
 * There is no way to load anything but zero in that COUNTER, sorry.
 *
 * Another way is to load register C with COUNTER+desired_delta,
 * and use the match as interrupt trigger. At interrupt time the
 * difference COUNTER-C is the latency. COUNTER would be free-running
 * in this solution. There is an issue here as to how many cycles
 * does it take to (a) read COUNTER (b) add DELTA (c) write C.
 * Unless this is (a) deterministic and (b) known with high accuracy
 * we'll get strong clock drift.
 *
 * Yet another way is to load C with desired-delta, and reset+start
 * the counter. Interrupt again is at match with C.  One advantage is
 * that C holds Ticks directly on-chip, reducing memory load/stores.
 * The same drift problem as above applies here, the sequence is
 * (a) read COUNTER (b) reset-restart it.
 *
 * In both these last two cases the counter could be match-reset.
 * The problem with that is that we sometimes load very small delta
 * values, and it might be a while after the interrupt triggers
 * before we reload the timer. [This is scheduler-dependent]
 * So the counter might reset multiple times...
 *
 * The first (non-)solution would be the one that works best without
 * the RTC, assuming the swap trick.  The third one is the one that
 * minimizes drift uncertainty, and therefore the chosen one.
 * The equations for this solution are
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (PIT - Ticks)
 *
 * PIT.Set(t) ::
 *      PIT.C = t
 *      PIT_WAS = PIT
 *      PIT.Restart()
 *      ReloadDelta += (PIT_WAS - Ticks) + <drift>
 *      Ticks = 0
 *
 * PIT.Interrupt() :: <nothing needed [except calling PIT.Set()]>
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, ~2 seconds
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 */

#include <mmlite.h>
#include <diagnostics.h>
#include <fred.h>
#include <mmhal.h>
#include "at91m63200.h"
#include "eb63.h"

/* This board has a 25MHz crystal that provides the system clock.
 * Counters are fed that clock, divided by one of 2,8,32,128,1024.
 * Counter registers are 16 bit (yuch).
 *
 * Therefore our choices are:
 * DIVISOR   PERIOD      MAX_DELTA
 *  2           80 ns       5.242880 ms
 *  8          320 ns      20.971520 ms
 *  32        1280 ns      83.886080 ms
 *  128       5120 ns     335.544320 ms
 *  1024     40960 ns    2684.354560 ms
 *
 * Our internal unit of time is 100 ns, we must convert back and
 * forth against whatever period we chose here. All periods are
 * powers of 2 off the basic one, which can easily be accomodated
 * by quick shift operations.  So we are down to the basic ratio
 * 100 ns / 80 ns e.g. 5/4 (and its reciprocal 4/5).  Precision
 * is therefore not helped by one choice or the other.
 * All considered, 32 seems like the best tradeoff: about a usec
 * granularity is sufficient in all cases, and 80 msec should cover
 * just about all cases [including the default timesharing slice].
 * 
 * As for the RTC, since we have so many timers we can expend one.
 * It is desireable to maximize the distance between RTC interrupts,
 * to minimize overhead.  The RTC interval also must be chosen to
 * avoid roundoff errors, as this is the one that controls drift.
 * A round 50,000 at /1024 would give a 2.048 sec, for instance.
 * Given the period value at /1024, the value must be a multiple
 * of 5 to avoid roundoffs. The maximum such value happens to be
 * 65,535 (0xffff) in 16 bits.  This yields an interval of
 * 2.684313600 sec, or 26843136 of our TIME units.
 * See ClockIsr() for how this is used.
 *
 * NB: The code in here is more general than that, but thats the idea.
 */

volatile struct {
    TIME Toy;                   /* Time-of-year (gross estimate/epoch)      */

                                /* NB: These two are PERIODs, not TIMEs     */
    UINT32 ReloadDelta;         /* Delta from TOY due to multiple PIT intrs */
    UINT16 Ticks;               /* Value of the Counter at RTC interrupt    */
    UINT16 Overflows;           /* Number of times PIT overflowed           */
    UINT32 IsrStatus;           /* PIT status in ISR [for PIT overflow]     */

} SystemTimer = {
    Int64Initializer(0, 0),
    };

/* The board can use an EXT clock source. We built a daugtherboard with one
 * such external crystal, with the usual divisor and a jumper select.
 * The crystal is 9.8304 MHz, available clocks are /1, /2, /4, /8, /16.
 * Note that the reference clock on P20/TIOA0 is still 25/16 MHz,
 * therefore its impossible to correctly autodetect all selections.
 * Besides, its also impossible to detect if the main clock selector
 * is in the EXT position.  Urgh.
 */
#define EXT_CLOCK 0

/* AT 25 MHz:
 * The timer is a 16bit counter running at 25/32=0.78125 MHz,
 * max interval is therefore 83.88608 ms.
 * Make sure it doesnt wrap around unnoticed.
 * BUGBUG We could do better than this, by looking at the overflow bit.
 */
#define RtcTicker      EbTimerConfig[0].RtcClockTick
#define OstMaxInterval EbTimerConfig[0].PitMaxInterval
#define OstShifter     EbTimerConfig[0].PitShiftValue
#define OstScaler      EbTimerConfig[0].PitClockScaler

TIMER_CONFIG EbTimerConfig[] = {
    /* First entry is the one in use, and the default one
     */
/*0*/
    {/* 25MHz, no divisor */
        /* See above for this RTC constant */
        Int64Initializer(0,26843136),

        Int64Initializer(0, TIME_MILLIS(83)),
        6, /* 64 */
        TCHM_MCKI_32,

        Eb63Crystal
    },
/*1*/
    {/* 25MHz/2 */
        /* No change in RTC programming, hence 2x the above */
        Int64Initializer(0,26843136*2),

        Int64Initializer(0, TIME_MILLIS(83)*2),
        7, /* 128 */
        TCHM_MCKI_32,

        Eb63Crystal/2
    },
/*2*/
    {/* 25MHz/4 */
        /* No change in RTC programming, hence 4x the above */
        Int64Initializer(0,26843136*4),

        /* Speedup the counter, back to #0 in granularity */
        Int64Initializer(0, TIME_MILLIS(83)),
        6, /* 64 */
        TCHM_MCKI_8,

        Eb63Crystal/4
    },
/*3*/
    {/* 25MHz/8 */
        /* No change in RTC programming, hence 8x the above */
        Int64Initializer(0,26843136*8),

        /* Speedup the counter, back to #1 in granularity */
        Int64Initializer(0, TIME_MILLIS(83)*2),
        7, /* 128 */
        TCHM_MCKI_8,

        Eb63Crystal/8
    },
};

const TIMER_CONFIG EbExtConfig[] = {
/*0*/
    {/* 9.8304MHz / 1024 = 9.6 KHz.  65535 / 9.6KHz = 6.8265625 sec */
        Int64Initializer(0,68265625),

        Int64Initializer(0, TIME_MILLIS(52)),
        3, /* /8 */
        TCHM_MCKI_8,

        9830400
    },
/*1*/
    {/* 9.8304MHz / 1024 / 8 = 1.2 KHz.  65535 / 1.2KHz = 54.6125 sec */
        Int64Initializer(0,68265625*8),

        Int64Initializer(0, TIME_MILLIS(52*2)),
        4, /* /8/2 */
        TCHM_MCKI_2,

        9830400/8
    }
};

/*
 * Interrupt handler for the programmable timer (scheduler)
 */
BOOL TimerIsr(TC_CHANNEL *Channel, BOOL *pNotMine)
{
    /* Acknowledge the interrupt
     */
    SystemTimer.IsrStatus |= Channel->Status & TCHI_OVERFLOW;

    /* No need for this, as this is the default */
    /* *pNotMine=FALSE; */

    /* Say its time to reschedule */
    return TRUE;
}


/*
 * Interrupt handler for RTC timer.
 */
BOOL ClockIsr(TC_CHANNEL *Channel, BOOL *pNotMine)
{
    UINT32 x;

    /* Acknowledge the interrupt */
    x = Channel->Status;

    /* Add one tick worth to the time of day */
    SystemTimer.Toy = TimeAdd(SystemTimer.Toy, RtcTicker);

    /* Zero the increment */
    SystemTimer.ReloadDelta = 0;

    /* Take the value of the PIT at this point */
    SystemTimer.Ticks = ThePIT->Counter;

    /* No need for this, as this is the default */
    /* *pNotMine=FALSE; */

    /* Leave the scheduler alone */
    return FALSE;
}

/*
 * The Atmel part has a 32x32->64 bit multiplier
 */
#if defined(__NO_BUILTIN_INT64)
extern INT64 Uint32TimesUint32ToInt64(UINT32 a, UINT32 b);
#else
#define Uint32TimesUint32ToInt64(_a_,_b_) (INT64)(((UINT64)_a_)*((UINT64)_b_))
#endif

/* Worker functions for the two crystals cases
 */
typedef UINT32 (* TO_TICKS)(TIME Delta);

UINT32 TimeToTicks25MHz(TIME Delta)
{
    UINT32 Ticks;

    /* Is it within range ?
     */
    if (!TimeLess(Delta,OstMaxInterval))
        /* Nope, trim */
        return 64844; /* roundup(MAX / 1280) */

    /*
     * To get from TIME-Delta to PERIOD-Ticks @25MHz:
     *
     *  Ticks   =  Delta * 5/64
     *          = (Delta*4 + Delta) >> 6
     *
     * Note that we dont need 64bits here, we just checked.
     * At slower clock speeds just change the 64.
     */
    Ticks = (UINT32) Int64ToInt32(Delta);
    Ticks = (Ticks << 2) + Ticks; /* x5 */
    Ticks = Ticks >> OstShifter;
    return Ticks;
}

UINT32 TimeToTicks9MHz(TIME Delta)
{
    UINT32 Ticks;

    /* Is it within range ?
     */
    if (!TimeLess(Delta,OstMaxInterval))
        /* Nope, trim */
        return 63897; /* roundup(MAX / 1.2288MHz) */

    /*
     * Crystal is 9.8304 MHz, almost 10MHz but not exactly. Sigh.
     *  
     *  Ticks  = Delta * 100000 / 98304 = ....
     *         = Delta + Delta * 2^-6 + Delta * 0xd5555555 * 2^-41
     */
    Ticks = (UINT32) Int64ToInt32(Delta);
    Delta = Uint32TimesUint32ToInt64(0xd5555555,Ticks);
    Delta = Int64RShift(Delta, 41);
    Ticks = Ticks + (Ticks >> 6) + (UINT32) Int64ToInt32(Delta);
    Ticks = Ticks >> OstShifter;
    return Ticks;
}

TO_TICKS TimeToTicks = TimeToTicks25MHz;

typedef TIME (* TO_TIME)(UINT32 Ticks);

TIME TicksToTime25MHz(UINT32 Ticks)
{
    TIME Delta64;

    /* Convert from Ticks to TIME.
     *
     * Time = Ticks * (64/5)
     *      = ((64 * Ticks) * (2**?? / 5)) / 2**??
     */
    Ticks = Ticks << OstShifter; /* fixthisifdivisorchanges */
    Delta64 = Uint32TimesUint32ToInt64(0xcccccccc, Ticks);
    Delta64 = Int64RShift(Delta64, 32+2);
    return Delta64;
}

TIME TicksToTime9MHz(UINT32 Ticks)
{
    TIME Delta64;

    /*
     * Crystal is 9.8304 MHz, almost 10MHz but not exactly. Sigh.
     *  
     *  Time  = Ticks * 98304 / 100000 = ....
     *        = Ticks - Ticks * 2^-6 - Ticks * 0xaefb2aae * 2^-41
     */
    Ticks = Ticks << OstShifter;
    Delta64 = Uint32TimesUint32ToInt64(0xaefb2aae, Ticks);
    Delta64 = Int64RShift(Delta64, 41);
    Ticks = Ticks - (Ticks >> 6) - (UINT32) Int64ToInt32(Delta64);
    Int64FromHighAndLow(Delta64,0,Ticks);
    return Delta64;
}

TO_TIME TicksToTime = TicksToTime25MHz;

/* Arm the timer to trigger in DELTA units of TIME (100ns) from now.
 */
extern UINT32 ReadWrite(PUINT32 ReadAddress,
                        PUINT32 WriteAddress, UINT32 WriteValue);

BOOL SetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    UINT32 PitWas, Ticks;
    UINT16 Delta16;
    UINT IntrState;
    BOOL StateWas;

    Ticks = TimeToTicks(Delta);

    if (Ticks < 2)
        Ticks = 2;              /* sanity minimum */

    assert(Ticks <= 0xffff);

    /*
     * Got the tick count, program the timer now
     */
    TURN_INTERRUPTS_OFF(IntrState);

    /* Set the new match value, save the old
     */
    StateWas = ThePIT->C;
    ThePIT->C = Ticks;
    Ticks = StateWas;

    /* Get&Restart the COUNTER, in a well-known amount of time
     */
    PitWas = ReadWrite((PUINT)&ThePIT->Counter,
                       (PUINT)&ThePIT->Control, TCHC_ENABLE | TCHC_TRIGGER);

    /* Check for overflow, adjust PIT value accordingly
     * NB: Can only overflow if it matches first!
     */
    if (SystemTimer.IsrStatus && (Ticks > PitWas)) {
        PitWas += 0x10000;
        SystemTimer.Overflows++;
    }
    SystemTimer.IsrStatus  = 0;

    /* Account for this reload
     */
    Delta16 = PitWas - SystemTimer.Ticks;
    SystemTimer.ReloadDelta += Delta16; /* BUGBUG add drift if no RTC */
    SystemTimer.Ticks = 0;

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);

    return StateWas;
}

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is max_toy_resolution
 */
TIME GetKernelTime ()
{
    UINT32 Delta;
    TIME Delta64;
    TIME TOY;
    UINT16 Ticks, PIT, Delta16;
    UINT IntrState;

    /* Cache a few values with interrupt protection
     *
     * NB: The value we return is bound to be 'obsolete',
     * not just by the time needed to compute it and return
     * to the point of call but also by unpredictable
     * delays due to device and timer interrupts.
     * Therefore it is not worth over-extending the protection
     * against interrupts inside this function, as it would
     * serve no benefit whatever.  The opposite need,
     * minimizing interrupt latency, is the one that dominates.
     */
    TURN_INTERRUPTS_OFF(IntrState);

    PIT   = ThePIT->Counter;
    Ticks = SystemTimer.Ticks;
    Delta = SystemTimer.ReloadDelta;
    TOY   = SystemTimer.Toy;

    RESTORE_INTERRUPTS(IntrState);

    /* Compute the number of elapsed ticks since the last RTC interrupt.
     */
    Delta16 = PIT - Ticks;
    Delta += Delta16;

    Delta64 = TicksToTime(Delta);

    /* Now put them all together.
     */
    TOY = Int64Add(Delta64, TOY);

    return TOY;
}

/* The board can be jumper-set to run at various clock speeds.
 * This function detects what frequency we are running at, and
 * sets up various pseudo-constants accordingly.
 * Besides the timer, at least one other module (serial line)
 * needs to know this information.
 * BUGBUG Export this in MACHINFO for all device drivers.
 */
extern void DbgPortInit(void);

void ClockDetect(void)
{
    /* The 25MHz signal from the crystal is fed to a divisor
     * and it is the output of this divisor that becomes MCLKI,
     * the CPU's and system's master clock.  A jumper selects
     * which bit of this counter becomes MCLKI.  There are 5
     * positions for this jumper, corresponding to:
     * 25 MHz (counter is bypassed), 25/2 MHz, 25/4 MHz, 25/8 MHz,
     * and an EXTERNAL position whereby MCLKI comes from an
     * outside source [via extra custom hardware].
     */
    /* The signal from the 25 MHz crystal is always present, divided by 16,
     * at the TIOA0 pin.  The idea here is to start two counters
     * concurrently, one fed by the (25/16)MHz and the other by MCLKI.
     * Comparing the two gives the true speed we are running at.
     * BUGBUG I dont think this part can be overclocked.
     */
    UINT32 c, s, i;
#define T0 (&Tc0->Channel0)
#define T1 (&Tc0->Channel1)

    /* Enable the 25/16MHz external signal on pin PB20/TIOA0 as XC1 */
    PioB->Disable = PIOB_TIOA0;
    PioB->OutDisable = PIOB_TIOA0;
    PioB->FilterDisable = PIOB_TIOA0;

    T0->Mode = TCHM_MCKI_2 | TCHM_LDBSTOP | TCHM_AA_FALL | TCHM_AB_FALL;
    T0->IntrDisable = ~0;
    T0->A =
    T0->B = 
    T0->C = 0;
    T0->Control = TCHC_ENABLE;
    s = T0->Status;

#if 0
    /* This one doesnt work and methinks it should */
    /* It would be a heck of a lot better if we could get a better ratio
     * by free-running the two clocks in parallel 
     */
    Tc0->BlockMode = TCBM_1_TIOA0; /* xc1 is TIOA0 */

    T1->Mode = TCHM_WAVE | TCHM_XC1;
    T1->IntrDisable = ~0;
    T1->A =
    T1->B =
    T1->C = 0;
    T1->Control = TCHC_ENABLE;
    s = T1->Status;
#endif

    c = 0;
 Again:
    /* Start all counters */
    Tc0->BlockControl = TCBC_SYNCRHO;

    /* Wait a minimum */
    Delay(5);

    /* Dont loop forever */
    for (i = 0; i < 0x10000; i++) {
        s = T0->Status;/*  a destructive read */
        if (s & TCHI_B_LOAD) break;
    }
    DBGME(1,printf("%s %d %d [%d %x %x]\n",
                   (s & TCHI_B_LOAD) ? "YES!" : "nope",
                   T0->A, T0->B, T0->Counter, s, i));

    /* See how much slower the external clock is */
    s = T0->B - T0->A;

    /* Check we gotsome */
    if (i >= 0x10000) {
        if (++c < 4)
            goto Again;
        /* Ouch. Hope its the external and is configed properly */
        s = 0;
    }
    T0->Control = TCHC_DISABLE;

    switch (s) {
    case 4:
        /* Running at Crystal/2 MHz, config #1 */
        s = 1; break;
#if EXT_CLOCK
    case 3:
        /* 9.8304 MHz */
        TimeToTicks = TimeToTicks9MHz;
        TicksToTime = TicksToTime9MHz;
        EbTimerConfig[0] = EbExtConfig[0];
        DbgPortInit();
        return;
#endif
    case 2:
#if EXT_CLOCK
    /* 9.8304/8 ~= 1Mhz */

    /* Fix the RAM settings
     */
    TheEbi->ChipSelect[SRAM_CHIP_SELECT] = /* RAM */
         0x02000000 | EBICS_DBW_16 | EBICS_PS_16M |
             EBICS_TDF(0) | EBICS_BAT_W | EBICS_CSEN;

    TheEbi->MemoryControl = EBIMC_DRP_EARLY | EBIMC_ALE_CS4_6;

    /* Fix the LCD
     */
    TheEbi->ChipSelect[2] = /* LCD */
         0x20000000 | EBICS_DBW8 | EBICS_PS_1M| EBICS_BAT_W | EBICS_CSEN;

    /* Fix the FLASH
     */
    TheEbi->ChipSelect[FLASH_CHIP_SELECT] = /* FLASH */
         0x01000000 | EBICS_DBW_16 | EBICS_PS_16M | EBICS_BAT_W | EBICS_CSEN;

        TimeToTicks = TimeToTicks9MHz;
        TicksToTime = TicksToTime9MHz;
        EbTimerConfig[0] = EbExtConfig[1];
        DbgPortInit();
        return;
#else
        /* Running at Crystal/4 MHz, config #2 */
        s = 2; break;
#endif
    case 1:
#if EXT_CLOCK
        /* Running at Crystal/8 MHz, config #3 */
        /* Fix the RAM settings, no need for waitstates
         */
        TheEbi->ChipSelect[SRAM_CHIP_SELECT] = /* RAM */
            0x02000000 | EBICS_DBW_16 | EBICS_PS_16M |
                EBICS_TDF(0) | EBICS_BAT_W | EBICS_CSEN;

        TheEbi->MemoryControl = EBIMC_DRP_EARLY | EBIMC_ALE_CS4_6;
#endif
        s = 3; break;
    case 8:
    default:
        /* Running at 25MHz (or ..?). This is the default, nothing to do */
        return;
    }
    EbTimerConfig[0] = EbTimerConfig[s];
    /* Make sure debug serial line is ok */
    DbgPortInit();
}

/* Initialization
 */
extern UINT DelayMultiplier;
extern UINT DelayShifter;
extern UINT DelayOverhead;
extern TIME SleepOverhead;

void EnableTimers( void )
{
    UINT32 x;

    /* Start by finding out what clock frequency we got
     */
    /* ClockDetect(); Done already */
    DBGME(1,printf("ClockSpeed: %d\n",Eb63Clock));

    /* Configure Delay() and other overheads
     */
    x = Eb63Crystal/Eb63Clock;
    DelayShifter    =     10;
    DelayMultiplier =   1600 / x;

    /* Note that the number of instructions is the same for the
     * various cases, we just run the clock differently and this
     * affects the per-loop cost.  But the DelayOverhead measures
     * the cost of those fixed instructions scaled by the per-loop
     * cost.  In other words it takes the clock speed into account.
     * Therefore it should be constant, barred other changing factors.
     */
#if defined(ADS)
    DelayOverhead   =   9468;
#elif defined(_MSC_VER)
    DelayOverhead   =  21769;
#else
    DelayOverhead   =  12176;
#endif

    /* One relevant factor are the waistates in the SRAM accesses.
     * Since we changed them above for the 25/8 MHz case then both
     * constants are changing also.
     */
    if (x == 8) {
        DelayMultiplier =    400;
#if defined(ADS)
        DelayOverhead   =  10242;
#elif defined(_MSC_VER)
        DelayOverhead   =  23804;
#else
        DelayOverhead   =  13052;
#endif
    }

    /* Sleeping overheads now
     */
    Int32ToInt64(SleepOverhead,3000 * x);

    /*
     * First, do the RTC. Use channel 1 on TC0 for it.
     */
    x = TheRTC->Status;
    TheRTC->Control = TCHC_DISABLE; /* stop it if it was running */

    /* Install the ISR */
    AddDevice((PTR) TheRTC, (void *) ClockIsr, 0, IRQ_ID_TIMER1, 0);

    /* Enable the clock feed, in the power manager */
    ThePmc->PerClockEnable = ThePmc->PerClockStatus | PMCPC_TC1;

    /* Program the counter, as slow as possible */
    TheRTC->Mode = TCHM_WAVE | TCHM_MCKI_1024 | TCHM_TRG_RC;

    /* See the discussion at the beginning of this file */
    TheRTC->C = 65535;

    /* Reset and start the counter */
    TheRTC->Control = TCHC_ENABLE | TCHC_TRIGGER;

    /* Enable interrupts */
    TheRTC->IntrEnable = TCHI_C_COMPARE;

    /*
     * Next the programmable timer. Use channel 0 on TC0 for it.
     */
    x = ThePIT->Status;
    ThePIT->Control = TCHC_DISABLE; /* stop it if it was running */

    /* Install the ISR */
    AddDevice((PTR) ThePIT, (void *) TimerIsr, 0, IRQ_ID_TIMER0, 0);

    /* Enable the clock feed, in the power manager */
    ThePmc->PerClockEnable = ThePmc->PerClockStatus | PMCPC_TC0;

    /* Program the counter */
    ThePIT->Mode = TCHM_WAVE | OstScaler;
    ThePIT->A =
    ThePIT->B =
    ThePIT->C = 0;

    /* Reset and start the counter */
    ThePIT->Control = TCHC_ENABLE | TCHC_TRIGGER;

    /* Enable timer interrupt */
    ThePIT->IntrEnable = TCHI_C_COMPARE;

    /* Start of time is now
     * NB: Leave the TOY+ReloadDelta, in case a reset restarts the system.
     */
    SystemTimer.Ticks = ThePIT->Counter;

}

/* Estimate the current processor speed
 */
UINT64 CurrentProcessorSpeed(void)
{
    UINT64 Speed;

    /* Dont think we'll overflow 32 bits :-))
     */
    Int64FromHighAndLow(Speed,0,Eb63Clock);
    return Speed;
}
