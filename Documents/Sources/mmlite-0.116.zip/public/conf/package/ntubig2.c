/* Copyright (c) Microsoft Corporation. All rights reserved. */

#define NTUBIG2
#include "ntu_cfg.c"
