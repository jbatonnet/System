/* logger.h
 * Definitions for generic logging facility, implemented in src/util/logger.c
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __LOGGER_H__
#define __LOGGER_H__

#if !(defined(LOGGING_ENABLED) && defined(_DEBUG))
/* Release build optimization */
#define Log_Init(plThis, Size, Buffer);
#define Log_WriteEntry(plThis, pletType, Data)
#define Log_Print(plThis)

#undef LOGGING_ENABLED

#else 
/* Only define logger stuff when LOGGING_ENABLED requested *and* debug build */
#undef Log_Init
#undef Log_WriteEntry
#undef Log_Print

#define DECLARE_LOG(_name_)                                                   \
  LOG _name_;                                                                 \
  PLOG p##_name_ = &_name_

#define DECLARE_LOG_EVENT_TYPE(_name_, _string_, _enabled_)                   \
  LOG_EVENT_TYPE _name_ = { _string_, _enabled_ };                            \
  PLOG_EVENT_TYPE LOG_##_name_ = &_name_

typedef struct _LOG_EVENT_TYPE {
  char* szName;
  BOOL bIsEnabled;
} LOG_EVENT_TYPE, *PLOG_EVENT_TYPE;

typedef struct _LOG_ENTRY {
  PLOG_EVENT_TYPE pletType;  /* Also identifies the type of Data */
  UINT Data; /* Data being logged (usually a pointer to a thread or queue) */
  TIME tTime; /* Time the event was logged */
} LOG_ENTRY, *PLOG_ENTRY;

typedef struct _LOG {
  UINT EntryIndex;
  UINT BufferSize;
  PLOG_ENTRY pleBuffer;
} LOG, *PLOG;

EXTERN_C void Log_Init(PLOG plThis, UINT BufferSize, PLOG_ENTRY pleBuffer);
EXTERN_C void Log_WriteEntry(PLOG plThis, PLOG_EVENT_TYPE pletType, UINT Data);
EXTERN_C void Log_Print(PLOG plThis);

#endif /* LOGGING_ENABLED && _DEBUG */

#endif /* __LOGGER_H__ */

