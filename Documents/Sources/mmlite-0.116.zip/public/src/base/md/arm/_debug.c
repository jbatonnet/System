/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Generic debug console sopport.
 */
#include <base/debugger.h>

extern void DCPutChar( UINT8 c );
extern unsigned char dgetc( BOOL DoEcho );
#define __HAS_MACHINE_PUTS 1


#if defined(ANGEL_SEMIHOST)

#define swiWriteC    0x3
#define swiReadC     0x7

INT __swi(0x123456)         _ARMSemiHost( const UINT swiID, void *args );

void DCPutChar( UINT8 c)
{
    _ARMSemiHost(swiWriteC, &c);
}

void DebuggerOutputString( const unsigned char *String, int nBytes )
{
    int i;
    for (i = 0; i < nBytes; i++)
        DCPutChar(String[i]);
}

unsigned char dgetc( BOOL DoEcho )
{
    UINT8 c;
    c = _ARMSemiHost(swiReadC, NULL);
#if 0
    /* Not needed, the ARMulator actually wont refrain from echoing */
    if (DoEcho)
    DCPutChar(c);
#endif
    return c;
}

#endif

PRIVATE void OutputString(const BYTE *s, int len)
{
    char ch;

    /* Sanity
     */
    if (len == 0)
        return;
#if !_MINIMIZE
    if (DebuggerAttached) {
        DebuggerOutputString(s, len);
        return;
    }
#endif

    /* If no debugger just print
     */
    if (len < 0) len = ((UINT)~0 >> 1);
    while (s && ((ch = *s++) != 0)) {
        DCPutChar(ch);
        if (--len == 0) return;
    }
}

int puts(const char *s)
{
    OutputString((const BYTE *)s, -1);
    return 0;
}



int DCGetchar( BOOL DoEcho )
{
    int c;

    do {
        c = dgetc(DoEcho);
    } while (c == '\r');    /* zap returns */
    return c;
}

static const struct IFileVtbl DebugConsoleVtbl;

typedef struct {
    const struct IFileVtbl *v;
    UINT    RefCnt;
} *PDCONS;

#define pDC(_t_) ((PDCONS)(_t_))

PDCONS DCNew(void)
{
    PDCONS File;

    File = (PDCONS) CurrentHeap()->v->Alloc(CurrentHeap(),
                            HEAP_ZERO_MEMORY,
                            sizeof(*File),
                            0);
    if (!File)
      return NULL;

    File->v = &DebugConsoleVtbl;
    File->RefCnt = 1;

    return File;
}

void DCDestroy(PDCONS File)
{
    CurrentHeap()->v->Free(CurrentHeap(), 0, File);
}

SCODE MCT DCQueryInterface(PIFILE pThis, REFIID pIid, void* *ppNew)
{
    return GenericQueryInterface((PIUNKNOWN) pThis, pIid, ppNew, &IID_IFile);
}

UINT MCT DCAddRef(PIFILE pThis)
{
    PDCONS File = pDC(pThis);

    return AtomicInc(&File->RefCnt);
}

UINT MCT DCRelease(PIFILE pThis)
{
    PDCONS File = pDC(pThis);
    UINT Refs;

    Refs = AtomicDec(&File->RefCnt);
    if (Refs == 0)
      DCDestroy(File);

    return Refs;
}

/*
 * Read from a file
 */
SCODE MCT
DCReadAt(PIFILE pThis, UINT64 Position, 
                                 BYTE *Buffer, UINT ByteCount, PUINT pSizeRead)
{
    int c;

    UnusedParameter(pThis);
    UnusedParameter(Position);

#ifdef _UNICODE
    if (ByteCount < 2)
        return E_INVALID_PARAMETER;
#else
    if (ByteCount < 1)
        return E_INVALID_PARAMETER;
#endif

    c = DCGetchar(FALSE);

    if (c == -1) { /* EOF */
        if (pSizeRead)
            *pSizeRead = 0;
        return E_FAIL;
    } else {
#ifdef _UNICODE
        if (pSizeRead)
            *pSizeRead = 2;
        *(wchar_t &)Buffer = c;
#else
        if (pSizeRead)
            *pSizeRead = 1;
        *Buffer = (char) c;
#endif
        return (c == '\n') ? S_FALSE : S_OK;
    }
}


/*
 * Write to a file
 */
SCODE MCT
DCWriteAt(PIFILE pThis, UINT64 Position, 
          const BYTE *Buffer, UINT ByteCount, PUINT pSizeWritten)
{
    UnusedParameter(pThis);
    UnusedParameter(Position);

#ifdef _UNICODE
    --- must convert to ascii ---;
#endif

    OutputString(Buffer, ByteCount);

    if (pSizeWritten)
      *pSizeWritten = ByteCount;

    return S_OK;
}

/* Get/Set a file's size
 */
SCODE MCT DCGetSize(PIFILE pThis, PUINT64 pSize)
{
    UnusedParameter(pThis);
    UnusedParameter(pSize);

    return E_NOT_IMPLEMENTED;
}

SCODE MCT DCSetSize(PIFILE pThis, UINT64 Size)
{
    UnusedParameter(pThis);
    UnusedParameter(Size);

    return E_NOT_IMPLEMENTED;
}

static const struct IFileVtbl DebugConsoleVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    DCQueryInterface, 
    DCAddRef, 
    DCRelease, 
    DCReadAt, 
    DCWriteAt, 
    DCSetSize, 
    DCGetSize 
};

SCODE InitDebugConsole(void)
{
    PIFILE File = (PIFILE) DCNew();
    PINAMESPACE ns = CurrentNameSpace();
    SCODE sc;

    if (!File)
      return E_NOT_ENOUGH_MEMORY;

    sc = ns->v->Register(ns, _TEXT("stdin"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = ns->v->Register(ns, _TEXT("stdout"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    sc = ns->v->Register(ns, _TEXT("stderr"), (PIUNKNOWN) File, 0, NULL);
    if (FAILED(sc))
      goto Error;

    return S_OK;

  Error:
    return sc;
}
