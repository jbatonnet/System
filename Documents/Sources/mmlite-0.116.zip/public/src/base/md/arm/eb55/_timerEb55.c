/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Time might be kept using both an RTC and the PIT (timer 0).
 * The former gives an RTCDelta interrupt granularity, and
 * is the sole responsible for the drift [temperature & co.].
 * The latter gives fine grain resolution, and is used for
 * scheduling purposes.
 *
 * The basic idea is that the current time is given by
 *
 *      Now = TOY + ReloadDelta + (Ticks - PIT)
 *
 * where TOY is the accumulated count of the RTC interrupts,
 * ReloadDelta is the accumulated count of PIT reloads (one
 * reload per rescheduling), Ticks is the value the PIT was
 * last reloaded with, and PIT is the current reading of
 * the PIT.
 *
 * An important but subtle point is how the subexpression
 * in parens is evaluated.  PIT is a 16 bit counter, which
 * counts down from the (Ticks) value it is loaded with.
 * When it reaches zero it keeps decrementing from xFFFF.
 * (We use the Intel 8254 in Mode0).
 * By using signed 16 bits arithmetic we are guaranteed that
 * the (unsigned!) result of the subtraction is precisely
 * the number of ticks elapsed.  Assuming only that we did
 * not ignore the PIT interrupt for e.g. 54 milliseconds,
 * which is a safe assumption (else this whole OS is garbage..).
 *
 *
 * Formal analysis was based on the following pseudo code.
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (Ticks - PIT)
 *
 * PIT.Set(t) ::
 *      ReloadDelta += (Ticks - PIT)
 *      PIT = t
 *      Ticks = t
 *
 * PIT.Interrupt() :: <nothing needed>
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, 16msec
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * All functions are assumed atomic interrupt-wise.
 *
 * Notice that the above proof still holds if we remove
 * the RTC chip: just cancel RTC.Interrupt() and wire TOY==0.
 * Drift analysis (in PIT.Set()) becomes important, e.g. the
 * time between the first and second statement.
 *
 * UPDATE UPDATE UPDATE --for Atmel board-- UPDATE UPDATE UPDATE
 *
 * Here the PIT counts up, not down. One way to work around this
 * is to set COUNTER at MAX-desired_delta and take the interrupt
 * at overflow. At interrupt time COUNTER measures our latency,
 * so we can account for it.
 * One useful idea here is to use ARM's "swap" instruction, which
 * atomically does a read+write operation, e.g. on the COUNTER.
 * Darn, the counter is infact read-only. So much for that one.
 * There is no way to load anything but zero in that COUNTER, sorry.
 *
 * Another way is to load register C with COUNTER+desired_delta,
 * and use the match as interrupt trigger. At interrupt time the
 * difference COUNTER-C is the latency. COUNTER would be free-running
 * in this solution. There is an issue here as to how many cycles
 * does it take to (a) read COUNTER (b) add DELTA (c) write C.
 * Unless this is (a) deterministic and (b) known with high accuracy
 * we'll get strong clock drift.
 *
 * Yet another way is to load C with desired-delta, and reset+start
 * the counter. Interrupt again is at match with C.  One advantage is
 * that C holds Ticks directly on-chip, reducing memory load/stores.
 * The same drift problem as above applies here, the sequence is
 * (a) read COUNTER (b) reset-restart it.
 *
 * In both these last two cases the counter could be match-reset.
 * The problem with that is that we sometimes load very small delta
 * values, and it might be a while after the interrupt triggers
 * before we reload the timer. [This is scheduler-dependent]
 * So the counter might reset multiple times...
 *
 * The first (non-)solution would be the one that works best without
 * the RTC, assuming the swap trick.  The third one is the one that
 * minimizes drift uncertainty, and therefore the chosen one.
 * The equations for this solution are
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (PIT - Ticks)
 *
 * PIT.Set(t) ::
 *      PIT.C = t
 *      PIT_WAS = PIT
 *      PIT.Restart()
 *      ReloadDelta += (PIT_WAS - Ticks) + <drift>
 *      Ticks = 0
 *
 * PIT.Interrupt() :: <nothing needed [except calling PIT.Set()]>
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, ~2 seconds
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 */

#include <mmlite.h>
#include <diagnostics.h>
#include <fred.h>
#include <mmhal.h>
#include "at91m55800.h"
#include "eb55.h"

/* BUGBUG revise */

/* This board has a 32MHz crystal that provides the system clock.
 * Counters are fed that clock, divided by one of 2,8,32,128,1024.
 * Counter registers are 16 bit (yuch).
 *
 * Therefore our choices are:
 * DIVISOR   PERIOD      MAX_DELTA
 *  2           62.5 ns     4.096 ms
 *  8          250 ns      16.384 ms
 *  32        1000 ns      65.536 ms
 *  128       4000 ns     262.144 ms
 *  1024     32000 ns    2097.152 ms
 *
 * Our internal unit of time is 100 ns, we must convert back and
 * forth against whatever period we chose here. All periods are
 * powers of 2 off the basic one, which can easily be accomodated
 * by quick shift operations.  The most interesting case is /32,
 * or 100 ns / 1000 ns e.g. 1/10 (and its reciprocal 10).
 * The multiplication is trivial, the division by 5 unavoidable
 * [When oh when will they learn to put a 10 MHz crystal in there ?!?!?]
 * 
 * As for the RTC we should eventually use the builtin one...BUGBUG
 *
 */

volatile struct {
    TIME Toy;                   /* Time-of-year (gross estimate/epoch)      */

                                /* NB: These two are PERIODs, not TIMEs     */
    UINT32 ReloadDelta;         /* Delta from TOY due to multiple PIT intrs */
    UINT16 Ticks;               /* Value of the Counter at RTC interrupt    */

} SystemTimer = {
    Int64Initializer(0, 0),
    };

/* AT 32 MHz:
 * The timer is a 16bit counter running at 32/32=1 MHz,
 * max interval is therefore 65.536 ms.
 * Make sure it doesnt wrap around unnoticed.
 * BUGBUG We could do better than this, by looking at the overflow bit.
 */
#define RtcTicker      EbTimerConfig[0].RtcClockTick
#define OstMaxInterval EbTimerConfig[0].PitMaxInterval
#define OstShifter     EbTimerConfig[0].PitShiftValue
#define OstScaler      EbTimerConfig[0].PitClockScaler

TIMER_CONFIG EbTimerConfig[] = {
    /* First entry is the one in use, and the default one
     */
/*0*/
    {/* 32MHz, no divisor */
        /* See above for this RTC constant */
        Int64Initializer(0,20971200),

        Int64Initializer(0, TIME_MILLIS(65)),
        6, /* 64 */
        TCHM_MCKI_32,

        Eb55Crystal
    },
};

/*
 * Interrupt handler for the programmable timer (scheduler)
 */
BOOL TimerIsr(TC_CHANNEL *Channel, BOOL *pNotMine)
{
    UINT32 x;

    /* Acknowledge the interrupt
     */
    x = Channel->Status;

    /* No need for this, as this is the default */
    /* *pNotMine=FALSE; */

    /* Say its time to reschedule */
    return TRUE;
}


/*
 * Interrupt handler for RTC timer.
 */
BOOL ClockIsr(TC_CHANNEL *Channel, BOOL *pNotMine)
{
    UINT32 x;

    /* Acknowledge the interrupt */
    x = Channel->Status;

    /* Add one tick worth to the time of day */
    SystemTimer.Toy = TimeAdd(SystemTimer.Toy, RtcTicker);

    /* Zero the increment */
    SystemTimer.ReloadDelta = 0;

    /* Take the value of the PIT at this point */
    SystemTimer.Ticks = ThePIT->Counter;

    /* No need for this, as this is the default */
    /* *pNotMine=FALSE; */

    /* Leave the scheduler alone */
    return FALSE;
}

/*
 * The Atmel part has a 32x32->64 bit multiplier
 */
#if defined(__NO_BUILTIN_INT64)
extern INT64 Uint32TimesUint32ToInt64(UINT32 a, UINT32 b);
#else
#define Uint32TimesUint32ToInt64(_a_,_b_) (INT64)(((UINT64)_a_)*((UINT64)_b_))
#endif

/* Worker functions for the two crystals cases
 */
typedef UINT32 (* TO_TICKS)(TIME Delta);

UINT32 TimeToTicks32MHz(TIME Delta)
{
    UINT32 Ticks;

    /* Is it within range ?
     */
    if (!TimeLess(Delta,OstMaxInterval))
        /* Nope, trim */
        return 65000; /* MAX / 1us) */

    /*
     * To get from TIME-Delta to PERIOD-Ticks @32MHz:
     *
     *  Ticks   = Delta * 1/10
     *          = (Delta / 5) / 2
     *          = (Delta * (0x400000000/5)) / 0x400000000 / 2
     *          = (Delta * 0xcccccccc) >> 34+1
     *          = (Delta * 0xcccccccc) >> (32+3)
     *
     * Note that we dont need 64bits here, we just checked
     * and Delta is less than 0x26be3680.
     */
    Ticks = (UINT32) Int64ToInt32(Delta);
    Delta = Uint32TimesUint32ToInt64(0xcccccccc, Ticks);
    Ticks = (UINT32) Uint64High32Bits(Delta);
    return Ticks >> 3;
}

#define TimeToTicks TimeToTicks32MHz

typedef TIME (* TO_TIME)(UINT32 Ticks);

TIME TicksToTime32MHz(UINT32 Ticks)
{
    TIME Delta64;

    /* Convert from Ticks to TIME.
     *
     * Time = Ticks * 10
     *      = (Ticks * (4+1)) * 2
     *
     * Note that at most we have to convert one RTC worth of Ticks,
     * namely ~2100ms == 21000000 us == 21,000,000 TIME units, which
     * fits in 25 bits. No need for 64bit math then.
     */
    Ticks = (Ticks + (Ticks << 2)) << 1;
    Int32ToInt64(Delta64,(INT32)Ticks);
    return Delta64;
}

#define TicksToTime TicksToTime32MHz

/* Arm the timer to trigger in DELTA units of TIME (100ns) from now.
 */
extern UINT32 ReadWrite(PUINT32 ReadAddress,
                        PUINT32 WriteAddress, UINT32 WriteValue);

BOOL SetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    UINT32 PitWas, Ticks;
    UINT16 Delta16;
    UINT IntrState;
    BOOL StateWas;

    Ticks = TimeToTicks(Delta);

    if (Ticks < 2)
        Ticks = 2;              /* sanity minimum */

    assert(Ticks <= 0xffff);

    /*
     * Got the tick count, program the timer now
     */
    TURN_INTERRUPTS_OFF(IntrState);

    /* Set the new match value
     */
    ThePIT->C = Ticks;

    /* Get&Restart the COUNTER, in a well-known amount of time
     */
    PitWas = ReadWrite((PUINT)&ThePIT->Counter,
                       (PUINT)&ThePIT->Control, TCHC_ENABLE | TCHC_TRIGGER);

    /* Account for this reload
     */
    Delta16 = PitWas - SystemTimer.Ticks;
    SystemTimer.ReloadDelta += Delta16; /* BUGBUG add drift if no RTC */
    SystemTimer.Ticks = 0;

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);

    return StateWas;
}

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is max_toy_resolution
 */
TIME GetKernelTime ()
{
    UINT32 Delta;
    TIME Delta64;
    TIME TOY;
    UINT16 Ticks, PIT, Delta16;
    UINT IntrState;

    /* Cache a few values with interrupt protection
     *
     * NB: The value we return is bound to be 'obsolete',
     * not just by the time needed to compute it and return
     * to the point of call but also by unpredictable
     * delays due to device and timer interrupts.
     * Therefore it is not worth over-extending the protection
     * against interrupts inside this function, as it would
     * serve no benefit whatever.  The opposite need,
     * minimizing interrupt latency, is the one that dominates.
     */
    TURN_INTERRUPTS_OFF(IntrState);

    PIT   = ThePIT->Counter;
    Ticks = SystemTimer.Ticks;
    Delta = SystemTimer.ReloadDelta;
    TOY   = SystemTimer.Toy;

    RESTORE_INTERRUPTS(IntrState);

    /* Compute the number of elapsed ticks since the last RTC interrupt.
     */
    Delta16 = PIT - Ticks;
    Delta += Delta16;

    Delta64 = TicksToTime(Delta);

    /* Now put them all together.
     */
    TOY = Int64Add(Delta64, TOY);

    return TOY;
}

/* The board can run at various clock speeds.
 * This function detects what frequency we should run at and
 * sets up various pseudo-constants accordingly.
 * BUGBUG do it ;-) based on ..? button presses I suppose.
 */
extern void DbgPortInit(void);

void ClockDetect(void)
{
}

/* Initialization
 */
extern UINT DelayMultiplier;
extern UINT DelayShifter;
extern UINT DelayOverhead;

void EnableTimers( void )
{
    UINT32 x;

    /* Start by finding out what clock frequency we got
     */
    /* ClockDetect(); Done already */
    DBGME(1,printf("ClockSpeed: %d\n",Eb55Clock));

    /* Configure Delay()
     */
    DelayShifter    =  0;
    DelayMultiplier =  2; /* 500 ns / loop */
    DelayOverhead   = 11; /* overhd = 5.875 us */

    /*
     * First, do the RTC. Use channel 1 on TC0 for it.
     */
    x = TheRTC->Status;
    TheRTC->Control = TCHC_DISABLE; /* stop it if it was running */

    /* Install the ISR */
    AddDevice((PTR) TheRTC, (void *) ClockIsr, 0, IRQ_ID_TIMER1, 0);

    /* Enable the clock feed, in the power manager */
    ThePmc->PerClockEnable = ThePmc->PerClockStatus | PMCPC_TC1;

    /* Program the counter, as slow as possible */
    TheRTC->Mode = TCHM_WAVE | TCHM_MCKI_1024 | TCHM_TRG_RC;

    /* See the discussion at the beginning of this file */
    TheRTC->C = 65535;

    /* Reset and start the counter */
    TheRTC->Control = TCHC_ENABLE | TCHC_TRIGGER;

    /* Enable interrupts */
    TheRTC->IntrEnable = TCHI_C_COMPARE;

    /*
     * Next the programmable timer. Use channel 0 on TC0 for it.
     */
    x = ThePIT->Status;
    ThePIT->Control = TCHC_DISABLE; /* stop it if it was running */

    /* Install the ISR */
    AddDevice((PTR) ThePIT, (void *) TimerIsr, 0, IRQ_ID_TIMER0, 0);

    /* Enable the clock feed, in the power manager */
    ThePmc->PerClockEnable = ThePmc->PerClockStatus | PMCPC_TC0;

    /* Program the counter */
    ThePIT->Mode = TCHM_WAVE | OstScaler;
    ThePIT->A =
    ThePIT->B =
    ThePIT->C = 0;

    /* Reset and start the counter */
    ThePIT->Control = TCHC_ENABLE | TCHC_TRIGGER;

    /* Enable timer interrupt */
    ThePIT->IntrEnable = TCHI_C_COMPARE;

    /* Start of time is now
     * NB: Leave the TOY+ReloadDelta, in case a reset restarts the system.
     */
    SystemTimer.Ticks = ThePIT->Counter;

}

/* Estimate the current processor speed
 */
UINT64 CurrentProcessorSpeed(void)
{
    UINT64 Speed;

    /* Dont think we'll overflow 32 bits :-))
     */
    Int64FromHighAndLow(Speed,0,Eb55Clock);
    return Speed;
}
