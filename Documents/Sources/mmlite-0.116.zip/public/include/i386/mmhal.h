/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* --------------------------------------------------------------------------
 *
 * Module:
 *
 *    mmhal.h
 *
 * Purpose:
 *
 *    FRED header file (x86 version)
 *
 * Author:
 *    A. Forin (sandrof)
 *
 * --------------------------------------------------------------------------
 */

#ifndef __MMHAL_
#define __MMHAL_ 1


#ifdef _MSC_VER
#pragma warning(disable:4035)   /* disable warning C4035: no return value */
#endif

/*
 * Bit/Byte-order defines
 */
#ifndef BYTE_ORDER

#define LITTLE_ENDIAN 1
#define BIG_ENDIAN 0

#define BYTE_ORDER LITTLE_ENDIAN

#endif /* BYTE_ORDER */

#include <endian.h>

/*
 * I/O accesses
 */
typedef UINT16 IO_PORT;

__inline UINT8 IOSpaceReadInt8( IO_PORT This)
{  __asm {
        mov dx,This;
        in al,dx;
    }
}
__inline void IOSpaceWriteInt8( IO_PORT This, UINT8 Value)
{
    __asm {
        mov dx,This;
        mov al,Value;
        out dx,al;
    }
}

__inline UINT16 IOSpaceReadInt16( IO_PORT This)
{  __asm {
        mov dx,This;
        in ax,dx;
    }
}
__inline void IOSpaceWriteInt16( IO_PORT This, UINT16 Value)
{
    __asm {
        mov dx,This;
        mov ax,Value;
        out dx,ax;
    }
}

__inline UINT32 IOSpaceReadInt32( IO_PORT This)
{  __asm {
        mov dx,This;
        in eax,dx;
    }
}
__inline void IOSpaceWriteInt32( IO_PORT This, UINT32 Value)
{
    __asm {
        mov dx,This;
        mov eax,Value;
        out dx,eax;
    }
}

__inline void IOSpaceReadFIFO16( IO_PORT This, PUINT16 String, UINT32 Count)
{
    __asm {
        mov dx,This;
        mov edi,String;
        mov ecx,Count;
        rep insw;
    }
}

__inline void IOSpaceWriteFIFO16( IO_PORT This, PUINT16 String, UINT32 Count)
{
    __asm {
        mov dx,This;
        mov esi,String;
        mov ecx,Count;
        rep outsw;
    }
}

/*
 * There are no I/O WriteBuffer-ing issues
 */
#define IOWriteBufferFlush()

/*
 * There are no out-of-order I/O read issues
 */
#define IOMemoryBarrier()


/*
 *  NT compatibility defines
 */
#define READ_PORT_UCHAR(_a_)       IOSpaceReadInt8((IO_PORT)_a_)
#define WRITE_PORT_UCHAR(_a_,_v_)  IOSpaceWriteInt8((IO_PORT)_a_,_v_)
#define READ_PORT_USHORT(_a_)      IOSpaceReadInt16((IO_PORT)_a_)
#define WRITE_PORT_USHORT(_a_,_v_) IOSpaceWriteInt16((IO_PORT)_a_,_v_)
#define READ_PORT_ULONG(_a_)       IOSpaceReadInt32((IO_PORT)_a_)
#define WRITE_PORT_ULONG(_a_,_v_)  IOSpaceWriteInt32((IO_PORT)_a_,_v_)
#define READ_PORT_BUFFER_USHORT(_a_,_b_,_c_) \
                                   IOSpaceReadFIFO16((IO_PORT)(_a_),_b_,_c_)
#define WRITE_PORT_BUFFER_USHORT(_a_,_b_,_c_) \
                                   IOSpaceWriteFIFO16((IO_PORT)(_a_),_b_,_c_)

#define KeStallExecutionProcessor(_u_) Delay(_u_)

#ifdef _MSC_VER
#pragma warning(default:4035)   /* reenable warning C4035   */
#endif

#endif  /*__MMHAL_*/
