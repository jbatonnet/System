/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

/* BEGIN_SAMPLE */
/* Prints available memory. */
int _tmain()
{
    PIPROCESS pPrc;    /* Pointer to process object.*/
    MACHINE_INFO Minfo;
    SCODE StatusCode;

    pPrc = CurrentProcess();    /* Get reference to current process.*/

    StatusCode = pPrc->MachineInfo(MACHINE_KIND_GENERIC, &Minfo);
    if (FAILED(StatusCode)) {
        _tprintf(_TEXT("Can't get machine info, sc = x%x\n"),
                 StatusCode);
        exit(0);
    }
    _tprintf(_TEXT("AvailablePhysicalMemory %d bytes\n"),
             Minfo.AvailablePhysicalMemory);
}
