/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Reference:
 * "AT91EB63 Evaluation Board, USER MANUAL"
 * PubNo 1359A Rev 02/00
 * Editor: Atmel Corporation, 2000 http://www.atmel.com
 *
 * Definitions specific to the EB63 board
 */

/*
 * Some random info on this board.
 * 1- The LEDs are connected to port B, as follows:
 *    DS1-PB8 DS2-PB9 DS3-PB10 DS4-PB11 DS5-PB12 DS6-PB13 DS7-PB14 DS8-PB15
 *    Write a 1 to PioB->ClearData (e.g. set Status to 0) to turn the LED on.
 *    Write a 1 to PioB->SetData (e.g. set Status to 1) to turn the LED off.
 * 2- The LED DS9 is connected directly to the power line.
 * 3- The push-buttons are connected as follows:
 *    SW1-PB3 SW2-PB4 SW3-PB5 SW4-PA9(IRQ0)
 * 4- The RESET button S5 is connected directly to the reset line.
 * 5- The S7 white button connects to the NWAKEUP line.
 *
 * SRAM can be populated with either 256KB or 1MB:
 * - 2 x KM68V1002 (128Kx8) == 256KB
 * - 2 x KM68V4002 (512Kx8) == 1MB
 */

/* The boot code sets up these chip selects (in the EBI)
 * to enable memory accesses to the FLASH and SRAM chips
 */
#define FLASH_CHIP_SELECT 0
#define SRAM_CHIP_SELECT  1

/* The board uses a 25MHz crystal as reference clock.
 * There is a divisor between this signal and MCLKI,
 * normally set at 1.  For lower power consumption the
 * clock is reduced [and voltage is settable at 1.8V]
 */
#define Eb63Crystal (25*1000*1000)

/* The timer code uses TC0 and TC1 for timing purposes
 */
#define ThePIT (&Tc0->Channel0)
#define TheRTC (&Tc0->Channel1)

/* The timer code auto-detects the clock frequency
 */
typedef struct _TIMER_CONFIG {
    TIME RtcClockTick;
    TIME PitMaxInterval;
    UINT8 PitShiftValue;
    UINT8 PitClockScaler;
    UINT32 ClockFrequency;  /* in Hz */
} TIMER_CONFIG;

extern TIMER_CONFIG EbTimerConfig[];

#define Eb63Clock EbTimerConfig[0].ClockFrequency

/*
 * The Microsoft add-on board with the Epson LCD and buttons
 * provides the following:
 * - The Epson LCD is visible at 0x20000000, using CS2
 * - The 6 buttons are mapped as follows:
 *   Button1-PA10(IRQ1) Button2-PA11(IRQ2) Button3-PA12(IRQ3)
 *   Button4-PB6 Button5-PB7 Button6-PB16
 */
#define LCD_CHIP_SELECT 2
