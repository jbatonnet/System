/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <loaders/cobtab.h>

const struct PRECOB ThePreCobTable[] = {{0,0}
};
