/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>

/* Create the system heap.  Left to machdep code because messy otherwise.
 * The heap should account for all available memory, carved out of memory
 * that is already used or unavailable (like the 640K-1meg hole on PCs).
 * It does not have to account for all the memory in the system.
 * Returns a PIHEAP pointer.
 */

PIHEAP MachineHeapCreate( void )
{
    PIHEAP pIHeap;
    ADDRESS Base = (ADDRESS) _end;

#define MemTop  0x2000000       /* Sidearm has 32M ram */
#define MemBase 0x80            /* memory starts after vector table */
#define MemSize (MemTop - MemBase)
#define _HOLE_STARTS 0x8000
#define _HOLE_SIZE (Base-_HOLE_STARTS)

    pIHeap = CreateHeapFrom(MemBase, 0, MemSize, MemSize);

    /* Carve out "the hole".
     * BUGBUG Check if this will work with the bit-map heap, ie. is
     * 32K free mem in front of the base image enough?
     */
    if (MemTop > Base) {
        pIHeap->v->Extract(pIHeap, 0,
                           (PTR)_HOLE_STARTS,
                           _HOLE_SIZE);
    }

    return pIHeap;
}

void TheEnd(void)
{
#if defined(ANGEL_SEMIHOST)
    __asm {
        mov     r0, angel_SWIreason_ReportException
        mov     r1, ADP_Stopped_ApplicationExit
        swi     angel_SWI_ARM
    }
    assert("Exit failed!");
#else
    for(;;) ;
#endif
}
