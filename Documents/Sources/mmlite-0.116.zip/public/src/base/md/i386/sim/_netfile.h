/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Microsoft MMLITE June 1995 --jvh
 * Protocol specification for remote IFile using sockets.
 */

#define MAX_UDP_SIZE 65507
/*#define MAX_READ_SIZE (4096*16) */
#define MAX_READ_SIZE (4096)
#undef MAX_PATH         /* delete NT definition. Must be same on both ends */
#define MAX_PATH 1024
#define DEFAULT_PORT 12345
#define HOSTFS_TCHAR _TCHAR

struct open_req {
    UINT32 flags;               /* currently interpreted as boolean WRITABLE */
    HOSTFS_TCHAR path[MAX_PATH];        /* translated to multibyte by server */
};
struct open_rep {
    UINT32 handle;
};

#define close_req open_rep
/* close_rep -- no private data */

#define delete_req open_req
/* delete_rep -- no private data */

struct read_req {
    UINT32 handle;
    UINT64 position;
    UINT32 count;
};
struct read_rep {
    UINT32 nread;
    char data[MAX_READ_SIZE];
};

struct write_req {
    UINT32 handle;
    UINT64 position;
    UINT32 count;
    char data[MAX_READ_SIZE];
};
struct write_rep {
    UINT32 nwritten;
};

#define getsize_req open_rep
struct getsize_rep {
    UINT64 size;
};

struct setsize_req {
    UINT32 handle;
    UINT64 size;
};
/* setsize_rep -- no private data */

struct findnext_req {
    HOSTFS_TCHAR prefix[MAX_PATH];      /* translated to multibyte by server */
    HOSTFS_TCHAR previous[MAX_PATH];    /* translated to multibyte by server */
};
struct findnext_rep {
    HOSTFS_TCHAR name[MAX_PATH];        /* translated to multibyte by server */
};


typedef UINT8 PACKETTYPE;

struct packet {
    PACKETTYPE packet_type;
#define PACKET_TYPE_BOGUS               0
#define PACKET_TYPE_OPEN_REQ            1
#define PACKET_TYPE_OPEN_REP            2
#define PACKET_TYPE_CLOSE_REQ           3
#define PACKET_TYPE_CLOSE_REP           4
#define PACKET_TYPE_READ_REQ            5
#define PACKET_TYPE_READ_REP            6
#define PACKET_TYPE_WRITE_REQ           7
#define PACKET_TYPE_WRITE_REP           8
#define PACKET_TYPE_GETSIZE_REQ         9
#define PACKET_TYPE_GETSIZE_REP         10
#define PACKET_TYPE_SETSIZE_REQ         11
#define PACKET_TYPE_SETSIZE_REP         12
#define PACKET_TYPE_FINDNEXT_REQ        13
#define PACKET_TYPE_FINDNEXT_REP        14
#define PACKET_TYPE_DELETE_REQ          15
#define PACKET_TYPE_DELETE_REP          16
    UINT8 seqno;
    UINT16 packet_length;
    INT32 sc;   /* sign extended */     /* in every reply basically */
#define SUCCESS 0
    union {
        struct open_req open_req;
        struct open_rep open_rep;
        struct read_req read_req;
        struct read_rep read_rep;
        struct write_req write_req;
        struct write_rep write_rep;
        struct getsize_rep getsize_rep;
        struct setsize_req setsize_req;
        struct findnext_req findnext_req;
        struct findnext_rep findnext_rep;
    } u;
};

/* Initialize a header */
INLINE void packet_init(struct packet *p, PACKETTYPE type)
{
    p->packet_type = type;
    p->seqno = 0;
    p->sc = SUCCESS;
    /* header length including alignment */
    p->packet_length = (UINT16) ((char *)&p->u - (char *)p);
}

/* Finalize packet for send */
INLINE void packet_prepare(struct packet *p, UINT32 sizedelta)
{
    p->packet_length = (UINT16) (p->packet_length + sizedelta);
}

/* Check a received packet */
/* OK to inline as this is used only once in client and once in server */
INLINE SCODE packet_check(struct packet *p, PACKETTYPE expect_type, UINT32 length)
{
    SCODE sc;
    UnusedParameter(length);
#if 0
    printf("packet_check(%x %x %x) p->l = %x d=%x\n",
           p, expect_type, length, p->packet_length,
           (char *)&p->u - (char *)p);
#endif

    /* add more sanity checks here */
    if (p->packet_length < (char *)&p->u - (char *)p)
        return 0x88888801;      /* BUGBUG: bogus error */

#if 0    /* SimFile doesn't bother updating length */
    if (p->packet_length != length)
        return 0x88888802;      /* BUGBUG: bogus error */
#endif

    if (p->packet_type != expect_type)
        return 0x88888803;      /* BUGBUG: bogus error */

    sc = (SCODE) p->sc;         /* sign extends */
    return sc;
}

/* SimFile interface -- a packet_rpc surrogate */
SCODE SimFile_Server(struct packet *p);
/* Call this initially in order to setup things */
SCODE SimFile_Init(void);
