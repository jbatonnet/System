/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>
#include <drivers/drivers.h>

const DRIVER_CONFIG DriverConfigs[] = {
  {_T("null"), _T("COB/null.cob"), 0, },

  {_T("com1"), _T("COB/at91x40.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_LEVEL_TRIGGER|DEVICE_FLAGS_POSITIVE_LEVEL, 0xfffd0000, 2, NULL, NULL, 38400, },
  {_T("com2"), _T("COB/at91x40.cob"), DEVICE_FLAGS_INTERRUPTS|DEVICE_FLAGS_LEVEL_TRIGGER|DEVICE_FLAGS_POSITIVE_LEVEL, 0xfffcc000, 3, NULL, NULL, 38400, },

//  {_T("fm0"), _T("COB/fmradio.cob"), 0,0,0, (_TCHAR *) 38400, (_TCHAR *) _T("com2"), 0, },
  {NULL,}    
};
