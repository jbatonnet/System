/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <import_windows.h>
#include <mmlite.h>
#include <stdio.h>
#include <assert.h>
#include <x86_cpu.h>
#include <machdep.h>            /* for TURN_INTERRUPT_OFF */
#include "_ntmmglu.h"

#define printf NT_printf
EXTERN_C INT __cdecl NT_printf(const char *format, ...);

BOOL volatile SimInt_State = SIMINT_DISABLED;

typedef void (__cdecl *INTERRUPTROUTINE)(void);

extern void __cdecl SchedulingInterrupt(void);
extern void __cdecl IoCompletionInterrupt(void);

INTERRUPTROUTINE Ints[10] = {
    SchedulingInterrupt,
    IoCompletionInterrupt,
    0,
};

UINT32 StateBits[10] = {
    SIMINT_PENDING,
    SIMINT_PENDING1,
    0,
};

void SimInt_CallPending(void)
{
    void (__cdecl *routine)(void);

    if (SimInt_State & SIMINT_PENDING) {
        routine = Ints[0];
        AtomicNandSwap((PTR) &SimInt_State, SIMINT_PENDING);
    } else if (SimInt_State & SIMINT_PENDING1) {
        routine = Ints[1];
        AtomicNandSwap((PTR) &SimInt_State, SIMINT_PENDING1);
    } else {
        assert(FALSE);
    }

    assert(SimInt_State & SIMINT_DISABLED);
    
    /* Push flags, cs, eip. Jump to routine */
    _asm {
        pushfd;
        push cs;
        call routine;
    }
}

/* The thread is suspended. Build frame on stack and modify regs */
BOOL NT_TimerCallBack(UINT *pEip,
                      UINT *pCs,
                      UINT *pEsp,
                      UINT *pEFlags,
                      UINT InterruptId)
{
    INT32 *sp;
//    printf("NT_TimerCallBack pc=%x cs=%x sp=%x fl=%x\n", *pEip, *pCs, *pEsp, *pEFlags);

    if (Ints[InterruptId] == 0) {
        printf("Bogus interrupt %x\n", InterruptId);
        DebugBreak();
    }

    if (SimInt_State & SIMINT_DISABLED) {
//      printf("NT_TimerCallBack PENDING\n");
        SimInt_State |= StateBits[InterruptId];
        return FALSE;
    }
    SimInt_State = SIMINT_DISABLED;

    sp = (void*) *pEsp;

    sp--; *sp = *pEFlags;
    sp--; *sp = *pCs;
    sp--; *sp = *pEip;

    /* On stack we have:
     * (high)
     *              saved SS     only if from user level  ;; 32bits
     *              saved ESP    only if from user level  ;; 32bits
     *              saved EFLAGS     ;; 32bits
     *              saved CS         ;; 32bits
     * esp->        saved eip        ;; 32bits
     */

    /* Update the actual stack pointer */
    *pEsp = (UINT32) sp;
    /* And make it run the handler */
    *pEip = (UINT32) Ints[InterruptId];

    /* Turn off trace flag, it will be restored in iretd after the intr */
    *pEFlags &= ~X86_FLAG_TF;

    return TRUE;
}

/*
 * If anything needs to be done to start the system timer(s),
 * do it when this function is called.
 */
extern void EnableTimers(void)
{
    UINT32 State;

    TURN_INTERRUPTS_OFF(State);
    NT_EnableTimers(NT_TimerCallBack);
    RESTORE_INTERRUPTS(State);
}

/*
 * If anything needs to be done to stop the system timer(s),
 * do it when this function is called.  
 * Called on kernel (orderly) shutdown. 
 */
extern void DisableTimers(void)
{
    UINT32 State;

    TURN_INTERRUPTS_OFF(State);
    NT_DisableTimers();
    RESTORE_INTERRUPTS(State);
}

/*
 * Returns the speed of the current processor.
 */
extern UINT64 CurrentProcessorSpeed(void)
{
    return NT_CurrentProcessorSpeed();
}

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is machine-specific.
 */
extern TIME GetKernelTime (void)
{
    UINT32 State;
    TIME r;

    TURN_INTERRUPTS_OFF(State);
    r = NT_GetKernelTime();
    RESTORE_INTERRUPTS(State);
    return r;
}

 /* Set the hardware programmable interrupt timer (PIT) to
  * give us an interrupt in DELTA time units from now.
  * If pStateVariable is non-NULL, set it to FALSE and return
  * the previous value, with the timer interrupt off.
  * If it is null return FALSE;
  */
extern BOOL SetNextInterrupt( TIME Delta, BOOL *pStateVariable)
{
    UINT32 State;
    BOOL StateWas;

    TURN_INTERRUPTS_OFF(State);
    NT_SetNextInterrupt( (int) Delta);

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }
    RESTORE_INTERRUPTS(State);
    return StateWas;
}

/* Say we are a simulator
 */
UINT CurrentProcessorOEM(void)
{
    return ~0U;
}

/* Terminate the system.  Whatever that means (=>machdep)
 */
void TheEnd(void)
{
    UINT32 State;

    TURN_INTERRUPTS_OFF(State);
    NT_TheEnd();
    RESTORE_INTERRUPTS(State);
}

void DCPutChar(UINT8 c)
{
    UINT32 State;

    TURN_INTERRUPTS_OFF(State);
    NT_putchar(c);
    RESTORE_INTERRUPTS(State);
}

/* Caveat emptor: This function will block with interrupts disabled. */
int DCGetChar( BOOL DoEcho )
{
    int c;
    UINT32 State;
    INT Delay = 1;

    for (;;) {
        TURN_INTERRUPTS_OFF(State);
        c = NT_getchar();
        RESTORE_INTERRUPTS(State);

        if (c > 0)
            break;

        if (c == -2) {          /* would block */
            SleepUntil(TIME_RELATIVE(TIME_MILLIS(Delay)));
            Delay += Delay;
            if (Delay > 100)
                Delay = 100;
        }
    }

    if (c == '\r')
        c = '\n';

    if ( DoEcho )
        DCPutChar((UINT8) c);

    return c;
}

/* *** AtomicOrSwap
 *
 * Atomically Ors bits in Bits into *pTarget and returns the OLD value.
 */
unsigned int AtomicOrSwap(unsigned int * pTarget, unsigned int Bits)
{
    UINT OldValue, NewValue;

    for (;;) {
        OldValue = *pTarget;
        NewValue = OldValue | Bits;
        if (AtomicCmpAndSwap(pTarget, OldValue, NewValue))
            return OldValue;
    }
}

/* *** AtomicNand
 *
 * Atomically Nands bits in Bits from *pTarget and returns the OLD value.
 */
unsigned int AtomicNandSwap(unsigned int * pTarget, unsigned int Bits)
{
    UINT OldValue, NewValue;

    for (;;) {
        OldValue = *pTarget;
        NewValue = OldValue &~ Bits;
        if (AtomicCmpAndSwap(pTarget, OldValue, NewValue))
            return OldValue;
    }
}

/* Guard CRT library from "interrupts" */
INT __cdecl NT_printf(const char *format, ...)
{
    va_list arg;
    INT ret = 0;
    static int (*vpr)() = NULL;
    HANDLE h;
    UINT32 State;

    if (vpr == NULL) {
        h = GetModuleHandle(_T("msvcrt.dll"));
        if (h == INVALID_HANDLE_VALUE || h == NULL)
            h = LoadLibrary(_T("msvcrt.dll"));
        if (h == INVALID_HANDLE_VALUE || h == NULL) {
            DebugBreak();
            return -1;
        }
#ifdef _MSC_VER
#pragma warning(disable:4152)   /* conversion in expression */
#endif

        vpr = (void*) (ADDRESS) GetProcAddress(h, "vprintf");
        if (vpr == NULL) {
            DebugBreak();
            return -1;
        }
    }

    TURN_INTERRUPTS_OFF(State);
    va_start(arg,format);
    if (format != NULL)
        ret = (*vpr)( format, arg );
    va_end(arg);
    RESTORE_INTERRUPTS(State);

    return ret;
}

char * NT_GetCommandLineA(void)
{
    return (char*) GetCommandLineA();
}

