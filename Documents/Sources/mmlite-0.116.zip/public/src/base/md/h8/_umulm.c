/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* OPTIMIZE!!! */
#include <mmlite.h>

//unsigned int umulm(unsigned int a, unsigned int b)
UINT32 umulm(UINT32 a, UINT32 b)
{
    UINT32 i, r;

    r = 0;
    for (i = 1; i < 32; i++)
        if (a & (1 << i))
            r += b >> (32 - i);
    return r;
}
