/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <diagnostics.h>
#include <fred.h>
#include "at91x40.h"
#include "zenith1.h"

extern void _start(void); /* truly our image's start */

extern void ClockDetect(void);

#define SRAM_Base ((ADDRESS)0x100000)
#define SRAM_Size (1024*128)
#define EXTRAM_Base ((ADDRESS)0x02000000)

void Z1Init(void)
{
#if 0 /* no need to waste code if.. */
    /* The EBI setup is fine with us.
     */
#else
    /* Setup the EBI the way we want it.
     *
     * Notice we also turn off FLASH/SRAM boot-time remapping, ifnot.
     */
    static const struct _Ebi EbiSetup = {
     { 
         /* FLASH  @1mil
          * We run max at 22MHz: [BUGBUG minimize!]
          * 16bit bus, 1Meg, 16bit write, enabled, 2 waitstates, 1 float.
          */
         0x01000000 | EBICS_DBW_16 | EBICS_PS_1M | EBICS_BAT_S | EBICS_CSEN |
             EBICS_WSE | EBICS_NWS(1) | EBICS_TDF(1),

         /* external RAM
          * Same as FLASH for 22 MHz. [BUGBUG: minimize!]
          * 16bit bus, 16Meg, 16bit write, enabled, 1 waitstates, 0 float.
          */
         EXTRAM_Base | EBICS_DBW_16 | EBICS_PS_16M | EBICS_BAT_S | EBICS_CSEN |
//             EBICS_NWS(1) | EBICS_WSE, | EBICS_TDF(1),
             EBICS_WSE | EBICS_NWS(0),

         /* Ray's LCD
            Address = 0x20000000
            8-bit data bus
            Page Size = 1 Mb
            Byte-Write access type
            Chip Select Enabled
            1 Wait State
            0 Data float output states (unless using read/write multiple, then should be 4)
          */
         0x20000000 | EBICS_DBW8 | EBICS_PS_1M | EBICS_BAT_W | EBICS_CSEN | 
             EBICS_WSE | EBICS_NWS(0) | EBICS_TDF(0),

         /* Rest is invalid
          */
         0x30000000, 0x40000000, 0x50000000, 0x60000000, 0x70000000 },
       EBIRC_NO_REMAP,
       EBIMC_DRP_EARLY | EBIMC_ALE_CS4_6
    };
    *TheEbi = EbiSetup;
#endif

    /* Turn the clock on to all the peripherals we (know we'll) use
     */
    ThePs->PerClockEnable = PSPC_USART0 | PSPC_USART1 |
                             PSPC_TC0 | PSPC_TC1 |
                             PSPC_PIO;

    /* Clocks are always enabled after reset, 
     * so turn off the ones we don't need
     */
    ThePs->PerClockDisable = PSPC_TC2;

    /* Initialize the PIO
     * - P3,4 boot select as inputs
     */
    ThePio->FilterEnable = PIO_3 | PIO_4;
    ThePio->IntrDisable  = PIO_3 | PIO_4;
    ThePio->Disable      = PIO_3 | PIO_4;

#if 0
    /* Init LCD here, so we can print early on
     */
    LcdInit();
    putDebugChar(014);/*^L clear screen */
#endif

    /* Check what clock we are using
     */
    ClockDetect();

    /* ..Any other peripherals that need initialization
     */
}

/* See how much SRAM we have
 * Memory banks are aliased.
 */
UINT ExternalMemorySize(void)
{
    ADDRESS MemBase, MemTop, MemLimit;
    UINT32 *pa, *pb, a, b;
    UINT MaxSize, Size;

    /* Start by finding how far we can go before trapping
     */
    Size = TheEbi->ChipSelect[SRAM_CHIP_SELECT];
    if ((Size & EBICS_CSEN) == 0)
        return 0;

    MemBase = EBICS_BA(Size);
    /* use PageSize info */
    MaxSize = 1*1024*1024 * (1 << (EBICS_PS_G(Size)*2));
    DBGME(1,printf("CS=%x MaxSize=%x\n",Size,MaxSize));
    MemLimit = MemBase + MaxSize;

    for (;;) {
        /* This will be aliased, unless we got it */
        MemTop = MemBase + MaxSize;
        pa = (UINT32*)(MemTop - 4);
        a  = *pa;

        /* Cut our size estimate in half */
        Size = MaxSize >> 1;

        /* Watch out just below the new potential top
         */
        pb = (UINT32*)(MemBase + Size - 4);

        /* Write at the old top, check, put it back
         */
        *pa = a+1;
        /* But what if the is no memory, or it is not writeable,
         * or its bad (wrong waistates or something).
         */
        b = *(volatile UINT32*)pa;
        if (b != (a+1))
            return 0;

        b = *pb;
        *pa = a;

        /* Look for an alias */
        if ((b != (a + 1)) || (*pb != a))
            /* Not aliased, stop here */
            break;

        /* Its an alias, keep going */
        MaxSize = Size;
        DBGME(0,printf("Size -> %x\n",MaxSize));
    }

#if 1 /* save some code */
    return MaxSize;
#else /*anal-retentive*/

    /* If fully populated we are done
     */
    if (MemTop == MemLimit)
        return MaxSize;

    /* Now suppose we got 768K... the code above gets 512K.
     * Next loop makes sure there are no fragments of a smaller "Size"
     * That would happen iff we had two memory chips of different sizes.
     * Which is very unlikely, so this code is normally disabled.
     */
    /* First pass checks for no extra memory, which is common case.
     * Following passes estimate the size of the extra chunk
     */
    pa = (UINT32*)(MemBase);
    Size = 0;
    for (;;) {
        /* Once we get the right Size we'll see an alias
         */
        pb = (UINT32*)(MemTop + Size);
        DBGME(0,printf("check @%x @%x\n",pa,pb));
        a = *pa;
        b = *pb;

        /* Found an alias ?
         */
        if (b == a) {
            /* Uhmm, could be a coincidence
             * Write a different value and check again
             */
            *pa = a + 1;
            b = *pb;
            *pa = a; /* dont forgetta.. */
            if (b == (a + 1))
                /* Really an alias, thats it then.
                 */
                goto Done;
        }                

        /* No alias, so there is (more) memory.
         */
        if (Size)
            /* Not the second pass, try a bigger chunk
             */
            Size = Size << 1;
        else {
            /* Smallest chunk we'll detect is 2K.
             * Anything less will be marked as 2k. Sorry.
             */
            Size = 2*1024;

            /* We are no longer looking at the first memory chip.
             */
            pa = (UINT32*)(MemTop);
        }
        
    }

  Done:
    DBGME(1,printf("MemorySize: %d+%d bytes\n",MaxSize,Size));
    return MaxSize+Size;
#endif
}

/* Create the system heap.  Left to machdep code because messy otherwise.
 * The heap should account for all available memory, carved out of memory
 * that is already used or unavailable (like the 640K-1meg hole on PCs).
 * It does not have to account for all the memory in the system.
 * Returns a PIHEAP pointer.
 */

PIHEAP MachineHeapCreate( void )
{
    PIHEAP pIHeap;
    ADDRESS MemBase = 0;
    UINT MemSize = 1024*128, ExtSize = 0;
    ADDRESS MemTop;

    /* See if we got any external RAM.
     * If we do, we'll pretend the heap covers them both.
     * Yes this is wasteful, should cascade two heaps instead.
     */
    ExtSize = ExternalMemorySize();
    /* External RAM is 256K max (until debug boards fixed, e.g. never)
     */
    if (ExtSize > 0x80000) {
        ExtSize = 0x80000;
        printf("Suspicious extRAM, trimmed to x%x\r\n", ExtSize);
    }
    MemTop = (ExtSize) ? (EXTRAM_Base + ExtSize) :
                         (SRAM_Base + SRAM_Size);
    MemBase = SRAM_Base;

    /* There is nothing before the image if we load/run at SRAM_Base
     * Ifso we have no way to account for our own memory,
     * unless the heap manage is the bitmap one. 
     * Therefore we cannot carve out a heap header in there,
     * unless we overwrite the code [which is doable, but then
     * we cannot self-flash the image]
     */
#define MinHeap (0x80+0x10)
//#define ImageStart ((ADDRESS)_start + MinHeap)
#define ImageStart ((ADDRESS)_start)

    /* Are we running at the start of SRAM ?
     * Ifso bump the start up to skip us.
     */
    if (MemBase == ImageStart)
        MemBase = (ADDRESS) _end;
    MemSize = MemTop - MemBase;

    pIHeap = CreateHeapFrom(MemBase, 0, MemSize, MemSize);
    if (pIHeap == NULL)
        return NULL;

    /* Carve us out the heap.
     * There must be a minimum of memory before us.
     * Beware we might be loaded at the very top.
     */
    if ((MemBase < ImageStart) &&
        ((ImageStart - MemBase) > MinHeap) &&
        (((ADDRESS)_end) < MemTop)) {

        MemSize = ((ADDRESS)_end) - ImageStart;
        pIHeap->v->Extract(pIHeap, 0,
                           (PTR)ImageStart,
                           MemSize);
    }

    /* If we got external RAM, carve out the hole between SRAM and EXTRAM.
     */
    if (ExtSize) {

        MemTop = SRAM_Base + SRAM_Size;
        MemSize = EXTRAM_Base - MemTop;
        pIHeap->v->Extract(pIHeap, 0,
                           (PTR)MemTop,
                           MemSize);
    }

    return pIHeap;
}

void TheEnd(void)
{
    void (*Reset)(void) = (void (*)(void))0x0;

    /* BUGBUG Somewhere there's got to be a reset register or something.
     */
    printf("Jumping to 0 cuz I'm stoop (seeya!)\n");
    for(;;)
        Reset();
}


#define verify 0
#if verify
/*extern void PrintIrqCounts(void);*/
#define PrintIrqCounts()
UINT32 TimeHalted[8] = {0,};
#endif
/* .. */
void ArmMachineIdle(ADDRESS Arg)
{
#if verify
    UINT16 t0, t1, s;
    static INT32 maxsleep = -1;

    t0 = TheCNT->Counter;
    ThePs->SysClockDisable = PSSC_CPU;
    t1 = TheCNT->Counter;
    s = t1 - t0;

    TimeHalted[0] = t0;
/*    TimeHalted[1] = in the PIT routine */
    TimeHalted[2] = t1;

    TimeHalted[3] = s;
    TimeHalted[4] += s;

    if (s > maxsleep) {
        maxsleep = s;
        printf("{%d}",maxsleep);
        PrintIrqCounts();
    }
#else
    ThePs->SysClockDisable = PSSC_CPU;
#endif
    UnusedParameter(Arg);
}

