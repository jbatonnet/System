/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>

const _TCHAR *FIRST_IMAGE_NAME = _T("tzk.cob");

const struct PRECOB ThePreCobTable[] = {
#if 1
    WINBIG_COBS
#else
    {_T("protocol.cob"), ShimProtocolCobMain }, \
    BASIC_SOAP_COBS
    PRIVATE_SOAP_COBS
#endif
    {0, 0}
};
