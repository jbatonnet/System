/* Header file for src/base/condition2.c
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef _OLDSCHED

#ifndef __CONDITION2_H__
#define __CONDITION2_H__

#include <util/list-single.h>
#include <assert.h>

extern PTR DeferredConditionSignals;

/* Concrete class.
 *
 * WAITERS is used to queue threads waiting on this condition.
 *
 * NEXTCOND is used to link all conditions that cannot be immediately
 * signalled at interrupt time (by Condition_InterruptSignal), so
 * that they get signalled as soon as the scheduler lock is released.
 * It is also used to remember if the condition has been interrupt-signalled.
 */

typedef struct _COND COND, *PCOND;

struct _COND { /* Internal definition */
  LIST lWaiterQueue; /* Circular queue of waiters */
  PCOND pCondNext;
};

#ifdef _DEBUG
/* This debug mechanism allows us to force the debugger into explicitly using
 * the private COND kernel struct so we can see its members.
 * ConditionPrologue must be after all variable declarations but before any
 * statements.
 */
#define Condition_Prologue() PCOND pCDProxy = pCD(pCond)
#define pCondArg pCDProxy
#else
#define Condition_Prologue()
#define pCondArg pCond
#endif /* _DEBUG */

/* Use volatile here to ensure that the compiler does NOT optimize/move
 * any loads/stores. Conditions are used/modified from ISRs etc,
 * we don't want any values cached in registers.
 */

#define pCD(pCond) ((volatile PCOND)(pCond))

/* These BOOLs are compressed into the lower 2 bits of pCondNext.
 * This only works because all supported architectures have a
 * word size >= 4 bytes.
 */
#define CD_SIGNALLED 0x1
#define CD_QUEUED 0x2
#define CD_INVERSE_MASK (CD_SIGNALLED | CD_QUEUED)
#define CD_MASK (~CD_INVERSE_MASK)

/* BAD_COND is a state after a condition has been signalled. */
#if _UINTSIZE == 16
#define BAD_COND (0x8FF0 | CD_SIGNALLED)
#endif
#if _UINTSIZE == 32
#define BAD_COND (0x8FFBAD00 | CD_SIGNALLED)
#endif
#if _UINTSIZE == 64
#define BAD_COND (0x8FFFFFFFFFBAD000 | CD_SIGNALLED)
#endif

#define /* BOOL */                                                            \
Condition_IsBad(/* PCOND */ _pcd_)                                            \
     (Condition_GetNext(_pcd_) == (PCOND)BAD_COND)

#define /* void */                                                            \
Condition_SetBad(/* PCOND */ _pcd_)                                           \
     ((pCD(_pcd_)->pCondNext) = (PCOND)BAD_COND)

#define /* PLIST */                                                           \
Condition_GetWaiterQueue(/* PCOND */ _pcd_)                                   \
     &(pCD(_pcd_)->lWaiterQueue)

#define /* void */                                                            \
Condition_WaiterQueueAddConstraint(/* PCOND */ _pcd_,                         \
                                  /* PKCONSTRAINT */ _pkc_)                   \
     (List_InsertSortedDescending(Condition_GetWaiterQueue(_pcd_),           \
                                 KConstraint_UrgencyGT,                       \
                                 KConstraint_GetWaitQueueNode(_pkc_)))

#define /* PKCONSTRAINT */                                                    \
Condition_WaiterQueueRemoveConstraint(/* PCOND */ _pcd_,                      \
                                     /* PKCONSTRAINT */ _pkc_)                \
     List_Remove(Condition_GetWaiterQueue(_pcd_),                             \
                 KConstraint_GetWaitQueueNode(_pkc_))

#define /* BOOL */                                                            \
Condition_WaiterQueueIsEmpty(/* PCOND */ _pcd_)                               \
     List_IsEmpty(Condition_GetWaiterQueue(_pcd_))

#define /* void */                                                            \
Condition_WaiterQueueInitialize(/* PCOND */ _pcd_)                            \
     List_Init(Condition_GetWaiterQueue(_pcd_))

#define /* PKCONSTRAINT */                                                    \
Condition_WaiterQueueRemoveMostUrgentConstraint(/* PCOND */ _pcd_)            \
     Node_GetData(List_HeadRemove(Condition_GetWaiterQueue(_pcd_)))

#define /* PCOND */                                                           \
Condition_GetNext(/* PCOND */ _pcd_)                                          \
     ((PCOND)(((UINT)(pCD(_pcd_)->pCondNext)) & CD_MASK))

#define /* BOOL */                                                            \
Condition_IsAloneAndCleared(/* PCOND */ _pcd_)                                \
     (pCD(_pcd_)->pCondNext == NULL)

#define /* BOOL */                                                            \
Condition_IsAlone(/* PCOND */ _pcd_)                                          \
    (Condition_GetNext(_pcd_) == NULL)

#define /* void */                                                            \
Condition_SetNext(/* PCOND */ _pcd_,                                          \
                 /* PCOND */ _pcdNext_)                                       \
    (pCD(_pcd_)->pCondNext = (PCOND)(((UINT)(pCD(_pcdNext_)) & CD_MASK) | CD_QUEUED))

#define /* void */                                                            \
Condition_SetAloneAndCleared(/* PCOND */ _pcd_)                               \
    (pCD(_pcd_)->pCondNext = NULL)

#define /* void */                                                            \
Condition_SetSignalled(/* PCOND */ _pcd_)                                     \
     (pCD(_pcd_)->pCondNext =                                                 \
          ((PCOND)(((UINT)(pCD(_pcd_)->pCondNext)) | CD_SIGNALLED)))

#define /* void */                                                            \
Condition_ClearSignalled(/* PCOND */ _pcd_)                                   \
     (pCD(_pcd_)->pCondNext =                                                 \
          ((PCOND)(((UINT)(pCD(_pcd_)->pCondNext)) & ~CD_SIGNALLED)))

#define /* BOOL */                                                            \
Condition_IsSignalled(/* PCOND */ _pcd_)                                      \
     ((((UINT)(pCD(_pcd_)->pCondNext)) & CD_SIGNALLED) == CD_SIGNALLED)

#define /* void */                                                            \
Condition_SetQueued(/* PCOND */ _pcd_)                                        \
     (pCD(_pcd_)->pCondNext =                                                 \
          ((PCOND)(((UINT)(pCD(_pcd_)->pCondNext)) | CD_QUEUED)))

#define /* void */                                                            \
Condition_ClearQueued(/* PCOND */ _pcd_)                                      \
     (pCD(_pcd_)->pCondNext =                                                 \
          ((PCOND)(((UINT)(pCD(_pcd_)->pCondNext)) & ~CD_QUEUED)))

#define /* BOOL */                                                            \
Condition_IsQueued(/* PCOND */ _pcd_)                                         \
     ((((UINT)(pCD(_pcd_)->pCondNext)) & CD_QUEUED) == CD_QUEUED)

/* Pops the next condition off the signalled condition stack rooted at
 * pCond.
 */
PRIVATE INLINE PCOND
Condition_Pop(PCOND pCond)
{
  PCOND pCondNext;
  
  assert(pCond != NULL);
  
  pCondNext = Condition_GetNext(pCond);
  /* Set next to null and clear signalled and queued bits */
  Condition_SetAloneAndCleared(pCond);
  
  return pCondNext;
}

PRIVATE INLINE void
Condition_Push(PCOND pCond)
{
  /* This sets pCond's next and also sets its queued bit. */
  Condition_SetNext(pCond, DeferredConditionSignals);
  DeferredConditionSignals = pCond;
}

void
Condition_DrainDeferred(void);

void Condition_TimedOut(
    PCONDITION pCond
    );

#endif /* __CONDITION2_H__ */

#endif /* _OLDSCHED */
