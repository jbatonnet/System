/* dummy file */
static int foo;
