/* Copyright (c) Microsoft Corporation. All rights reserved. */

#if __GNUC__ >= 4
#define _WCHAR_T_DEFINED
#endif

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Get a pointer to the current process heap. */
IHeap *pHeap = CurrentHeap();
void *ptr = NULL;
BOOL OK;

ptr = pHeap->Alloc(HEAP_ZERO_MEMORY, 50, 0);
if(ptr==NULL) {
    _tprintf(_TEXT("Memory allocation failed.\n"));
    return 0;
} 
OK = SUCCEEDED(pHeap->Validate(0, ptr));
/* The variable OK should equal TRUE indicating valid memory. */
if(OK)
    _tprintf(_TEXT("The specified memory block is valid.\n"));
else
    _tprintf(_TEXT("The specified memory block is invalid.\n"));
/* END_SAMPLE */
return 0;
}
