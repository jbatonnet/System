/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <stdio.h>

int _tmain()
{
/* BEGIN_SAMPLE */
/* Pointer and reference to the current process. */
PIPROCESS pPrc = CurrentProcess();
PIMODULE pModule;
SCODE StatusCode;

/* Get the module that corresponds to our process. */
StatusCode = pPrc->v->QueryInterface(pPrc, &IID_IModule, (void **) &pModule);
if (FAILED(StatusCode)) {
    _tprintf(_TEXT("QueryInterface failed, sc =  %08x\n"), StatusCode);
    return 1;
}
_tprintf(_TEXT("Process is %08x, module is %08x.\n"),
         (ADDRESS) pPrc, (ADDRESS) pModule);
pModule->v->Release(pModule);
return 0;
/* END_SAMPLE */
}
