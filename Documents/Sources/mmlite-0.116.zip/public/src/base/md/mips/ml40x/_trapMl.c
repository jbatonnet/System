/* Copyright (c) Microsoft Corporation. All rights reserved. */
#define DBGLVL 0
#define DEVICE_ORDER LITTLE_ENDIAN
#include <mmlite.h>

# define CAUSE_EXCMASK 0x0000003f  //nb:including the low two bits0
# define CAUSE_INT     (4*0)
# define CAUSE_MOD     (4*1)
# define CAUSE_TLBL    (4*2)
# define CAUSE_TLBS    (4*3)
# define CAUSE_AdEL    (4*4)
# define CAUSE_AdES    (4*5)
# define CAUSE_IBE     (4*6)
# define CAUSE_DBE     (4*7)
# define CAUSE_Sys     (4*8)
# define CAUSE_Bp      (4*9)
# define CAUSE_RI      (4*10)
# define CAUSE_CpU     (4*11)
# define CAUSE_Ovf     (4*12)
# define CAUSE_CEMASK  0x30000000
# define CAUSE_CU1     0x10000000
# define CAUSE_IPMASK  0x0000ff00
# define CAUSE_BD      0x80000000

extern ADDRESS MMUFaultAddress(void);
extern void MMUEnter(UINT32 TlbHi, UINT32 TlbLo);

BOOL BoardTrap(CXTINFO *Context, UINT Cause)
{
    ADDRESS BadV;

    switch (Cause & CAUSE_EXCMASK)
    {
    case CAUSE_TLBL:
    case CAUSE_TLBS:
    case CAUSE_MOD:
        BadV = MMUFaultAddress() & 0xfffff000;
        MMUEnter(BadV, BadV | 0x700);
        //if ((Cause & CAUSE_BD) == 0)
          //  Context->pc -= 4;
        return FALSE;
    }

    return TRUE;
}

