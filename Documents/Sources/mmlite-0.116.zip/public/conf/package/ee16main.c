/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>

PIUNKNOWN Ee16CobMain(void);

PIUNKNOWN CobMain(void)
{
    return Ee16CobMain();
}
