/* Header file for standard binary tree definitions
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __TREE_H__
#define __TREE_H__

#include <util/util.h>

/******************************************************************************
 * Binary tree node definitions
 */

typedef struct _TNODE TNODE, *PTNODE, **PPTNODE;
typedef struct _TREE TREE, *PTREE, **PPTREE;

/* Macros for casting */
#define pTN(_ptn_)   ((PTNODE)(_ptn_))
#define ppTN(_pptn_) ((PPTNODE)(_pptn_))
#define pT(_pt_)     ((PTREE)(_pt_))

struct _TNODE {
  PTNODE ptnLeft;
  PTNODE ptnRight;
/*   PTNODE ptnParent; */
  PTR pData;
};

struct _TREE {
  PTNODE ptnRoot;
  CompareFunc cfSort;
};


/******************************************************************************
 * Binary tree node read macros
 */

#define /* BOOL */                                                            \
TNode_IsLeaf(/* PTNODE */ _ptn_)                                              \
    ((TNode_GetRight(_ptn_) == NULL) && (TNode_GetLeft(_ptn_) == NULL))

#define /* PTNODE */                                                          \
TNode_GetLeft(/* PTNODE */ _ptn_)                                             \
    (pTN(_ptn_)->ptnLeft)

#define /* PTNODE */                                                          \
TNode_GetRight(/* PTNODE */ _ptn_)                                            \
    (pTN(_ptn_)->ptnRight)

#define /* PTNODE */                                                          \
TNode_GetParent(/* PTNODE */ _ptn_)                                           \
    (pTN(_ptn_)->ptnParent)

#define /* PPTNODE */                                                         \
TNode_GetLeftPointer(/* PTNODE */ _ptn_)                                      \
    &(pTN(_ptn_)->ptnLeft)

#define /* PPTNODE */                                                         \
TNode_GetRightPointer(/* PTNODE */ _ptn_)                                     \
    &(pTN(_ptn_)->ptnRight)

#define /* BOOL */                                                            \
TNode_HasLeft(/* PTNODE */ _ptn_)                                             \
    (TNode_GetLeft(_ptn_) != NULL)

#define /* BOOL */                                                            \
TNode_HasRight(/* PTNODE */ _ptn_)                                            \
    (TNode_GetRight(_ptn_) != NULL)

#define /* PTR */                                                             \
TNode_GetData(/* PTNODE */ _ptn_)                                             \
    (pTN(_ptn_)->pData)

/******************************************************************************
 * Binary tree node write macros
 */

#define /* void */                                                            \
TNode_SetParent(/* PTNODE */ _ptn_, /* PTNODE */ _ptnParent_)                 \
    (TNode_GetParent(_ptn_) = pTN(_ptnParent_))

#define /* void */                                                            \
TNode_SetLeft(/* PTNODE */ _ptn_, /* PTNODE */ _ptnLeft_)                     \
    (TNode_GetLeft(_ptn_) = pTN(_ptnLeft_))

#define /* void */                                                            \
TNode_SetRight(/* PTNODE */ _ptn_, /* PTNODE */ _ptnRight_)                   \
    (TNode_GetRight(_ptn_) = pTN(_ptnRight_))

#define /* void */                                                            \
TNode_SetData(/* PTNODE */ _ptn_, /* PTR */ _ptr_)                            \
    (TNode_GetData(_ptn_) = _ptr_)

#define /* void */                                                            \
TNode_Init(/* PTNODE */ _ptn_)                                                \
    TNode_SetLeft(_ptn_, NULL);                                               \
    TNode_SetRight(_ptn_, NULL);                                              \
    TNode_SetData(_ptn_, NULL)


/******************************************************************************
 * Binary tree node function prototypes
 */

void 
TNode_RotateLeft(
    PPTNODE pptnParent
    );

void 
TNode_RotateRight(
    PPTNODE pptnParent
    );


PTNODE
TNode_Search(
    PTNODE pRoot,
    CompareFunc cfSort,
    PTR pKey
    );

PTNODE
TNode_ChildSuccessor(
    PTNODE pRoot
    );

PTNODE
TNode_ChildPredecessor(
    PTNODE pRoot
    );

void
TNode_Swap(
    PPTNODE pptn1,
    PPTNODE pptn2
    );

/******************************************************************************
 * Binary tree read macros
 */

#define /* BOOL */                                                            \
Tree_IsEmpty(/* PTREE */ _pt_)                                                \
    (Tree_GetRoot(_pt_) == NULL)

#define /* PTNODE */                                                          \
Tree_GetRoot(/* PTREE */ _pt_)                                                \
    (pT(_pt_)->ptnRoot)

#define /* CompareFunc */                                                     \
Tree_GetSortFunc(/* PTREE */ _pt_)                                            \
    (pT(_pt_)->cfSort)


/******************************************************************************
 * Binary tree write macros
 */

#define /* void */                                                            \
Tree_SetRoot(/* PTREE */ _pt_, /* PTNODE */ _ptnRoot_)                        \
    (Tree_GetRoot(_pt_) = pTN(_ptnRoot_))

#define /* void */                                                            \
Tree_SetSortFunc(/* PTREE */ _pt_, /* CompareFunc */ _cfSort_)                \
    (Tree_GetSortFunc(_pt_) = (CompareFunc)(_cfSort_))

#define /* void */                                                            \
Tree_Init(/* PTREE */ _pt_, /* CompareFunc */ _cfSort_)                       \
    Tree_SetRoot(_pt_, NULL);                                                 \
    Tree_SetSortFunc(_pt_, _cfSort_)


/******************************************************************************
 * Tree function prototypes
 */

static INLINE PTNODE
Tree_Search(
    PTREE ptThis,
    PTR pKey
    )
{
  return TNode_Search(Tree_GetRoot(ptThis), Tree_GetSortFunc(ptThis), pKey);
}

#endif /* __TREE_H__ */
