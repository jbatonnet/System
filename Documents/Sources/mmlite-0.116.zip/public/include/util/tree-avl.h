/* tree-avl.h
 * Header file for AVL trees.
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __TREE_AVL_H__
#define __TREE_AVL_H__

#include <mmlite.h>
#include <util/tree.h>
#include <assert.h>

typedef struct _ATNODE ATNODE, *PATNODE, **PPATNODE;

/* Macros for casting */
#define pATN(_patn_)   ((PATNODE)(_patn_))
#define ppATN(_ppatn_) ((PPATNODE)(_ppatn_))
#define pAT(_pat_)     ((PAVLTREE)(_pat_))

typedef enum {
  HEIGHT_UNCHANGED,
  HEIGHT_GROWN,
  HEIGHT_SHRUNK,
  DUPLICATE_KEY,
  SUCCESS,
  KEY_NOT_FOUND
} TREE_RESULT_ENUM;

typedef enum {
  DOUBLE_RIGHT_HEAVY = +2,
  RIGHT_HEAVY        = +1,
  BALANCED           =  0,
  LEFT_HEAVY         = -1,
  DOUBLE_LEFT_HEAVY  = -2,
} BALANCE_ENUM;

struct _ATNODE {
  TNODE tnNode;
  BALANCE_ENUM balanceFactor;
};

typedef struct _AVLTREE {
  TREE tBase;
  ATNODE atnSentinel;
} AVLTREE, *PAVLTREE;


/******************************************************************************
 * AVL tree node read macros and inline functions
 */

INLINE BOOL
ATNode_IsLeaf(PATNODE patn) { 
  return TNode_IsLeaf(pTN(patn));
}

INLINE PATNODE
ATNode_ChildSuccessor(PATNODE patn) {
  return pATN(TNode_ChildSuccessor(pTN(patn)));
}

INLINE PATNODE
ATNode_ChildPredecessor(PATNODE patn) {
  return pATN(TNode_ChildPredecessor(pTN(patn)));
}

INLINE PTR
ATNode_GetData(PATNODE patn) {
  return TNode_GetData(pTN(patn));
}

INLINE PATNODE
ATNode_GetLeft(PATNODE patn) {
  return pATN(TNode_GetLeft(pTN(patn)));
}

INLINE PATNODE
ATNode_GetRight(PATNODE patn) {
  return pATN(TNode_GetRight(pTN(patn)));
}

INLINE PPATNODE
ATNode_GetLeftPointer(PATNODE patn) {
  return ppATN(TNode_GetLeftPointer(pTN(patn)));
}

INLINE PPATNODE
ATNode_GetRightPointer(PATNODE patn) {
  return ppATN(TNode_GetRightPointer(pTN(patn)));
}

INLINE BOOL
ATNode_HasLeft(PATNODE patn) {
  return TNode_HasLeft(pTN(patn));
}

INLINE BOOL
ATNode_HasRight(PATNODE patn) {
  return TNode_HasRight(pTN(patn));
}

INLINE BALANCE_ENUM
ATNode_GetBalance(PATNODE patn) {
  return patn->balanceFactor;
}

INLINE BOOL
ATNode_IsBalanced(PATNODE patn) {
  return (ATNode_GetBalance(patn) == BALANCED);
}

INLINE PATNODE
ATNode_Search(PATNODE patn,
              CompareFunc cfSort,
	      PTR pKey) {
  return pATN(TNode_Search(pTN(patn), cfSort, pKey));
}


/******************************************************************************
 * ATNode write wrappers for TNode methods
 */

INLINE void
ATNode_SetData(PATNODE patn, PTR pData) {
  TNode_SetData(pTN(patn), pData);
}

INLINE void
ATNode_SetLeft(PATNODE patn, PATNODE patnLeft) {
  TNode_SetLeft(pTN(patn), patnLeft);
}

INLINE void
ATNode_SetRight(PATNODE patn, PATNODE patnRight) {
  TNode_SetRight(pTN(patn), patnRight);
}

INLINE void
ATNode_SetBalance(PATNODE patn, BALANCE_ENUM bf) {
  patn->balanceFactor = bf;
}

INLINE  void
ATNode_Init(PATNODE patn) {
  TNode_Init(pTN(patn));
  ATNode_SetBalance(patn, BALANCED);
}

INLINE void
ATNode_Swap(PPATNODE ppatn1, PPATNODE ppatn2) {
  TNode_Swap(ppTN(ppatn1), ppTN(ppatn2));
}

/* We don't have to worry about dereferencing a null patn, since a sentinel
 * is always placed to the left */
#define /* BOOL */                                                            \
ATNode_IsSentinel(/* PATNODE */ patn)                                         \
  ((ATNode_GetLeft(patn) == patn) || (ATNode_GetRight(patn) == patn))

/******************************************************************************
 * AVL tree node function prototypes and inline definitions
 */

INLINE void 
ATNode_AdjustLeft(PATNODE pNode)
{
  pNode->balanceFactor--;
  assert(ATNode_GetBalance(pNode) >= DOUBLE_LEFT_HEAVY);
}

INLINE void 
ATNode_AdjustRight(PATNODE pNode)
{
  pNode->balanceFactor++;
  assert(ATNode_GetBalance(pNode) <= DOUBLE_RIGHT_HEAVY);
}

INLINE void 
ATNode_AdjustDoubleLeft(PATNODE pNode)
{
  pNode->balanceFactor -= 2;
  assert(ATNode_GetBalance(pNode) >= DOUBLE_LEFT_HEAVY);
}

INLINE void 
ATNode_AdjustDoubleRight(PATNODE pNode)
{
  pNode->balanceFactor += 2;
  assert(ATNode_GetBalance(pNode) <= DOUBLE_RIGHT_HEAVY);
}

INLINE void
ATNode_RotateLeft(
    PPATNODE ppNode, /* Node to rotate about */
    BOOL bSingle     /* Is this a single-heavy rotation in CASE 3/4 insert? */
    )
{
  PATNODE pNode;
  PATNODE pRight;

  assert(ppNode != NULL);
  pNode = *ppNode;
  assert(pNode != NULL);
  pRight = ATNode_GetRight(pNode);
  ATNode_AdjustLeft(pRight);
  if (bSingle) {
    ATNode_AdjustLeft(pNode);
    assert(ATNode_GetBalance(pRight) == LEFT_HEAVY);
  }
  else {
    ATNode_AdjustDoubleLeft(pNode);
/*     assert(ATNode_IsBalanced(pRight)); */
  }
  assert(ATNode_IsBalanced(pNode));
  TNode_RotateLeft((PPTNODE)ppNode);
}

INLINE void
ATNode_RotateRight(
    PPATNODE ppNode, /* Node to rotate about */
    BOOL bSingle     /* Is this a single-heavy rotation in CASE 3/4 insert? */
    )
{
  PATNODE pNode;
  PATNODE pLeft;

  assert(ppNode != NULL);
  pNode = *ppNode;
  assert(pNode != NULL);
  pLeft = ATNode_GetLeft(pNode);
  ATNode_AdjustRight(pLeft);
  if (bSingle) {
    ATNode_AdjustRight(pNode);
    assert(ATNode_GetBalance(pLeft) == RIGHT_HEAVY);
  }
  else {
    ATNode_AdjustDoubleRight(pNode);
/*     assert(ATNode_IsBalanced(pLeft)); */
  }
  assert(ATNode_IsBalanced(pNode));
  TNode_RotateRight((PPTNODE)ppNode);
}

/******************************************************************************
 * PUBLIC AVL TREE READ MACROS
 */
#define /* PATNODE */                                                         \
AVLTree_GetRoot(/* PAVLTREE */ _pat_)                                         \
    (pATN(Tree_GetRoot(_pat_)))

#define /* CompareFunc */                                                     \
AVLTree_GetSortFunc(/* PAVLTREE */ _pat_)                                     \
    (Tree_GetSortFunc(_pat_))

INLINE PATNODE
AVLTree_GetSentinel(PAVLTREE pat)
{
  PATNODE pSentinel = &pat->atnSentinel;
  /* The sentinel node's children point to itself as a marker */
  ATNode_SetLeft(pSentinel, pSentinel);
  ATNode_SetRight(pSentinel, pSentinel);
  return pSentinel;
}


/******************************************************************************
 * AVL tree write macros
 */

#define /* void */                                                            \
AVLTree_SetRoot(/* PAVLTREE */ _pat_, /* PATNODE */ _patn_)                   \
    (Tree_SetRoot(pT(_pat_), pTN(_patn_)))

#define /* void */                                                            \
AVLTree_SetSortFunc(/* PAVLTREE */ _pat_, /* CompareFunc */ _cf_)             \
    (Tree_SetSortFunc(_pat_, _cf_))

#define /* void */                                                            \
AVLTree_Init(/* PAVLTREE */ _pat_, /* CompareFunc */ _cf_)                    \
  Tree_Init(pT(_pat_), _cf_)

#define /* BOOL */                                                            \
AVLTree_IsEmpty(/* PAVLTREE */ _pat_)                                         \
  Tree_IsEmpty(pT(_pat_))

#define /* PATNODE */                                                         \
AVLTree_Search(/* PAVLTREE */ _pat_, /* PTR */ _pKey_)                        \
  ((PATNODE)Tree_Search(pT(_pat_), _pKey_))


/******************************************************************************
 * AVL tree function prototypes
 */

TREE_RESULT_ENUM 
AVLTree_Insert(
    PAVLTREE pThis,
    PATNODE pNew
);

TREE_RESULT_ENUM
AVLTree_Remove(
    PAVLTREE pThis,
    PATNODE pRemove
    ); 

#endif /* __TREE_AVL_H__ */
