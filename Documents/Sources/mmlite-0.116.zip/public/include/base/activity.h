/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef __activity_h__
#define __activity_h__

#include <util/list-single.h>
#include <base/schedul.h>
#include <base/mutex2.h>
#include <base/condition2.h>
#include <base/kconstraint2.h>
#include <base/tconstraint2.h>

typedef struct _ACTINFO ACTINFO, *PACTINFO;

typedef enum _ACTIVITY_STATE_ENUM {
  ACTIVITY_READY,           /* 0 - Able to be run but not yet running        */
  ACTIVITY_RUNNING,         /* 1 - Current thread (for a given cpu)          */
  ACTIVITY_DEAD,            /* 2 - Going away                                */
  ACTIVITY_SLEEPING,        /* 3 - Suspended                                 */
  ACTIVITY_WAITING,         /* 4 - Waiting for a timeout, mutex, or cond     */
  ACTIVITY_STARTING         /* 5 - just added to the scheduler               */
} ACTIVITY_STATE_ENUM;

typedef enum _ACTIVITY_WAIT_ENUM {
  ACTIVITY_WAIT_NONE,
  ACTIVITY_WAIT_MUTEX,
  ACTIVITY_WAIT_CONDITION
} ACTIVITY_WAIT_ENUM;


#define ACTIVITY_IDLE_BIT 0x1
#define ACTIVITY_IDLE_MASK (~ACTIVITY_IDLE_BIT)
#define ACTIVITY_IDLE_INVERSE_MASK ACTIVITY_IDLE_BIT

struct _ACTINFO {
  const struct IActivityVtbl *v;
  UINT RefCount;             /* Reference count (see below)               */
  SCODE LastError;         /* Get/SetLastError                          */
  PIPROCESS StartedIn;     /* initially created in this process/module  */
  KCONSTRAINT Constraint;
  LIST lMutexList;           /* List of mutexes owned by this activity */
  PACTINFO pThread;        /* underlying thread, if any */
  NODE nQueueNode;
  NODE nWaitNode;
  ACTIVITY_STATE_ENUM State;   /* What to do at context switch              */
  ACTIVITY_WAIT_ENUM WaitState;
  PTR pWaitObject;           /* What object am I waiting on               */
/*   PACTINFO pWard;            /\* activity we are acting as a surrogate for *\/ */
};

#define pACT(_pAct_)  ((PACTINFO) (_pAct_))

#ifdef _DEBUG
/* This debug mechanism allows us to force the debugger into explicitly using
 * the private ACTINFO kernel struct so we can see its members.
 * ActivityPrologue must be after all variable declarations but before any
 * statements.
 */
#define Activity_Prologue() PACTINFO pActProxy = pACT(pAct)
#define pActArg pActProxy
#else
#define Activity_Prologue()
#define pActArg pAct
#endif /* _DEBUG */

/* #define /\* PACTINFO *\/                                                        \ */
/* Activity_GetWard(/\* PACTINFO *\/ _pAct_ )                                      \ */
/*      (pACT(_pAct_)->pWard) */

/* #define /\* void *\/                                                            \ */
/* Activity_SetWard(/\* PACTINFO *\/ _pAct_,                                       \ */
/*                  /\* PACTINFO *\/ _pWard_)                                      \ */
/*      (Activity_GetWard(_pAct_) = (_pWard_)) */

#define /* void */                                                            \
Activity_CopyConstraint(/* PACTINFO */ _pActDest_,                            \
                        /* PACTINFO */ _pActSrc_)                             \
  (pACT(_pActDest_)->Constraint = pACT(_pActSrc_)->Constraint)

#define /* void */                                                            \
Activity_SetVtable(/* PIACTIVITY */ _pAct_,                                   \
                   /* IActivityVtbl* */ _vt_)                                 \
  (pACT(_pAct_)->v = (struct IActivityVtbl*)(_vt_))

#define /* PKCONSTRAINT */                                                    \
Activity_GetConstraint(/* PIACTIVITY */ _pAct_)                               \
     &(pACT(_pAct_)->Constraint)

#define /* UINT */                                                           \
Activity_GetRefCount(/* PIACTIVITY */ _pAct_)                                \
  (pACT(_pAct_)->RefCount)

#define /* void */                                                            \
Activity_SetRefCount(/* PIACTIVITY */ _pAct_,                                 \
                     /* UINT */ _rc_)                                         \
     (Activity_GetRefCount(_pAct_) = (_rc_))

#define /* void */                                                            \
Activity_Process(/* PIACTIVITY */ _pAct_)                                  \
     (pACT(_pAct_)->StartedIn)

#define /* void */                                                            \
Activity_SetProcess(/* PIACTIVITY */ _pAct_,                                  \
                    /* PIPROCESS */ _pPrc_)                                   \
     (Activity_Process(_pAct_) = (_pPrc_))

#define /* SCODE */                                                           \
Activity_GetLastError(/* PIACTIVITY */ _pAct_)                                \
  (pACT(_pAct_)->LastError)

#define /* void */                                                            \
Activity_SetLastError(/* PIACTIVITY */ _pAct_,                                \
                   /* SCODE */ _sc_)                                          \
     (Activity_GetLastError(_pAct_) = (_sc_))

#define /* PLIST */                                                           \
Activity_GetMutexList(/* PACTINFO */ _pAct_)                                  \
     &(pACT(_pAct_)->lMutexList)

#define /* void */                                                            \
Activity_MutexListAdd(                                                        \
    /* PACTINFO */ _pAct_,                                                    \
    /* PMUTEX   */ _pmx_)                                                     \
  (List_TailAdd(Activity_GetMutexList(_pAct_), Mutex_GetListNode(_pmx_)))

#define /* void */                                                            \
Activity_MutexListRemove(                                                     \
    /* PACTINFO */ _pAct_,                                                    \
    /* PMUTEX   */ _pmx_)                                                     \
  (List_Remove(Activity_GetMutexList(_pAct_), Mutex_GetListNode(_pmx_)))

#define /* PACTINFO */                                                        \
Activity_GetThread(/* PIACTIVITY */ _pAct_)                                   \
  (pACT(_pAct_)->pThread)

#define /* void */                                                            \
Activity_SetThread(/* PIACTIVITY */ _pAct_,                                   \
                 /* PTHDINFO */ _pThd_)                                       \
     (Activity_GetThread(_pAct_) = pACT(_pThd_))

#define /* PNODE */                                                           \
Activity_GetNode(/* PACTINFO */ _pAct_)                                       \
     &(pACT(_pAct_)->nQueueNode)

#define /* PNODE */                                                           \
Activity_GetWaitNode(/* PACTINFO */ _pAct_)                                   \
     &(pACT(_pAct_)->nWaitNode)

#define /* THREAD_STATE_ENUM */                                               \
Activity_GetState(/* PACTINFO */ _pAct_ )                                     \
     (pACT(_pAct_)->State)

#define /* void */                                                            \
Activity_SetState(/* PACTINFO */ _pAct_,                                      \
                  /* ACTIVITY_STATE_ENUM */ _state_)                          \
     (Activity_GetState(_pAct_) = (_state_))

#define /* ACTIVITY_WAIT_ENUM */                                              \
Activity_GetWaitState(/* PACTINFO */ _pAct_ )                                 \
     (pACT(_pAct_)->WaitState)

#define /* void */                                                            \
Activity_SetWaitState(/* PACTINFO */ _pAct_,                                  \
               /* ACTIVITY_WAIT_ENUM */ _state_)                              \
     (Activity_GetWaitState(_pAct_) = (_state_))

#define /* PTR */                                                             \
Activity_GetWaitObject(/* PACTINFO */ _pAct_)                                 \
     ((PTR)((UINT)(pACT(_pAct_)->pWaitObject) & ACTIVITY_IDLE_MASK))

#define /* void */                                                            \
Activity_SetWaitObject(/* PITHREAD */ _pAct_,                                 \
                       /* PTR */ _ptr_)                                       \
     (pACT(_pAct_)->pWaitObject = (PTR)(((UINT)(_ptr_) & ACTIVITY_IDLE_MASK) | ((UINT)(pACT(_pAct_)->pWaitObject) & ACTIVITY_IDLE_INVERSE_MASK)))

#define /* void */                                                            \
Activity_ClearWaiting(/* PACTINFO */ _pAct_)                                  \
     Activity_SetState((_pAct_), ACTIVITY_READY);                             \
     Activity_SetWaitState((_pAct_), ACTIVITY_WAIT_NONE);                     \
     Activity_SetWaitObject((_pAct_), NULL)

#define /* void */                                                            \
Activity_MutexListInitialize(/* PACTINFO */ _pAct_)                           \
     List_Init(Activity_GetMutexList(_pAct_));

#define /* void */                                                            \
Activity_SetWaiting(/* PACTINFO */ _pAct_,                                    \
                 /* WAIT_STATE_ENUM */ _wse_,                                 \
                 /* PTR */ _pWaitObject_)                                     \
     Activity_SetState((_pAct_), ACTIVITY_WAITING);                          \
     Activity_SetWaitState((_pAct_), (_wse_));                                \
     Activity_SetWaitObject((_pAct_), (_pWaitObject_))

#define /* BOOL */                                                            \
Activity_IsDead(/* PACTINFO */ _pAct_)                                        \
  (Activity_GetState(_pAct_) == ACTIVITY_DEAD)

#define /* BOOL */                                                            \
Activity_IsRunning(/* PACTINFO */ _pAct_)                                     \
  (Activity_GetState(_pAct_) == ACTIVITY_RUNNING)

#define /* BOOL */                                                            \
Activity_IsWaiting(/* PACTINFO */ _pAct_)                                     \
  (Activity_GetWaitState(_pAct_) != ACTIVITY_WAIT_NONE)

#define /* BOOL */                                                            \
Activity_IsReady(/* PACTINFO */ _pAct_)                                       \
  (Activity_GetState(_pAct_) == ACTIVITY_READY   )

#define /* BOOL */                                                            \
Activity_IsStarting(/* PACTINFO */ _pAct_)                                    \
  (Activity_GetState(_pAct_) == ACTIVITY_STARTING   )

#define /* BOOL */                                                            \
Activity_IsIdle(_pAct_)                                                         \
    (((UINT)(pACT(_pAct_)->pWaitObject) & ACTIVITY_IDLE_BIT) == ACTIVITY_IDLE_BIT)

#define /* void */                                                            \
Activity_SetIdle(_pAct_)                                                        \
    (pACT(_pAct_)->pWaitObject = (PTR)((UINT)(pACT(_pAct_)->pWaitObject) | ACTIVITY_IDLE_BIT))

#define /* void */                                                            \
Activity_ClearIdle(_pAct_)                                                      \
    (pACT(_pAct_)->pWaitObject = (PTR)((UINT)(pACT(_pAct_)->pWaitObject) & ~ACTIVITY_IDLE_BIT))

#define /* BOOL */                                                            \
Activity_IsWaiting(/* PACTINFO */ _pAct_)                                     \
   (Activity_GetWaitState(_pAct_) != ACTIVITY_WAIT_NONE)

#define /* BOOL */                                                            \
Activity_IsSleeping(_pAct_)                                                   \
   (Activity_IsWaitingForTimeout(_pAct_))

#define /* BOOL */                                                            \
Activity_IsWaitingForTimeout(/* PACTINFO */ _pAct_)                           \
   (Activity_GetState(_pAct_) == ACTIVITY_SLEEPING)

#define /* BOOL */                                                            \
Activity_IsWaitingForMutex(/* PACTINFO */ _pAct_)                             \
     (Activity_GetWaitState(_pAct_) == ACTIVITY_WAIT_MUTEX)

#define /* BOOL */                                                            \
Activity_IsWaitingForCondition(/* PACTINFO */ _pAct_)                         \
     (Activity_GetWaitState(_pAct_) == ACTIVITY_WAIT_CONDITION)



SCODE MCT
Activity_QueryInterface( 
    PIACTIVITY pThis,
    /* [in] */ REFIID pIid,
    /* [out] */ void **ppUnk
    );

UINT MCT
Activity_AddRef(
    PIACTIVITY pThis
    );

UINT MCT
Activity_Release(
    PIACTIVITY pThis
    );

PIPROCESS MCT
Activity_GetProcess (
    PIACTIVITY pThis
    );

SCODE MCT
Activity_CreateThread( 
    PIACTIVITY pAct,
    PIPROCESS pProcess,
    THREAD_FUNCTION pStart,
    THREAD_ARGUMENT Arg,
    ADDR_SIZE StackSize,
    PIVMVIEW pVmView,
    /* [out] */ PIACTIVITY* ppNewActivity
    );

SCODE MCT 
Activity_CreateWorkItem( 
    PIACTIVITY pAct,
    PIPROCESS pProcess,
    WORK_FUNCTION pStart,
    WORK_ARGUMENT Arg,
    WORK_SWITCH_FUNCTION SwitchFunction,
    /* [out] */ PIACTIVITY* ppNewActivity
    );

TIME MCT
Activity_GetTimeUsage(
    PIACTIVITY pAct
    );

PRIVATE INLINE void
Activity_Init(
    PACTINFO pAct,
    PIPROCESS StartedIn,
    const struct IActivityVtbl* Vtbl
    )
{
  Activity_SetVtable(pAct, Vtbl);
  /* Subclasses of activity should set their own ref count appropriately */
/*   Activity_SetRefCount(pAct, 0); */
  Activity_SetThread(pAct, NULL);
  Activity_SetProcess(pAct, StartedIn);
  Activity_ClearIdle(pAct);
  KConstraint_Init(Activity_GetConstraint(pAct), NULL);
  Node_Init(Activity_GetNode(pAct), pAct);
  Node_Init(Activity_GetWaitNode(pAct), pAct);
  Activity_MutexListInitialize(pAct);
  List_Init(Activity_GetMutexList(pAct));
  Activity_SetWaiting(pAct, ACTIVITY_WAIT_NONE, NULL);
  /* This must go after SetWaiting to avoid stomping on activity state */
  Activity_SetState(pAct, ACTIVITY_STARTING);
}

void
Activity_Exit(
    PACTINFO pAct
    );

void 
Activity_UnlockMutexes(
     PACTINFO pAct
     );


#endif /* __activity_h__ */
