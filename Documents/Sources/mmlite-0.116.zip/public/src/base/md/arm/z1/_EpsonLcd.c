/* Copyright (c) Microsoft Corporation. All rights reserved. */

/*
 * Console display for Epson SED15E0 based LCD display on Zenith board
 *
 * Reference:
 * "SED15E0 Data Sheet" Rev: MF1241-03 Preliminary
 * Seiko Epson Corporation, 2000
 */
#include <mmlite.h>
#include <tchar.h>

#define CTRL_L '\014'

/* A few simple macos to access the LCD registers
 */
volatile UINT8 *lcd = (volatile UINT8*)0x20000000;

#define LcdWriteData(_c_) \
{\
     lcd[1] = (UINT8)(_c_);\
}

#define LcdReadData()      (lcd[1])


#define LcdWriteControl(_c_) \
{\
     lcd[0] = (UINT8)_c_;\
}

#define LcdSetPointer(_row_,_col_) \
{\
     LcdWriteControl(0xb0 | ((_row_)&0xf));\
     LcdWriteControl(0x10 | (((_col_)>>4)&0xf));\
     LcdWriteControl(0x00 | ((_col_)&0xf));\
}

/* Power-on sequence for the LCD
 */
void LcdInit(void)
{
    /* Turning on the oscillator */
    LcdWriteControl(0x50);
    LcdWriteControl(0xab);


    /* PowerOn */
    LcdWriteControl(0x27);

    /* Turning off powersave */
    LcdWriteControl(0xe1);

    /* DisplayOn */
    LcdWriteControl(0xaf);


    /* Adjusting contrast */
    LcdWriteControl(0x81);
    LcdWriteControl(0x40);

}

/* FONTING */

#define FirstVisibleLcdColumn 12
#define FirstVisibleLcdRow    0
#define LcdRamSize (96*132)

#define ffont ffont_S
#include "font8x8.c"
#define FontHeight 8
#define FontWidth 8
#if    (FontHeight==8)
#    define TIMES_FontHeight(w)    ((w)<<3)
#else
#    define TIMES_FontHeight(w)    ((w)*FontHeight)
#endif

#define NumRows 15
#define NumColumns 12
#define FirstVisibleColumn 0
#define LastVisibleColumn (NumColumns-1)
#define FirstVisibleSpot (FirstVisibleColumn)

static UINT cursor = FirstVisibleSpot;

/*
 * Routine to paint an 8x8 char on an Epson LCD.
 */
void PaintCharAt_S(
    int        c,
    int        row,
    int        col)
{
    int           j;
    unsigned char *font;

    /* Maping from logical coords to the LCD coords.
     *
     * With an 8x8 font we have plenty of choices for the mapping.
     * An 8x8 font results in a 15x12 (or 12x15) text terminal.
     * One consideration (but its probably not a huge deal) is
     * that we can minimize repositioning of the RAM pointer
     * by re-orienting the LCD 90 degrees left or right.
     * Using the same left-rotation as above:
     * (0,0)==>(11,0), (0,11)==>(0,0), (29,0)==>(11,29), (29,11)==>(0,29)
     * And in general (r,c)==>(11-c,r)
     * After that, consider the size of a single character.
     */
    j = col;
    col = TIMES_FontHeight(row) + FirstVisibleLcdColumn;
    row = (11 - j) + FirstVisibleLcdRow;

    font = ffont_S(c);

    /* 8 pixels per byte
     */
    LcdSetPointer(row,col);
    for (j = 0; j < FontHeight; j++)
        LcdWriteData(*font++);
}

/*
 * Simulate a textual display
 */
BOOL putDebugChar( UINT8 c)
{
    int i;

    switch (c) {
    case CTRL_L:                   /* ^L == clear screen and home cursor */
        cursor = FirstVisibleSpot;
        LcdSetPointer(0,0);
        for (i = 0; i < LcdRamSize; i++)
            LcdWriteData(0);
        break;

    case '\b':
        if ((cursor % NumColumns) > FirstVisibleColumn) {
            /* Clear previous char and move cursor back
             */
            cursor--;
            PaintCharAt_S(' ',
                        (cursor / NumColumns) % NumRows,
                        cursor % NumColumns);
        }
        break;

    case '\n':
        cursor += NumColumns;
        /* fall through - translate LF -> CRLF */

    case '\r':
        cursor = cursor - (cursor % NumColumns) + FirstVisibleColumn;
        break;

    default:
        /* Just paint */
        PaintCharAt_S( c,
                    (cursor / NumColumns) % NumRows,
                    cursor % NumColumns);
        cursor++;
        break;
    }

    /* Scroll ? */
    if (cursor >= NumColumns*NumRows) {

#if 1
        /* I wish I could */
        cursor = FirstVisibleColumn;
#else
        static int scroll = 0;

        scroll += 4;
        if (scroll >= 96) scroll = 0;
        LcdWriteControl(0x8a);
        LcdWriteControl(scroll);

        scroll += 4;
        if (scroll >= 96) scroll = 0;
        LcdWriteControl(0x8a);
        LcdWriteControl(scroll);

        cursor -= NumColumns;
#endif
    }

    return TRUE;
}

