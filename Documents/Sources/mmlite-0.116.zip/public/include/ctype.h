/* Copyright (c) Microsoft Corporation. All rights reserved. */
/***
 * ctype.h - definitions/declarations for character handling routines
 *
 * Purpose:
 *      This file defines the structures, values, macros, and functions
 *      used by the character testing&manipulation routines.
 * Reference:
 *      ISO/IEC 9899 : 1990 (E) "Programming languages -- C "
 *      Section 7.3 "Character handling <ctype.h>" pagg 102-105.
 *
 ***/

#ifndef _INC_CTYPE
#define _INC_CTYPE 1

#define _U      0x01
#define _L      0x02
#define _N      0x04
#define _S      0x08
#define _P      0x10
#define _C      0x20
#define _X      0x40
#define _B      0x80

extern  const char __ctype[];

#define isalnum(c)      ((__ctype+1)[(unsigned int)c]&(_U|_L|_N))
#define isalpha(c)      ((__ctype+1)[(unsigned int)c]&(_U|_L))
#define iscntrl(c)      ((__ctype+1)[(unsigned int)c]&_C)
#define isdigit(c)      ((__ctype+1)[(unsigned int)c]&_N)
#define isgraph(c)      ((__ctype+1)[(unsigned int)c]&(_P|_U|_L|_N))
#define islower(c)      ((__ctype+1)[(unsigned int)c]&_L)
#define isprint(c)      ((__ctype+1)[(unsigned int)c]&(_P|_U|_L|_N|_B))
#define ispunct(c)      ((__ctype+1)[(unsigned int)c]&_P)
#define isspace(c)      ((__ctype+1)[(unsigned int)c]&_S)
#define isupper(c)      ((__ctype+1)[(unsigned int)c]&_U)
#define isxdigit(c)     ((__ctype+1)[(unsigned int)c]&(_N|_X))
#define tolower(c)      ( (isupper(c)) ? ((c)-'A'+'a') : (c) )
#define toupper(c)      ( (islower(c)) ? ((c)-'a'+'A') : (c) )

#ifndef _INC_WCTYPE
/* This only works for ISO-LATIN-1, sorry.
 */
#define iswalnum(c)     isalnum((unsigned char)c)
#define iswalpha(c)     isalpha((unsigned char)c)
#define iswcntrl(c)     iscntrl((unsigned char)c)
#define iswdigit(c)     isdigit((unsigned char)c)
#define iswgraph(c)     isgraph((unsigned char)c)
#define iswlower(c)     islower((unsigned char)c)
#define iswprint(c)     isprint((unsigned char)c)
#define iswpunct(c)     ispunct((unsigned char)c)
#define iswspace(c)     isspace((unsigned char)c)
#define iswupper(c)     isupper((unsigned char)c)
#define iswxdigit(c)    isxdigit((unsigned char)c)
#define towlower(c)     ( (iswupper(c)) ? ((c)-_T('A')+_T('a')) : (c) )
#define towupper(c)     ( (iswlower(c)) ? ((c)-_T('a')+_T('A')) : (c) )

#endif /* _INC_WCTYPE */

#endif /* _INC_CTYPE */
