/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * P6 Advance Interrupt Controller (APIC) support.
 */

#define DBGLVL DBGLVL_NOISE

#define DEVICE_ORDER LITTLE_ENDIAN
#include <mmlite.h>
#include <mmhal.h>
#include <mmmacros.h>
#include <limits.h>
#include <base/bitmap.h>
#include <base/schedul.h>
#include <schedulif.h>
#include <drivers/drivers.h>
#include <fred.h>
#include "_pic.h"
#include <i386/x86_cpu.h>

/*
 * Define the virtual address of the P6 APIC hardware.
 */
#define PhysicalToLogical(a) (a - 0x20000)
#define LogicalToPhysical(a) (a + 0x20000)
#define P6APIC() ((volatile I586_APIC *)PhysicalToLogical(APIC_PHYSICAL_ADDRESS))

#define IRQ_ID_COUNT (128)
#define MIN_IRQ 42 /* 0-35 old PIC, 36-41 Local. */
#define LOCAL_IRQ_BASE 20 //36
#define APIC_DIVIDER 2          /* use APIC_TIMER_DIVIDER_2 =0 */

/*** Some forward decls ***/
extern void __cdecl _ApicInterrupt(void);
extern void __cdecl ApicTimerInterrupt(void);
void RTCWaitForTransition(void);
void PrintGdt();

#define OFFSETOF_INTR(_i_) (((_i_) * 4) + (8 * ((_i_) / 32)))
#define Reflect(_n_) (((ADDRESS) _ApicInterrupt) + OFFSETOF_INTR(_n_))

/*** Local types ***/
typedef struct _ITABLE {
    INTERRUPT_SERVICE_ROUTINE Isr;  /* isr for IRQn*/
    void *pDevice;                  /* Argument to pass to ISR */
#ifdef _STATISTICS
    UINT32 Count;
#endif
} ITABLE;

/* The interrupt dispatcher uses a simple table of handlers. */
typedef struct _APIC {
    const struct IPicVtbl *v;
    UINT32 Enabled;
    ITABLE InterruptTable[IRQ_ID_COUNT * 8]; /* XXX x8 is for compiler warn */
    UINT32 LastDecrementer;
    UINT64 TicksSinceBoot;
} APIC;

/* Utilities
 */
/*
 * The P6 APIC registers are physically stored in little endian
 * format.
 */
INLINE UINT32 APicReadRegister32(volatile UINT32 *Address)
{
    UINT32 r = *Address;
    r = _bs32(r);
    return r;
}

INLINE void APicWriteRegister32(volatile UINT32 *Address, UINT32 Value)
{
    Value = _bs32(Value);
    *Address = Value;
    IOMemoryBarrier();
}

#if _DEBUG
PRIVATE void DumpRegisters(volatile I586_APIC *Pic, char *When)
{
    UINT32 v;

    PrintGdt();

    _tprintf(_T("APIC @%x, register dump %s\n"),(ADDRESS)Pic,When);

    //#define dump_a(off) printf("@%x: %x\n", (ADDRESS) Pic + off, *(UINT32 *)((ADDRESS) Pic + off))

#define dump(x) { \
    v = APicReadRegister32(&Pic->x); \
    _tprintf(_T("%s @%p: %x\n"), # x ,&Pic->x,v); \
}
#define dump8(x) { \
    v = Pic->x; \
    _tprintf(_T("%s @%p: %x\n"), # x ,&Pic->x,v); \
}

    dump(LocalId);
    dump(Version);
    dump(TaskPriority);
    dump(ArbitrationPriority);
    dump(ProcessorPriority);
    dump(Destination);
    dump(DestinationFormat);
    dump(SpuriousVector);

    dump(Isr[0].val);
    dump(Tsr[0].val);
    dump(Irr[0].val);

    dump(ErrorStatus);
    dump(LvtCmgi);
    dump(InterruptCommand);
    dump(LocalVectorTimer);
    dump(LocalVectorThermal);
    dump(LocalVectorPerformance);
    dump(LocalVectorLINT0);
    dump(LocalVectorLINT1);
    dump(LocalVectorError);
    dump(TimerInitial);
    dump(TimerCurrent);
    dump(TimerConfiguration);
#undef dump
#undef dump_a

    //assert((ADDRESS) &Pic->TimerConfiguration == 0xfee003e0);
    assert(sizeof(*Pic) == 0x400);
}
#else
#define DumpRegisters(x,n)
#endif

#if 1
void SearchForPCIBios()
{
#define BIOS_START 0xe0000
#define BIOS_LENGTH 0x20000
#define BIOS_PATTERN 0x5f32335f
    ADDRESS a = PhysicalToLogical(BIOS_START);
    ADDRESS end = PhysicalToLogical(BIOS_START + BIOS_LENGTH);
    UINT32 val;

    for (; a < end; a++) {
        val = *(UINT32*)a;
        if (val  == BIOS_PATTERN)
            printf("Found PCI BIOS pattern at %08x\n", a);
    }
}

void SearchForAnything()
{
    ADDRESS a = PhysicalToLogical(APIC_PHYSICAL_ADDRESS);
    ADDRESS end = PhysicalToLogical(APIC_PHYSICAL_ADDRESS);
    UINT32 val;

    for (; a < end; a++) {
        val = *(UINT32*)a;
        if (val  != 0xffffffff) {
            printf("Found Something at %08x (val=%08x)\n", a, val);
            break;
        }
    }

    a = PhysicalToLogical(APIC_PHYSICAL_ADDRESS);
    for (; a < end; a++) {
        val = *(UINT32*)a;
        if ((val & 0xff) == 0x14) {
            printf("Found 0x14 at %08x (val=%08x)\n", a, val);
        }
    }
}

/* See dosxtnedr.asm fr segment numbers */
#define SEG_KD 1
#define SEG_KC 2
#define SEG_RD 3
#define SEG_RC 4
#define SEG_UD 5
#define SEG_UC 6
#define SEG_TCB 7
#define SEG_TSS 8
#define SEG_PHYS 9

void CopyFromReallyPhys(char *Dst, UINT32 Phys, UINT NBytes)
{
    UINT32 _gs = (SEG_PHYS << 3);
    UINT i;
    char cc;

    DBG(("CopyFromReallyPhys(%p %x %x)\n", Dst, Phys, NBytes));
    __asm {
        mov eax, _gs;
        mov gs, ax;
    }

    for (i = 0; i < NBytes; i++) {
        __asm {
            mov eax, Phys;
            mov cl, gs:[eax];
            mov cc, cl;
        }
        *Dst = cc;

        Phys++;
        Dst++;
    }
}

void CopyToReallyPhys(char *Src, UINT32 Phys, UINT NBytes)
{
    UINT32 _gs = (SEG_PHYS << 3);
    UINT i;
    char cc;

    DBG(("CopyToReallyPhys(%p %x %x)\n", Src, Phys, NBytes));
    __asm {
        mov eax, _gs;
        mov gs, ax;
    }

    for (i = 0; i < NBytes; i++) {
        cc = *Src;
        __asm {
            mov eax, Phys;
            mov cl, cc;
            mov gs:[eax], cl;
        }

        Phys++;
        Src++;
    }
}

void PrintSeg(UINT Index, I386_SEGMENT_DESCRIPTOR *Seg)
{
    printf("Seg %d %s @%08x: lim0_15=%04x base0_23=%04x type=%x sg=%x dpl=%x present=%x limit_16_19=%x base_24_32=%02x\n",
           Index, Index > 9 ? "INVALID" : "", (UINT) Seg,
           Seg->limit_0_15, Seg->base_0_23,
           Seg->type, Seg->cd_sg, Seg->dpl, Seg->present,
           Seg->limit_16_19, Seg->base_24_32);
}

void PrintGdt()
{
    GDT_POINTER MyGDT;
    I386_SEGMENT_DESCRIPTOR SegCopy[12];
    //I386_SEGMENT_DESCRIPTOR * pGDTDesc; /*, adesc = {0, };*/
    UINT i;

    memset(&MyGDT,0,sizeof MyGDT);
    DBG(("MyGDT base=%x limit=%x\n",
         MyGDT.base_0_31,
         MyGDT.limit_0_15));
    __asm { sgdt [MyGDT] }
    DBG(("MyGDT base=%x limit=%x\n",
         MyGDT.base_0_31,
         MyGDT.limit_0_15));

    CopyFromReallyPhys((PTR) SegCopy, MyGDT.base_0_31, 12 * sizeof(I386_SEGMENT_DESCRIPTOR));

    //pGDTDesc = (I386_SEGMENT_DESCRIPTOR *) Resegment(MyGDT.base_0_31);
    for (i = 0; i < 12; i++)
        PrintSeg(i, &SegCopy[i]); //PrintSeg(i, &pGDTDesc[i]);

}

SCODE APicInit(void)
{
    ADDRESS ApicVirt;
    UINT32 val, val2;
    I586_APIC *Apic;

    ApicVirt = PhysicalToLogical(APIC_PHYSICAL_ADDRESS);
    Apic = (PTR) ApicVirt;

    SearchForPCIBios();
    __asm {
        mov ecx, 0x1b;
        rdmsr;
        mov val, eax;
    }
    printf("MSR(0x1b)=0x%08x\n", val);

    PrintGdt();

    if ((val & 0x800) == 0) {
        val |= 0x800;

        __asm {
            mov ecx, 0x1b;
            mov edx, 0;
            mov eax, val;
            wrmsr;
        }

        __asm {
            mov ecx, 0x1b;
            rdmsr;
            mov val, eax;
        }
        printf("MSR(0x1b)=0x%08x\n", val);
    }

    DBG(("Apic effective address at %08x (relocated from %08x)\n",
         ApicVirt, APIC_PHYSICAL_ADDRESS));
    
    //    DumpRegisters((PTR) ApicPhys, "before init");
    //    DumpRegisters((PTR) APIC_PHYSICAL_ADDRESS, "before init");
    DumpRegisters(Apic, "before init");

    //SearchForAnything();

    Apic->LocalVectorTimer = 36 | APIC_LOCAL_VECTOR_MASKED; /* Interrupt number, other fields zero */
    DumpRegisters(Apic, "Timer setup");

    Apic->TimerInitial = _UI32_MAX;

    RTCWaitForTransition();
    val = Apic->TimerCurrent;
    RTCWaitForTransition();
    val2 = Apic->TimerCurrent;

    DBG(("One second took %d cycles\n", val2 - val));
    DumpRegisters(Apic, "Timer armed");

    InstallIsr(36, Reflect(36), TRUE, FALSE);

    return S_OK;
}
#endif

/* Interrupt handling for shared interrupts
 */
typedef struct _ISHARED {
    INTERRUPT_SERVICE_ROUTINE Isr;  /* isr for IRQn*/
    void *pDevice;                  /* Argument to pass to ISR */
} ISHARED, *PISHARED;

#define MaxShared 4

/* Handler for shared interruptys
 */
PRIVATE BOOL
P6SharedIsr(PIDEVICE pThis, BOOL *pNotOurInterrupt)
{
    PISHARED this = (PISHARED) pThis;
    BOOL Reschedule = FALSE;
    int i;

    for (i = 0; i < MaxShared; i++) {
        if (this[i].Isr)
            Reschedule |= this[i].Isr(this[i].pDevice,pNotOurInterrupt);
    }
    return Reschedule;
}

/* Install a shared Isr.
 * Returns TRUE if this is NOT the first time the Irq was enabled,
 * meaning the interrupt is already active.
 */
PRIVATE BOOL
EnableSharedIsr(APIC *this, UINT Irq,  INTERRUPT_SERVICE_ROUTINE Isr, void *pDevice)
{
    PISHARED Shared;
    PIHEAP pHeap = CurrentHeap();
    int i;
    BOOL Alloced = FALSE;

    /* Do we have some already.
     */
    Shared = (PISHARED) this->InterruptTable[ Irq ].pDevice;
    if (Shared == NULL) {
        Shared = pHeap->v->Alloc(pHeap,HEAP_ZERO_MEMORY|HEAP_CACHE_ALIGN,
                                 MaxShared*sizeof(*Shared),0);
        /* Fail silently, sigh */
        if (Shared == NULL)
            return TRUE;

        /* Remember we allocated it and where
         */
        Alloced = TRUE;
        this->InterruptTable[ Irq ].pDevice = Shared;
    }

    /* Look for a free spot
     */
    for (i = 0; i < MaxShared; i++) {

        if (Shared[i].Isr == NULL) {

            /* Dont swap these assignments
             */
            Shared[i].pDevice = pDevice;
            IOMemoryBarrier();
            Shared[i].Isr = Isr;

            return !Alloced;
        }
    }

    /* Could not find a spot, fail silently. Triple sigh.
     */
    return TRUE;
}

/*
 * Table to map from IRQ numbers to the hardware interrupt numbers
 * because they are few and quite sparse.
 */
#define SPURIOUS_VECTOR 0
#define IPI_VECTOR 4
#define IPI_LEVEL  14
#define EE_LEVEL   13

#define INVALID_IRQ 0xff
PRIVATE const UINT8 IrqToInterruptSource[IRQ_ID_COUNT] = {
    0,   // SPURIOUS_VECTOR
};

void MCT EnableInterrupt( IPic *pThis, DEVICE_FLAGS Flags, UINT Irq, INTERRUPT_SERVICE_ROUTINE Isr, void *pDevice)
{
    APIC *pic = (APIC *) pThis;
    UINT32 Destination;
    UINT8 InterruptSource;
    UINT32 LocalVector = 0;
    UINT IrqForIdt;

    assert (LocalVector < APIC_LOCAL_VECTOR_MAX);
    assert (LocalVector < IRQ_ID_COUNT);
    assert (LocalVector >= MIN_IRQ || (Flags & DEVICE_FLAGS_LOCAL));

    /* BUGBUG */
    Destination = 1; /* Processor P0 */

    /*
     *  Configure the vector as desired
     */
    if (Flags & DEVICE_FLAGS_LOCAL)
        LocalVector = IrqForIdt = Irq + LOCAL_IRQ_BASE;
    else
        LocalVector = IrqForIdt = Irq;

    if (Flags & DEVICE_FLAGS_LEVEL_TRIGGER)
        LocalVector |= APIC_LOCAL_VECTOR_TRIGGER_LEVEL;

    if (Flags & DEVICE_FLAGS_POSITIVE_LEVEL)
        LocalVector |= APIC_LOCAL_VECTOR_POLARITY;

    /*
     * Map and verify the IRQ number
     */

    InterruptSource = IrqToInterruptSource[Irq & (IRQ_ID_COUNT-1)];

    DBGME(0,_tprintf(_T("EnableInterrupt %d(%d)=>%d %x %x\n"), 
                     Irq, InterruptSource, IrqForIdt, Flags, (ADDRESS) Isr));

    if (InterruptSource != INVALID_IRQ) {

        /* Shared?
         */
        if (Flags & DEVICE_FLAGS_SHARED_INTERRUPT) {

            /* Did we enable the interrupt already.
             */
            if (EnableSharedIsr(pic,Irq,Isr,pDevice))
                return;

            /* Nope, pick up the shared list as arg
             */
            pDevice = pic->InterruptTable[ Irq ].pDevice;
            Isr = P6SharedIsr;
        }

        /* The order of the following operations is NOT irrelevant
         *
         * First, the argument. Failure case is if interrupt was
         * active and we are called with interrupts on and we get
         * an interrupt right after this statement. Wont happen.
         * [e.g. old ISR called with new argument]
         */
        pic->InterruptTable[ Irq ].pDevice = pDevice;

        /* Also put it into the IDT */
        //InstallIsr(IrqForIdt, Reflect(Irq), TRUE, FALSE); // (ADDRESS) Isr
        InstallIsr(IrqForIdt, (ADDRESS) ApicTimerInterrupt, TRUE, FALSE);

        IOMemoryBarrier();

        /* Second, the ISR. If the interrupt was active we are done already.
         */
        pic->InterruptTable[ Irq ].Isr = Isr;

        /* Third, the mask
         */
        pic->Enabled |= (1 << Irq);

        /* Finally, the hardware
         */
        if (Flags & DEVICE_FLAGS_LOCAL) {
            switch (Irq) {
            case APIC_LOCAL_VECTOR_SPURIOUS:
                LocalVector |= APIC_SPURIOUS_INTERRUPT_VECTOR_SWENABLED;
                P6APIC()->SpuriousVector = LocalVector;
                break;
            case APIC_LOCAL_VECTOR_TIMER:
                /* Unfortunately the APIC counter remains stuck at zero
                 * when done unless periodic. The rearm lets us find out
                 * how much time elapsed until we found it.
                 */
                //LocalVector |= APIC_LOCAL_VECTOR_TIMER_PERIODIC;
                P6APIC()->LocalVectorTimer = LocalVector;
                DBG(("Enabled %08x (ISR=%p) in LocalTimer\n", LocalVector, Isr));
                break;
            case APIC_LOCAL_VECTOR_THERMAL:
                P6APIC()->LocalVectorThermal = LocalVector;
                break;
            case APIC_LOCAL_VECTOR_PERFORMANCE:
                P6APIC()->LocalVectorPerformance = LocalVector;
                break;
            case APIC_LOCAL_VECTOR_LINT0:
                P6APIC()->LocalVectorLINT0 = LocalVector;
                break;
            case APIC_LOCAL_VECTOR_LINT1:
                P6APIC()->LocalVectorLINT1 = LocalVector;
                break;
            case APIC_LOCAL_VECTOR_ERROR:
                P6APIC()->LocalVectorError = LocalVector;
                break;
            default:
                assert(Irq < APIC_LOCAL_VECTOR_COUNT);
            }
        } else {
            // XXX Use correct APIC and destination XXX
        }
            //APicWriteRegister32(&P6APIC()->InterruptSource[InterruptSource].Destination, Destination);
    }
    else {
        DumpRegisters(P6APIC(),"AAAA In Enable");
    }
}

/*
 * Undo the above EnableInterrupt
 */
void MCT DisableInterrupt( IPic *pThis, UINT Irq, void **pOldDevice)
{
    APIC *pic = (APIC *) pThis;
    UINT32 InterruptSource;
    UINT32 LocalVector = 0;

    /*
     *  Configure the vector as desired
     */

    LocalVector |= APIC_LOCAL_VECTOR_MASKED;

    /*
     * Map and verify the IRQ number
     */

    InterruptSource = IrqToInterruptSource[Irq & (IRQ_ID_COUNT-1)];

    DBGME(0,_tprintf(_T("DisableInterrupt %d(%d) %x\n"), 
                   Irq, InterruptSource, (ADDRESS) pOldDevice));

    if (InterruptSource != INVALID_IRQ) {

        /* If it is shared then dont. (there is a bug upstairs)
         * We would need to know which object we want disabled.
         */
        if (pic->InterruptTable[ Irq ].Isr == P6SharedIsr)
            return;

        /* Remove the ISR and its argument from our tables after setting
         * the hardware mask.
         */
        pic->Enabled &= ~(1 << Irq);

        switch (Irq) {
        case APIC_LOCAL_VECTOR_SPURIOUS:
            LocalVector = 0;    /* The other flags differ */
            LocalVector |= APIC_SPURIOUS_INTERRUPT_VECTOR_SWENABLED;
            P6APIC()->SpuriousVector = LocalVector;
            break;
        case APIC_LOCAL_VECTOR_TIMER:
            P6APIC()->LocalVectorTimer = LocalVector;
            DBG(("Disabled %08x in LocalTimer\n", LocalVector));
            break;
        case APIC_LOCAL_VECTOR_THERMAL:
            P6APIC()->LocalVectorThermal = LocalVector;
            break;
        case APIC_LOCAL_VECTOR_PERFORMANCE:
            P6APIC()->LocalVectorPerformance = LocalVector;
            break;
        case APIC_LOCAL_VECTOR_LINT0:
            P6APIC()->LocalVectorLINT0 = LocalVector;
            break;
        case APIC_LOCAL_VECTOR_LINT1:
            P6APIC()->LocalVectorLINT1 = LocalVector;
            break;
        case APIC_LOCAL_VECTOR_ERROR:
            P6APIC()->LocalVectorError = LocalVector;
            break;
        default:
            ; // XXX Use correct APIC and destination XXX
        }
        IOWriteBufferFlush();

        /* Return the old one
         */
        *pOldDevice = pic->InterruptTable[ Irq ].pDevice;

        pic->InterruptTable[ Irq ].pDevice = NULL;
        pic->InterruptTable[ Irq ].Isr = NULL;

        InstallIsr(Irq, 0, TRUE, FALSE);
    }
}

/*
 * Mask *all* interrupts.
 */
void MCT MaskAll( IPic *pThis )
{
    volatile I586_APIC *Apic = P6APIC();

    UnusedParameter(pThis);

    DBG(("APIC MaskAll"));
    Apic->LocalVectorTimer |= APIC_LOCAL_VECTOR_MASKED;
    Apic->LocalVectorThermal |= APIC_LOCAL_VECTOR_MASKED;
    Apic->LocalVectorPerformance |= APIC_LOCAL_VECTOR_MASKED;
    Apic->LocalVectorLINT0 |= APIC_LOCAL_VECTOR_MASKED;
    Apic->LocalVectorLINT1 |= APIC_LOCAL_VECTOR_MASKED;
    Apic->LocalVectorError |= APIC_LOCAL_VECTOR_MASKED;

#if 0
    /* This disables the power button as well, which we dont want to.
     */
    for (i = 0; i < APIC_NUMBER_OF_PROCESSOR_BLOCKS; i++)
        Apic->ProcessorBlock[i].TaskPriority = 15;
#endif
}

/*
 * Mask *all* interrupts on old PIC.  Except NMI, but thats another story.
 */
void MCT i8259MaskAll( IPic *pThis )
{
#define PIC0_PORT 0x20
#define PIC1_PORT 0xa0
    /* quick&dirty */
    UnusedParameter(pThis);
    IOSpaceWriteInt8((IO_PORT)(PIC1_PORT+1),(UINT8)0xff);
    IOSpaceWriteInt8((IO_PORT)(PIC0_PORT+1),(UINT8)0xff);
}

/*
 * Unmask all interrupts that should be unmasked.
 */
void MCT UnmaskAll( IPic *pThis )
{
//    int i;

    UnusedParameter(pThis);

    DBG(("APIC UnmaskAll"));
//    for (i = 0; i < APIC_NUMBER_OF_PROCESSOR_BLOCKS; i++)
//        P6APIC()->ProcessorBlock[i].TaskPriority = 0;
}

static const struct IPicVtbl picVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    EnableInterrupt,
    DisableInterrupt,
    MaskAll,
    UnmaskAll
};

APIC ThePIC = {
    &picVtbl,
    0,
};

/*
 * Constructor/Destructor
 */
void PicDelete( IPic *pThis )
{
    /* Disable all channels*/
    MaskAll(pThis);
}


IPic *PicCreate(void)
{
    //UINT32 TimerFrequency;
    IPic *iThis;
    //I586_APIC *Apic = (PTR) PhysicalToLogical(APIC_PHYSICAL_ADDRESS);

    //DumpRegisters(P6APIC(),"before init");

    ThePIC.Enabled = 0;
    iThis = (IPic *)&ThePIC;

    /* Turn off interrupts to BIOS if any */
    i8259MaskAll(NULL);

#if 0
    APIC_GLOBAL_CONFIGURATION GlobalConfiguration;
    APIC_VECTOR_PRIORITY VectorPriority;
    /*
     * Remember the timer frequency across the below hardware reset.  This value
     * is maintained by software only.
     */

    TimerFrequency = APicReadRegister32(&P6APIC()->TimerFrequencyReporting);

    /*
     * Reset the interrupt controller and delay waiting for the reset to
     * complete.
     */

    GlobalConfiguration.AsUINT32 = 0;
    GlobalConfiguration.Reset = 1;

    APicWriteRegister32(&P6APIC()->GlobalConfiguration.AsUINT32,
        GlobalConfiguration.AsUINT32);

    Delay(1000);

    /*
     * Enable the interrupt controller unit.
     */

    GlobalConfiguration.AsUINT32 = 0;
    GlobalConfiguration.MixedMode = 1;

    APicWriteRegister32(&P6APIC()->GlobalConfiguration.AsUINT32,
        GlobalConfiguration.AsUINT32);

    /*
     * Restore the timer frequency value.
     */

    APicWriteRegister32(&P6APIC()->TimerFrequencyReporting,
        TimerFrequency);

    /*
     * Configure the spurious interrupt vector.
     */

    APicWriteRegister32(&P6APIC()->SpuriousVector,SPURIOUS_VECTOR);

    /*
     * Configure the generic interprocessor interrupt.
     */

    VectorPriority.AsUINT32 = 0;
    VectorPriority.Vector = IPI_VECTOR;
    VectorPriority.Priority = IPI_LEVEL;

    APicWriteRegister32(&P6APIC()->IpiConfiguration[0].VectorPriority.AsUINT32,
        VectorPriority.AsUINT32);
#endif

    /*
     * Set the task priority to the operational value, for all processors.
     */
    UnmaskAll(iThis);

    /*
     * Done
     */
    return iThis;
}

#define CurrentProcessorNumber() (0)

/* Dispatch an interrupt
 */
CXTINFO *ApicInterruptHandler(UINT32 IntNo, CXTINFO *pContext)
{
    BOOL DoReschedule = FALSE;
    BOOL NotMyInterrupt;
    //UINT32 MyProcessor = CurrentProcessorNumber();
    INTERRUPT_SERVICE_ROUTINE Isr;
    ITABLE *IntSource;

    printf("{APICINT%d}", IntNo);

    //InterruptPending = P6APIC()->ProcessorBlock[MyProcessor].InterruptAcknowledge;
    //DBGME(0,_tprintf(_T("I%d "), IntNo));

    IntSource = &ThePIC.InterruptTable[IntNo];
    Isr = ThePIC.InterruptTable[IntNo].Isr;
#if _STATISTICS
    IntSource->Count++;
#endif
    if (Isr != NULL) {
        DoReschedule |= (Isr)(IntSource->pDevice, &NotMyInterrupt);
        P6APIC()->EndOfInterrupt = 0;
        IOWriteBufferFlush();
    }

    /* If the handler requested a reschedule, it will get done */
    if (DoReschedule) {
        printf("{R}");
        _Reschedule(); //pContext = _Reschedule(pContext); 
    }
    printf("{X}");

    return pContext;
}

/* Dispatching code for interrupts.
 */
#define INTR0(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch0 }
#define INTR1(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch1 }
#define INTR2(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch2 }
#define INTR3(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch3 }
#define INTR4(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch4 }
#define INTR5(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch5 }
#define INTR6(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch6 }
#define INTR7(_n_) __asm { __asm push _n_ __asm jmp SHORT Dispatch7 }

__declspec(naked) void __cdecl _ApicInterrupt(void)
{
    INTR0( 0); INTR0( 1); INTR0( 2); INTR0( 3);
    INTR0( 4); INTR0( 5); INTR0( 6); INTR0( 7);
    INTR0( 8); INTR0( 9); INTR0(10); INTR0(11);
    INTR0(12); INTR0(13); INTR0(14); INTR0(15);
    INTR0(16); INTR0(17); INTR0(18); INTR0(19);
    INTR0(20); INTR0(21); INTR0(22); INTR0(23);
    INTR0(24); INTR0(25); INTR0(26); INTR0(27);
    INTR0(28); INTR0(29); INTR0(30); INTR0(31);
 Dispatch0:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR1(32); INTR1(33); INTR1(34); INTR1(35);
    INTR1(36); INTR1(37); INTR1(38); INTR1(39);
    INTR1(40); INTR1(41); INTR1(42); INTR1(43);
    INTR1(44); INTR1(45); INTR1(46); INTR1(47);
    INTR1(48); INTR1(49); INTR1(50); INTR1(51);
    INTR1(52); INTR1(53); INTR1(54); INTR1(55);
    INTR1(56); INTR1(57); INTR1(58); INTR1(59);
    INTR1(60); INTR1(61); INTR1(62); INTR1(63);
 Dispatch1:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR2(64); INTR2(65); INTR2(66); INTR2(67);
    INTR2(68); INTR2(69); INTR2(70); INTR2(71);
    INTR2(72); INTR2(73); INTR2(74); INTR2(75);
    INTR2(76); INTR2(77); INTR2(78); INTR2(79);
    INTR2(80); INTR2(81); INTR2(82); INTR2(83);
    INTR2(84); INTR2(85); INTR2(86); INTR2(87);
    INTR2(88); INTR2(89); INTR2(90); INTR2(91);
    INTR2(92); INTR2(93); INTR2(94); INTR2(95);
 Dispatch2:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR3(96); INTR3(97); INTR3(98); INTR3(99);
    INTR3(100); INTR3(101); INTR3(102); INTR3(103);
    INTR3(104); INTR3(105); INTR3(106); INTR3(107);
    INTR3(108); INTR3(109); INTR3(110); INTR3(111);
    INTR3(112); INTR3(113); INTR3(114); INTR3(115);
    INTR3(116); INTR3(117); INTR3(118); INTR3(119);
    INTR3(120); INTR3(121); INTR3(122); INTR3(123);
    INTR3(124); INTR3(125); INTR3(126); INTR3(127);
 Dispatch3:
#if 0
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR4(128); INTR4(129); INTR4(130); INTR4(131);
    INTR4(132); INTR4(133); INTR4(134); INTR4(135);
    INTR4(136); INTR4(137); INTR4(138); INTR4(139);
    INTR4(140); INTR4(141); INTR4(142); INTR4(143);
    INTR4(144); INTR4(145); INTR4(146); INTR4(147);
    INTR4(148); INTR4(149); INTR4(150); INTR4(151);
    INTR4(152); INTR4(153); INTR4(154); INTR4(156);
    INTR4(157); INTR4(158); INTR4(159); INTR4(160);
 Dispatch4:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR5(96); INTR5(97); INTR5(98); INTR5(99);
    INTR5(100); INTR5(101); INTR5(102); INTR5(103);
    INTR5(104); INTR5(105); INTR5(106); INTR5(107);
    INTR5(108); INTR5(109); INTR5(110); INTR5(111);
    INTR5(112); INTR5(113); INTR5(114); INTR5(115);
    INTR5(116); INTR5(117); INTR5(118); INTR5(119);
    INTR5(120); INTR5(121); INTR5(122); INTR5(123);
    INTR5(124); INTR5(125); INTR5(126); INTR5(127);
 Dispatch5:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR6(96); INTR6(97); INTR6(98); INTR6(99);
    INTR6(100); INTR6(101); INTR6(102); INTR6(103);
    INTR6(104); INTR6(105); INTR6(106); INTR6(107);
    INTR6(108); INTR6(109); INTR6(110); INTR6(111);
    INTR6(112); INTR6(113); INTR6(114); INTR6(115);
    INTR6(116); INTR6(117); INTR6(118); INTR6(119);
    INTR6(120); INTR6(121); INTR6(122); INTR6(123);
    INTR6(124); INTR6(125); INTR6(126); INTR6(127);
 Dispatch6:
    __asm {
        jmp /*LONG*/ Dispatch;
        nop;
        nop;
        nop; /* 8 bytes gap */
    }

    INTR7(96); INTR7(97); INTR7(98); INTR7(99);
    INTR7(100); INTR7(101); INTR7(102); INTR7(103);
    INTR7(104); INTR7(105); INTR7(106); INTR7(107);
    INTR7(108); INTR7(109); INTR7(110); INTR7(111);
    INTR7(112); INTR7(113); INTR7(114); INTR7(115);
    INTR7(116); INTR7(117); INTR7(118); INTR7(119);
    INTR7(120); INTR7(121); INTR7(122); INTR7(123);
    INTR7(124); INTR7(125); INTR7(126); INTR7(255);
 Dispatch7:
#endif
    __asm {
    }

 Dispatch:
    __asm {
        /* On stack we have:
         * (high)
         *              saved SS     only if from user level  ;; 32bits
         *              saved ESP    only if from user level  ;; 32bits
         *              saved EFLAGS     ;; 32bits
         *              saved CS         ;; 32bits
         *              saved eip        ;; 32bits
         * esp->        intrNo           ;; 32bits
         *
         */

        /* ... ds slot is occupied by intrNo */
        push es;
        push gs;
        push fs;
        pushad;         /* eax, ecx, edx, ebx, bogus esp, ebp, esi, edi */
        push 0;         /* pFpa */

        /* Finally put ds where it belongs and get the code out */
        mov ax, ds;
        xchg [esp+48], eax;

#if 1
        /* Set segment registers to ring0 conventions */
        mov  dx,ss;
        mov  ds,dx;   /* Reference kernel data */
        mov  es,dx;   /* Reference kernel data */
        xor  dx,dx;
        mov  fs,dx;   /* Zapped */
        mov  gs,dx;   /* Zapped */
#endif

#if 0
        mov     esi,esp;        /* save pCxt in callee saved register */
        push    esi;            /* pCxt for Handler */
        push eax                /* Push IntNo for Handler */
        push    0;              /* ErrorCode */
        push    0;              /* StopIt */
        push    esi;            /* pCxt */
        push    eax;            /* IntNo */
        call    DumpIt;
        add     esp,16;         /* pop two args, leave IntNo, pCxt as arg */
#else
        mov     esi,esp;        /* save pCxt in callee saved register */
        push    esi;            /* pCxt for Handler */
        push    eax;            /* IntNo */
#endif

        call    ApicInterruptHandler;
        push    esi; //       push    eax;            /* Returned context */
        call HWLoadThreadContext;
        int 3;
    }
}

#if _STATISTICS
void PrintIrqCounts(void)
{
    int i;
    for (i = 0; i < IRQ_ID_COUNT; i++)
        if (ThePIC.InterruptTable[i].Count != 0)
            _tprintf(_T("int[%d] = %d\n"), i, ThePIC.InterruptTable[i].Count);
}
#endif

__declspec(naked) void __cdecl ApicTimerInterrupt()
{
    /* On stack we have:
     * (high)
     *              saved SS     only if from user level  ;; 32bits
     *              saved ESP    only if from user level  ;; 32bits
     *              saved EFLAGS     ;; 32bits
     *              saved CS         ;; 32bits
     * esp->        saved eip        ;; 32bits
     */
    __asm {
        /* Interrupt frame setup
         */
        push ds;
        push es;
        push gs;
        push fs;
        pushad;
        push 0;                 /* pFpa */

#if 1
        /* Set segment registers to ring0 conventions */
        mov  dx,ss;
        mov  ds,dx;   /* Reference kernel data */
        mov  es,dx;   /* Reference kernel data */
        xor  dx,dx;
        mov  fs,dx;   /* Zapped */
        mov  gs,dx;   /* Zapped */
#endif

#if 0
        /* Quiet PIC (PIT always hangs off master PIC)
         */
        mov al,PIC_NS_EOI;
        out PIC0_PORT,al;
#else
        /* Ack the interrupt to the APIC EIO */
        mov ecx, 0x40000070;    /* HV_X64_MSR_EOI HYPER-ONLY */
        xor eax, eax
        wrmsr;
#endif
        

        /* Do not return here, go directly
         * where we came from (via an iretd)
         */
        jmp _Reschedule;
    }
}

/*
 *** APIC based timer.
 */

#define RTC_PORT 0x70
#define WriteDecrementer(val) P6APIC()->TimerInitial = val
#define ReadDecrementer() P6APIC()->TimerCurrent
typedef UINT32 (* TO_TICKS32)(TIME TimeValue);
typedef TIME (* TO_TIME)(UINT64 TicksValue);

PRIVATE UINT64 ProcessorSpeed = 0;
PRIVATE UINT32 TimebaseFrequency = 0;

extern UINT DelayMultiplier;

/* NB: Only valid if ProcessorSpeed > 10MHz */
UINT32 GeneralTimeToTicks32(TIME TimeValue)
{
    UINT64 t;
    assert(TimebaseFrequency >= 10*1000*1000);
    t = *(UINT64*)&TimeValue;
    t = Uint64TimesUint32(t,TimebaseFrequency);
    t = Uint64DividedByUint32(t,10*1000*1000);
    //DBG(("TimeToTicks %016lx -> %016lx TBF=%08x\n",
    //     TimeValue, t, TimebaseFrequency));
    return Uint64ToUint32(t);
}

TIME GeneralTicksToTime(UINT64 TicksValue)
{
    TIME t;
    t = *(TIME*)&TicksValue;
    t = Int64TimesInt32(t,10*1000*1000);
    t = Int64DividedByInt32(t,TimebaseFrequency);
    return t;
}

TO_TICKS32 TimeToTicks32 = GeneralTimeToTicks32;
TO_TIME      TicksToTime = GeneralTicksToTime;



/* Read one of the RTC registers.
 * Needs interrupt protection.
 */
static UINT8 ReadRTC( int RegNum )
{
    UINT Value;
    __asm {
        /* Select the register
         */
        mov eax,RegNum
        out RTC_PORT,al;

        /* Wait for slow chip
         */
        jmp l0;
l0:     jmp l1;

        /* Read the register
         */
l1:     in al,(RTC_PORT+1);
        mov Value,eax;
    }
    return (UINT8)Value;
}

/* Wait for RTC to move to the next second.
 * Call this twice and you know there will be one second in between.
 * Intended for initial speed calibration only.
 */
void RTCWaitForTransition()
{
    UINT IntrState;
    TURN_INTERRUPTS_OFF(IntrState);
    while (ReadRTC(0xa) & 0x80) /* In case already in the middle of update */
        ;
    while ((ReadRTC(0xa) & 0x80) == 0)
        ;
    RESTORE_INTERRUPTS(IntrState);
}

PRIVATE void SetNextInterruptTicks(UINT32 DecrementerValue)
{
    UINT32 Elapsed;
    /* Interrupts must be off */

    /* If the timer underflowed we will have lost the current time */
    // XXX Need a minimum timeout.
    //DBG(("SetNextInterruptTicks: last=%08x now=%08x delta=%08x BOOT=%016lx\n",
    //     ThePIC.LastDecrementer, ReadDecrementer(), 
    //     ThePIC.LastDecrementer - ReadDecrementer(), ThePIC.TicksSinceBoot)); 
    assert(ThePIC.LastDecrementer > ReadDecrementer() || ThePIC.LastDecrementer == 0);

    /* Figure out how much time elapsed from where we last armed the timer. */
    if (ThePIC.LastDecrementer)
        Elapsed = ThePIC.LastDecrementer - ReadDecrementer();
    else
        Elapsed = 0;

    WriteDecrementer(DecrementerValue);

    /* Save the decrementer value for next time */
    ThePIC.LastDecrementer = DecrementerValue;
    /* And update global time */
    ThePIC.TicksSinceBoot += Elapsed;
}

/* Arg in ecx, return in edx:eax */
__declspec(naked) UINT64 __fastcall ReadMsr(UINT32 reg)
{
    __asm {
        rdmsr;
        ret;
    }
}

TIME GetKernelTime ()
{
#if 1
    TIME FromBoot;

#if 0
    FromBoot = ReadMsr(0x40000020);    /* HV_X64_MSR_TIME_REF_COUNT */
#else
    UINT32 hi, lo;
    __asm {
        mov ecx, 0x40000020;    /* HYPER-ONLY */
        rdmsr;
        mov [hi], edx;
        mov [lo], eax;
    }

    Int64FromHighAndLow(FromBoot, hi, lo);
#endif
    //DBG(("GetKernelTime ==> %016lx\n", FromBoot));
    return FromBoot;
#else
    UINT64 ticks = ThePIC.TicksSinceBoot + ReadDecrementer();
    return TicksToTime(ticks);
#endif
}

BOOL MCT ApicTimerIsr(APIC *This, PBOOL pNotMyInterrupt)
{
#ifdef _DEBUG
    UINT32 cur = P6APIC()->TimerCurrent;
    DBG(("ApicTimerIsr Apic.TimerCurrent=%08x\n", cur));
#endif

    /* Emulate sensible timer beavior by making it continue running down from
     * zero after triggered. However, if we get suspended (e.g. on hypervisor
     * or debugger) before we get here, we will lose track of time.
     */
    SetNextInterruptTicks(_UI32_MAX);

    return TRUE;                /* Need to reschedule */
}

void EnableTimers( void )
{
    I586_APIC *Apic = (PTR) PhysicalToLogical(APIC_PHYSICAL_ADDRESS);
    UINT32 tick1, tick2, tick3, tick4, tick5, delay;

    /* Calibrate cycle speed */
    Apic->TimerInitial = _UI32_MAX;
    DelayMultiplier = 0;

    /* XXX If Speed > 8 GHz, this will overflow and we need to rearm timer */
    RTCWaitForTransition();
    tick1 = Apic->TimerCurrent;
    RTCWaitForTransition();
    tick2 = Apic->TimerCurrent;
    /* Calibrate Delay loop */
    Delay(1000000);
    tick3 = Apic->TimerCurrent;
    DelayMultiplier = 1000000;
    tick4 = Apic->TimerCurrent;
    Delay(0);
    tick5 = Apic->TimerCurrent;

    DBG(("Ticks: 1=%08x 2=%08x 3=%08x 4=%08x 5=%08x\n",
         tick1, tick2, tick3, tick4, tick5));
    DBG(("One second took %d cycles, 1M Delay loop %d, empty %d\n",
         tick1 - tick2, tick2 - tick3, tick4 - tick5));

    TimebaseFrequency = tick1 - tick2;
    TimeToTicks32 = GeneralTimeToTicks32;
    TicksToTime = GeneralTicksToTime;
    delay = (tick2 - tick3);
    DelayMultiplier = (TimebaseFrequency / delay / 1180) + 1; /* XXX 1180 hyper-hack */
    //DelayOverhead = tick3 - tick2;
    //DelayShifter = 10;
    //Int32ToInt64(SleepOverhead,30);    /* ~3 uSec               */

    ProcessorSpeed = (UINT64) TimebaseFrequency * 2; /* minimum Apic divider */
    DBG(("TimebaseFrequency=%d DelayMultiplier=%d ProcessorSpeed=%lld Hz\n",
         TimebaseFrequency, DelayMultiplier, ProcessorSpeed));

    EnableInterrupt((IPic *) &ThePIC, DEVICE_FLAGS_LOCAL,
                    APIC_LOCAL_VECTOR_TIMER, ApicTimerIsr, &ThePIC);

    DumpRegisters(Apic, "Timer armed");
}

void DisableTimers( void )
{
    PTR p;
    DisableInterrupt((IPic *) &ThePIC, APIC_LOCAL_VECTOR_TIMER, &p);
}

BOOL SetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    UINT IntrState;
    BOOL StateWas;
    UINT32 DecrementerValue = TimeToTicks32(Delta);

    //if (DecrementerValue < 200) /* XXX minimum so we don't lose track of time */
    //    DecrementerValue = 200; /* XXX Could be tighter */

    // TMP XXX
    //if (DecrementerValue < TIME_SECONDS(1)) /* XXX minimum so we don't lose track of time */
    //    DecrementerValue = TIME_SECONDS(1); /* XXX Could be tighter */

    //DBG(("SNEXTI %016lx -> %08x\n", Delta, DecrementerValue));
    TURN_INTERRUPTS_OFF(IntrState);

    SetNextInterruptTicks(DecrementerValue);

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);

    return StateWas;
}

UINT64 CurrentProcessorSpeed(void)
{
    return (UINT64)ProcessorSpeed;
}

__declspec(naked) void SlaveStart(void)
{
    __asm {
        int 19;
    };
}

#define CODE_LOCATION 0x7d000
#define CODE_LOCATION_PROT 0x0007d800
#define CODE_LOCATION_PROT_0 0x00
#define CODE_LOCATION_PROT_1 0xd8
#define CODE_LOCATION_PROT_2 0x07
#define CODE_LOCATION_PROT_3 0x00
#define CODE_SIZE 0x800
#define STATE_LOCATION 0x7e000
#define STACK_LOCATION 0x7f000

struct SlaveStartState {
    GDT_POINTER GDT;
} *SlaveGdt = (PTR) STATE_LOCATION;

#define CR0_MSW_PE 1

__declspec(naked) void SlaveStart16()
{
    __asm {
        int 18;
        mov ax, STACK_LOCATION;
        mov sp, ax;

	__emit 0x66;
        lgdt [SlaveGdt];
        smsw ax;
        or ax, CR0_MSW_PE;
        lmsw ax;

	// MASM does not like non-relocatable segments
	// [or I do not know how to say it]
	__emit 0x66;             // operand override
        
        __emit 0xea;             // jmp ptr16:32
	//__emit OFFSET SlaveProt; // R_C_SEL:lab
        __emit CODE_LOCATION_PROT_0;
        __emit CODE_LOCATION_PROT_1;
        __emit CODE_LOCATION_PROT_2;
        __emit CODE_LOCATION_PROT_3;

        __emit 0;               /* seg2 hi */
        __emit SEG_KC << 3;     /* Seg2 lo code */

        int 7;
    }
}

void SlaveStartB()
{
    DBG(("FREE THE SLAVES!!!!!!!!\n"));
}

__declspec(naked) void SlaveStart32()
{
    __asm {
        mov bx, SEG_KD << 3                /* Seg1 data */
        mov	ds,bx;
	mov	es,bx;
	mov	ss,bx;
    }

    SlaveStartB();

    __asm {
        int 12;
    }
}

void StartCpu(UINT CpuNo)
{
    GDT_POINTER MyGDT;
    I586_APIC *Apic = (PTR) PhysicalToLogical(APIC_PHYSICAL_ADDRESS);
    UINT32 cmd, i;

    DBG(("StartCPU: begin\n"));

    CopyToReallyPhys((PTR) (ADDRESS) SlaveStart16, CODE_LOCATION, CODE_SIZE);
    CopyToReallyPhys((PTR) (ADDRESS) SlaveStart32, CODE_LOCATION_PROT, CODE_SIZE);
    __asm { sgdt [MyGDT] }
    CopyToReallyPhys((PTR)&MyGDT, STATE_LOCATION, sizeof(struct SlaveStartState));

    DBG(("StartCPU: Setup launch pad SlaveStart=%08p\n", SlaveStart));

    /* The 8-bit vector is 4KB aligned within the low megabyte. */
    cmd = CODE_LOCATION >> 12;
    cmd |= APIC_COMMAND_LEVEL_ASSERT; /* must be 1 */
    cmd |= APIC_COMMAND_DELIVERY_STARTUP | APIC_COMMAND_SHORTHAND_ALL_BUT_SELF;

    for (i = 1; i < 256; i++) {
        DBG(("StartCPU: Messing with APIC ID=%d cmd=%08x\n", i, cmd));
        Apic->Destination = i << APIC_DESTINATION_ID_SHIFT;
        Apic->InterruptCommand = cmd;
    }
}


