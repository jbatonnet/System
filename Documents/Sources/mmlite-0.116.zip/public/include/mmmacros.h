/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* Commonly used defines that are not part of the "official" interface */
#ifndef _MMMACROS
#define _MMMACROS 1

/* This may disable diagnostics.h */
#include <assert.h>

#define MACRO_BEGIN do {
#define MACRO_END } while(0)

#define RELEASE(_p_) \
    MACRO_BEGIN \
    if ((_p_)) (_p_)->v->Release((_p_)); \
    MACRO_END

#define RELEASE_NULL(_p_) \
    MACRO_BEGIN \
    if ((_p_)) (_p_)->v->Release((_p_)); \
    _p_ = NULL; \
    MACRO_END

#define DBGLVL_NOISE 0
#define DBGLVL_COMMENT 1
#define DBGLVL_MAJOR 2

#define MAX(x,y) (((x)>(y))?(x):(y))
#define MIN(x,y) (((x)<(y))?(x):(y))
#define ABS(x) (((x)<(0))?(-(x)):(x))

#ifdef _DEBUG

#ifndef __DIAGNOSTICS__

#ifndef DBGLVL
#define DBGLVL DBGLVL_COMMENT
/* 0 noise, 1 - comment, 2 - major function (def DbgLvl == 3)*/
#endif

#define DBGME(_l_,_s_) \
    MACRO_BEGIN \
    if ((_l_) >= DBGLVL) (_s_); \
    MACRO_END

#define DBG(_x_) printf _x_
#define DBGT(_x_) _tprintf _x_
#define TRACE(_x_) DBGME(0,printf("%s (%s, %u)\n", _x_, __FILE__, __LINE__))

#endif /* __DIAGNOSTICS__ */

#ifdef __cplusplus
#define METHOD_DECLARE(_class_,_method_) \
    SCODE sc = S_OK; \
    const char *_errmsg = "?"; \
    const char *_method_name = # _class_ # _method_
#else
#define METHOD_DECLARE(_class_,_method_) \
    _class_ *This = (_class_ *) iThis; \
    SCODE sc = S_OK; \
    const char *_errmsg = "?"; \
    const char *_method_name = # _class_ # _method_

#define METHOD_DECLARE_MULTI(_class_,_prefix_,_method_) \
    _class_ *This = (_class_ *) ((iThis) ? (ADDRESS)(iThis) - offsetof(_class_, _prefix_ ## v) : 0); \
    SCODE sc = S_OK; \
    const char *_errmsg = "?"; \
    const char *_method_name = # _prefix_ # _method_
#endif

#define METHOD_DECLARE_NOTHIS(_class_,_method_) \
    SCODE sc = S_OK; \
    const char *_errmsg = "?"; \
    const char *_method_name = # _class_ # _method_

#define METHOD_CLEANUP \
    goto Out; /* avoids warning for unused label */ \
Out: \
    MACRO_BEGIN \
        if (FAILED(sc)) \
            printf("%s: Failed to %s sc=%x\n", _method_name, _errmsg, sc); \
    MACRO_END

#define METHOD_CLEANUP_MAYBE_PRINT(_bool_expr_)     \
    goto Out; /* avoids warning for unused label */ \
Out: \
    MACRO_BEGIN \
        if (FAILED(sc) && (_bool_expr_)) \
            printf("%s: Failed to %s sc=%x\n", _method_name, _errmsg, sc); \
    MACRO_END

#define CHECKSC(_msg_) \
    MACRO_BEGIN \
    if (FAILED(sc)) { \
       _errmsg = (_msg_); \
        goto Out; \
    } \
    MACRO_END

#define CHECKSETSC(_test_, _sc_, _msg_) \
    MACRO_BEGIN \
    if (!(_test_)) { \
        sc = _sc_; \
       _errmsg = (_msg_); \
        goto Out; \
    } \
    MACRO_END

#define CHECKOP(_op_, _msg_) \
    MACRO_BEGIN \
    if (FAILED(_op_)) { \
       _errmsg = (_msg_); \
        goto Out; \
    } \
    MACRO_END

/* secondary cleanup point */
#define METHOD_CLEANUP2 \
    goto Out2; /* avoids warning for unused label */ \
Out2: \
    MACRO_BEGIN \
        if (FAILED(sc)) \
            printf("%s: Out2: Failed to %s sc=%x\n", _method_name, _errmsg, sc); \
    MACRO_END

#define CHECKSC2(_msg_) \
    MACRO_BEGIN \
    if (FAILED(sc)) { \
       _errmsg = (_msg_); \
        goto Out2; \
    } \
    MACRO_END

#define CHECKSETSC2(_test_, _sc_, _msg_) \
    MACRO_BEGIN \
    if (!(_test_)) { \
        sc = _sc_; \
       _errmsg = (_msg_); \
        goto Out2; \
    } \
    MACRO_END

#define CHECK_HEAP() do {CurrentHeap()->v->Validate(CurrentHeap(), 0, NULL);} while(0)

#else  /* _DEBUG */

#ifndef __DIAGNOSTICS__
#define DBGME(_l_,_s_)
#define DBGT(_x_)
#define DBG(_x_)
#define TRACE(_x_)
#endif /* __DIAGNOSTICS__ */

#define METHOD_DECLARE(_class_,_method_) \
    _class_ *This = (_class_ *) iThis; \
    SCODE sc

#define METHOD_DECLARE_MULTI(_class_,_prefix_,_method_) \
    _class_ *This = (_class_ *) ((iThis) ? (ADDRESS)(iThis) - offsetof(_class_, _prefix_ ## v) : 0); \
    SCODE sc

#define METHOD_DECLARE_NOTHIS(_class_,_method_) \
    SCODE sc

#define METHOD_CLEANUP \
    goto Out; /* avoids warning for unused label */ \
Out:

#define METHOD_CLEANUP_MAYBE_PRINT(_bool_expr_)     \
    goto Out; /* avoids warning for unused label */ \
Out:

#define CHECKSC(_msg_) \
    MACRO_BEGIN \
    if (FAILED(sc)) { \
        goto Out; \
    } \
    MACRO_END

#define CHECKSETSC(_test_, _sc_, _msg_) \
    MACRO_BEGIN \
    if (!(_test_)) { \
        sc = _sc_; \
        goto Out; \
    } \
    MACRO_END

#define CHECKOP(_op_, _msg_) \
    MACRO_BEGIN \
    if (FAILED(_op_)) { \
        goto Out; \
    } \
    MACRO_END

/* secondary cleanup point */
#define METHOD_CLEANUP2 \
    goto Out2; /* avoids warning for unused label */ \
Out2:

#define CHECKSC2(_msg_) \
    MACRO_BEGIN \
    if (FAILED(sc)) { \
        goto Out2; \
    } \
    MACRO_END

#define CHECKSETSC2(_test_, _sc_, _msg_) \
    MACRO_BEGIN \
    if (!(_test_)) { \
        sc = _sc_; \
        goto Out2; \
    } \
    MACRO_END


#define CHECK_HEAP()
#endif

#ifndef PrintTime
#ifdef _DEBUG
/* A stupid compiler adds a new buffer to your frame whenever you print time... */
#define PrintTime(_desc_,_time_) \
    { \
        _TCHAR buf[50]; \
        TimeFormat(_time_, buf, sizeof(buf)-1); \
        printf(_desc_); \
        printf(": %s\n", buf); \
    }
#else 
#define PrintTime(_desc_,_time_)
#endif /* _DEBUG */
#endif /* PrintTime */

/* disable diagnostics.h */
#define __DIAGNOSTICS__ 1

#endif /* _MMMACROS */
