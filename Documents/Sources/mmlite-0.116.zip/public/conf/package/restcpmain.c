/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>

PIUNKNOWN RestcpCobMain(void);

PIUNKNOWN CobMain(void)
{
    return RestcpCobMain();
}
