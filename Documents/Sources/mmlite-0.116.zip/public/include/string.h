/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef _INC_STRING
#define _INC_STRING

#define __NEEDS_SIZE_T 1
#define __NEEDS_NULL 1
#include <__defs.h>

#include <sal.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function prototypes */

void *  __cdecl memcpy(_Out_cap_(size) void *, _In_ const void *, _In_ size_t size);
int     __cdecl memcmp(_In_count_(size) const void *, _In_ const void *, _In_ size_t size);
void *  __cdecl memset(_Out_cap_(size) void *, _In_ int, _In_ size_t size);
char *  __cdecl _strset(char *, int);
char *  __cdecl strcpy(_Out_ char *, _In_z_ const char *);
char *  __cdecl strcat(_Inout_z_ char *, _In_z_ const char *);
int     __cdecl strcmp(const char *, const char *);
size_t  __cdecl strlen(_In_z_ const char *);
void *  __cdecl _memccpy(void *, const void *, int, unsigned int);
void *  __cdecl memchr(const void *, int, size_t);
int     __cdecl _memicmp(const void *, const void *, unsigned int);
void *  __cdecl memmove(_Out_cap_(size) void *, _In_ const void *, _In_ size_t size);


char *  __cdecl strchr(const char *, int);
int     __cdecl _strcmpi(const char *, const char *);
int     __cdecl _stricmp(const char *, const char *);
int     __cdecl strcoll(const char *, const char *);
int     __cdecl _stricoll(const char *, const char *);
int     __cdecl _strncoll(const char *, const char *, size_t);
int     __cdecl _strnicoll(const char *, const char *, size_t);
size_t  __cdecl strcspn(const char *, const char *);
char *  __cdecl _strdup(const char *);
char *  __cdecl _strndup(const char *, size_t);
char *  __cdecl _strerror(const char *);
char *  __cdecl strerror(int);
char *  __cdecl _strlwr(char *);
char *  __cdecl strncat(char *, const char *, size_t);
int     __cdecl strncmp(const char *, const char *, size_t);
int     __cdecl _strnicmp(const char *, const char *, size_t);
char *  __cdecl strncpy(_Out_z_cap_(len) char *, _In_z_ const char *, _In_ size_t len);
char *  __cdecl _strnset(char *, int, size_t);
char *  __cdecl strpbrk(const char *, const char *);
char *  __cdecl strrchr(const char *, int);
char *  __cdecl _strrev(char *);
size_t  __cdecl strspn(const char *, const char *);
char *  __cdecl strstr(const char *, const char *);
char *  __cdecl strtok(char *, const char *);
char *  __cdecl _strupr(char *);
size_t  __cdecl strxfrm (char *, const char *, size_t);

/* Additional functions */
char * __cdecl _strsplit(char *s1, const char *delimit);
/*BOOL*/ int _strnequal(const char *s1, size_t l1, const char *s2, size_t l2);
int __cdecl strcpy_s(char * _Dst, size_t _SizeInBytes, const char * _Src);

#ifdef __cplusplus
}
#endif

#endif  /* _INC_STRING */
