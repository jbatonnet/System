/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <mmlite_md.h>
#include <base/thread.h>

#ifdef __RENESAS__
#include <web/typeinfo.h>
#define MAX_REGARG_COUNT 2
UINT32 H8SetRegArgs(ADDRESS sp, UINT32 regargs[], CPMETHOD_DESCR pDescr);
#endif

/* Initialize the machine-dependent part of a thread object.
 * The (new) thread should be set to execute the function START
 * with argument ARG.  No scheduling side-effects.
 */
void MachineThreadCreate(PITHREAD pThis, THREAD_FUNCTION pStart,
                         THREAD_ARGUMENT Arg, PTR StackTop, UINT ArgCount,
                         UINT32 Flags)
{
    UINT32 *pStk = (UINT32 *)StackTop;
    CXTINFO *pCxt;
    UINT32 er0=0, er1=0, er2=0;
	
    /* Push argument & return PC on stack
     */
    if (ArgCount == -1) {
        //*(--pStk) = (UINT32) Arg;
        er0 = (UINT32)Arg;
        *(--pStk) = (UINT32) ThreadExit;
    } else {
        //
        // TODO: SOAP RPC Thread
        //
#ifdef __RENESAS__
        UINT32 regargs[MAX_REGARG_COUNT];
        pStk = (UINT32 *)H8SetRegArgs((ADDRESS)pStk, regargs, (CPMETHOD_DESCR)ArgCount);
        er0 = regargs[0];
        er1 = regargs[1];
#else
        // __GNUC__
        if (ArgCount > 0)
            er0 = *pStk++;
        if (ArgCount > 1)
            er1 = *pStk++;
        if (ArgCount > 2)
            er2 = *pStk++;
#endif

        *(--pStk) = (UINT32) Arg;	// Return Address
    }

    /* Make room for context on stack
     * Thread's initial state will point there.
     */
    pCxt = (CXTINFO *)pStk;
    pCxt--;
    pTH(pThis)->CxtInfo = pCxt;

    /* Setup non-irrelevant registers
     */
    pCxt->ccr = 0; /* intr enabled */
    pCxt->pc = (UINT32) pStart;
    pCxt->sp = (UINT32) pStk;
    pCxt->er0 = er0;
    pCxt->er1 = er1;
    pCxt->er2 = er2;
    pCxt->er3 = 0;
    pCxt->er4 = 0;
    pCxt->er5 = 0;
    pCxt->er6 = 0;
}

#ifdef __RENESAS__
//
// Called by strump and MachineThreadCreate
//
// Stack -> RegArg
//
// NOTE: Assuming that interger arguments are 32-bit.
//
UINT32 H8SetRegArgs(ADDRESS sp, UINT32 regargs[], CPMETHOD_DESCR pDescr)
{
	CPMETHOD_DESCR pArgTable = pDescr->ptable;
	CPMETHOD_DESCR pArgTableEnd = pArgTable + pDescr->table_size;
	int RegArgCount;
	UINT32 StackTopOffset;

	//
	// Special Handling for "THIS" pointer.
	//
	regargs[0] = *((UINT32 *)(sp));
	RegArgCount = 1;
	StackTopOffset = sizeof(UINT32);
	
	// OTHER
	for(; pArgTable < pArgTableEnd && RegArgCount < MAX_REGARG_COUNT; pArgTable++) {
		if (pArgTable->_Flags & ARGUMENT_DESCR_FLAGS_RETURN) {
			// ignoring return value
			continue;
		}

		if ((pArgTable->_Flags & ARGUMENT_DESCR_FLAGS_BYREF) ||
			pArgTable->descr_type == ARG_INT ||
			pArgTable->descr_type == ARG_CONTINUATION) {

			regargs[RegArgCount++] = *((UINT32 *)(sp + pArgTable->FrameOffset));
			
			if (StackTopOffset == pArgTable->FrameOffset) {
				StackTopOffset += sizeof(UINT32);
			} else {
				memcpy((void *)(sp+StackTopOffset+sizeof(UINT32)), (void *)(sp+StackTopOffset), pArgTable->FrameOffset - StackTopOffset);
			}
		} else {
			//
			// CONTINUE!
			//
			// With Renesas Compiler, 1st and 3rd args could be regarg.
			//
		}
	}

	return sp+StackTopOffset;
}
#endif
