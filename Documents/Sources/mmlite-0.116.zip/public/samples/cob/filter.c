/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* This file contains a sample implementations of a restricted file,
 * i.e. a filter that restricts access to another file (the parent).
 * The constructor is CreateFilterFile().
 */
#include <mmlite.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* Component internal declarations */
#include "cobsamp.h"

PRIVATE struct IFileVtbl FilterFileVtbl;

/* Instance layout */
typedef struct _FILTERFILE {
    /* Common part */
    struct IFileVtbl *v;
    UINT RefCnt;

    /* Implementation specific part */
    UINT64 Offset;
    UINT64 Size;
    PIFILE pParent;
} *PFILTERFILE;

/* Convert between interface and instance pointer and vice versa */
#define pFF(_i_) ((PFILTERFILE)(_i_))
#define iFF(_p_) ((PIFILE)(_p_))

/* Internal constructor */
PRIVATE PFILTERFILE FFNew(void)
{
    PFILTERFILE x;

    DPRINT(("FFNew\n"));
    x = (PFILTERFILE) CurrentHeap()->v->Alloc(CurrentHeap(),
                                              HEAP_ZERO_MEMORY,
                                              sizeof(*x),
                                              0);
    if (x) {
        x->v = &FilterFileVtbl;
        x->RefCnt = 1;

        /* The factory keeps the module from going away */
        pTheFactory->v->AddRef(pTheFactory);
    }
    return x;
}

/* Internal destructor */
PRIVATE void FFDestroy(PFILTERFILE x)
{
    DPRINT(("FFDestroy\n"));
    CurrentHeap()->v->Free(CurrentHeap(), 0, (PTR) x);

    /* The factory keeps the module from going away */
    pTheFactory->v->Release(pTheFactory);
}

/* Exported FilterFile constructor */
SCODE CreateFilterFile(PIFILE pParent, UINT64 Offset, UINT64 Size,
                       PIFILE *ppNew)
{
    PFILTERFILE x;

    DPRINT(("CreateFilterFile\n"));

    x = FFNew();
    if (!x)
        return E_NOT_ENOUGH_MEMORY;

    x->pParent = pParent;
    x->Offset = Offset;
    x->Size = Size;

    *ppNew = iFF(x);
    return S_OK;
}

/* IUnknown::QueryInterface method */
PRIVATE SCODE MCT FFQueryInterface(PIFILE This, REFIID Iid, void **ppObj)
{
    DPRINT(("FFQueryInterface x%x\n", This));
    return GenericQueryInterface((PIUNKNOWN) This, Iid, ppObj, &IID_IFile);
}

/* IUnknown::AddRef method */
PRIVATE UINT MCT FFAddRef(PIFILE This)
{
    UINT RefCnt = AtomicInc(&pFF(This)->RefCnt);
    DPRINT(("FFAddRef x%x ==> %d\n", This, RefCnt));
    return RefCnt;
}

/* IUnknown::Release method */
PRIVATE UINT MCT FFRelease(PIFILE This)
{
    UINT RefCnt = AtomicDec(&pFF(This)->RefCnt);
    DPRINT(("FFRelease x%x ==> %d\n", This, RefCnt));
    if (RefCnt == 0) {
        FFDestroy(pFF(This));
    }
    return RefCnt;
}

/* Utility functions for parameter checks */
PRIVATE BOOL FFCheckSize(PFILTERFILE x, UINT64 Offset, UINT64 Size)
{
    /* Beware of integer overflow: Offset + Size might be > MAXUINT64
     * So do comparison in parts.  The Int64Stuff makes this harder...
     */
    INT64 s;

    /* if (Size > x->Size)... */
    if (Uint64Less(x->Size, Size) && !Int64Equal(x->Size, Size))
        return FALSE;

    /* if (Offset > x->Size)... */
    if (Uint64Less(x->Size, Offset) && !Int64Equal(x->Size, Offset))
        return FALSE;

    /* if (Offset + Size > x->Size)... */
    s = Int64Add(Uint64ToInt64(Size), Uint64ToInt64(Offset));
    Size = Int64ToUint64(s);
    if (Uint64Less(x->Size,Int64ToUint64(Size)) && !Int64Equal(x->Size,Offset))
        return FALSE;

    return TRUE;
}

#define AdjustOffset(_x_, _offset_) \
    Int64Add(Uint64ToInt64((_x_)->Offset), Uint64ToInt64(_offset_))

/* IFIle::ReadAt method.  Check, adjust, and delegate. */
PRIVATE SCODE MCT FFReadAt(PIFILE This, UINT64 Offset, PBYTE pBuffer, UINT Size, UINT *pSizeRead)
{
    PFILTERFILE x = pFF(This);
    INT64 tmp;
    DPRINT(("FFRead x%x\n", This));

    Int32ToInt64(tmp, Size);
    if (!FFCheckSize(x, Offset, Int64ToUint64(tmp)))
        return E_INVALID_PARAMETER;

    tmp = AdjustOffset(x, Offset);
    return x->pParent->v->ReadAt(x->pParent, Int64ToUint64(tmp),
                                 pBuffer, Size, pSizeRead);
}

/* IFile::WriteAt method.  Check, adjust, and delegate. */
PRIVATE SCODE MCT FFWriteAt(PIFILE This, UINT64 Offset, const BYTE *pBuffer,
                            UINT Size, UINT *pSizeWritten)
{
    PFILTERFILE x = pFF(This);
    INT64 tmp;
    UnusedParameter(pBuffer);
    DPRINT(("FFWrite x%x\n", This));

    Int32ToInt64(tmp, Size);
    if (!FFCheckSize(x, Offset, Int64ToUint64(tmp)))
        return E_INVALID_PARAMETER;

    tmp = AdjustOffset(x, Offset);
    return x->pParent->v->WriteAt(x->pParent, Int64ToUint64(tmp),
                                  pBuffer, Size, pSizeWritten);
}

/* IFile::SetSize method. Check and delegate. */
PRIVATE SCODE MCT FFSetSize(PIFILE This, UINT64 Size)
{
    PFILTERFILE x = pFF(This);
    UINT64 Zero;
    DPRINT(("FFSetSize x%x %lx\n", This, Size));

    Int32ToInt64(Zero, 0);
    if (!FFCheckSize(x, Zero, Size))
        return E_INVALID_PARAMETER;
    
    return x->pParent->v->SetSize(x->pParent, Size);
}

/* IFile::GetFile method.  Minimum of this and parent. */
PRIVATE SCODE MCT FFGetSize(PIFILE This, UINT64 *pSize)
{
    PFILTERFILE x = pFF(This);
    UINT64 Size;
    SCODE sc;
    DPRINT(("FFgetSize x%x\n", This));

    sc = x->pParent->v->GetSize(x->pParent, &Size);
    if (FAILED(sc))
        return sc;

    if (Uint64Less(Size, x->Size))
        *pSize = Size;
    else
        *pSize = x->Size;
    return S_OK;
}

/* method table */
PRIVATE struct IFileVtbl FilterFileVtbl = {
    __VTABLE_COMPATIBILITY_FILLER_INITIALIZER

    FFQueryInterface,
    FFAddRef,
    FFRelease,
    FFReadAt,
    FFWriteAt,
    FFSetSize,
    FFGetSize
};
