/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <diagnostics.h>

extern PINAMESPACE InitHostFileSystem(_TCHAR *LinkName);

/* RomFs initialization specific to board */
PINAMESPACE BoardInitHostFs(void)
{
    /* hostfs must use serplex */
    PINAMESPACE ns = InitHostFileSystem("serplex6a");
    if (!ns) DBGME(3,printf("BoardInitHostFs failed\n"));
    return ns;
}
