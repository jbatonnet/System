/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <loaders/cobtab.h>

PIUNKNOWN CW10CobMain(void);

PIUNKNOWN CobMain(void)
{
    return CW10CobMain();
}
