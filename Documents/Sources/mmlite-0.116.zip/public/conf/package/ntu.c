/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <driverif.h>
#include <assert.h>
#include <stdio.h>

const _TCHAR *FIRST_IMAGE_NAME = _T("tzk.cob");
