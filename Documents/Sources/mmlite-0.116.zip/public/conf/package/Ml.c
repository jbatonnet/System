/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>

/* Select root "fs" file system */
PINAMESPACE BoardInitRomFs(void);
PINAMESPACE BoardInitHostFs(void);

PINAMESPACE BoardInitFileSystem(void)
{
    /* Try for RomFs first, fall back to HostFs */
    PINAMESPACE ns = BoardInitRomFs();
    if (!ns)                    /* not there */
        ns = BoardInitHostFs(); /* use hostfs instead */
    return ns;
}
