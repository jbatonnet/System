/* Copyright (c) Microsoft Corporation. All rights reserved. */

#ifndef _SERPLEX_
#define _SERPLEX_

/* Over a serial line, each packet is preceeded by an STH character,
 * terminated by an EOT and followed by a 2-byte CRC.
 * Special characters are ESC-aped inside a packet, including ESC itself.
 * The CRC avoids using special chars.
 */
#define STH_CHAR '['
#define EOT_CHAR ']'
#define ESC_CHAR 'E'
#define COMP_CHAR 'C'

typedef struct _CONNECTION {
    const struct IConnectionVtbl *v;
    UINT RefCnt;
    UINT8 SequenceNumber;
    MUTEX Mutex;
    PIFILE Link;
    struct _NTFILE *FileList;
} CONNECTION, *PCONNECTION;

#if __HOSTFS_CLIENT

 /* In-place request/reply. 
 */
extern SCODE LinkLevelRpc(PCONNECTION Connection, struct packet *Packet,
                          UINT PacketBufferSize);
#define LINK_HANDLE PIFILE
#define Pushout(_l_,_n_)
extern void PrintLinkErrors(struct _LINK_ERRORS *Errors);
extern SCODE Getabyte(PIFILE Link, UINT8 *pByte);
extern SCODE Petabyte(PIFILE Link, UINT8 Byte);
extern SCODE Petabytes(PIFILE Link, UINT8 *pBytes, UINT nBytes);
extern void LongTimeout(PIFILE Link);
extern void ShortTimeout(PIFILE Link);
/*-------------------- IFile stuff --------------------------*/
extern const struct IFileVtbl SerplexVtbl; /* forward */

#else

/* Connection status, flow
 */
struct IConnectionVtbl {
    void (*ShortTimeout)( PCONNECTION pThis );
    void (*LongTimeout)( PCONNECTION pThis );
    SCODE (*Getabyte)( PCONNECTION pThis, UINT8 *pByte);
    SCODE (*Petabyte)( PCONNECTION pThis, UINT8 pByte);
    SCODE (*Petabytes)( PCONNECTION pThis, UINT8 *pBytes, UINT nBytes);
    SCODE (*Pushout)( PCONNECTION pThis, UINT Count);
    void (*Close)( PCONNECTION pThis );
};
/* Customize generic packet I/O routines
 */
#define LINK_HANDLE PCONNECTION
#define Getabyte(_l_,_p_) (_l_)->v->Getabyte(_l_,_p_)
#define Petabyte(_l_,_c_) (_l_)->v->Petabyte(_l_,_c_)
#define Petabytes(_l_,_b_,_n_) (_l_)->v->Petabytes(_l_,_b_,_n_)
#define LongTimeout(_l_) (_l_)->v->LongTimeout(_l_)
#define ShortTimeout(_l_) (_l_)->v->ShortTimeout(_l_)
#define Pushout(_l_,_n_) (_l_)->v->Pushout(_l_,_n_)

#endif

typedef struct _SerplexState {
    /* Serial stuff. State of incoming message. */
    UINT8 ByteNum;
    UINT16 Sum;
    UINT State;
} SERPLEXSTATE, *PSERPLEXSTATE;

/* Currently ETHER_MTU + overhead. Make smaller later? */
#define SERPLEX_MTU 1516
#define MAX_CON_BUF 128

typedef struct _Transport {
    UINT RefCnt;
    LINK_HANDLE file;
    _TCHAR *name;
    struct _Transport *next;
    MUTEX WriteLock;
    MUTEX ReadLock;
    CONDITION ReadCondition;
    UINT32 MemberBitMap;
    UINT8 IntendedReceiver;
    
    /* We must receive a full Serplex frame even if the app asked for less */
    UINT8 ReadBuffer[SERPLEX_MTU];    
    UINT Avail, Consumed; /* Pointers into ReadBuffer */
    /* Independent buffer for console */
    UINT8 ConReadBuffer[MAX_CON_BUF];    
    UINT ConAvail; /* Pointer into ConReadBuffer */
}TRANSPORT, *PTRANSPORT;

typedef struct _SERPLEX {
    const struct IFileVtbl *v;
    UINT RefCnt;
    PTRANSPORT transport;
    BYTE SerplexAddr;
    BYTE WakeupNum;
    BYTE ContinueDropNum;
} *PSERPLEX;
#endif
