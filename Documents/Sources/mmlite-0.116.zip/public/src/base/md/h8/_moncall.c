/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>

/* embedded monitor call
 * NB: Args get packed funny
 */
/*
UINT Moncall( UINT8 Code, UINT16 Parm2, UINT8 Parm1)
{
    asm("mov.b  r2l,r0h");
    asm("jsr    @@0xfc:8");
}
*/

/* Avoid use of debug.o unless needed
 */
void putc( UINT8 c)
{
	Sci_WriteChar(c);
}

int putchar( int c )
{
    if (c == '\n')
        putc('\r');
    putc((UINT8) c);

    return c;
}

#ifdef DEBUG
void perror(char *p)
{
	Sci_WriteStr("perror:");
	Sci_WriteStr(p);
	Sci_WriteStr("\r\n");
}

void __p_query(char *p)
{
}
#endif
