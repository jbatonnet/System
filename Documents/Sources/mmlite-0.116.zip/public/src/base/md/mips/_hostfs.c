/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Microsoft MMLite June 1995 --jvh
 * Remote IFile using sockets.
 *
 * The server could reside eg. on an NT box and the file could be a disk image.
 * => Remote FS, remote devices.
 */

#define USE_WINSOCK 0

#include <mmlite.h>
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include <file.h>

#include <hostfsp.h>

#include <machdep.h>            /* for INTERRUPT stuff */

#define DPRINT(x)
#define EPRINT(x) printf x

PINAMESPACE InitHostFileSystem(void);

PRIVATE UINT StrLenWchar(const wchar_t *pStr);
PRIVATE void StrNCpyWcharToTchar(_TCHAR *pDst, const wchar_t *pSrc,UINT Count);
PRIVATE void StrNCpyTcharToWchar(wchar_t *pDst, const _TCHAR *pSrc,UINT Count);

PRIVATE SCODE ComposePathToTchar(_TCHAR *NewPath, UINT MaxLen,
                                 const _TCHAR *Prefix, const _TCHAR *Name);
PRIVATE SCODE ComposePathToWchar(wchar_t *NewPath, UINT MaxLen,
                                 const _TCHAR *Prefix, const _TCHAR *Name);


/*------------------ Low level  network rpc -------------------------*/
#define MIN_TIMEOUT_PERIOD (100000)     /* 10 ms */
#define MAX_TIMEOUT_PERIOD (300000000) /* 30 s */

typedef struct _CONNECTION {
    UINT RefCnt;
    MUTEX Mutex;
} *PCONNECTION;

/* 
 * Send a packet and receive into the same buffer.
 * The send buffer is never guaranteed to be valid on return.
 * Access to the connection is being serialized here.
 */
PRIVATE SCODE packet_rpc(PCONNECTION Conn, struct packet *p,  PACKETTYPE expect_type)
{
    SCODE sc;
    UINT32 length;

    p->seqno = 0;

    length = p->packet_length;
    Mutex_Lock(&Conn->Mutex);

    sc = HostFile_Server(p);

    if (FAILED(sc))
        goto out;

   sc = packet_check(p, expect_type, length);

 out:
    Mutex_Unlock(&Conn->Mutex);
    return sc;
}

/* Post-process RPC.  Returns TRUE if the call should be retried */
PRIVATE BOOL packet_rpc_check(PCONNECTION Conn, SCODE sc)
{
    UnusedParameter(Conn);
    UnusedParameter(sc);

    return FALSE;
}

/*-------------------- IFile stuff --------------------------*/
extern const struct IFileVtbl NetFileVtbl; /* forward */
extern const struct INameSpaceVtbl NetFileNSVtbl; /* ditto */

typedef struct _NETFILENS {
    const INameSpaceVtbl *v;
    UINT RefCnt;
    PCONNECTION Conn;
    _TCHAR Prefix[MAX_PATH];    /* relative path */
} *PNETFILENS;

typedef struct _NETFILE {
    const IFileVtbl *v;
    UINT RefCnt;
    PCONNECTION Conn;
    UINT32 Handle;
} *PNETFILE;

PRIVATE PNETFILE AllocNetFile(PCONNECTION Conn)
{
    PNETFILE File = NULL;

    File = (PNETFILE) CurrentHeap()->v->Alloc(CurrentHeap(), 0, sizeof(struct _NETFILE), 0);
    if (!File)
        return NULL;

    File->v = &NetFileVtbl;
    File->RefCnt = 1;
    File->Handle = 0;
    File->Conn = Conn;

    return File;
}

PRIVATE PNETFILENS AllocNetFileNS(PCONNECTION Conn)
{
    PNETFILENS Ns;

    Ns = (PNETFILENS) CurrentHeap()->v->Alloc(CurrentHeap(), 0, sizeof(struct _NETFILENS), 0);
    if (!Ns)
        return NULL;

    Ns->v = &NetFileNSVtbl;
    Ns->RefCnt = 1;
    Ns->Conn = Conn;
    _tcscpy(Ns->Prefix, _T(""));

    return Ns;
}

PRIVATE PCONNECTION MakeConnection(_TCHAR *i_addr, UINT i_port)
{
    PCONNECTION Conn = NULL;
#if 0
    SCODE sc;
    struct sockaddr_in *sin;
#else
    UnusedParameter(i_addr);
    UnusedParameter(i_port);
#endif

    DPRINT(("MakeConnection(\"%s\" %d)\n", i_addr, i_port));
    Conn = (PCONNECTION) CurrentHeap()->v->Alloc(CurrentHeap(), 0,
                                                 sizeof(*Conn), 0);
    if (!Conn)
        return NULL;

    Conn->RefCnt = 1;
    Mutex_Init(&Conn->Mutex);

#if 0
    sc = MakeUDPSocket(&Conn->Socket);
    if (FAILED(sc))
        goto Error1;

    /* Remote end */
    sin = (struct sockaddr_in *) &Conn->sa;
    sin->sin_port = htons((UINT16) i_port);
    sin->sin_family = AF_INET;
    sin->sin_addr.s_addr = inet_addrW(i_addr);
    Conn->sa_len = sizeof(struct sockaddr_in);
    /* Got socket, set receive timeout. */
    fix_timeout(Conn, Init);
#endif

    return Conn;
#if 0
 Error1:
    CurrentHeap()->v->Free(CurrentHeap(), 0, (PTR) Conn);    
    SetLastError(sc);
    return NULL;
#endif
}

PRIVATE UINT MCT ConnectionAddRef(PCONNECTION Conn)
{
    INT Refs;

DPRINT(("ConnectionADDREF"));
    Refs = AtomicInc(&Conn->RefCnt);
    return Refs;
}

PRIVATE UINT MCT ConnectionRelease(PCONNECTION Conn)
{
    INT Refs;

DPRINT(("ConnectionRELEASE"));
    Refs = AtomicDec(&Conn->RefCnt);
    if (Refs == 0) {
        /* BUGBUG: Destroy socket */
        CurrentHeap()->v->Free(CurrentHeap(), 0, (PTR) Conn);
    }
    return Refs;
}

PRIVATE SCODE OpenNetFile(PCONNECTION Conn, const _TCHAR *Prefix,
                          const _TCHAR *name, PNETFILE *File_out, UINT Flags)
{
    SCODE sc;
    PNETFILE File;

    struct packet p;
    struct open_req *req = &p.u.open_req;
    struct open_rep *rep = &p.u.open_rep;

    /* Remove undefined flags */
    Flags &= (NAME_SPACE_READ|NAME_SPACE_WRITE|NAME_SPACE_CREATE|NAME_SPACE_FAILIFEXIST);

    File = AllocNetFile(Conn);
    if (!File) {
        EPRINT(("OpenNetFile: AllocNetFile failed\n"));
        return GetLastError();
    }
    /* BUGBUG: failure after this leaks File */

    /* Got connection.  Now get a handle */
 reinit_and_resend:
    packet_init(&p, PACKET_TYPE_OPEN_REQ);
    req->flags = Flags;
    sc = ComposePathToWchar(req->path, MAX_PATH, Prefix, name);
    if (FAILED(sc))
        goto Error;
    packet_prepare(&p, sizeof(*req));

    sc = packet_rpc(Conn, &p, PACKET_TYPE_OPEN_REP);
    if (packet_rpc_check(Conn, sc))
        goto reinit_and_resend;
    if (FAILED(sc))
        goto Error;

    File->Handle = rep->handle;

    *File_out = File;
    return sc;
Error:
    CurrentHeap()->v->Free(CurrentHeap(), 0, File);
    return sc;
}

/* Similar to OpenNetFile */
PRIVATE SCODE NetFileMkDir(PNETFILENS Ns)
{
    SCODE sc;
    PCONNECTION Conn = Ns->Conn;

    struct packet p;
    struct open_req *req = &p.u.open_req;

    UINT Flags = NAME_SPACE_READ|NAME_SPACE_WRITE|NAME_SPACE_CREATE|NAME_SPACE_FAILIFEXIST|0x800;

    /* Got connection.  Now get a handle */
 reinit_and_resend:
    packet_init(&p, PACKET_TYPE_OPEN_REQ);
    /* Server calls WideCharToMultiByte */
    StrNCpyTcharToWchar(req->path, Ns->Prefix, MAX_PATH);
    req->flags = Flags;
    packet_prepare(&p, sizeof(*req));

    sc = packet_rpc(Conn, &p, PACKET_TYPE_OPEN_REP);
    if (packet_rpc_check(Conn, sc))
        goto reinit_and_resend;

    return sc;
}

PRIVATE SCODE NetFileDestroy(PNETFILE File)
{
    SCODE sc;
    PCONNECTION Conn = File->Conn;

    struct packet p;
    struct close_req *req = &p.u.close_req;

    /* Close file */
 reinit_and_resend:
    packet_init(&p, PACKET_TYPE_CLOSE_REQ);
    req->handle = File->Handle;
    packet_prepare(&p, sizeof(*req));

    sc = packet_rpc(Conn, &p, PACKET_TYPE_CLOSE_REP);
    if (packet_rpc_check(Conn, sc))
        goto reinit_and_resend;
    if (FAILED(sc)) {
        EPRINT(("NetFileDestroy: Close packet_rpc failed sc=x%x (ignored)\n",
                sc));
    }
    /* Destroy socket */
    ConnectionRelease(File->Conn);
    sc = NO_ERROR;

    sc = CurrentHeap()->v->Free(CurrentHeap(), 0, (PTR) File);
    if (FAILED(sc))
        EPRINT(("NetFileDestroy: Heap Free failed sc=x%x (ignored)\n", sc));
    return sc;
}


/*-------------------- IFile methods --------------------------*/

PRIVATE UINT MCT NetFileAddRef(PIFILE This)
{
    PNETFILE File = (PNETFILE) This;

    DPRINT(("NetFileADDREF"));
    return AtomicInc(&File->RefCnt);
}

PRIVATE UINT MCT NetFileNSAddRef(PINAMESPACE This)
{
    PNETFILENS Ns = (PNETFILENS) This;

    DPRINT(("NSaddref"));
    return AtomicInc(&Ns->RefCnt);
}

PRIVATE SCODE MCT NetFileQueryInterface(PIFILE This, REFIID pIid, void* *ppNew)
{
    if (IidCmp(&IID_IFile, pIid) || IidCmp(&IID_IUnknown, pIid)) {
        DPRINT(("NetFileQIok"));
        NetFileAddRef(This);
        *ppNew = This;
        return NO_ERROR;
    }
    DPRINT(("NetFileQIfail"));
    *ppNew = NULL;
    return E_NO_INTERFACE;
}

PRIVATE SCODE MCT NetFileNSQueryInterface(PINAMESPACE This, REFIID pIid, void* *ppNew)
{
    if (IidCmp(&IID_INameSpace, pIid) || IidCmp(&IID_IUnknown, pIid)) {
        DPRINT(("NSqiok"));
        NetFileNSAddRef((PINAMESPACE) This);
        *ppNew = This;
        return NO_ERROR;
    }
    DPRINT(("NSqifail"));
    *ppNew = NULL;
    return E_NO_INTERFACE;
}

PRIVATE UINT MCT NetFileRelease(PIFILE pThis)
{
    PNETFILE File = (PNETFILE) pThis;
    INT Refs;

    Refs = AtomicDec(&File->RefCnt);
    DPRINT(("NetFileRELE%d", Refs));
    if (Refs == 0)
        (void) NetFileDestroy(File);

    return Refs;
}

/*
 * Read from a file
 */
PRIVATE SCODE MCT
NetFileReadAt(PIFILE This, UINT64 Position, 
          BYTE *Buffer, UINT ByteCount, PUINT pSizeRead)
{
    SCODE sc;
    PNETFILE File = (PNETFILE) This;
    PCONNECTION Conn = File->Conn;
    UINT nread, ActualCount;

    struct packet p;
    struct read_req *req = &p.u.read_req;
    struct read_rep *rep = &p.u.read_rep;

    if (ByteCount > MAX_READ_SIZE)
        ActualCount = MAX_READ_SIZE;
    else
        ActualCount = ByteCount;

 reinit_and_resend:
    packet_init(&p, PACKET_TYPE_READ_REQ);
    req->handle = File->Handle;
    req->position = Position;
    req->count = ActualCount;
    packet_prepare(&p, sizeof(*req));

    sc = packet_rpc(Conn, &p, PACKET_TYPE_READ_REP);
    if (packet_rpc_check(Conn, sc))
        goto reinit_and_resend;
    if (FAILED(sc)) {
        EPRINT(("NetFileReadAt failed sc=%x p.sc=%x len=%x\n",
                sc, p.sc, p.packet_length));
        return sc;
    }

    nread = rep->nread > ActualCount ? ActualCount : rep->nread;

DPRINT(("NetFileReadAt(T=x%x P=%x.%x C=x%x (asked %x) PR=x%x nRead=%x sc=%x\n", (UINT) This, Position, ActualCount, ByteCount, (UINT) pSizeRead, nread, sc));

    memcpy(Buffer, rep->data, nread);
    *pSizeRead = nread;
    return sc;
}

/*
 * Write to a file
 */
PRIVATE SCODE MCT
NetFileWriteAt(PIFILE This, UINT64 Position, 
               const BYTE *Buffer, UINT ByteCount, PUINT pSizeWritten)
{
    SCODE sc;
    PNETFILE File = (PNETFILE) This;
    PCONNECTION Conn = File->Conn;

    struct packet p;
    struct write_req *req = &p.u.write_req;
    struct write_rep *rep = &p.u.write_rep;

DPRINT(("NetFileWriteAt(T=x%x P=%x.%x C=x%x PW=x%x\n", (UINT) This, Position, ByteCount, (UINT) pSizeWritten));
    if (ByteCount > MAX_READ_SIZE)
        ByteCount = MAX_READ_SIZE;

 reinit_and_resend:
    packet_init(&p, PACKET_TYPE_WRITE_REQ);
    req->handle = File->Handle;
    req->position = Position;
    req->count = ByteCount;
    memcpy(req->data, Buffer, ByteCount);
    packet_prepare(&p, sizeof(*req) - (MAX_READ_SIZE - ByteCount));

    sc = packet_rpc(Conn, &p, PACKET_TYPE_WRITE_REP);

DPRINT(("NetFileWriteAt_END(T=x%x P=%lx sc=x%x N=x%x\n", (UINT) This, Position, sc, rep->nwritten));
    if (packet_rpc_check(Conn, sc))
        goto reinit_and_resend;
    if (FAILED(sc))
        return sc;

    *pSizeWritten = rep->nwritten;
    return sc;
}

/* Get/Set a file's size
 */
PRIVATE SCODE MCT NetFileGetSize(PIFILE This, PUINT64 pSize)
{
    SCODE sc;
    PNETFILE File = (PNETFILE) This;
    PCONNECTION Conn = File->Conn;

    struct packet p;
    struct getsize_req *req = &p.u.getsize_req;
    struct getsize_rep *rep = &p.u.getsize_rep;

 reinit_and_resend:
    packet_init(&p, PACKET_TYPE_GETSIZE_REQ);
    req->handle = File->Handle;
    packet_prepare(&p, sizeof(*req));

    sc = packet_rpc(Conn, &p, PACKET_TYPE_GETSIZE_REP);
    if (packet_rpc_check(Conn, sc))
        goto reinit_and_resend;
    if (FAILED(sc))
        return sc;

DPRINT(("NetFileGetSize -> %lx (%x.%x)", rep->size, rep->size));

    *pSize = rep->size;
    return sc;
}

PRIVATE SCODE MCT NetFileSetSize(PIFILE This, UINT64 Size)
{
    SCODE sc;
    PNETFILE File = (PNETFILE) This;
    PCONNECTION Conn = File->Conn;

    struct packet p;
    struct setsize_req *req = &p.u.setsize_req;

DPRINT(("NetFileSetSize"));
 reinit_and_resend:
    packet_init(&p, PACKET_TYPE_SETSIZE_REQ);
    req->handle = File->Handle;
    req->size = Size;
    packet_prepare(&p, sizeof(*req));

    sc = packet_rpc(Conn, &p, PACKET_TYPE_SETSIZE_REP);
    if (packet_rpc_check(Conn, sc))
        goto reinit_and_resend;

    return sc;
}

const struct IFileVtbl NetFileVtbl = {
    NetFileQueryInterface, 
    NetFileAddRef, 
    NetFileRelease, 
    NetFileReadAt, 
    NetFileWriteAt, 
    NetFileSetSize, 
    NetFileGetSize
};


PRIVATE UINT MCT NetFileNSRelease(PINAMESPACE This)
{
    PNETFILENS Ns = (PNETFILENS) This;
    INT Refs;

    Refs = AtomicDec(&Ns->RefCnt);
DPRINT(("NSrele%x", Refs));
    if (Refs == 0) {
        if (Ns->Conn)
            ConnectionRelease(Ns->Conn);
        CurrentHeap()->v->Free(CurrentHeap(), 0, (PTR) Ns);
    }
    return Refs;
}

/* Always advances pName */
PRIVATE PNETFILENS ParseAndLookupNS(const _TCHAR **pName)
{
    _TCHAR server[MAX_PATH];
    UINT i_port;
    PCONNECTION Conn;
    PNETFILENS Ns;

    i_port = DEFAULT_PORT;

#if 0
    const _TCHAR *Name = *pName;
    BOOL looking_at_name = TRUE;

    for (i = 0; Name != EOS; Name++, i++) {
        if (IS_PATH_SEPARATOR(*Name)) {
            Name++;             /* Get rid of the slash */
            if (looking_at_name)
                server[i] = EOS;
            break;
        }
        if (*Name == _T(':')) {
            i_port = Atoi(Name);
            looking_at_name = FALSE;
            server[i] = EOS;
        }
        if (looking_at_name)
            server[i] = *Name;
    }
    *pName = Name;
#else
    UnusedParameter(i);
#endif

    /* Open adds ref */
    Conn = MakeConnection(server, i_port);
    if (!Conn) {
        EPRINT(("ParseAndLookupNS: MakeConnection failed\n"));
        return NULL;
    }
    Ns = AllocNetFileNS(Conn);
    if (!Ns) {
        EPRINT(("AllocNetFileNS failed"));
        ConnectionRelease(Conn);
    }
    return Ns;
}

/* Give "inetaddr:inetport/remotename", get IFile.  :inetport is optional */
PRIVATE SCODE MCT NetFileNSBind(PINAMESPACE This, const _TCHAR *Name_in, NAME_SPACE_FLAGS Flags, PIUNKNOWN *Object)
{
    PNETFILENS Ns = (PNETFILENS) This, NewNs;
    SCODE sc = NO_ERROR;
    PNETFILE File;
    _TCHAR *Name = (_TCHAR *) Name_in;

    DPRINT(("NetFileNSBind(x%x \"%s\" x%x)\n", (UINT) This, Name_in, Flags));
    /* Check flags. Parse name. Open remote file. */
    if (Object == NULL)
        return E_INVALID_PARAMETER;
    *Object = NULL;
    if (Name == NULL)
        return E_INVALID_PARAMETER;

    if (Ns->Conn == NULL) {
        /* This is the initial Name Space. Get a connected one and use it. */
        Ns = ParseAndLookupNS(&Name);   /* Always advances Name */
        if (!Ns) {
            *Object = NULL;
            return GetLastError();
        }
    } else {
        Ns->v->AddRef((PINAMESPACE) Ns);
    }
    
    if (Name[0] == _EOS) {      /* DIR start directory or this directory */
        *Object = (PIUNKNOWN) Ns;       /* May be NULL */
        DPRINT(("NetFileNSBind Ns: Name=\"%s\" Ns=x%x sc=x%x\n",
                 Name, (UINT) Ns, sc));
    } else if (IS_PATH_SEPARATOR(Name[_tcslen(Name) - 1])) { /* DIR */
        /* 
         * BUGBUG: mind "/" root directory and "//" UNC quotes etc.
         * BUT, they are not seen in practice.
         */
        Name[_tcslen(Name) - 1] = _EOS;
        /* Make sure the remembered prefix is big enough.  Make dynamic! */
        if (_tcslen(Ns->Prefix) + _tcslen(Name) + 2 > MAX_PATH) {
            sc = E_INVALID_PARAMETER;
            goto ErrorA;
        }

        NewNs = AllocNetFileNS(Ns->Conn);
        if (NewNs == NULL) {
            sc = GetLastError();
            goto ErrorA;
        }
        ConnectionAddRef(NewNs->Conn);
        sc = ComposePathToTchar(NewNs->Prefix, MAX_PATH, Ns->Prefix, Name);
        Ns->v->Release((PINAMESPACE) Ns);
        if (FAILED(sc))
            goto ErrorB;
        DPRINT(("NetFileNSBind subdir: NewNs=%x Prefix=\"%s\"\n",
                 (UINT) NewNs, NewNs->Prefix));

        /* Check if it really exists on remote or create it. */
        if (Flags & NAME_SPACE_CREATE) {
            /* Create it! */
            sc = NetFileMkDir(NewNs);
            if (FAILED(sc)) {
                DPRINT(("NetFileNSBind: create subdir \"%s\" failed %x\n",
                         NewNs->Prefix, sc));
                goto ErrorB;
            }
        } else {
            /* Does it exist then? */
            _TCHAR tmpbuf[10];
            UINT tmp;
            sc = NewNs->v->FindNext((PINAMESPACE) NewNs, _T(""), _T(""),
                                    tmpbuf, sizeof(tmpbuf), &tmp);
            if (FAILED(sc)) {
                DPRINT(("NetFileNSBind: nonexisting subdir \"%s\" rejected %x\n",
                         NewNs->Prefix, sc));
                goto ErrorB;
            }
        }

        *Object = (PIUNKNOWN) NewNs;
        return NO_ERROR;
    ErrorA:
        Ns->v->Release((PINAMESPACE) Ns);
        *Object = NULL;
        return sc;
    ErrorB:
        NewNs->v->Release((PINAMESPACE) NewNs);
        *Object = NULL;
        return sc;
    } else {                    /* FILE */
        sc = OpenNetFile(Ns->Conn, Ns->Prefix, Name, &File, Flags);
        if (SUCCEEDED(sc))
            ConnectionAddRef(Ns->Conn);
        DPRINT(("NetFileNSBind File: Name=%s Ns=x%x file=x%x fla=%x sc=x%x\n",
                 Name, (UINT) Ns, (UINT) File, Flags, sc));
        *Object = (PIUNKNOWN) File;     /* may be NULL */
        Ns->v->Release((PINAMESPACE) Ns);               /* not returned */
    }
    return sc;
}

PRIVATE SCODE MCT NetFileNSFindNext(PINAMESPACE This, const _TCHAR *Prefix,
         const _TCHAR *Previous,_TCHAR *Buffer, UINT BufSize, PUINT StrLen_out)
{
    SCODE sc;
    PNETFILENS Ns = (PNETFILENS) This;
    PCONNECTION Conn = Ns->Conn;
    UINT len;

    struct packet p;
    struct findnext_req *req = &p.u.findnext_req;
    struct findnext_rep *rep = &p.u.findnext_rep;

DPRINT(("NetFileNSFindNext(Ns=x%x Ns->Prefix=\"%ls\" Prefix=\"%ls\" Previ=\"%ls\") Conn=x%x\n",
        (UINT) Ns, Ns->Prefix, Prefix ? Prefix : "NULL",
        Previous ? Previous : "NULL", (UINT) Conn));

    if (Previous == NULL) Previous = "";
    if (Prefix == NULL) Prefix = "";

    /* at least the _EOS must fit in Buffer */
    if (BufSize < sizeof(_TCHAR) || Buffer == NULL)
        return E_INVALID_PARAMETER;

#if 0
    if (Conn == NULL) {
        /* BUGBUG: The prefix might contain an address. Not in real life. */
        return E_NOT_READY;     /* Something else? */
    }
#endif

 reinit_and_resend:
    packet_init(&p, PACKET_TYPE_FINDNEXT_REQ);
    StrNCpyTcharToWchar(req->previous, Previous, MAX_PATH);
    /* Compose req->prefix from pieces.  Make this a separate function */
    sc = ComposePathToWchar(req->prefix, MAX_PATH, Ns->Prefix, Prefix);
    if (FAILED(sc))
        return sc;

    packet_prepare(&p, sizeof(*req));

    sc = packet_rpc(Conn, &p, PACKET_TYPE_FINDNEXT_REP);
    if (packet_rpc_check(Conn, sc))
        goto reinit_and_resend;
    if (FAILED(sc))
        return sc;

    len = StrLenWchar(rep->name);
    if (len < BufSize/sizeof(_TCHAR))
        StrNCpyWcharToTchar(Buffer, rep->name, len);
    else {
        sc = S_BUFFER_TOO_SMALL;
        len = 0;
    }

    Buffer[len] = _EOS;
    if (StrLen_out)
        *StrLen_out = len;
    return sc;
}

/* We need separate implementations for each unimplemented method because
 * of __stdcall. Argh.
 */
PRIVATE SCODE MCT UnimplementedNameRegister(PINAMESPACE This,
                const _TCHAR *Name, PIUNKNOWN Obj, UINT Flags, PINAMESPACE SNS)
{
    UnusedParameter(This); UnusedParameter(Name); UnusedParameter(Obj);
    UnusedParameter(Flags); UnusedParameter(SNS);
    return E_NOT_IMPLEMENTED;
}

PRIVATE SCODE MCT UnimplementedNameUnregister(PINAMESPACE This, const _TCHAR *Name)
{
    UnusedParameter(This); UnusedParameter(Name);
    return E_NOT_IMPLEMENTED;
}

PRIVATE SCODE MCT UnimplementedNameRename(PINAMESPACE This, const _TCHAR *Name,
                                  const _TCHAR *NewName)
{
    UnusedParameter(This); UnusedParameter(Name); UnusedParameter(NewName);
    return E_NOT_IMPLEMENTED;
}

PRIVATE SCODE MCT UnimplementedNameCopy(PINAMESPACE This, const _TCHAR *Name,
                                const _TCHAR *NewCopy)
{
    UnusedParameter(This); UnusedParameter(Name); UnusedParameter(NewCopy);
    return E_NOT_IMPLEMENTED;
}

PRIVATE SCODE MCT UnimplementedNameFlush(PINAMESPACE This, const _TCHAR *Name)
{
    UnusedParameter(This); UnusedParameter(Name);
    return E_NOT_IMPLEMENTED;
}

PRIVATE SCODE MCT UnimplementedNameGetCapabilities(PINAMESPACE This,
                              const _TCHAR *Name, NAME_SPACE_FLAGS *Flags_out)
{
    UnusedParameter(This); UnusedParameter(Name); UnusedParameter(Flags_out);
    return E_NOT_IMPLEMENTED;
}

const struct INameSpaceVtbl NetFileNSVtbl = {
    NetFileNSQueryInterface,
    NetFileNSAddRef,
    NetFileNSRelease,
    UnimplementedNameRegister,
    UnimplementedNameUnregister,
    NetFileNSBind,
    NetFileNSFindNext,
    UnimplementedNameGetCapabilities
};

/*--------------------- Initialization ----------------------*/

INT RegisterEndpointInterfaces(void);

PINAMESPACE InitHostFileSystem()
{
#if 0
    SCODE sc;
    sc = SimFile_Init();
    if (FAILED(sc)) {
        SetLastError(sc);
        return NULL;
    }
#endif
    return (PINAMESPACE) AllocNetFileNS(NULL);
}

#if 0
PRIVATE SCODE NetFileNSCreate()
{
    SCODE sc;
    PNETFILENS Ns;
    PINAMESPACE IName;
    const _TCHAR *NFname = PUBLIC_DIR _T("NetFile") STR_PATH_SEPARATOR;

    RegisterEndpointInterfaces();

    IName = CurrentNameSpace();
    if (!IName)
        return GetLastError();

    Ns = AllocNetFileNS(NULL);
    if (!Ns)
        return GetLastError();

    sc = IName->v->Register(IName, NFname, (PIUNKNOWN) Ns,
                            NAME_SPACE_CREATE, NULL);
    if (FAILED(sc))
        EPRINT(("NetFileNSCreate: register x%x\n", sc));
    else
        EPRINT(("Registered NetFile Server as %s\n", NFname));

    Ns->v->Release((PINAMESPACE) Ns);
    return sc;
}
#endif


/* ------------ Loose ends from netmisc.c ----------------- */
PRIVATE UINT StrLenWchar(const wchar_t *pStr)
{
    UINT Count = 0;

    while (*pStr++ != _EOS)
        Count++;

    return Count;
}

/* Count should be non-zero and indicates the size of the destination buffer.
 * Always null-terminates the destination string.
 */
PRIVATE void StrNCpyWcharToTchar(_TCHAR *pDst, const wchar_t *pSrc, UINT Count)
{
    _TCHAR c;

    while (--Count != 0) {
        c = (_TCHAR) *pSrc++;
        if (c == _EOS)
            break;
        *pDst++ = c;
    }
    *pDst = _EOS;
}

/* Count should be non-zero and indicates the size of the destination buffer.
 * Always null-terminates the destination string.
 */
PRIVATE void StrNCpyTcharToWchar(wchar_t *pDst, const _TCHAR *pSrc, UINT Count)
{
    wchar_t c;

    while (--Count != 0) {
        c = (wchar_t) *pSrc++;
        if (c == _EOS)
            break;
        *pDst++ = c;
    }
    *pDst = 0;
}

PRIVATE SCODE ComposePathToTchar(_TCHAR *NewPath, UINT MaxLen,
                                 const _TCHAR *Prefix, const _TCHAR *Name)
{
    _TCHAR *s;
    UINT len;

    len = _tcslen(Prefix) + _tcslen(Name) + 2;
    if (len > MaxLen) {
        /* So what should we do? */
        EPRINT(("ComposePath \"%s\" \"%s\" too long %x > %x\n",
                 Prefix, Name, len, MaxLen));
        return E_INVALID_PARAMETER; /* reject it altogether */
    }

    /* Combine Prefix and Name  "Prefix/Name" or "Prefix" or "Name" or "" */
    _tcscpy(NewPath, Prefix);
    if (Prefix[0] != _EOS && Name[0] != _EOS)
        _tcscat(NewPath, _T("\\")); /* NT separator */
    _tcscat(NewPath, Name);

    /* Remove trailing slash */
    len = _tcslen(NewPath);
    if (len > 0 && IS_PATH_SEPARATOR(NewPath[len - 1]))
        NewPath[len - 1] = _EOS;

    /* Convert slashes to backslashes for NT */
    for (s = NewPath; s[0] != _EOS; s++)
        if (IS_PATH_SEPARATOR(s[0]))
            s[0] = _T('\\');    /* NT separator */
    DPRINT(("ComposePath \"%s\" \"%s\" -> \"%s\" sizoef(*p)=%x\n", Prefix, Name, NewPath, sizeof(struct packet)));
    return NO_ERROR;
}

#if _UNICODE
PRIVATE SCODE ComposePathToWchar(wchar_t *NewPath, UINT MaxLen,
                                 const _TCHAR *Prefix, const _TCHAR *Name)
{
    return ComposePathToTchar(NewPath, MaxLen, Prefix, Name);
}
#else
PRIVATE SCODE ComposePathToWchar(wchar_t *NewPath, UINT MaxLen,
                                 const _TCHAR *Prefix, const _TCHAR *Name)
{
    _TCHAR Buffer[MAX_PATH * sizeof(_TCHAR)];
    SCODE sc;

    sc = ComposePathToTchar(Buffer, MAX_PATH, Prefix, Name);
    if (FAILED(sc))
        return sc;

    StrNCpyTcharToWchar(NewPath, Buffer, MaxLen);
    return sc;
}
#endif
