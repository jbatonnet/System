/* Copyright (c) Microsoft Corporation. All rights reserved. */


#ifndef __SOCK__
#define __SOCK__ 1


#include <mmlite.h>
#include <mmhal.h>

/* Basic initialization */
#define PROTOCOL_START_DRIVERS 1
#define PROTOCOL_START_DHCP 2
#define PROTOCOL_START_LO 4
SCODE ProtocolStart(UINT what);

//#define __WANTS_STATS
#ifdef __WANTS_STATS
#define _COLLECT_STAT(x) x
#else
#define _COLLECT_STAT(x)
#endif

/* Various types needed by netif.h */
#define HTTP_DEFAULT_PORT               80
struct sockaddr;
struct rtentry;
struct mbuf;
struct ifnet;
struct ether_header;
#include <netif.h>
#include <drivers/drivers.h>
#include <driverif.h>


#ifdef _MSC_VER
#pragma warning(disable:4100 4133)  /* Unreferenced formal parameter */
#endif

#ifndef PRIVATE
#define PRIVATE static
#define PUBLIC
#endif

/*
 * Configuration switches
 */
#if !defined(_MINIMIZE_NET)
# if _MINIMIZE
#  define _MINIMIZE_NET 1
# else
#  define _MINIMIZE_NET 0
# endif
#endif

#define BSD 44
#define COMPAT_43 1
#define MMLITE_EXT 1
#define INET 1
#define RAW_SOCKETS 1
#define ROUTE_SOCKETS 1
#define MULTICAST 1
# define __WANTS_TCP
#if defined (_MINIMIZE_NET) && (_MINIMIZE_NET == 0)
# define __WANTS_IGMP
# define MROUTING
#endif
#define __WANTS_UDP 1

#define __WANTS_DSR 0           /* Until moved to public tree */
//#define __WANTS_DSR !_MINIMIZE_NET

#define NBPFILTER 0

#define MONARCH_ADHOC __WANTS_DSR
//#define MONARCH_DEBUG 1

#define KERNEL 1

/* Macros and types
 */
#define __CONCAT(x,y) x ## y
#define roundup(x, y) ((((x)+((y)-1))/(y))*(y))

typedef UINT16 u_short;
typedef UINT8 u_char;
typedef UINT32 u_long;
typedef UINT32 u_int;
typedef char *caddr_t;

typedef INT32 pid_t;

#define u_int8_t UINT8
#define u_int16_t UINT16
#define u_int32_t UINT32

/* param.h, machdep */
#define MSIZE 128L
#define MCLBYTES 2048L
/* end param.h */


/* instead of kernel.h */
extern TIME time(void);
#define tv_sec(x) ((UINT32) Int64ToInt32(Int64DividedByInt32(x,10000000)))
/* end kernel.h */

/* instead of malloc.h */
#define M_FREE          0       /* should be on free list */
#define M_MBUF          1       /* mbuf */
#define M_DEVBUF        2       /* device driver memory */
#define M_SOCKET        3       /* socket structure */
#define M_PCB           4       /* protocol control block */
#define M_RTABLE        5       /* routing tables */
#define M_HTABLE        6       /* IMP host tables */
#define M_FTABLE        7       /* fragment reassembly header */
#define M_ZOMBIE        8       /* zombie proc status */
#define M_IFADDR        9       /* interface address */
#define M_SOOPTS        10      /* socket options */
#define M_SONAME        11      /* socket name */
#define M_NAMEI         12      /* namei path name buffer */
#define M_GPROF         13      /* kernel profiling buffer */
#define M_IOCTLOPS      14      /* ioctl data buffer */
#define M_MAPMEM        15      /* mapped memory descriptors */
#define M_CRED          16      /* credentials */
#define M_PGRP          17      /* process group header */
#define M_SESSION       18      /* session header */
#define M_IOV           19      /* large iov's */
#define M_MOUNT         20      /* vfs mount struct */
#define M_FHANDLE       21      /* network file handle */
#define M_NFSREQ        22      /* NFS request header */
#define M_NFSMNT        23      /* NFS mount structure */
#define M_NFSNODE       24      /* NFS vnode private part */
#define M_VNODE         25      /* Dynamically allocated vnodes */
#define M_CACHE         26      /* Dynamically allocated cache entries */
#define M_DQUOT         27      /* UFS quota entries */
#define M_UFSMNT        28      /* UFS mount structure */
#define M_SHM           29      /* SVID compatible shared memory segments */
#define M_VMMAP         30      /* VM map structures */
#define M_VMMAPENT      31      /* VM map entry structures */
#define M_VMOBJ         32      /* VM object structure */
#define M_VMOBJHASH     33      /* VM object hash structure */
#define M_VMPMAP        34      /* VM pmap */
#define M_VMPVENT       35      /* VM phys-virt mapping entry */
#define M_VMPAGER       36      /* XXX: VM pager struct */
#define M_VMPGDATA      37      /* XXX: VM pager private data */
#define M_FILE          38      /* Open file structure */
#define M_FILEDESC      39      /* Open file descriptor table */
#define M_LOCKF         40      /* Byte-range locking structures */
#define M_PROC          41      /* Proc structures */
#define M_SUBPROC       42      /* Proc sub-structures */
#define M_SEGMENT       43      /* Segment for LFS */
#define M_LFSNODE       44      /* LFS vnode private part */
#define M_FFSNODE       45      /* FFS vnode private part */
#define M_MFSNODE       46      /* MFS vnode private part */
#define M_NQLEASE       47      /* Nqnfs lease */
#define M_NQMHOST       48      /* Nqnfs host address table */
#define M_NETADDR       49      /* Export host address structure */
#define M_NFSSVC        50      /* Nfs server structure */
#define M_NFSUID        51      /* Nfs uid mapping structure */
#define M_NFSD          52      /* Nfs server daemon structure */
#define M_IPMOPTS       53      /* internet multicast options */
#define M_IPMADDR       54      /* internet multicast address */
#define M_IFMADDR       55      /* link-level multicast address */
#define M_MRTABLE       56      /* multicast routing tables */
#define M_TEMP          74      /* misc temporary data buffers */
#define M_DHCPINFO	75 
#define M_DHCPHOST	76
#define M_DHCPOPT	77
#define M_WAITFOR	78
#define M_LAST          79      /* Must be last type + 1 */

#define M_WAITOK 0x0000
#define M_NOWAIT 0x0001
#define M_ZERO   0x0002

extern PTR bsd_malloc(UINT NBytes, UINT Tag, UINT Options);
extern void bsd_free(PTR Ptr, UINT Tag);
#define MALLOC(space, cast, size, type, flags) \
        (space) = (cast)bsd_malloc((UINT)(size), type, flags)
#define FREE(addr, type) bsd_free(addr,type)
/* end malloc.h */


/* instead of errno.h (xxx should just include winsock.h) */
/*
 * All Windows Sockets error constants are biased by WSABASEERR from
 * the "normal"
 */
#define WSABASEERR           10000

#define EINTR                (WSABASEERR+4)
#define EACCES               (WSABASEERR+13)
#define EFAULT               (WSABASEERR+14)
#define EINVAL               (WSABASEERR+22)

#define EWOULDBLOCK          (WSABASEERR+35)
#define EINPROGRESS          (WSABASEERR+36)
#define EALREADY             (WSABASEERR+37)
#define ENOTSOCK             (WSABASEERR+38)
#define EDESTADDRREQ         (WSABASEERR+39)
#define EMSGSIZE             (WSABASEERR+40)
#define EPROTOTYPE           (WSABASEERR+41)
#define ENOPROTOOPT          (WSABASEERR+42)
#define EPROTONOSUPPORT      (WSABASEERR+43)
#define EOPNOTSUPP           (WSABASEERR+45)
#define EAFNOSUPPORT         (WSABASEERR+46)
#define EADDRINUSE           (WSABASEERR+48)
#define EADDRNOTAVAIL        (WSABASEERR+49)
#define ENETDOWN             (WSABASEERR+50)
#define ENETUNREACH          (WSABASEERR+51)
#define ENETRESET            (WSABASEERR+52)
#define ECONNABORTED         (WSABASEERR+53)
#define ECONNRESET           (WSABASEERR+54)
#define ENOBUFS              (WSABASEERR+55)
#define EISCONN              (WSABASEERR+56)
#define ENOTCONN             (WSABASEERR+57)
#define ESHUTDOWN            (WSABASEERR+58)  /* covers EPIPE */
#define ETOOMANYREFS         (WSABASEERR+59)
#define ETIMEDOUT            (WSABASEERR+60)
#define ECONNREFUSED         (WSABASEERR+61)
#define EHOSTDOWN            (WSABASEERR+64)
#define EHOSTUNREACH         (WSABASEERR+65)
#define EDQUOT               (WSABASEERR+69)

#if 0
/*unused errors from winsock.h */
#define ESOCKTNOSUPPORT      (WSABASEERR+44)
#define EPFNOSUPPORT         (WSABASEERR+46)
#define ELOOP                (WSABASEERR+62)
#define ENAMETOOLONG         (WSABASEERR+63)
#define ENOTEMPTY            (WSABASEERR+66)
#define EPROCLIM             (WSABASEERR+67)
#define EUSERS               (WSABASEERR+68)
#define ESTALE               (WSABASEERR+70)
#define EREMOTE              (WSABASEERR+71)
#endif

#ifndef WSASYSNOTREADY          /* WinError.h defines same value differently */
/*
 * Extended Windows Sockets error constant definitions
 */
#define WSASYSNOTREADY       (WSABASEERR+91)
#define WSAVERNOTSUPPORTED   (WSABASEERR+92)
#define WSANOTINITIALISED    (WSABASEERR+93)
#endif

/* end errno.h */


/* instead of ioctl.h */
#define IOCPARM_MASK    0x7ff            /* parameters must be < 2k bytes */
#define IOCGROUP(x)     (((x) >> 8) & 0xff)
#define IOC_VOID        0x20000000      /* no parameters */
#define IOC_OUT         0x40000000      /* copy out parameters */
#define IOC_IN          0x80000000      /* copy in parameters */
#define _IOC(inout,group,num,len) \
        (inout | ((len & IOCPARM_MASK) << 16) | ((group) << 8) | (num))
#define _IO(g,n)        _IOC(IOC_VOID,  (g), (n), 0)
#define _IOR(g,n,t)     _IOC(IOC_OUT,   (g), (n), sizeof(t))
#define _IOW(g,n,t)     _IOC(IOC_IN,    (g), (n), sizeof(t))
/* this should be _IORW, but stdio got there first */
#define _IOWR(g,n,t)    _IOC(IOC_IN | IOC_OUT,  (g), (n), sizeof(t))


#define SIOCATMARK      _IOR('s',  7, int)              /* at oob mark? */
#define SIOCSPGRP       _IOW('s',  8, int)              /* set process group */
#define SIOCGPGRP       _IOR('s',  9, int)              /* get process group */

#define SIOCSIFADDR     _IOW('i', 12, struct ifreq)     /* set ifnet address */
#define OSIOCGIFADDR    _IOWR('i',13, struct ifreq)     /* get ifnet address */
#define SIOCGIFADDR     _IOWR('i',33, struct ifreq)     /* get ifnet address */
#define SIOCSIFDSTADDR  _IOW('i', 14, struct ifreq)     /* set p-p address */
#define OSIOCGIFDSTADDR _IOWR('i',15, struct ifreq)     /* get p-p address */
#define SIOCGIFDSTADDR  _IOWR('i',34, struct ifreq)     /* get p-p address */
#define SIOCSIFFLAGS    _IOW('i', 16, struct ifreq)     /* set ifnet flags */
#define SIOCGIFFLAGS    _IOWR('i',17, struct ifreq)     /* get ifnet flags */
#define OSIOCGIFBRDADDR _IOWR('i',18, struct ifreq)     /* get brdcast addr */
#define SIOCGIFBRDADDR  _IOWR('i',35, struct ifreq)     /* get brdcast addr */
#define SIOCSIFBRDADDR  _IOW('i',19, struct ifreq)      /* set brdcast addr */
#define OSIOCGIFCONF    _IOWR('i',20, struct ifconf)    /* get ifnet list */
#define SIOCGIFCONF     _IOWR('i',36, struct ifconf)    /* get ifnet list */
#define OSIOCGIFNETMASK _IOWR('i',21, struct ifreq)     /* get net addr mask */
#define SIOCGIFNETMASK  _IOWR('i',37, struct ifreq)     /* get net addr mask */
#define SIOCSIFNETMASK  _IOW('i',22, struct ifreq)      /* set net addr mask */
#define SIOCGIFMETRIC   _IOWR('i',23, struct ifreq)     /* get IF metric */
#define SIOCSIFMETRIC   _IOW('i',24, struct ifreq)      /* set IF metric */
#define SIOCDIFADDR     _IOW('i',25, struct ifreq)      /* delete IF addr */
#define SIOCAIFADDR     _IOW('i',26, struct ifaliasreq) /* add/chg IF alias */
#define SIOCSIFDEBUG    _IOW('i',27, struct ifreq)      /* set IF debug opt */

#define SIOCADDMULTI    _IOW('i', 49, struct ifreq)     /* add m'cast addr */
#define SIOCDELMULTI    _IOW('i', 50, struct ifreq)     /* del m'cast addr */

#ifdef MMLITE_EXT
#define SIOCGIFSTATS    _IOWR('i',42, struct if_data)   /* get statistics */
#define SIOCIDHCP       _IOW('i',43, struct ifreq)      /* initiate DHCP */
#define SIOCGDHCPINFO   _IOWR('i',44, struct DhcpInfo)  /* get DHCP info */
#define SIOCGDHCPOPTION _IOWR('i',45, struct DhcpOption)  /* get DHCP option */
#define SIOCGDHCPFILE _IOWR('i',46, char[255])  /* get DHCP boot filename */
#define SIOCGDHCPINFOPTR _IOWR('i',47, struct ifreq)/* get pointer to DHCP info */
#endif

#define FIONREAD        _IOR('f', 127, int)     /* get # bytes to read */
#define FIONBIO         _IOW('f', 126, int)     /* set/clear non-blocking i/o */
#define FIOASYNC        _IOW('f', 125, int)     /* set/clear async i/o */

/* end ioctl.h */

/* instead of uio.h */
/* xxx just an iovec */
struct uio {
    caddr_t uio_pointer;
    INT uio_resid;
};
/* end uio.h */

/*
 * Message header for the various recv and send calls.
 */
struct msghdr {
    struct sockaddr *msg_name;  /* optional address */
    UINT msg_namelen;  /* size of address */
    UINT32 msg_flags;  /* flags on received message */
    struct uio req;    /* holds: */
                       /* uio_pointer: src/dst pointer */
                       /* uio_resid  : # bytes requested */
};

#ifdef COMPAT_43
#define MSG_COMPAT 0x8000
#endif

/* other stuff */
#define uiomoveout(_f_,_s_,_u_) \
    { \
          UINT _ss_ = _s_; \
          memcpy( (_u_)->uio_pointer, _f_, _ss_ ); \
          (_u_)->uio_resid -= _ss_; \
          (_u_)->uio_pointer += _ss_; \
    }
#define uiomovein(_t_,_s_,_u_) \
    { \
          UINT _ss_ = _s_; \
          memcpy( _t_, (_u_)->uio_pointer, _ss_ ); \
          (_u_)->uio_resid -= _ss_; \
          (_u_)->uio_pointer += _ss_; \
    }
#define bcopy(f,t,n) memcpy(t,f,n)
#define bcmp(a,b,n)  memcmp(a,b,n)
#define bzero(p,n)   memset(p,0,n)
/* is this right ? */
#define ovbcopy(f,t,n) memcpy(t,f,n)

#define typed_min(_a_, _b_, _type_)     \
        (((_type_)(_a_)) < ((_type_)(_b_)) ? ((_type_)(_a_)) : ((_type_)(_b_))) 

#define typed_max(_a_, _b_, _type_)     \
        (((_type_)(_a_)) > ((_type_)(_b_)) ? ((_type_)(_a_)) : ((_type_)(_b_)))

#ifndef min
#define min(_a_, _b_)   typed_min(_a_, _b_, UINT)
#endif

#ifndef max
#define max(_a_, _b_)   typed_max(_a_, _b_, UINT)
#endif

#define imin(_a_, _b_)  typed_min(_a_, _b_, INT)
#define imax(_a_, _b_)  typed_max(_a_, _b_, INT)

typedef struct _MYQUEUE {
    struct _MYQUEUE *Next;
    struct _MYQUEUE *Prev;
} MYQUEUE;

extern void insque(MYQUEUE *What, MYQUEUE *Where);
extern void remque(MYQUEUE *What);

extern void errlog(UINT Level, char *Fmt, UINT a1, UINT a2);
#define LOG_DEBUG 0
#define LOG_INFO  1
#define LOG_WARN  2
#define LOG_ERR   3

/* The real includes..
 */
#include <net/socket.h>
#include <net/socketv.h>
#include <net/mbuf.h>
#include <net/protosw.h>


/* Scaffolding
 */
extern void panic(char *Msg);

extern void RTLCALLTYPE NetLock(void);
extern void RTLCALLTYPE NetUnlock(void);
extern INT XXXWaitFor(PTR Event, const char *Msg, TIME TimeOut);
extern void WakeUp(PTR event);

#define psignal(x,y) panic("What about signals ?");


/* Byte swappings, for LITTLE ENDIAN boxes only.
 * (Else these should be the identity function)
 */
#if BYTE_ORDER == LITTLE_ENDIAN

#if defined(_MSC_VER)
#pragma warning(disable:4035)  /* disable warning C4035: no return value */
#endif

PRIVATE INLINE UINT16 Htons(UINT16 This)
{
#if 0
#if defined (i386)
    __asm {
        mov ax,This;
        xchg ah,al;
    }
#endif
#else
#define __BROKEN_INLINE_HTONS_DAMNIT__
#endif
#if defined (mips) || defined (__BROKEN_INLINE_HTONS_DAMNIT__)
/*
 *  __asm {
 *      sra  v0,a0,8;
 *      andi v0,v0,0xff;
 *      sll  a0,a0,8;
 *      or   v0,v0,a0;
 *      andi v0,v0,0xffff;
 *  }
 */
    UINT v = (UINT) This;
    return (UINT16) (((v >> 8) & 0xff) | ((v << 8) & 0xff00));
#endif

}
PRIVATE INLINE UINT32 Htonl(UINT32 This)
{
#if defined (i386)
    __asm {
        mov eax,This;
        xchg ah,al;
        rol eax,16;
        xchg ah,al;
    }
#elif BYTE_ORDER == BIG_ENDIAN
    return This;
#else
/*
 *  __asm {
 *      srl  v1,a0,24;
 *      sll  v0,a0,24;
 *      or   v0,v0,v1;
 *      andi v1,a0,0xff00;
 *      sll  v1,v1,8;
 *      or   v0,v0,v1;
 *      srl  v1,a0,8;
 *      andi v1,v1,0xff00;
 *      or   v0,v0,v1
 *  }
 */
    UINT v = (UINT) This;
    return (UINT32) ((v >> 24) | (v << 24) |
                          ((v & 0xff00) << 8) | ((v >> 8) & 0xff00));
#endif
}

#define htonl(x) Htonl(x)
#define ntohl(x) Htonl(x)
#define htons(x) Htons(x)
#define ntohs(x) Htons(x)
#define HTONS(x) x = ntohs(x)
#define NTOHS(x) x = ntohs(x)
#define NTOHL(x) x = ntohl(x)
#define HTONL(x) x = ntohl(x)

#if defined(_MSC_VER)
#pragma warning(default:4035)   /* reenable warning C4035   */
#endif

#elif BYTE_ORDER == BIG_ENDIAN

#define htonl(x) x
#define ntohl(x) x
#define htons(x) x
#define ntohs(x) x
#define HTONS(x)
#define NTOHS(x)
#define NTOHL(x)
#define HTONL(x)

#endif

#endif /* __SOCK__ */
