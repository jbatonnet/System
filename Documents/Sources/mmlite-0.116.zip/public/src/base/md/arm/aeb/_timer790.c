/* Copyright (c) Microsoft Corporation. All rights reserved. */
/*
 * Time might be kept using both an RTC and the PIT (timer 0).
 * The former gives an RTCDelta interrupt granularity, and
 * is the sole responsible for the drift [temperature & co.].
 * The latter gives fine grain resolution, and is used for
 * scheduling purposes.
 *
 * The basic idea is that the current time is given by
 *
 *      Now = TOY + ReloadDelta + (Ticks - PIT)
 *
 * where TOY is the accumulated count of the RTC interrupts,
 * ReloadDelta is the accumulated count of PIT reloads (one
 * reload per rescheduling), Ticks is the value the PIT was
 * last reloaded with, and PIT is the current reading of
 * the PIT.
 *
 * An important but subtle point is how the subexpression
 * in parens is evaluated.  PIT is a 16 bit counter, which
 * counts down from the (Ticks) value it is loaded with.
 * When it reaches zero it keeps decrementing from xFFFF.
 * (We use the Intel 8254 in Mode0).
 * By using signed 16 bits arithmetic we are guaranteed that
 * the (unsigned!) result of the subtraction is precisely
 * the number of ticks elapsed.  Assuming only that we did
 * not ignore the PIT interrupt for e.g. 54 milliseconds,
 * which is a safe assumption (else this whole OS is garbage..).
 *
 *
 * Formal analysis was based on the following pseudo code.
 *
 * TIME TimeNow() :: 
 *      return TOY + ReloadDelta + (Ticks - PIT)
 *
 * PIT.Set(t) ::
 *      ReloadDelta += (Ticks - PIT)
 *      PIT = t
 *      Ticks = t
 *
 * PIT.Interrupt() :: <nothing needed>
 *
 * RTC.Set(t) ::
 *      TOY = t
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * RTC.Interrupt() ::
 *      TOY += RTCDelta   -- constant, 16msec
 *      ReloadDelta = 0
 *      Ticks = PIT
 *
 * All functions are assumed atomic interrupt-wise.
 *
 * Notice that the above proof still holds if we remove
 * the RTC chip: just cancel RTC.Interrupt() and wire TOY==0.
 * Drift analysis (in PIT.Set()) becomes important, e.g. the
 * time between the first and second statement.
 *
 * This is the way it is used in this file for the MSP processor.
 *
 */

#include <mmlite.h>
#include <fred.h>
#include <mmhal.h>
#include <_irq790.h>
#include "_pic790.h"
#include "_timer790.h"

static UINT32 LastTimerVal;

/* Note: interrupts must be off inside this function*/
void PITWrite( UINT TimerVal )
{
    /* Save last written timer val in case we try to read
     * value back before timer has latched it
     */
    LastTimerVal = TimerVal;

    /* After writing a control word, timer 0 is shut off until a
     * count is written.
     */
    TheHWTimer->Control = SC_0 | RW_LSB_MSB | BINARY | MODE0;
    
    /* Write initial count D[15:0] to timer 0
     */
    TheHWTimer->Timer0 = (BYTE)(TimerVal & 0xFF);
    TheHWTimer->Timer0 = (BYTE)(TimerVal >> 8);   /* Timer0 enabled*/

    return;
}

/* Note: interrupts must be off inside this function*/
UINT PITRead(void)
{
    UINT TimerVal;
    BYTE Timer0Status;

    /* Latch status & count of timer 0.
     */
    TheHWTimer->Control = SC_READBACK | RB_0;

    Timer0Status = TheHWTimer->Timer0;           /* Read Timer0 status byte*/
    TimerVal  = TheHWTimer->Timer0;              /* Read LSB0*/
    TimerVal |= TheHWTimer->Timer0 << 8;         /* Read MSB0*/

    /* If timer never latched last written value, lsw/msw may be garbage
     * so return last value that was written to timer
     */
#if 0
    if (Timer0Status & STATUS_NULL) {
        DebugBreak();
//      TimerVal = LastTimerVal;
    }
#endif

    return TimerVal;
}

/* Timer 2 is used as a general purpose debugging counter. Resolution
 * is currently programmed at 10.67 uS.  That can be changed in
 * EnableTimers(), below.
 */
UINT16 ReadCounter(void)
{
    UINT16 TimerVal;
    BYTE Timer2Status;

    /* Latch status & count of timer 2.
     */
    TheHWTimer->Control = SC_READBACK | RB_2;

    Timer2Status = TheHWTimer->Timer2;           /* Read Timer2 status byte*/
    TimerVal  = TheHWTimer->Timer2;              /* Read LSB0*/
    TimerVal |= TheHWTimer->Timer2 << 8;         /* Read MSB0*/

    if ((Timer2Status & STATUS_NULL) != 0) {
        DebugBreak();
    }

    return TimerVal;

}

volatile struct {
    TIME Toy;                   /* Time-of-year */
    UINT32 ReloadDelta;         /* PIT Ticks since Toy */
    UINT32 TicksDelta;          /* Current PIT reload value */
} SystemTimers = {
    Int64Initializer(0, 0),
    0,
    0};

BOOL TimerIsr(void *pThis, BOOL *pNotMine)
{
    UnusedParameter(pThis);

    /* We know the counter is 0; update the stored values now so that
     * we reduce the likelihood of an overflow. 
     */
    SystemTimers.ReloadDelta += SystemTimers.TicksDelta;
    SystemTimers.TicksDelta = 0;

    *pNotMine=FALSE;
    return TRUE;
}

/* We get exactly 3 clock tics per second.
 */
BOOL ClockIsr(void *pThis, BOOL *pNotMine)
{
    static const TIME ClockTick    = Int64Initializer(0,3333333);
    static const TIME ClockTickAdj = Int64Initializer(0,3333334);
    static UINT driftTick = 3;

    /* The timer is programmed as a rate generator, where the interrupt
     * is active for one and only one clock.  The interrupt controller
     * treats it edge triggered.
     */

    SystemTimers.TicksDelta = PITRead();
    SystemTimers.ReloadDelta = 0;

    if (0 == --driftTick) {
        driftTick = 3;
        SystemTimers.Toy = TimeAdd(SystemTimers.Toy, ClockTickAdj);
    } else {
        SystemTimers.Toy = TimeAdd(SystemTimers.Toy, ClockTick);
    }

    *pNotMine=FALSE;
    return FALSE;
}

/*
 * Timers are fed by a 24.0000 Mhz clock signal which is divided by 16
 * resulting in an actual 1.50000 Mhz signal.  Max PIT interval is
 * 0x10000 * resolution == 43.6907 ms.  Max for delta is therefore
 * 0x6AAA4.  Assume 170us max timer interrupt latency.
 */
#define PIT_MAX_INTERVAL (0x6AAA4 - 1700)

/* Arm the PIT for a TIME (100ns) DELTA
 */

BOOL SetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    static TIME PitMaxInterval = Int64Initializer(0,PIT_MAX_INTERVAL);
    UINT32 Ticks;
    UINT32 r, Pit;
    UINT IntrState;
    BOOL StateWas;

    if (TimeLess(PitMaxInterval, Delta)) {
        Ticks = PIT_MAX_INTERVAL * 0.15;
    } else {
        UINT32 d = Int64ToInt32(Delta);

        assert(!TimeNeeds32Bits(Delta));

    /*
     * To get from TIME-Delta to Ticks:
     *
     *  Ticks   = Delta * 0.15
     *      = Delta * (1/8 + 0xCCD/0x20000)
     */
    Ticks = (d * 0xCCD) >> 17;
    Ticks = Ticks + (d >> 3);

    if (Ticks < 2)
            Ticks = 2;              /* sanity minimum */
    }

    assert(Ticks < 0xFF01 && Ticks > 1);
    
    /*
     * Got the tick count, program the timer now
     */
    TURN_INTERRUPTS_OFF(IntrState);

    /* Swap old and new values
     */
    Pit = PITRead();
    PITWrite(Ticks-1);

    /* Careful about the 16bit math
     */
    r = (SystemTimers.TicksDelta - Pit) & 0xFFFF;

    /* Say when we reloaded the PIT
     */
    SystemTimers.ReloadDelta += r;

    /* Say what we loaded it with.
     */
    SystemTimers.TicksDelta = Ticks;

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(IntrState);

    return StateWas;

}

/*
 * Return count of time since boot in 100 ns units.
 * Resolution is max_toy_resolution
 */
TIME GetKernelTime ()
{
    UINT32 Deltas;
    INT64 Deltas64;
    UINT IntrState;
    TIME r;
    UINT32 a, b, c;
    
    /* Cache a few values with interrupt protection
     */
    TURN_INTERRUPTS_OFF(IntrState);

    Deltas = SystemTimers.ReloadDelta;
    b = SystemTimers.TicksDelta;
    c = PITRead();
    r = SystemTimers.Toy;

    RESTORE_INTERRUPTS(IntrState);

    /* Careful with math here
     */
    a = (b - c) & 0xFFFF;
    Deltas += a;

    /* Must convert from Ticks to TIME.
     * Time = Ticks * 6 2/3
     * Time = (Ticks * 6) + (Ticks * 1/2) + (Ticks * 1/8) + (Ticks * 1/32) + (Ticks * 0x1555/0x80000)
     */
    Deltas = (Deltas * 6) + (Deltas >> 1) + (Deltas >> 3) + (Deltas >> 5) + ((Deltas * 0x1555) >> 19);

    /* Now put them all toghether
     */
    Int64FromHighAndLow(Deltas64,0,Deltas);

    r = Int64Add(Deltas64, r);

    return r;
}

/******************************************************************************/
/* Timer code*/
/******************************************************************************/

#define CT0CCR  ((volatile INT *)  0xFFFFAC18)      /* Timer 0 clock control */
#define CT1CCR  ((volatile INT *)  0xFFFFAC1C)      /* Timer 1 clock control */
#define CT2CCR  ((volatile INT *)  0xFFFFAC20)      /* Timer 2 clock control */
#define ICR1    ((volatile char *) 0xFFFFA804)      /* Int Cntlr config */
#define IOCR    ((volatile INT *)  0xFFFFA410)      /* I/O config */
#define CCCR    ((volatile char *) 0xFFFFAC28)      /* CPU Clock control */

/* Initialization
 */
void EnableTimers( void )
{
    /* Verify system clock is running full speed.
     */
    //assert(*CCCR == 0x01);
    SystemTimers.TicksDelta = 1;

    /* Add the timer irq handler to system
     */
    AddDevice((PTR) NULL, (void *) TimerIsr, 0, IRQ_ID_TIMER0, 0);
    *CT0CCR = 0x10;    /* divide XCLK by 16 to get 1.5MHz PIT frequency */

    /* Add the second lower frequency timer irq handler to system
     */
    AddDevice((PTR) NULL, (void *) ClockIsr, 0, IRQ_ID_TIMER1, 0);
    *CT1CCR = 0x80;   /* divide XCLK by 128 to get 187.5KHz Clock frequency */

    *ICR1 = 0x1;       /* set timer 0 interrupt active high, timer 1 active low */
    *IOCR = 0x7E00;    /* set timers 0, 1 & 2 gates high */

    /* Program timer1 as a rate generator, 3 interrupts per second, that
     * we can use as a clock.  This will compensate for skew from timer 0
     */
    TheHWTimer->Control = SC_1 | RW_LSB_MSB | BINARY | MODE2;

    /* Write the count D[15:0] to timer 1.  The timer automatically reloads
     * this count when it reaches 1, so we never have to reload it again.
     *
     * 187.5KHz / 3 = 0xF424
     */
    TheHWTimer->Timer1 = (BYTE)(0x24);
    TheHWTimer->Timer1 = (BYTE)(0xF4);

    /* Program timer2 but don't unmask the interrupt.  We are interested
     * only in the counter's value.
     */
    *CT2CCR = 0x100;    /* divide XCLK by n to get n/24MHz resolution */
    TheHWTimer->Control = SC_2 | RW_LSB_MSB | BINARY | MODE0;
    TheHWTimer->Timer2 = (BYTE) 0;
    TheHWTimer->Timer2 = (BYTE) 0;

    /* The beginning of time is now.
     */
    PITWrite(0);
}

/* Estimate the current processor speed
 */
UINT64 CurrentProcessorSpeed(void)
{
    UINT64 Speed;

    /* The AEB runs at 24 MHz.
     */
    Int64FromHighAndLow(Speed,0,24*1000*1000);
    return Speed;
}
