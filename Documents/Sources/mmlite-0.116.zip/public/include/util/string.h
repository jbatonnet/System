/* Header file for some string methods definitions
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef __STRING_EXTRAS_H__
#define __STRING_EXTRAS_H__

#include <util/util.h>

int _tcscmpprefix(const _TCHAR *pStr1, const _TCHAR *pStr2);
const _TCHAR* _tcsreturnfield(const _TCHAR *pStr1);
const _TCHAR* _tcsreturnsuffix(const _TCHAR *pStr1);
_TCHAR* _tcsreturnprefix(const _TCHAR *pStr1);

#endif /* __STRING_EXTRAS_H__ */
