/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <fred.h>

#define DOUBLE_TRAP 0 /* enable to debug cases of two-traps in a row */

/* Trap handlers, in assembly
 */
extern void Exception(void);
extern void Exception_end(void);
extern void UserModeTLBMiss(void);
extern void UserModeTLBMiss_end(void);

/* Other imports
 */
extern CXTINFO *ExternalInterrupt(CXTINFO *Context, UINT InterruptPendingMask);
extern BOOL BoardTrap(CXTINFO *Context, UINT Cause);

#include <mips/ml40x.h>

#if DOUBLE_TRAP
CXTINFO SavedContext;

static void Dump(ADDRESS a, int nWords)
{
    while (nWords-- > 0) {
        printf("@%x = %x\n", a, *(UINT32*)a);
        a += 4;
    }
}

static void DumpContext(PCXTINFO Context, char *Banner)
{
    printf("%s Context @%x is [\n"\
                   "%08x %08x %08x %08x\n%08x %08x %08x %08x\n"\
                   "%08x %08x %08x %08x\n%08x %08x %08x %08x\n"\
                   "%08x %08x %08x %08x\n%08x %08x %08x %08x\n"\
                   "%08x %08x %08x %08x\n%08x %08x %08x %08x\n"\
                   "%08x]\n", Banner, Context,
               Context->gpr[0], Context->gpr[1], Context->gpr[2], Context->gpr[3],
               Context->gpr[4], Context->gpr[5], Context->gpr[6], Context->gpr[7],
               Context->gpr[8], Context->gpr[9], Context->gpr[10], Context->gpr[11],
               Context->gpr[12], Context->gpr[13], Context->gpr[14], Context->gpr[15],
               Context->gpr[16], Context->gpr[17], Context->gpr[18], Context->gpr[19],
               Context->gpr[20], Context->gpr[21], Context->gpr[22], Context->gpr[23],
               Context->gpr[24], Context->gpr[25], Context->gpr[26], Context->gpr[27],
               Context->gpr[28], Context->gpr[29], Context->gpr[30], Context->gpr[31],
               Context->pc);
    Dump(Context->pc-4, 2);
    Dump(Context->gpr[31], 16);
}
#endif

void Trap(PCXTINFO Context, UINT Cause)
{
#if DOUBLE_TRAP
    if (Context->pc == 0) {
        printf("EPC is zero, Ctx=%x\n", Context);
        DumpContext(Context,"Bad");
    }

    if (Cause != 36)
        memcpy(&SavedContext,Context,sizeof SavedContext);
#endif

    /* Extern Interrupt?
     */
    if ((Cause & 0x3c) == 0)
    {
        Context = ExternalInterrupt(Context, (Cause>>10) & 0x3f);
    }
    else
    {
        /* Can we handle it ?
         */
        if (BoardTrap(Context,Cause))
        {
            /* Make sure its not a debugger notification
             */
            if ((Cause & 0x3c) == (4*9)) {
                UINT32 *pInstruction = (UINT32*) Context->pc;
                if ((*pInstruction == 0x0001000d) || /* DebuggerNotifyLoad */
                    (*pInstruction == 0x0002000d)) { /* DebuggerNotifyUnload */
                    Context->pc += 4;
                    goto Proceed;
                }
            }

            /* Nope */
            printf("TRAP %d (%x) Context=%x\n", Cause, Context->sr, (ADDRESS) Context);
#if DOUBLE_TRAP
            DumpContext(Context,"Current");
            DumpContext(&SavedContext,"Saved");
            Dump(Context->pc-4, 2);
            Dump(Context->gpr[31], 8);
#else
            printf("Context is [\n"\
                   "%08x %08x %08x %08x\n%08x %08x %08x %08x\n"\
                   "%08x %08x %08x %08x\n%08x %08x %08x %08x\n"\
                   "%08x %08x %08x %08x\n%08x %08x %08x %08x\n"\
                   "%08x %08x %08x %08x\n%08x %08x %08x %08x\n"\
                   "%08x %08x]\n",
               Context->gpr[0], Context->gpr[1], Context->gpr[2], Context->gpr[3],
               Context->gpr[4], Context->gpr[5], Context->gpr[6], Context->gpr[7],
               Context->gpr[8], Context->gpr[9], Context->gpr[10], Context->gpr[11],
               Context->gpr[12], Context->gpr[13], Context->gpr[14], Context->gpr[15],
               Context->gpr[16], Context->gpr[17], Context->gpr[18], Context->gpr[19],
               Context->gpr[20], Context->gpr[21], Context->gpr[22], Context->gpr[23],
               Context->gpr[24], Context->gpr[25], Context->gpr[26], Context->gpr[27],
               Context->gpr[28], Context->gpr[29], Context->gpr[30], Context->gpr[31],
               Context->ec, Context->pc);
#endif

            Context->pc = (UINT32) ThreadExit;
        }
    }
 Proceed:
    HWLoadThreadContext(Context);
}

void TrapInit(void)
{
    ADDRESS Esize;

    Esize = (ADDRESS)Exception_end - (ADDRESS)Exception;
    memcpy((char*)0x80000080,Exception,Esize);

    Esize = (ADDRESS)UserModeTLBMiss_end - (ADDRESS)UserModeTLBMiss;
    memcpy((char*)0x80000000,UserModeTLBMiss,Esize);
}
