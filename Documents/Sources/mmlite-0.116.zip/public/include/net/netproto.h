/* Copyright (c) Microsoft Corporation. All rights reserved. */
struct sockaddr_in;
struct tcpcb;
typedef struct INetProtocol *PINETPROTOCOL;

struct NetProtocolVtbl {
    __VTABLE_COMPATIBILITY_FILLER_DECLARATION

    SCODE (*QueryInterface)(PINETPROTOCOL This, REFIID Iid, void **ppObject);
    UINT (*AddRef)(PINETPROTOCOL This);
    UINT (*Release)(PINETPROTOCOL This);

/* protocol-protocol hooks */
    SCODE (*Input)(PINETPROTOCOL This, void *Buf, UINT Len, UINT iphlen);
    SCODE (*Output)(PINETPROTOCOL This, struct tcpcb *tp, void *Buf, UINT Len);
    SCODE (*CtlInput)(PINETPROTOCOL This, INT Cmd, struct sockaddr *sa, void *arg);
    SCODE (*Setopt)(PINETPROTOCOL This, struct socket *so, INT level, INT optname, void *Arg);
    SCODE (*Getopt)(PINETPROTOCOL This, struct socket *so, INT level, INT optname, void *Arg);
/* user-protocol hook (pr_usrreq) */
    SCODE (*Attach)(PINETPROTOCOL This, struct socket *so);
    SCODE (*Detach)(PINETPROTOCOL This, struct socket *so);
    SCODE (*Bind)(PINETPROTOCOL This, struct socket *so, struct sockaddr_in *Name);
    SCODE (*Listen)(PINETPROTOCOL This, struct socket *so);
    SCODE (*Connect)(PINETPROTOCOL This, struct socket *so, struct sockaddr_in *Name);
    SCODE (*Accept)(PINETPROTOCOL This, struct socket *so, struct sockaddr_in *Name);
    SCODE (*Disconnect)(PINETPROTOCOL This, struct socket *so);
    SCODE (*Shutdown)(PINETPROTOCOL This, struct socket *so);
    SCODE (*Rcvd)(PINETPROTOCOL This, struct socket *so);
    SCODE (*Send)(PINETPROTOCOL This, struct socket *so, void *Buf, UINT Len);
    SCODE (*Abort)(PINETPROTOCOL This, struct socket *so);
    SCODE (*Control)(PINETPROTOCOL This, struct socket *so, INT Cmd, PTR Data, PTR ifp);
    SCODE (*Sense)(PINETPROTOCOL This, struct socket *so);
    SCODE (*RcvOob)(PINETPROTOCOL This, struct socket *so, void *Buf, UINT Flags);
    SCODE (*SendOob)(PINETPROTOCOL This, struct socket *so, void *Buf, UINT Len);
    SCODE (*SockAddr)(PINETPROTOCOL This, struct socket *so, struct sockaddr_in *Name);
    SCODE (*PeerAddr)(PINETPROTOCOL This, struct socket *so, struct sockaddr_in *Name);
    SCODE (*PruSlowtimo)(PINETPROTOCOL This, struct socket *so, INT Timer);
/* utility hooks */
    SCODE (*Init)(PINETPROTOCOL This);
    SCODE (*Fasttimo)(PINETPROTOCOL This);
    SCODE (*Slowtimo)(PINETPROTOCOL This);
    SCODE (*Drain)(PINETPROTOCOL This);
    SCODE (*Sysctl)(PINETPROTOCOL This);
};

struct INetProtocol {
    CONST_VTBL struct NetProtocolVtbl *v;
};

extern const IID IID_INetProtocol;
