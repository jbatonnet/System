/* Copyright (c) Microsoft Corporation. All rights reserved. */
#ifndef __MMLITE_MD_H__
#define __MMLITE_MD_H__

/* The bitfields do not follow ISO C so undef this */
#undef __STDC__

typedef signed char INT8;       /* size is 1 */
typedef unsigned char UINT8;    /* size is 1 */
typedef short INT16;            /* size is 2 */
typedef unsigned short UINT16;  /* size is 2 */
typedef long INT32;             /* size is 4 */
typedef unsigned long UINT32;   /* size is 4 */
typedef struct _INT64 INT64;
typedef struct _UINT64 UINT64;

typedef INT32 INT;
typedef UINT32 UINT;
#define _UINTSIZE        ( 32 )

#define __BYTE_ORDER_IS_BIG_ENDIAN 1
#define __NO_BUILTIN_INT64 1       /* No compiler support */

#ifdef _OLDSCHED
#define _MUTEX_STATE_SIZE       ( 1 )
#define _CONDITION_STATE_SIZE   ( 2 )
#else
#define _MUTEX_STATE_SIZE       ( 5 )
#define _CONDITION_STATE_SIZE   ( 3 )
#endif

/* Order is ~defined by RTE inst
 */
struct  _CXTINFO {
    UINT32 sp; /* stack pointer */
    UINT32 er0; /* first arg, retval */
    UINT32 er1;
    UINT32 er2;
    UINT32 er3;
    UINT32 er4;
    UINT32 er5;
    UINT32 er6;
    UINT32 ccr:8;/* condition codes (high byte) */
    UINT32 pc:24;
};

// #define __DebugBreak() __asm volatile ("bpt")

#define __DebugBreak() { \
	Sci_WriteStr("DebugBreak "); \
	Sci_WriteStr(" failed at "); \
	Sci_WriteStr(__FILE__); \
	Sci_WriteHexShort(__LINE__); \
	Sci_WriteStr("\r\n"); \
	for(;;); }

#define _DCACHELINESIZE (2)
#define _PAGE_SIZE (4096)
#define _PAGE_SHIFT (12)

#if 0
#define Dbg_WriteStr(s)      
#define Dbg_WriteHexByte(b)  
#define Dbg_WriteHexShort(s) 
#define Dbg_WriteHexLong(l)  
#else
#define Dbg_WriteStr(s)      Sci_WriteStr(s)
#define Dbg_WriteHexByte(b)  Sci_WriteHexByte(b)
#define Dbg_WriteHexShort(s) Sci_WriteHexShort(s)
#define Dbg_WriteHexLong(l)  Sci_WriteHexLong(l)

//#undef DBGME
//#define DBGME(x,y) y
#endif

#endif /* MMLITE_MD_H */
