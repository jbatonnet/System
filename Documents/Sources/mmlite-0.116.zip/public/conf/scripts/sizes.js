// Copyright (c) Microsoft Corporation. All rights reserved.
//

// This file parses arm .map files and generates a classified summary

//----------- Globals --------------------------------------------//
var tools = "arm";
var verbose = 0;
var debug = false;
var justsummary = false;
var ofs = null;
var scriptpath = null;
var xmldata = "";
var inputfile;
var suffix;
var recursive = false;
var excludeglob = "";
var excludedirs;
var rootpath = "";
var domdocument_name = "Msxml2.DOMDocument.5.0";
var schema_cache;

try {
    schema_cache = new ActiveXObject("Msxml2.XMLSchemaCache.5.0");
} catch (exception) {
try {
    schema_cache = new ActiveXObject("Msxml2.XMLSchemaCache.4.0");
    domdocument_name = "Msxml2.DOMDocument.4.0";
} catch (exception) {
    alert("*** Runtime Error: " + exception.description + "\n*** Looks like msxml4 is missing.\n*** Try downloading from http://msdn.microsoft.com/XML/XMLDownloads/default.aspx");
    exit;
}}

var apos = 0;

//----------- Main --------------------------------------------//
function usage() {
  alert("USAGE: sizes [-v]* (verbose) [-V] (debug) -t tools [-s] (summary) -c classification-file inputfile\n");
}

// main()
if (WScript != null) {
  var xmlcollectionfile = "";
  var classificationfile = null;

  ofs = WScript.CreateObject("Scripting.FileSystemObject");
  var scriptpath = ofs.getParentFolderName(WScript.scriptFullName);

  var args = WScript.arguments;
  var consumedargs = 0;
  for (var i = 0; i < args.length; i++) {
    if (args.item(i).substring(0,1) == "-") {
      consumedargs++;
      var opt = args.item(i).substr(1);
      switch(opt) {
      case "t":                 // output file
        if (args.length - i < 2)
          usage();
        tools = args.item(++i);
        consumedargs++;
        break;
      case "c":                 // classification file
        if (args.length - i < 2)
          usage();
        classificationfile = args.item(++i).replace(/\\/g, "/");
        consumedargs++;
        break;
      case "v":                 // Verbose
        verbose++;
        break;
      case "s":
        justsummary = true;
        break;
      case "V":                 // debug VVERRY Verbose
        debug = true;
        break;
      default:
        alert("unknown option '" + opt + "'");
      }
    }
  }

  if (args.length - consumedargs < 1)
    usage();

  if (classificationfile != null)
      initclassification(classificationfile);
  else
      echo ("No classification file.");

  // allocate one array for collecting results so as to help the GC.
  var newline = new Array();

  var tocdic = new ActiveXObject("Scripting.Dictionary");
  var tocprefix = "toc-4";

  while (args.length - consumedargs > 0) {
    var filespec = args.item(consumedargs);
    consumedargs++;

    var files = glob(filespec);
    for (var i = 0; i < files.length; i++) {
      inputfile = files[i];
      sizeitup(newline);
    }
  }
}

//----------- Utility functions -------------------------------------//
function expandsubdirs(path) {
  var arr = new Array();

  path = path.replace(/\\/gm, "/");

  var f = ofs.GetFolder(path);
  if (f == null)
    alert("can't open dir " + path);

  if (path == ".")
    path = "";
  else if (path != "")
    path += "/";

  var fc = new Enumerator(f.SubFolders);
 outer:
  for (fc.moveFirst() ; !fc.atEnd(); fc.moveNext()) {
    var item = "" + fc.item();
    if (debug)
      echo ("dir=" + item + " = " + path + basename(item));
    item = path + basename(item);

    for (var x = 0; x < excludedirs.length; x++) {
      if (item.match(excludedirs[x]) != null) {
        if (verbose > 0)
          echo ("canal expandsubdir skipped '" + item + "' due to exclusion ");
        continue outer;
      }
    }
    arr = arr.concat(item, expandsubdirs(item));
  }

  if (debug) 
    echo("expand " + path + " -> (" + arr.length + ") " + arr.join(" "));

  return arr.sort();
}

function glob(path) {
  //echo ("glob: " + path+" How come this is not provided by the runtime?\n");
  var arr = new Array();
  var name = basename(path);
  var ix = 0;

  path = pathname(path);
  path = path.replace(/\\/gm, "/");

  name = name.replace(/\./gm, "[.]");
  name = name.replace(/\*/gm, ".*");
  name = name.replace(/\?/gm, ".");
  name = "([/\\\\]|^)" + name + "$";

  if (debug)
    echo ("Globbing for " + name + " in " + path);

  var f = ofs.GetFolder(path == "" ? "." : path);
  if (f == null)
    alert("can't open dir");

  if (path != "")
    path += "/";

  var fc = new Enumerator(f.Files);
 outer:
  for (fc.moveFirst() ; !fc.atEnd(); fc.moveNext()) {
    var item = "" + fc.item();
    if (item.match(new RegExp(name, "")) != null) {
      for (var x = 0; x < excludeglob.length; x++) {
        if (item.match(excludeglob[x]) != null) {
          if (verbose > 0)
            echo ("canal glob skipped '" + item + "' due to exclusion ");
          continue outer;
        }
      }
      if (debug)
        echo ("item=" + item + " = " + path + basename(item));
      item = path + basename(item);

      arr[ix++] = item;
    }
  }
  fc = item = null;

  return arr.sort();
}

function runtimeError(exception)  {
  alert("XSL Runtime Error " + exception.description
        + " line " + exception.line);
}

function loadError(oSRC, str) {
  var oErr = oSRC.parseError;

  var s = "";
  for (var i=1; i < oErr.linepos; i++) {
    s += " ";
  }
  alert("XML parse error " + oErr.url + "(" + oErr.line + "): pos " + oErr.linepos + "\n" + oErr.reason + "\n"
        + oErr.srcText + "\n" + s + "^");
}

function setprops(tree) {
  var namespaces=null;

  tree.setProperty("SelectionLanguage", "XPath");
  if (namespaces != null)
    tree.setProperty("SelectionNamespaces", namespaces);
}

function load_xml(file, validate, resolve, quiet) {
  if (!ofs.FileExists(file)) {
    if (!quiet)
      echo ("File " + file + " does not exist");
    return null;
  }
  if (verbose > 1)
    echo("Loading " + file);

  var oXML = new ActiveXObject(domdocument_name);
  oXML.validateOnParse = validate;
  oXML.resolveExternals = resolve;
  oXML.async = false;
  oXML.schemas = schema_cache;
  if (!oXML.load(file))
    loadError(oXML, "Load of " + file + " failed");

  setprops(oXML);
  return oXML;
}

function apply_script(oSRC, result_name, script, dowrite) {
  var sXML2 = null;
  var oXSL = new ActiveXObject(domdocument_name);
  oXSL.validateOnParse = true;
  oXSL.async = false;
  oXSL.schemas = schema_cache;

  if (!oXSL.load(script)) {
    loadError(oXSL, "Load of " + script + " failed");
    return null;
  }

  if (verbose > 1)
    echo("Transforming with " + script);

  try {
    sXML2 = oSRC.transformNode(oXSL);
  } catch (exception) {
    alert("XSL Runtime Error: " + exception.description);
    return null;
  }

  if (verbose > 1 && debug)
    echo("Done with " + script);

  /* Fix output for C compiler */
  var re = /&gt;/g;
  sXML2 = sXML2.replace(re, ">");

  if (dowrite) {
    // Make sure the name isn't empty
    if (result_name.match(/[\/\\]$/) != null)
      result_name += "tmp";
    if (verbose > 1)
      echo("Creating " + result_name);
    var oFile = ofs.CreateTextFile(result_name);
    oFile.Write(sXML2);
    oFile.Close();
  }

  return sXML2;
}

function basename(path) {
  var result = path.match(/[^\/\\]*$/);
  //echo("basename(" + path + ") -> " + result);
  return "" + result;
}

function pathname(path) {
  if (path.match(/[\/\\][^\/\\]*$/) == null)
    return "";

  return "" + path.replace(/[\/\\][^\/\\]*$/, "");
}

function nonsuffix(path) {
  var result = path.replace(/[.][^.]*$/, "");
  echo("nonsuffix(" + path + ") -> " + result);
  return "" + result;
}

function getsuffix(path) {
  var result = basename(path).match(/[.][^.]*$/);
  var suf;

  if (result == null)
      suf = "";
  else
      suf = ("" + result).substr(1);
  if (debug)
    echo("getsuffix(" + path + ") -> " + result + " -> '" + suf + "'");

  result = path = null;
  return suf;
}

function makedir(path) {
  if (path == "")
    return;

  var bn = new RegExp("[/\\\\][^/\\\\]*$", "");
  if (path.match(bn) != null) {
    makedir(path.replace(bn, ""));
  }
  bn = null;

  if (!ofs.FolderExists(path)) {
    if (verbose > 0)
      echo("mkdir " + path);
    ofs.CreateFolder(path);
  }
}

function alert(str) {
  if (WScript != null) {
    WScript.Echo(str);
    WScript.Quit(1);
  } else {
    echo("ALERT: " + s);
  }
}

function echo(s) {
  if (WScript != null) {
    WScript.Echo(s);
  } else {
    oLog.WriteLine(s);
  }
}

// --- Index file generation
function make_file_index(srcdir, htmldir, rootpath,
                         dirlist, dirtoc,
                         filelist, filetoc)
{
    //echo("MAKE_FILE_INDEX: DIR=" + srcdir + " HTMLDIR=" + htmldir + " DIRLIST=" + dirlist + " DIRTOC=" + dirtoc + " FILELIST=" + filelist + " FILETOC=" + filetoc);

    var tree = load_xml(srcdir + "/files.xml", true, true, true);
    if (tree)
      echo("Loaded " + srcdir + "/files.xml");
    else
      tree = load_xml("conf/nofiles.xml", true, true, false);
    //echo("ROOTPATH=" + rootpath);
    var rootnode = tree.selectSingleNode("/source-files");
    rootnode.setAttribute("rootpath", rootpath);
    var i;
    for (i = 0; i < dirlist.length; i++) {
      var node = tree.selectSingleNode("//dir[@name = '"+dirlist[i]+"']");
      if (node) {
        //echo("FOUND " + dirlist[i]);
      } else {
        //echo("NOPE " + dirlist[i]);
        node = tree.createElement("dir");
        node.setAttribute("name", dirlist[i]);
        rootnode.appendChild(node);
      }
      node.setAttribute("tocPath", dirtoc[i]);
    }

    for (i = 0; i < filelist.length; i++) {
      var node = tree.selectSingleNode("//file[@name = '"+filelist[i]+"']");
      if (node) {
        //echo("FOUND " + filelist[i]);
      } else {
        //echo("NOPE " + filelist[i]);
        node = tree.createElement("file");
        node.setAttribute("name", filelist[i]);
        rootnode.appendChild(node);
      }
      node.setAttribute("tocPath", filetoc[i]);
    }

    //echo("srcdir.XML=" + tree.xml);

    apply_script(tree, htmldir + "/files.htm",
                 "conf/scripts/genfileindex.xsl", true);
}


//------------ Real work ----------------------------------------//

function read(filename)
{
  if (!ofs.FileExists(filename))
    alert("File does not exist: " + filename);

  var content = "";
  var f = ofs.GetFile(filename);
  if (f == null)
    alert("could not open " + filename);
  if (f.Size != 0) {
    if (verbose > 0)
      echo("File " + filename + " is " + f.Type + " Size=" + f.Size);
    var ff = f.OpenAsTextStream(1, 0);
    content = ff.ReadAll();
    ff.Close();
    ff = null;
  }
  f = null;
  return content;
}

var classification = null;
var summaryk = null;
var summaryt = null;

function initclassification(file) {
    classification = new ActiveXObject("Scripting.Dictionary");
    summaryk = new ActiveXObject("Scripting.Dictionary");
    summaryt = new Array();

    content = read(file);

    classes = content.split("@");

    summaryk.Add("unknown", summaryt.push(new Array("unknown", 0,0,0))-1);

    for (i = 1; i < classes.length; i++) {
        files = classes[i].split(/\s/);
        for (j = 1; j < files.length; j++) {
            if (files[j].length > 0) {
                //echo ("###" + files[0] + " -> " + files[j]);
                try {
                    classification.Add(files[j], files[0]);
                } catch(exception) {
                    echo("Duplicate file name "+ files[0] + " -> " + files[j]
                         + " exception=" + exception.description);
                }
            }
        }
        summaryk.Add(files[0], summaryt.push(new Array(files[0], 0,0,0))-1);
        // name, rw, ro, count
    }
}

function nodecmp(n1, n2)
{
    /* category */
    if (n1[3] < n2[3])
        return -1;
    else if (n1[3] > n2[3])
        return 1;

    /* type */
    if (n1[2] < n2[2])
        return -1;
    else if (n1[2] > n2[2])
        return 1;

    /* size */
    return n2[1] - n1[1];
}

function rvacmp(l1, l2)
{
    line1 = l1.split(/ +|$/);
    line2 = l2.split(/ +|$/);

    /* RVA */
    if (line1[2] < line2[2])
        return -1;
    else if (line1[2] > line2[2])
        return 1;

    /* section */
    if (line1[0] < line2[0])
        return -1;
    else
        return 1;
}

// Make string fixed width
function rightfix(s, n)
{
    var i = n - s.length;
    for (i = i; i > 0; i--)
        s = " " + s;
    return s;
}

function leftfix(s, n)
{
    var i = n - s.length;
    for (i = i; i > 0; i--)
        s = s + " ";
    return s;
}

// Make number fixed width
function num8(num)
{
  return rightfix(""+num, 8);
}

function sizeitup(newline) {
  //var outputfile = null;

  //outputfile = ofs.CreateTextFile(inputfile + ".size");
  //if (outputfile == null)
  //  alert("Can't open " + inputfile + ".size");

  var content = read(inputfile);
  var stuff = new Array();

  if (tools == "arm_arm") {
    // ARM250 output file
    var lines = content.split(/[\n\r]/);
    for (i = 3; i < lines.length - 6; i++) {
        //echo("LINE " + lines[i]);
        line = lines[i].split(/ +|$/);
        var file = line[8];
        var size = new Number("0x" + line[1]);
        var type;
        if (line[2] == "CODE")
          type = ".text";
        else if (line[2] == "ZERO")
          type = ".bss";
        else if (line[3] == "RO")
          type = ".rodata";
        else
          type = ".data";                  
        var category = "unknown";
        if (classification.Exists(file))
            category = classification.Item(file);
        var node = new Array(file, size, type, category, "");

        stuff.push(node); 

        //echo(size.toString(10) + "\t" + type + " " + file + " " +  category);
        var k = summaryk.Item(category);
        if (type == ".data" || type == ".bss")
            summaryt[k][2] += size;
        else
            summaryt[k][1] += size;
        summaryt[k][3]++;
    }
  } else if (tools == "arm_ads") {
    var lines = content.split(/[\n\r]/);
    for (i = 0; i < lines.length; i++) {
      line = lines[i].split(/ +|$/);
      var base = /^0x/;
      if (!line[0].match(base)) continue;
      if (line.length < 6) continue;
      //echo(line[0] + "\t" + line[6]);
      var file = line[6];
      if (line[5] == "*") file = line[7];
      if (file == null) continue;
      var start = file.search(/\(/);
      if (start > 0) file = file.substr(0, start);
      var size = new Number(line[1]);
      var type;
      if (line[2] == "Code")
        type = ".text";
      else if (line[2] == "Zero")
        type = ".bss";
      else if (line[3] == "RO")
        type = ".rodata";
      else
        type = ".data";                  
      var category = "unknown";
      if (classification.Exists(file))
        category = classification.Item(file);
      var node = new Array(file, size, type, category, "");

      stuff.push(node); 

      //echo(size.toString(10) + "\t" + type + " " + file + " " +  category);
      var k = summaryk.Item(category);
      if (type == ".data" || type == ".bss")
        summaryt[k][2] += size;
      else
        summaryt[k][1] += size;
      summaryt[k][3]++;
    }  
  } else if (tools == "arm_gnu" || tools == "mips" || tools == "mips_gnu") {
    // get rid of stuff before *(.text) and after *(.stab)
    var start = content.search(/[*][(][.]text[)]/);
    content = content.substr(start, content.search(/[ ][*][(][.]stab[)]/)-start);
    var lines = content.split(/[\n\r]/);
    for (i = 0; i < lines.length; i++) {
        // skip lines w/o .obj
        if (lines[i].search(/[.]obj[)]$/) == -1)
            continue;
        //echo("LINE " + lines[i]);
        line = lines[i].split(/\s+|$/);
        if (line.length < 4)
            continue;
        var file = line[3];
        // pick out the name between parentheses
        file = file.replace(/^[^(]+[(]([^)]+)[)].*$/, "$1");
        file = basename(file);
        var size = new Number(line[2]);
        var type = line[0];
        var category = "unknown";
        if (classification.Exists(file))
            category = classification.Item(file);
        var node = new Array(file, size, type, category, "");

        stuff.push(node); 

        //echo(size.toString(10) + "\t" + type + " " + file + " " +  category);
        var k = summaryk.Item(category);
        if (type == ".data" || type == ".bss")
            summaryt[k][2] += size;
        else
            summaryt[k][1] += size;
        summaryt[k][3]++;
    }
  } else {
    // Visual Studio .map file

    // get rid of stuff at beginning
    var start = content.search(/Lib:Object/);
    content = content.substr(start+10, 100000000);
    // Get rid of other non-address lines
    content = content.replace(/^ [^0].*$/, "");

    var lines = content.split(/[\n\r]/);

    // Sort the lines according to RVA.
    lines = lines.sort(rvacmp);
    
    for (i = 0; i < lines.length; i++) {
        // skip lines w/o .obj
        if (lines[i].search(/[.]obj$/) == -1)
            continue;

        //echo("LINE " + lines[i]);
        line = lines[i].split(/ +|$/);
        // 4th, 5th or 6th field is file name
        var file = line[3];
        if (line[4])
            file = line[4];
        if (line[5])
            file = line[5];
        file = file.replace(/^[^:]+:(.*$)/, "$1");
        var addr = line[0].replace(/^([^:])+:(.*$)/, "$2");
        var sect = line[0].replace(/^([^:])+:(.*$)/, "$1");
        //echo("FILE=" + file + " ADDR=" + addr + " SECT=" + sect);

        var size;
        if (lines[i+1]) {
            nextline = lines[i+1].split(/ +|$/);
            var nextaddr = nextline[0].replace(/^([^:])+:(.*$)/, "$2");
            var nextsect = nextline[0].replace(/^([^:])+:(.*$)/, "$1");
            //echo("NEXT ADDR=" + nextaddr + " SECT=" + nextsect);

            addr = new Number("0x" + addr);
            nextaddr = new Number("0x" + nextaddr);
            size = nextaddr - addr;
            if (nextsect != sect) {
                // XXX last one should be compared against sect size
                size = 0;
            }
        } else {
            // XXX last one should be compared against sect size
            size = 0;
        }
        //echo("SIZE=" + size);

        func = line[1];

        var type;
        if (sect == 1)
          type = ".text";
        else if (sect == 2)
          type = ".bss";
        else if (sect == 3)
          type = ".rodata";
        else if (sect == 4)
          type = ".data";
        else
          type = ".junk";
        var category = "unknown";
        if (classification.Exists(file))
            category = classification.Item(file);
        var node = new Array(file, size, type, category, func);

        stuff.push(node);

        //echo(size.toString(10) + "\t" + type + " " + file + " " +  category);
        var k = summaryk.Item(category);
        if (type == ".data" || type == ".bss")
            summaryt[k][2] += size;
        else
            summaryt[k][1] += size;
        summaryt[k][3]++;
    }
  }


  stuff = stuff.sort(nodecmp);

  for (i = 0; i < stuff.length; i++) {
    var file = stuff[i][0];
    var size = stuff[i][1];
    var type = stuff[i][2];
    var category = stuff[i][3];
    var func = stuff[i][4];

    if (!justsummary)
      echo(size.toString(10) + "\t" + type + " " + file + " " +  category
           + "\t" + func);
  }

  echo("");
  echo("File            ROM      RAM    nFiles");
  var total = new Array("TOTAL", 0,0,0);
  for (i = 0; i < summaryt.length; i++) {
      var a = summaryt[i];
      if (a[3] == 0)
          continue;
      echo(leftfix(a[0], 10) + " " + num8(a[1]) + " " + num8(a[2]) + "  " + num8(a[3]));
      total[1] += a[1]; total[2] += a[2]; total[3] += a[3];
  }

  a = total;
  echo(leftfix(a[0],10) + " " + num8(a[1]) + " " + num8(a[2]) + "  " + num8(a[3]));
  //outputfile.Close();
}
