/* Copyright (c) Microsoft Corporation. All rights reserved. */
//#include "linkage.h"
#include <mmlite.h>
#include <fred.h>

#ifdef H8S_2168F
#include "2168f.h"
#endif

#if defined(H8_3048F) || defined(H8_3052F)
#include "3048f.h"
#endif

#include <ctype.h>

TIME g_KernelTime;

/* Return count of time since boot in 100 ns units. */
TIME GetKernelTime (void)
{
    return g_KernelTime;
}

BOOL SetNextInterrupt (TIME Delta, BOOL *pStateVariable)
{
    UINT8 ccr;
    BOOL StateWas;

    TURN_INTERRUPTS_OFF(ccr);

//// H8SetNextInterrupt( (int) Delta);

    /* Now if needed, and before we turn interrupts back on,
     * clear that bool variable and return its previous value.
     */
    StateWas = FALSE;
    if (pStateVariable) {
        StateWas = *pStateVariable;
        *pStateVariable = FALSE;
    }

    RESTORE_INTERRUPTS(ccr);
    return StateWas;
}

/* Initialization.
 */
#define TIMER_INTERVAL_MSEC 2

void EnableTimers( void )
{
#ifdef H8S_2168F
    // H8S/2168F 16bit FRT (Free Running Timer)

    // Init FRT
    MSTP.CRH.BIT._FRT = 0;  // Enable FRT
    FRT.TOCR.BIT.OCRS = 0;  // Use OCRA
    FRT.TCR.BIT.CKS = 1;    // Internal clk/8

    // 33MHz
    // FRT.OCRA = TIMER_INTERVAL_MSEC * 4125;      // 4125 = 33000 / 8

    // 29.48MHz
    FRT.OCRA = TIMER_INTERVAL_MSEC * 3685;      // 3625 = 29480 / 8

    INTC.ICRB.BIT._FRT = 1; // higher priority
    FRT.TIER.BIT.OCIAE = 1; // Enable Output Compare Interrupt
    FRT.TCSR.BIT.OCFA = 0;  // Clear Output Compare Flag
    FRT.TCSR.BIT.CCLRA = 1; // Clear FRC When Compare Match A
    FRT.FRC = 0;
#endif

#if defined(H8_3048F) || defined(H8_3052F)
    // Initialize 3052f Timer
    ITU.TMDR.BYTE = 0;

    ITU1.TCR.BYTE = 0xA3;       /* Internal clk(25MHz)/8 = 3.125MHz */
    ITU1.TSR.BIT.IMFA = 0;
    ITU1.TIER.BYTE = 0xF9;      /* IMFA int (IMIA) */
#ifdef H8_3048F
    ITU1.GRA = TIMER_INTERVAL_MSEC * 2000; /* 2ms (1clk 0.0005ms) */
#endif
#ifdef H8_3052F
    ITU1.GRA = TIMER_INTERVAL_MSEC * 3125; /* 2ms (1clk 0.00032ms) */
#endif

    ITU.TSTR.BIT.STR1 = 1;      /* Start ITU ch1 */
#endif
}

/*
*/
void H8TimerIntProc(CXTINFO *pCxtInfo)
{
#ifdef H8S_2168F
    // 2168F 16bit FRT (Free Running Timer)
    FRT.TCSR.BIT.OCFA = 0; // Clear Output Compare Flag [A]
#endif

#if defined(H8_3048F) || defined(H8_3052F)
    // 3052f
    ITU1.TSR.BIT.IMFA=0;
#endif

    g_KernelTime = Int64AddInt32(g_KernelTime, TIMER_INTERVAL_MSEC * 10000);
}

/* BUGBUG refine */
/* Should be called only from interrupt handlers (ie kernel mode, interrupts
 * disabled).  This is not enforced, but if called from any other mode the
 * duration of the call can vary greatly.  The only real guarantee is that
 * we will spend AT LEAST uSec microseconds inside this routine.
 */
UINT DelayMultiplier = 10; /* machdep should refine at boot time */

void Delay(UINT uSec)
{
    volatile UINT LoopCount = uSec * DelayMultiplier;

    while (LoopCount-- > 0)
        ;
}


/* Estimate the current processor speed
 */
UINT64 CurrentProcessorSpeed(void)
{
    UINT64 Speed;
    Int64FromHighAndLow(Speed,0,16*1000*1000);
    return Speed;
}

