/* Copyright (c) Microsoft Corporation. All rights reserved. */

// this file (_debug.c) is included by debug.c

#include <mmlite.h>

#define __HAS_MACHINE_PUTCHAR 1
/* in moncall.c */

#if 1
void DCPutChar(UINT8 c)
{
    Sci_WriteChar(c);
}
void DebuggerNotifyLoad(const _TCHAR *ModuleName, ADDRESS LoadStart,
                        UINT Token)
{
}

void DebuggerNotifyUnload(const _TCHAR *ModuleName, ADDRESS LoadStart,
                          UINT Token)
{
}
#endif

PRIVATE unsigned char dgetc( BOOL DoEcho )
{
    UINT8 c;

    /* TODO: Get character from console */
    /* Moncall(MONCALL_CONSOLE_IN,(UINT)&c,1); */
    if (DoEcho)
        DCPutChar(c);
    return c;
}

