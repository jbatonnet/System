/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <base/cons.h>
#include <stdio.h>

SCODE FirstApp(const _TCHAR *Args)
{
    //return RunSoapServer("x-udp-aes-soap://sr1", TRUE);
    printf("eb63soap.c: CODE DELETED\n");
    return E_NOT_IMPLEMENTED;
}

/* Copyright (c) Microsoft Corporation. All rights reserved. */
#include <mmlite.h>
#include <tchar.h>
#include <loaders/cobtab.h>

extern PIUNKNOWN Db161CobMain(void);

extern PIUNKNOWN HostfsCobMain(void);
extern PIUNKNOWN SerplexCobMain(void);

const struct PRECOB ThePreCobTable[] = {
    {_T("eb63usart.cob"), SerialCobMain },
    {_T("sernet.cob"), SerNetCobMain }, \
    {_T("serplex.cob"), SerplexCobMain }, \
    {_T("db161.cob"), Db161CobMain },
    BASIC_NET_COBS
    BASIC_SOAP_UDP_COBS
    PRIVATE_SOAP_COBS
    {0,0}
};

/* Select root "fs" file system */
PINAMESPACE BoardInitRomFs(void);

PINAMESPACE BoardInitFileSystem(void)
{
    /* Use RomFs with eb63big: it's a flashed standalone image */
    return BoardInitRomFs();
}
