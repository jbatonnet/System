/* Copyright (c) Microsoft Corporation. All rights reserved. */

#include <mmlite.h>
#include <loaders/cobtab.h>
#include "sci.h"
#include <machdep.h>

#include <web/typeinfo.h>

/*
#include <net/dhcp/dhcp.h>
#include <net/ip/arp.h>
#include <net/ip/ip.h>
#include <net/ip/ip_icmp.h>
#include <net/tcp/tcp.h>
*/

MUTEX g_Mutex;

const struct PRECOB ThePreCobTable[] = {
    {0,0}
};

void Sleep(INT32 ms)
{
    TIME t;
    t.HighPart = (UINT32)-1;
    t.LowPart = (UINT32)(ms * 10000 * -1);
    SleepUntil(t);
}

void SecondThread(THREAD_ARGUMENT arg)
{
    int i = 0;

    for(;;) {
        Mutex_Lock(&g_Mutex);
        Sci_WriteStr("SecondThread ");
        Sci_WriteHexLong(++i);
        Sci_WriteStr("\r\n");
        Mutex_Unlock(&g_Mutex);
        Sleep(2000);
    }
}

void ThirdThread(THREAD_ARGUMENT arg)
{
    int i = 0;

    for(;;) {
        Mutex_Lock(&g_Mutex);
        Sci_WriteStr("ThirdThread ");
        Sci_WriteHexLong(++i);
        Sci_WriteStr("\r\n");
        Mutex_Unlock(&g_Mutex);
        Sleep(3000);
    }
}

void FirstThread(UINT32 arg)
{
    PIPROCESS pPrc;
    SCODE sc;
    IThread* pSecondThread = NULL;
    IThread* pThirdThread = NULL;
    int i = 0;

/*
	Sci_WriteStr("ether_header = ");
	Sci_WriteHexLong(sizeof(ether_header));
	Sci_WriteStr("\r\n");
	
	Sci_WriteStr("ip = ");
	Sci_WriteHexLong(sizeof(ip));
	Sci_WriteStr("\r\n");

	Sci_WriteStr("icmp = ");
	Sci_WriteHexLong(sizeof(icmp));
	Sci_WriteStr("\r\n");
	
	Sci_WriteStr("Dhcp = ");
	Sci_WriteHexLong(sizeof(Dhcp));
	Sci_WriteStr("\r\n");

	Sci_WriteStr("tcphdr = ");
	Sci_WriteHexLong(sizeof(tcphdr));
	Sci_WriteStr("\r\n");
*/

	Mutex_Init(&g_Mutex);
    
    Sci_WriteStr("\r\nStarting FirstThread!!!\r\n");

    pPrc = CurrentProcess();

    Mutex_Lock(&g_Mutex);
    Sci_WriteStr("FirstThread is trying to Create SecondThread\r\n");
    Mutex_Unlock(&g_Mutex);
    sc = pPrc->v->CreateThread(pPrc, 0, SecondThread, (THREAD_ARGUMENT)0,
                                         DEFAULT_STACK_SIZE, NULL, &pSecondThread);
    if (FAILED(sc)) {
        Sci_WriteStr("Creating SecondThread FAILED\r\n");
    }

    Mutex_Lock(&g_Mutex);
    Sci_WriteStr("FirstThread is trying to Create ThirdThread\r\n");
    Mutex_Unlock(&g_Mutex);
    sc = pPrc->v->CreateThread(pPrc, 0, ThirdThread, (THREAD_ARGUMENT)0,
                               DEFAULT_STACK_SIZE, NULL, &pThirdThread);
    if (FAILED(sc)) {
        Sci_WriteStr("Creating ThirdThread FAILED\r\n");
    }

    for(;;) {
        Mutex_Lock(&g_Mutex);
        Sci_WriteStr("FirstThread ");
        Sci_WriteHexLong(++i);
        Sci_WriteStr("\r\n");
        Mutex_Unlock(&g_Mutex);
        Sleep(1000);
    }

    BaseDelete();
}

