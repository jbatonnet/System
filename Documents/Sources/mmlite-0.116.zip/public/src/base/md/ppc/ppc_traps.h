/* Copyright (c) Microsoft Corporation. All rights reserved. */

/* Definitions that are common between C code and assembler
 * NB: Assembly code files are pre-processed by the C compiler
 */

/*
 * Define the trap cause argument to the general trap handler
 */
#define TRAP_PI     0
#define TRAP_EE     1
#define TRAP_FPU    2
#define TRAP_VPU    3
#define TRAP_DS     4
#define TRAP_IS     5
#define TRAP_AI     6
#define TRAP_SC     7
#define TRAP_T      8
#define TRAP_M      9
#define TRAP_VMX    10
#define TRAP_TH     11
#define TRAP_DSS    12
#define TRAP_ISS    13
#define TRAP_PM     14
#define TRAP_IA     15
#define TRAP_SM     16
#define TRAP_SP     17
#define TRAP_SV     18

#define TRAP_COUNT  19

/* Max possible number of proc we support
 */
#define MaximumNumberOfProcessors 2

#if defined(__ASSEMBLER__)

/* Assembly-only definitions
 */

/*
 * Define the offsets in the PCR
 */
PCR_Gpr2Save                    _EQU     0
PCR_Gpr5Save                    _EQU     8
PCR_Gpr6Save                    _EQU     16
PCR_DarSave                     _EQU     24
PCR_DsisrSave                   _EQU     32
PCR_SegvCause                   _EQU     36

#else

/* C-only definitions
 */

/* For perf resons, this should be allocated on a cache line boundary,
 * each element exactly one cache line worth in size.
 * And to make things worse, assembly code needs to know. Sigh.
 */
typedef struct {
    UINT64  Gpr2Save;
    UINT64  Gpr5Save;
    UINT64  Gpr6Save;
    UINT64  DarSave;
    UINT32  DsisrSave;
    UINT32  SegvCause;
    UINT8   Pad[_DCACHELINESIZE - ((4*8)+(2*4)) ];
} PCR, *PPCR;

extern PCR ProcessorControlRegion[MaximumNumberOfProcessors];

/* Processor indexing
 */
extern unsigned __sregister_get( unsigned const regnum );

INLINE UINT32 CurrentProcessorNumber(void)
{
    /* BUGBUG Is the shifting only valid for the 970 ? */
    return __sregister_get(1023) >> 1;
}

INLINE PPCR CurrentProcessor(void)
{
    return &ProcessorControlRegion[CurrentProcessorNumber()];
}

/* Mapping physical to virtual and back
 */
extern PTR PhysicalToVirtual(ADDRESS PhysicalAddress);
extern ADDRESS VirtualToPhysical( PTR VirtualAddress);

#endif
